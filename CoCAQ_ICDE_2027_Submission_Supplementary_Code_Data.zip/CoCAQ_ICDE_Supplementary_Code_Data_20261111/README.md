# CoCAQ — ICDE 2027 supplementary code and data

**Paper:** CoCAQ: Budgeted Data Acquisition for Multi-Stage Surrogate Prediction

This archive contains the recovered MATLAB experiment sources and seed-level result records used to prepare the reported **Alpine (10 cascade scales)** and **OPSD (4 stages, 13 exogenous inputs)** evaluation. The final manuscript compares P1, P2, CMA-ES, IPPO, MAPPO, GP-MAPPO and CoCAQ.

**Scope and verification notice:** The files were assembled from the archived experiment packages and the paper's frozen evidence directory. The CSV-level result verification script is executable with Python and has been run. MATLAB and the complete long-running experiments were **not executed in the packaging environment**. Consequently this release is a *source-and-evidence package*, not a claim of independently rerunning all published experiments. The original OPSD adaptive runner has a 100-seed/30-round default; the manuscript reports the **preselected 10 seeds (30590–30599)** and **rounds 0–12** of those archived runs. Do not conflate the source-run defaults with the reported evaluation subset.

## Contents

- `code/alpine_adaptive/`: source snapshot of the formal 10-scale adaptive-method suite. Entry point `COCAQ_GP_COOP_FORMAL_RUN.m`, shared `engine/` and required legacy oracle assets. Relevant options include `alpine_smoke`, `alpine_all`, `alpine_status`, `alpine_report`. The original shared suite also supports other cases; **only Alpine 2S2D–20S20D is evaluated in this paper**.
- `code/opsd_adaptive/`: original frozen L06 30-round adaptive source, `RUN_L06_OVERNIGHT.m` and `OPSD_load_L06.m`, GP/MARL engines, hyperparameter files, frozen MATLAB data. This snapshot was designed for 100 independent seeds; no claim is made that invoking `new` automatically reproduces the paper's selected ten-seed cohort without subsequent selection.
- `code/p1_p2_matched_lhs/`: direct terminal-GP (P1) and stage-wise-GP (P2) matched-LHS baselines for both cases. Entry `RUN_P12_TWO_CASES.m`, commands `check`, `smoke`, `alpine`, `opsd`, `report`, `plot`. The P1/P2 acquisition locations are matched within each seed. Publication plotting was restricted to **Fig8a and Fig8b**; the obsolete Fig8c plot code was excluded.
- `code/result_plots/`: original five-adaptive-method plot/report helper, with current evidence CSVs. Does **not** itself train the GP or MARL methods.
- `results/alpine/`: 10-scale/10-seed original adaptive method trajectories and summaries.
- `results/opsd/`: ten selected seed trajectories and archived 30-round provenance for five adaptive methods.
- `results/p12/`: original paired baseline final and per-round data.
- `results/derived/`: manuscript-ready seven-method summary tables, for checking values not for independent training.
- `data_provenance/opsd/`: 2019 frozen 13D data and provenance audit utilities; the frozen L06 split is in `code/opsd_adaptive/data/`.
- `reference_figures/`: the five manuscript experimental vector figures, **Fig8a and Fig8b included; Fig8c excluded**.
- `tools/check_paper_results.py`: read-only CSV verification of the reported numerical results.
- `SHA256SUMS.txt`: hashes of all included files other than the hash file itself.

## Reproduce the reported numerical summaries from frozen outputs

Requirements: Python 3 (standard library only). From this directory:

```bash
python tools/check_paper_results.py
```

This recomputes final mean Alpine NRMSE from the recorded five-method final RMSE and the paired P1/P2 test-target standard deviations. It verifies the frozen seven-method summary across ten seeds and verifies OPSD final RMSE and 0–12 AULC for all seven methods. It does not substitute for retraining.

## Running the MATLAB experiment sources

Use MATLAB with the source folder as working directory or on path. Each runner adds its own `engine` path. Typical starting calls:

```matlab
% Alpine source; this is a potentially expensive full rerun
cd('code/alpine_adaptive')
COCAQ_GP_COOP_FORMAL_RUN('preflight')
COCAQ_GP_COOP_FORMAL_RUN('selftest')
COCAQ_GP_COOP_FORMAL_RUN('alpine_smoke')
% COCAQ_GP_COOP_FORMAL_RUN('alpine_all')

% Historical frozen OPSD source (IMPORTANT: original default is 100 seeds x 30 rounds)
cd('../opsd_adaptive')
RUN_L06_OVERNIGHT('check')
% RUN_L06_OVERNIGHT('new')

% P1/P2 baseline source (10 seeds; Alpine 30 and OPSD 12 rounds)
cd('../p1_p2_matched_lhs')
RUN_P12_TWO_CASES('check')
RUN_P12_TWO_CASES('smoke')
% RUN_P12_TWO_CASES('all')
```

**Do not launch a full 100-seed OPSD run solely to verify the 12-round paper table.** For exact frozen values, check `results/` with the supplied Python script. New MATLAB runs may differ in floating point libraries, GP optimizer and stochastic trajectories if environments differ. MATLAB version/toolbox dependencies should be recorded by the submitting authors if they run the sources.

## Evaluation protocol

- Alpine: 10 vertical multiplicative cascades K=D=2,4,...,20; `seeds=16501:16510`; 30 acquisitions; 6K starting observations; 2048 fixed held-out inputs; 300 continuous-search score calls per adaptive round.
- OPSD L06: frozen aligned German 2019 source, 13 exogenous inputs, 4 stage responses; pool 1668, HYPER 504, SELECT 504, CHECK 504; initial 50 complete records; reported adaptive seeds 30590–30599; report exactly 12 acquired records (rounds 0 through 12). Historical run originally generated 30 rounds; no claim that it predicts future unseen dates.
- Stage outputs: photovoltaic capacity factor, solar generation, residual load, day-ahead electricity price. Stage GP fitting conditions on observed predecessor labels; prediction propagates predecessor GP estimates.
- P1 and P2 are *matched-LHS model controls*, not separately optimized active algorithms. The five adaptive methods share the cascade GP modeling setup.

## Source scope, attribution, and limitations

1. The current package omits unrelated Ackley/Ackley-Matyas pilot experiments and obsolete Fig8c. Some **legacy MATLAB functions and MSBO oracle files remain under the Alpine source directory** because the original shared runner enumerates them during setup. They are not experimental evidence for this paper.
2. The original OPSD Weather Data, Renewables.ninja profiles, and OPSD Time Series are third-party data sources. `data_provenance/opsd/` contains the aligned derived records; please retain appropriate upstream dataset citations and check applicable redistribution/attribution terms before public GitHub publication.
3. Early data-downloading/first-construction scripts were not recovered. The frozen source, split, later loader, and provenance verification scripts are supplied; reconstructing the earliest downloaded raw source products from scratch is not covered.
4. The CSV audit is an independent recomputation from frozen results; the MATLAB code has **not** been runtime-tested in this environment. The OPSD source's 100-seed default and paper's ten preselected seeds must remain distinguishable.
5. This package does not include the manuscript/Overleaf source. Upload it to a public, non-tracking repository and paste the genuine URL into the CMT supplemental-material field. A ZIP on a local disk cannot be used directly as the CMT URL.

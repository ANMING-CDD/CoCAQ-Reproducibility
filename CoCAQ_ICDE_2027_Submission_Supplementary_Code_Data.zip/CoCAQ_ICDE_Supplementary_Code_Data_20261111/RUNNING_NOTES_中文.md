# 投稿复现包使用提示

- 把本 ZIP 解压到一个空文件夹，确认 `README.md`、`code/`、`results/` 和 `tools/` 都在。
- 可先运行 `python tools/check_paper_results.py` 验证已存档实验表格。它读取真实 CSV，不需要 MATLAB，不会产生虚构结果。
- Alpine 自适应代码：`code/alpine_adaptive/COCAQ_GP_COOP_FORMAL_RUN.m`；OPSD：`code/opsd_adaptive/RUN_L06_OVERNIGHT.m`；P1/P2：`code/p1_p2_matched_lhs/RUN_P12_TWO_CASES.m`。
- OPSD 自适应原始运行器默认 100 种子 × 30 轮，论文报告预先选好的 30590–30599、前 12 轮。这是源代码与最终报告的真实区别，已在英文 README 说明。
- 本环境无 MATLAB，未声称重新跑通所有 MATLAB 程序。公开前请用你的 MATLAB 做 `check` 或 `preflight` 验证。
- **只保留 Fig8a 和 Fig8b，没有 Fig8c。**
- 上传到 GitHub public repo 后，在 CMT Supplemental Material URL 粘贴你仓库的真实地址；不要填写本地 ZIP 路径。

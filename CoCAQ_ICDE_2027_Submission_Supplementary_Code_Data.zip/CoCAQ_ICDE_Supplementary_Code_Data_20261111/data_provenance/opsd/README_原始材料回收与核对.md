# OPSD 源数据溯源核验

本目录所有已恢复 MAT/CSV 均为原始用户提供或先前实验冻结文件，没有合成数据。

## 目录

- `source_13d/`：首次 2019 德国 13D、四标签对齐数据，8,707 条。
- `source_dimension_diagnostic/`：真实 20D 扩展脚本 `OPSD_DIM_COMPARE.m` 和特征清单；**不是最终主动学习运行器**。
- `data/`：20D 延伸对齐的 8,533 条以及 L06 冻结分组。
- `OPSD_load_L06.m`：论文正式使用的 13D 特征布局和数据读取器。
- `VERIFY_OPSD_LINEAGE.py`：原始 CSV/MAT、20D MAT、L06 F 的逐行交叉校验。
- `VERIFY_OPSD_FROZEN_SOURCE.m`：MATLAB 端冻结配置校验。
- `audit_reports/`：已运行 Python 核查得到的计数、哈希和映射表。

## 一个容易混淆的差异

`case1_opsd_2019.csv` 是初次联接后 8,707 条 13D 数据；后来用于正式冻结 L06 的 `OPSD_DE_2019_20D_ALIGNED.mat` 是扩展 7 个特征、加入较长滞后并完整匹配后的 8,533 条记录。最终实验只是从这 8,533 条中按原始 13 维布局选取特征，**没有在正式预测中使用新加的 7 个特征**。

原始 `case1.stageLocalIdx` 还保留了探索期的**共享特征布局**（Stage 1 使用 7 个输入等），而正式冻结文件 `F.stageColumns` 采用**不共享外生输入的 5/3/3/2 布局**。两者不能互换；见 `audit_reports/OPSD_STAGE_LAYOUTS.csv`。

原始 MAT 的 `poolIdx`、`valIdx`、`testIdx` 是旧 8,707 条的分组；正式论文必须采用 20D MAT 匹配的 `FROZEN_LARGE_FOR_COCAQ.mat` 的 L06 索引，不能混用两套划分。

## 可核实范围

可以验证原始 13D 数据与 20D 对齐数据的数值承继、四个阶段标签、13 维映射和冻结索引；不应宣称已恢复从 OPSD 官网原始下载文件到初始 13D 数据的两个早期脚本。

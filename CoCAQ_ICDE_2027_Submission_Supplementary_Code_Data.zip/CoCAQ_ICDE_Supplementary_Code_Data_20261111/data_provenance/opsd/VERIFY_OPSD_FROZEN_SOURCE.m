function VERIFY_OPSD_FROZEN_SOURCE()
% Recover and independently audit the actual frozen 13D OPSD experiment
% inputs from author-provided MAT archives. This is NOT the original
% raw-download or three-dataset time-join preprocessing program.
root=fileparts(mfilename('fullpath'));
a=load(fullfile(root,'data','OPSD_DE_2019_20D_ALIGNED.mat'),'D');
b=load(fullfile(root,'data','FROZEN_LARGE_FOR_COCAQ.mat'),'F');
D=a.D; F=b.F;
assert(size(D.Xraw,1)==8533 && size(D.Xraw,2)>=20, ...
 'Unexpected aligned sample/feature counts.');
assert(size(D.Yraw,1)==8533 && size(D.Yraw,2)==4, ...
 'Expected four aligned stage outputs.');
assert(strcmp(char(D.fingerprint),char(F.sourceFingerprint)), ...
 'Aligned source fingerprint does not match frozen L06 partition.');
assert(strcmp(char(F.region),'L06_JAN_SEP_EXT') && F.dimension==13);
parts={double(F.poolRows(:)),double(F.hyperTuneRows(:)), ...
 double(F.validationSelectRows(:)),double(F.sealedCheckRows(:))};
expected=[1668 504 504 504];
for i=1:4
 assert(numel(parts{i})==expected(i),'Unexpected partition count.');
 assert(all(parts{i}>=1 & parts{i}<=8533),'Invalid row IDs.');
 for j=1:i-1
  assert(isempty(intersect(parts{i},parts{j})), ...
    'Frozen data partitions overlap.');
 end
end
allRows=vertcat(parts{:});
assert(numel(allRows)==3180 && ...
 isequal(sort(allRows),sort(double(F.allRegionRows(:)))), ...
 'Frozen L06 region does not equal partition union.');
cols=[1 2 3 6 7 8 4 5 9 10 11 12 13];
stages=[ones(1,5) 2*ones(1,3) 3*ones(1,3) 4*ones(1,2)];
raw=double(D.Xraw(:,cols));
lo=min(raw(parts{1},:),[],1); hi=max(raw(parts{1},:),[],1);
span=hi-lo;span(span<1e-10)=1;
X=bsxfun(@rdivide,bsxfun(@minus,raw,lo),span);
assert(all(isfinite(X(:))),'Nonfinite reconstructed features.');
Y=double(D.Y);
assert(all(isfinite(Y(:))),'Nonfinite stage targets.');

out=fullfile(root,'audit_output');
if ~isfolder(out), mkdir(out); end
names=string(D.featureNames(cols));
T=table((1:13)',cols(:),names(:),stages(:), ...
 'VariableNames',{'LocalFeature','AlignedRawColumn','Name','Stage'});
writetable(T,fullfile(out,'FEATURE_MAPPING.csv'));
setNames={'POOL';'HYPER';'SELECT';'CHECK'};
counts=cellfun(@numel,parts)';
writetable(table(string(setNames),counts, ...
 'VariableNames',{'Partition','Count'}), ...
 fullfile(out,'PARTITION_COUNTS.csv'));
save(fullfile(out,'REBUILT_OPSD_L06_13D.mat'), ...
 'X','Y','cols','stages','allRows','parts','names','lo','hi', ...
 '-v7.3');
fprintf('[OK] Aligned source: %d records, %d raw dimensions.\n', ...
 size(raw,1),size(D.Xraw,2));
fprintf('[OK] Frozen L06: %d records = %d+%d+%d+%d.\n', ...
 numel(allRows),counts);
fprintf('[OK] Recovered 13D stage inputs and all four stage targets.\n');
fprintf('[OK] Wrote audit files in %s\n',out);
fprintf('[NOTICE] This does not recreate 8,533 aligned rows from original OPSD ZIP/CSV.\n');
end

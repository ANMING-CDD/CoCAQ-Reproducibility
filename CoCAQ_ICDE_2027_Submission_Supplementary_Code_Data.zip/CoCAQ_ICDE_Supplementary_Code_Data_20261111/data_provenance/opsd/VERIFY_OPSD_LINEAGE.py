#!/usr/bin/env python3
"""Audit the actual, author-supplied OPSD data lineage for the CoCAQ paper.

Read-only: checks the original 13D CSV/MAT, the 20D aligned MAT, and
frozen L06 partition. No data are modified, manufactured, or refitted.
Requires pandas, numpy, scipy, and h5py.
"""
from __future__ import annotations
from collections import Counter
from pathlib import Path
import hashlib
import csv

import h5py
import numpy as np
import pandas as pd
from scipy.io import loadmat

HERE = Path(__file__).resolve().parent
CSV13 = HERE / "source_13d" / "case1_opsd_2019.csv"
MAT13 = HERE / "source_13d" / "case1_opsd_2019.mat"
MAT20 = HERE / "data" / "OPSD_DE_2019_20D_ALIGNED.mat"
FROZEN = HERE / "data" / "FROZEN_LARGE_FOR_COCAQ.mat"
OUT = HERE / "audit_reports"
XCOLS = ["TempC", "DirectWm2", "DiffuseWm2", "HourSinUTC", "HourCosUTC",
         "DayOfYearSin", "DayOfYearCos", "SolarCapacityMW", "WindCF",
         "LoadForecastMW", "LoadLag24MW", "PriceLag24EUR", "IsWeekendUTC"]
YCOLS = ["PvCF", "SolarMW", "ResidualLoadMW", "PriceEUR"]


def matlab_char(ds) -> str:
    a = np.asarray(ds[()]).ravel()
    return "".join(chr(int(k)) for k in a if int(k) != 0)


def row_multiset(a: np.ndarray, ndigits: int = 9) -> Counter:
    # Matching all 13 exogenous inputs and four stage responses, not only IDs.
    return Counter(map(tuple, np.round(a, ndigits)))


def assert_true(condition, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    print("[PASS]", message)


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(CSV13)
    assert_true(len(df) == 8707 and all(x in df.columns for x in XCOLS + YCOLS),
                "Original CSV has 8,707 rows, 13 input fields and four stage labels")
    assert_true(not df[XCOLS+YCOLS].isnull().any().any(), "Original CSV selected fields are complete")
    assert_true(not df["TimestampUTC"].duplicated().any(), "Original timestamps are unique")
    with h5py.File(MAT13) as f:
        origX = f["case1/X"][()].T
        origY = f["case1/Y"][()].T
        initial_pool = f["case1/poolIdx"].size
        initial_val = f["case1/valIdx"].size
        initial_test = f["case1/testIdx"].size
        original_stage_map = [list(map(int, f[ref][()].ravel()))
                              for ref in f["case1/stageLocalIdx"][()].ravel()]
    assert_true(origX.shape == (8707, 13) and origY.shape == (8707, 4),
                "Original MATLAB case1 contains 8,707 x 13 inputs and 8,707 x 4 labels")
    assert_true(np.allclose(origX, df[XCOLS].to_numpy(), rtol=0, atol=1e-12) and
                np.array_equal(origY, df[YCOLS].to_numpy()),
                "Original 13D CSV and MATLAB case1 input/label values agree")
    assert_true(initial_pool + initial_val + initial_test == 8707,
                "Original case1 POOL/VAL/TEST partitions cover all 8,707 rows")
    assert_true(original_stage_map == [[1,2,3,4,5,6,7], [8,2,3,4,5,6,7],
                                       [9,10,11,1,4,5], [12,9,4,5,6,7,13]],
                "Original case1 had an exploratory overlapping stage layout")

    with h5py.File(MAT20) as f:
        d = f["D"]
        alignXraw = d["Xraw"][()].T
        alignYraw = d["Yraw"][()].T
        alignY = d["Y"][()].T
        yScale = d["yScale"][()].ravel()
        fingerprint = matlab_char(d["fingerprint"])
    assert_true(alignXraw.shape == (8533, 20) and alignYraw.shape == (8533, 4),
                "20D extended/complete-case aligned source has 8,533 rows")
    assert_true(np.allclose(alignY * yScale.reshape(1,-1), alignYraw, rtol=0, atol=1e-9),
                "Aligned normalized response labels invert to original units")
    base = row_multiset(np.column_stack([origX,origY]))
    aligned = row_multiset(np.column_stack([alignXraw[:,:13], alignYraw]))
    unmatched = sum(max(n - base[k], 0) for k,n in aligned.items())
    assert_true(unmatched == 0, "Every aligned record matches an original 13D input + four-label tuple")
    assert_true(sum(aligned.values()) == 8533 and sum(base.values()) == 8707,
                "Alignment keeps 8,533 of 8,707 records (174 excluded)")

    frozen = loadmat(FROZEN, squeeze_me=True, struct_as_record=False)["F"]
    assert_true(str(frozen.sourceFingerprint) == fingerprint,
                "Frozen L06 source fingerprint matches aligned 20D MAT")
    assert_true(str(frozen.region) == "L06_JAN_SEP_EXT" and int(frozen.dimension)==13,
                "Frozen experiment uses L06_JAN_SEP_EXT and 13 exogenous inputs")
    parts = {
        "POOL":np.asarray(frozen.poolRows,dtype=int).ravel(),
        "HYPER":np.asarray(frozen.hyperTuneRows,dtype=int).ravel(),
        "SELECT":np.asarray(frozen.validationSelectRows,dtype=int).ravel(),
        "CHECK":np.asarray(frozen.sealedCheckRows,dtype=int).ravel(),
    }
    expected={"POOL":1668,"HYPER":504,"SELECT":504,"CHECK":504}
    for name,ids in parts.items():
        assert_true(len(ids)==expected[name] and np.all((ids>=1)&(ids<=8533)),
                    f"{name} has exactly {expected[name]} valid, 1-based indices")
    joined=np.concatenate(list(parts.values()))
    assert_true(len(np.unique(joined))==3180 and
                np.array_equal(np.sort(joined),np.sort(np.asarray(frozen.allRegionRows,dtype=int).ravel())),
                "Four frozen partitions are disjoint and cover the 3,180-record L06 subset")
    mapping=[1,2,3,6,7,8,4,5,9,10,11,12,13]
    stage_cols=[[1,2,3,6,7],[8,4,5],[9,10,11],[12,13]]
    actual=[list(map(int,np.asarray(v).ravel())) for v in np.asarray(frozen.stageColumns).ravel()]
    assert_true(actual==stage_cols, "Frozen four-stage mapping matches published 13D feature order")
    assert_true(original_stage_map != actual,
                "Original exploratory overlapping layout differs from final disjoint 5/3/3/2 stage layout")
    assert_true(int(frozen.initialLabeled)==50 and int(frozen.queryBudget)==30,
                "Frozen experiment starts from 50 rows and stores original 30-round budget")

    # A 12-round analysis is a prefix of the archived 30-round trajectories.
    audit_rows = [
        ("Original case1 2019","records",8707,"Original 13D CSV and MAT"),
        ("Original case1 2019","inputs",13,"Four output labels per row"),
        ("Original case1 2019","pool",initial_pool,"Original, not L06 partition"),
        ("Original case1 2019","validation",initial_val,"Original, not L06 partition"),
        ("Original case1 2019","test",initial_test,"Original, not L06 partition"),
        ("Aligned 20D diagnostic","records",8533,"Original source rows retained after timestamp/lag completeness"),
        ("Aligned 20D diagnostic","inputs",20,"Includes seven extra diagnostic features"),
        ("Aligned 20D diagnostic","excluded_rows",174,"Missingness/extended lag and source alignment"),
        ("Frozen L06 formal workload","records",3180,"January-September, 08-19 UTC subset"),
        ("Frozen L06 formal workload","POOL",1668,"Initial/acquisition candidate pool"),
        ("Frozen L06 formal workload","HYPER",504,"GP hyperparameter selection"),
        ("Frozen L06 formal workload","SELECT",504,"Method/development selection"),
        ("Frozen L06 formal workload","CHECK",504,"Fixed internal holdout; previously inspected during development"),
        ("Frozen L06 formal workload","inputs",13,"Mapped from first 13 of aligned Xraw"),
        ("Frozen L06 formal workload","initial_training_rows",50,"Per seed"),
        ("Frozen L06 formal workload","archived_query_budget",30,"Official experiments archived for 30 rounds"),
        ("Paper OPSD comparison","acquisition_rounds",12,"Analyze R0-R12 prefix of archived 30 rounds"),
    ]
    with (OUT/"OPSD_LINEAGE_COUNTS.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["DatasetStep","Quantity","Value","Interpretation"]);w.writerows(audit_rows)
    with (OUT/"OPSD_LINEAGE_SHA256.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["Artifact","SHA256"])
        for p in [CSV13,MAT13,MAT20,FROZEN]:w.writerow([str(p.relative_to(HERE)),sha256(p)])
    with (OUT/"OPSD_MAPPING.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["FormalFeatureIndex","Original13DIndex","Name","Stage"])
        for j,idx in enumerate(mapping,1):
            stage=1 if j<=5 else 2 if j<=8 else 3 if j<=11 else 4
            w.writerow([j,idx,XCOLS[idx-1],stage])
    with (OUT/"OPSD_STAGE_LAYOUTS.csv").open("w", newline="", encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["Stage", "Original13DExploratoryInputIndices", "FrozenFormalInputIndices"])
        for i,(a,b) in enumerate(zip(original_stage_map,actual),1):
            w.writerow([i," ".join(map(str,a))," ".join(map(str,b))])
    print("[DONE] Verified OPSD data lineage and wrote:", OUT)


if __name__ == "__main__":
    main()

function [D,s]=OPSD_load_L06()
% Strict L06_JAN_SEP_EXT region from V3 frozen study; ORIGINAL 13D partition.
% Reads the already aligned 20D MAT, but uses ONLY its first 13 raw features.
% IMPORTANT: records in HYPER/SELECT/CHECK are NEVER available for queries.
root=fileparts(mfilename('fullpath'));
f=fullfile(root,'data','FROZEN_LARGE_FOR_COCAQ.mat');
assert(isfile(f),'Missing frozen L06 region MAT in data folder.');
z=load(f,'F');F=z.F;
assert(strcmp(char(F.region),'L06_JAN_SEP_EXT') && F.dimension==13);
paths={fullfile(root,'data','OPSD_DE_2019_20D_ALIGNED.mat'), ...
 fullfile(fileparts(root),'OPSD_13D_16D_20D_GP_TUNED', ...
 'results','OPSD_DE_2019_20D_ALIGNED.mat'), ...
 char(F.sourceMat)};
source='';
for i=1:numel(paths)
 if isfile(paths{i}),source=paths{i};break;end
end
assert(~isempty(source), ['Missing aligned MAT. Copy OPSD_DE_2019_20D_ALIGNED.mat ', ...
 'to this project''s data folder, or leave it in the original preparation project.']);
v=load(source,'D');A=v.D;
assert(strcmp(char(A.fingerprint),char(F.sourceFingerprint)), ...
 'Aligned data changed since L06 was frozen. Do NOT silently change rows.');
assert(size(A.Xraw,2)>=13 && size(A.Y,2)==4);
N=size(A.Xraw,1);
idxList={F.poolRows(:),F.hyperTuneRows(:),F.validationSelectRows(:),F.sealedCheckRows(:)};
for k=1:numel(idxList)
 assert(all(isfinite(idxList{k})) && all(idxList{k}>=1 & idxList{k}<=N), ...
 'Frozen row indices outside aligned data.');
 for j=1:k-1
  assert(isempty(intersect(idxList{k},idxList{j})), 'Frozen subsets overlap.');
 end
end
cols=[1 2 3 6 7 8 4 5 9 10 11 12 13];
assert(isequal(sort(cols),1:13));
raw=double(A.Xraw(:,cols));
% Follow V3: scale only on known POOL covariates, never inspect CHECK labels.
lo=min(raw(idxList{1},:),[],1);hi=max(raw(idxList{1},:),[],1);
span=hi-lo;span(span<1e-10)=1;
X=bsxfun(@rdivide,bsxfun(@minus,raw,lo),span);
Y=double(A.Y);
assert(all(isfinite(X(:)),'all') && all(isfinite(Y(:)),'all'));
D=struct();D.region=char(F.region);D.sourceMat=source;
D.poolIdx=idxList{1};D.hyperIdx=idxList{2};
D.valIdx=idxList{3};D.testIdx=idxList{4};
D.X=X;D.Y=Y;D.Yraw=double(A.Yraw);
D.yScale=double(A.yScale(:))';D.stageDims=[5 3 3 2];
D.originalCols=cols;D.originalNames=A.featureNames(cols);
D.stageOutputs={'PV capacity factor','Solar generation MW', ...
 'Residual load MW','Day-ahead price EUR/MWh'};
D.featureLo=lo;D.featureHi=hi;D.frozenGPprofiles=F.GPprofiles;
D.fingerprint=['L06_13D_' char(F.sourceFingerprint) '_' ...
 num2str(numel(D.poolIdx)) '_' num2str(numel(D.valIdx)) '_' ...
 num2str(numel(D.testIdx))];
s=struct('id','OPSD_L06_13D_4STAGE','kind','opsd_pool', ...
 'name','OPSD L06 Jan-Sep 08-19 UTC frozen four-stage workflow', ...
 'd',13,'K',4,'p',NaN,'stageDims',[5 3 3 2],'nInitial',50);
assert(numel(D.poolIdx)>=80 && numel(D.valIdx)>0 && numel(D.testIdx)>0);
end

function RUN_L06_OVERNIGHT(action)
% FROZEN PARAMETER fresh recomputation: no old experimental checkpoints read.
% V00 from V6 SELECT; A4/A5 from original L06 SELECT Grid1; A2/A3 defaults.
% Usage: RUN_L06_OVERNIGHT('check'|'new'|'resume'|'status'|'report');
% First 'new' creates a unique FRESH_* directory. 'resume' is EXPLICIT.
% Historical CHECK has been inspected before: this is retrospective.
% Fixed 30-round, 100-seed independent cohort: fixed params, no new seeds chosen by outcome.
if nargin<1 || isempty(action),action='check';end
project=fileparts(mfilename('fullpath'));
addpath(project,'-begin');addpath(fullfile(project,'engine'),'-begin');
action=lower(char(action));
if strcmp(action,'help')
 fprintf(['RUN_L06_OVERNIGHT(''check'')\nRUN_L06_OVERNIGHT(''new'')\n' ...
 'RUN_L06_OVERNIGHT(''resume'')\n' ...
 'RUN_L06_OVERNIGHT(''status'')\n' ...
 'RUN_L06_OVERNIGHT(''report'')\n']);return;
end
[D,s]=OPSD_load_L06();
checkPreflight(D,s);
if strcmp(action,'check')
 fprintf('100-SEED x 30R CHECK PASS: original data + engine available.\n');
 params=loadFrozenConfigs(project); %#ok<NASGU>
 fprintf('Verified: scalar struct overrides for A4/A5 and V00.\n');
 fprintf('Using PREVIOUS SELECT frozen configs: V6 V00, A4/A5 Grid1.\n');
 fprintf('Four GP profiles fixed: smooth/smooth/smooth/flexible.\n');
 fprintf('No tuning or GP profile scan will execute. GP/Fast-Gi V00 frozen.\n');
 fprintf('%d final seeds x 5 methods x 30 rounds; 300+32 scoring calls each round.\n',numel(l06FormalSeeds()));return;
end
switch action
 case 'new'
  [study,meta]=createNewRun(project,D,s);
  fprintf('NEW RUN ID: %s\n',meta.RunID);
  fprintf('NEW RESULTS: %s\n',study);
  fprintf('ALL 0/%d new formal rounds at creation.\n',meta.Rounds*numel(meta.FormalSeeds)*numel(meta.Methods));
  executeFresh(study,D,s,meta);
 case 'resume'
  [study,meta]=openFreshRun(project,D,s);
  fprintf('EXPLICIT RESUME of FRESH RUN: %s\n',meta.RunID);
  executeFresh(study,D,s,meta);
 case 'status'
  [study,meta]=openFreshRun(project,D,s);
  freshStatus(study,meta);
 case 'report'
  [study,meta]=openFreshRun(project,D,s);
  s.gpOptsStages=readGPLock(study,D,s);
  z=readLock(study,D,s);
  strictFreshReport(study,D,s,meta,z);
 otherwise
  error('Unknown action. Use check, new, resume, status, report.');
end
end

function [study,meta]=createNewRun(project,D,s)
dirRoot=fullfile(project,'overnight_100seed_runs');
if ~isfolder(dirRoot),mkdir(dirRoot);end
runID=['FRESH_' datestr(now,'yyyymmdd_HHMMSSFFF')];
study=fullfile(dirRoot,runID);
assert(~isfolder(study),'Collision in fresh run ID; retry later.');
mkdir(study);
meta=struct();meta.RunID=runID;meta.Created=datestr(now,30);
meta.CreatedSerial=now;meta.Version='L06_V00_30R_100SEED_V1';
meta.DataFingerprint=D.fingerprint;meta.SourceHash=hashSource(project);
meta.Methods={'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_BEST_V00'};
meta.FormalSeeds=l06FormalSeeds();
meta.HistoricalMapTuneSeeds=16401:16403;
meta.HistoricalV00SelectSeeds=17511:17516;
meta.Rounds=30;meta.NAcq=300;meta.NProjection=32;
meta.HistoricalCheckAlreadyInspected=true;
meta.ParamSelection='V6_SELECT_V00_AND_ORIGINAL_L06_GRID1';
meta.GPProfileSelection='PREVIOUS_L06_HYPER';
save(fullfile(study,'RUN_MANIFEST.mat'),'meta','-v7');
manifest=fullfile(dirRoot,'CURRENT_RUN.txt');
f=fopen(manifest,'w');assert(f>=0,'Could not write current run pointer.');
fprintf(f,'%s\n',runID);fclose(f);
fprintf('Created exclusive run folder, no legacy checkpoint copy.\n');
end

function [study,meta]=openFreshRun(project,D,s)
f=fullfile(project,'overnight_100seed_runs','CURRENT_RUN.txt');
assert(isfile(f),'No fresh experiment yet. Call RUN_L06_OVERNIGHT(''new'').');
runID=strtrim(fileread(f));
assert(~isempty(regexp(runID,'^FRESH_[0-9]{8}_[0-9]{9}$','once')), ...
 'Invalid run pointer.');
study=fullfile(project,'overnight_100seed_runs',runID);
z=load(fullfile(study,'RUN_MANIFEST.mat'),'meta');meta=z.meta;
assert(strcmp(meta.RunID,runID)&&strcmp(meta.DataFingerprint,D.fingerprint), ...
 'Run manifest/data mismatch.');
assert(strcmp(meta.SourceHash,hashSource(project)), ...
 'Code or MAT source changed during a fresh run. Stop: never mix versions.');
assert(strcmp(meta.Version,'L06_V00_30R_100SEED_V1') && meta.Rounds==30 && ...
 meta.NAcq==300 && meta.NProjection==32 && s.nInitial==50, ...
 'Protocol mismatch.');
assert(isequal(meta.FormalSeeds,l06FormalSeeds()), ...
 'Formal seed list differs from current code; do not mix runs.');
end

function h=hashSource(project)
files={fullfile(project,'RUN_L06_OVERNIGHT.m'), ...
 fullfile(project,'OPSD_load_L06.m'), ...
 fullfile(project,'data','FROZEN_LARGE_FOR_COCAQ.mat'), ...
 fullfile(project,'data','OPSD_DE_2019_20D_ALIGNED.mat'), ...
 fullfile(project,'V00_FROZEN_FROM_V6.json'), ...
 fullfile(project,'LOCKED_V6.mat')};
eng=dir(fullfile(project,'engine','*.m'));
[~,ix]=sort({eng.name});eng=eng(ix);
for i=1:numel(eng),files{end+1}=fullfile(eng(i).folder,eng(i).name);end %#ok<AGROW>
md=java.security.MessageDigest.getInstance('SHA-256');
for i=1:numel(files)
 f=fopen(files{i},'rb');assert(f>=0,'Hash source not found: %s',files{i});
 b=fread(f,Inf,'*uint8');fclose(f);
 md.update(typecast(uint8(sprintf('%016d:',numel(b))),'int8'));
 md.update(typecast(b(:),'int8'));
end
h=lower(reshape(dec2hex(typecast(int8(md.digest()),'uint8'),2)',1,[]));
end

function executeFresh(study,D,s,meta)
assert(isfolder(study));
assert(strcmp(meta.SourceHash,hashSource(fileparts(fileparts(study)))));
% No re-tuning: replay immutable, previously selected GP profiles and settings.
s.gpOptsStages=freezeGP(study,D,s);
freezeConfig(study,D,s);
z=readLock(study,D,s);
S=protocol('formal');S.lockFingerprint=z.fingerprint;
fprintf('STARTING 30-round 100-seed fixed-parameter experiment: %d trajectories, %d rounds.\n',numel(S.seeds)*numel(S.methods),numel(S.seeds)*numel(S.methods)*S.rounds);
runSuite(study,D,s,S,z.params,'DEFAULT');
strictFreshReport(study,D,s,meta,z);
end

function freshStatus(study,meta)
fprintf('RUN: %s | Created %s\n',meta.RunID,meta.Created);
fprintf('RUN LOCATION: %s\n',study);
for phase={'FORMAL'}
 p=phase{1};ff=dir(fullfile(study,'results',p,'**','seed*.mat'));
 num=0;rounds=0;
 for i=1:numel(ff)
  try
   z=load(fullfile(ff(i).folder,ff(i).name),'H');
   num=num+1;rounds=rounds+numel(z.H.RMSE)-1;
  catch
  end
 end
 fprintf('%s: %d checkpoint files, %d actual recorded rounds\n',p,num,rounds);
end
fprintf('Only fresh formal checkpoints from this run are consulted. No retuning.\n');
 liveStatus=fullfile(study,'RESULTS','LIVE_STATUS.txt');
 if isfile(liveStatus),fprintf('%s\n',fileread(liveStatus));end
end

function opts=freezeGP(root,D,s)
% Use previously selected L06 HYPER GP policies. No new hyper search.
fn=fullfile(root,'results','TUNING','GP_LOCK.mat');
if isfile(fn),opts=readGPLock(root,D,s);return;end
names={'smooth','smooth','smooth','flexible'};
opts=cell(1,s.K);
assert(s.K==4,'Unexpected number of GP stages.');
for k=1:s.K,opts{k}=GCF_gp_options(names{k});end
folder=fileparts(fn);if ~isfolder(folder),mkdir(folder);end
dataFingerprint=D.fingerprint;
gpVersion='GP_PROFILE_STAGE_L06_V3';
frozenRegion=D.region;sourceProfiles=D.frozenGPprofiles;
selectionSource='PREVIOUS_L06_HYPER_PROFILE_VALIDATION';
save(fn,'opts','names','selectionSource','dataFingerprint', ...
 'gpVersion','frozenRegion','sourceProfiles','-v7');
fprintf('FIXED GP profiles from previous HYPER: %s\n',strjoin(names,','));
end

function opts=readGPLock(root,D,~)
fn=fullfile(root,'results','TUNING','GP_LOCK.mat');
assert(isfile(fn),'GP lock missing: run COCAQ_L06_RUN(''tune_gp'') first.');
z=load(fn,'opts','dataFingerprint','gpVersion','frozenRegion');
assert(strcmp(z.dataFingerprint,D.fingerprint) && ...
 strcmp(z.gpVersion,'GP_PROFILE_STAGE_L06_V3') && ...
 strcmp(z.frozenRegion,D.region),'Stage GP lock mismatch.');
assert(iscell(z.opts)&&numel(z.opts)==4);
expected={'smooth','smooth','smooth','flexible'};
for k=1:4
 assert(strcmp(z.opts{k}.name,expected{k}), ...
  'GP frozen profile does not match previous L06 HYPER selection.');
end
opts=z.opts;
end

function trace=snapshotGP(model)
trace=repmat(struct('Profile','','NLL',0,'SignalStd',0,'NoiseStd',0, ...
 'NoiseRatio',0,'MinEll',0,'MedianEll',0,'MaxEll',0),model.K,1);
for k=1:model.K
 g=model.stage{k};
 trace(k)=struct('Profile',g.gpProfile,'NLL',g.nll, ...
  'SignalStd',g.signalStd,'NoiseStd',g.noiseStd, ...
  'NoiseRatio',g.noiseRatio,'MinEll',min(g.ell), ...
  'MedianEll',median(g.ell),'MaxEll',max(g.ell));
end
end

function gpDiagnostics(root,D,s)
if isfile(fullfile(root,'results','TUNING','GP_LOCK.mat'))
 s.gpOptsStages=readGPLock(root,D,s);
else
 s.gpOptsStages=cell(1,4);for k=1:4,s.gpOptsStages{k}=GCF_gp_options('balanced');end
end
rng(271828,'twister');idx=D.poolIdx(randperm(numel(D.poolIdx),50));
m=GCF_fit(s,D.X(idx,:),D.Y(idx,:),'cascade');
for k=1:s.K
 g=m.stage{k};
 fprintf('Stage %d GP=%s | noiseStd (normalized)=%.5g | ', ...
 k,g.gpProfile,g.noiseStd);
 fprintf('signalStd=%.5g | signalVar=%.5g | ratio=%.5g | lengthscales=%s\n', ...
 g.signalStd,g.signal2,g.noiseRatio,mat2str(g.ell,3));
 assert(all(isfinite(g.ell)) && g.noise2>0 && isfinite(g.nll));
end
fprintf('GP diagnostics PASS. Learned stage-specific kernel and noise parameters.\n');
end

function reportInput(D,s)
fprintf('\n=== OPSD Germany 2019 | L06 January-September 08-19 UTC ===\n');
fprintf('N=%d D=%d K=%d; local dims=%s\n',size(D.X,1),s.d,s.K,mat2str(s.stageDims));
fprintf('POOL=%d; HYPER=%d; SELECT=%d; CHECK=%d\n',numel(D.poolIdx),numel(D.hyperIdx),numel(D.valIdx),numel(D.testIdx));
fprintf('Data source: %s\n',D.sourceMat);
for k=1:s.K
 idx=MSBO_stage_idx(s,k);
 fprintf('Stage%d local [%s] -> %s\n',k,strjoin(D.originalNames(idx),', '),D.stageOutputs{k});
end
fprintf('WARNING: historical/offline pool labels, not arbitrary controllable simulator outputs.\n');
fprintf('WARNING: complete multi-label query; no choosing x(k+1) after observing true y(k).\n');
end
function checkPreflight(D,s)
need={'GCF_gpcoop_ppo','GCF_mappo_v4','GCF_cmaes','GCF_fit', ...
 'GCF_gp_options','GCF_gp_fit','GCF_gp_predict', ...
 'GCF_chain_build','GCF_chain_eval','GCF_fastgi_build','GCF_fastgi_eval'};
for j=1:numel(need),assert(exist(need{j},'file')==2, ...
 'Missing original GCF function: %s',need{j});end
assert(all(D.X(D.poolIdx,:)>=-1e-10 & D.X(D.poolIdx,:)<=1+1e-10,'all'), ...
 'Training pool x must be in [0,1]. Evaluation rows may extrapolate.');
assert(numel(D.poolIdx)>=s.nInitial+30);
assert(~any(ismember(D.poolIdx,D.testIdx)));
reportInput(D,s);
end
function selftest(D,s)
% Run only numerical sanity test. No held-out test labels are used for tuning.
rng(271828,'twister');idx=D.poolIdx(randperm(numel(D.poolIdx),12));
m=GCF_fit(s,D.X(idx,:),D.Y(idx,:),'cascade');
p=GCF_predict_final(s,m,D.X(D.valIdx(1:3),:));
assert(numel(p)==3 && all(isfinite(p)));
F=GCF_chain_build(m,s,D.X(D.poolIdx(1:12),:));
[r,g]=GCF_chain_eval(F,D.X(D.poolIdx(13:16),:));
assert(all(isfinite(r)) && isequal(size(g),[4 s.K]));
assert(all(r>=0) && all(g(:)>=0));
for kk=1:s.K
 gp=m.stage{kk};
 assert(all(isfinite(gp.ell)) && gp.signal2>0 && gp.noise2>0);
 assert(norm(gp.L*gp.L'-(GCF_kernel(gp.X,gp.X,gp.ell)+ ...
     (gp.noiseRatio+gp.jitter)*eye(size(gp.X,1))),'fro')<1e-5);
end
F2=GCF_fastgi_build(m,s,D.X(D.poolIdx(1:12),:),6);
[r2,g2]=GCF_fastgi_eval(F2,D.X(D.poolIdx(13:16),:));
assert(all(isfinite(r2)) && all(isfinite(g2(:))));
if s.d==13,assert(isequal([MSBO_stage_idx(s,1),MSBO_stage_idx(s,2), ...
 MSBO_stage_idx(s,3),MSBO_stage_idx(s,4)],1:13));end
fprintf('OPSD GP V2 selftest PASS: 4 adaptive GPs, noise-aware chain/FastGi.\n');
end

function S=protocol(mode)
S=struct('mode',mode,'rounds',30,'seeds',l06FormalSeeds(), ...
 'nAcq',300,'nAnchors',48,'nRef',256,'nEval',512, ...
 'rank',32,'nProjection',32,'lockFingerprint','NONE', ...
 'methods',{{'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_BEST_V00'}});
switch mode
 case 'formal'
  % Same candidate and real-query budgets for every method.
 otherwise,error('Unknown phase');
end
end

function params=loadFrozenConfigs(project)
% Frozen selections from prior experiments, never chosen on this run's CHECK.
% Original L06 MAPPO and GP-MAPPO both selected GRID 1 on SELECT.
grid1=struct('hidden',64,'batch',32,'nEpoch',6, ...
 'actorLR',.002,'criticLR',.004,'sigma',1.10,'minSigma',.25, ...
 'ppoTargetKL',.07,'ppoMinEpoch',3,'ppoEntropyCoeff',0, ...
 'priorMix',.20,'priorTemp',.25,'priorWidth',.40,'priorH',.45);
j=fullfile(project,'V00_FROZEN_FROM_V6.json');
assert(isfile(j),'Missing V6 V00 freeze JSON: %s',j);
z=jsondecode(fileread(j));
assert(strcmp(z.configId,'V00') && strcmp(z.selectedOn,'SELECT') && ...
 strcmp(z.selectionSource,'V6_SELECT_LOCKED_V00'), ...
 'V00 provenance is not the locked V6 SELECT.');
v=z.cfg;
assert(v.hidden==64 && v.gradPerBatch==2 && v.nAnchors==48 && ...
 v.nRef==256 && v.rank==32 && strcmp(v.projection,'original32') && ...
 v.nHiddenLayers==2 && v.batch==32 && v.nEpoch==14 && ...
 abs(v.priorMix-.30)<1e-12 && abs(v.priorTemp-.20)<1e-12 && ...
 abs(v.actorLR-.003)<1e-12 && abs(v.criticLR-.006)<1e-12, ...
 'Unexpected V00: parameters differ from V6 SELECT locked settings.');
% Verify the JSON against the actual user-supplied V6 MATLAB freeze.
lockedMat=fullfile(project,'LOCKED_V6.mat');
assert(isfile(lockedMat),'Missing original V6 frozen parameter MAT.');
ll=load(lockedMat,'L');L=ll.L;
assert(strcmp(L.config.id,'V00') && strcmp(L.selectedOn,'SELECT') && ...
 strcmp(L.config.gp,'original') && L.config.direct==0 && ...
 L.config.wVar==0 && L.config.wNovel==0, ...
 'V6 MAT is not the original SELECT V00 lock.');
frozenKeys=fieldnames(L.config.cfg);
jsonKeys=fieldnames(v);
assert(isequal(sort(frozenKeys),sort(jsonKeys)), ...
 'Frozen V00 JSON and MAT fields differ.');
for j=1:numel(frozenKeys)
  key=frozenKeys{j};u=L.config.cfg.(key);w=v.(key);
  if isnumeric(u)
    assert(isnumeric(w) && isscalar(w) && ...
      abs(double(u)-double(w)) <= 1e-10*max(1,abs(double(u))), ...
      'V00 frozen value mismatch: %s',key);
  else
    assert(strcmp(char(u),char(w)),'V00 frozen string mismatch: %s',key);
  end
end
% IMPORTANT: store scalar parameter STRUCTS, not cell arrays of field names.
params=struct('A4_MAPPO',grid1,'A5_GP_MAPPO',grid1, ...
 'V4A_BEST_V00',v);
assert(isscalar(params) && isstruct(params.A4_MAPPO) && ...
 isscalar(params.A4_MAPPO) && isstruct(params.A5_GP_MAPPO) && ...
 isscalar(params.A5_GP_MAPPO) && isstruct(params.V4A_BEST_V00), ...
 'Frozen overrides must all be scalar parameter structures.');
end

function freezeConfig(root,D,s)
% Save a local copy of previously selected parameters; do NOT search.
fn=fullfile(root,'results','TUNING','LOCKED_PARAMS.mat');
if isfile(fn)
 z=readLock(root,D,s);
 fprintf('Already imported this run''s fixed config: %s\n',fn);
 disp(z.choices);return;
end
params=loadFrozenConfigs(fileparts(fileparts(root)));
choices=struct('A4_MAPPO','PREVIOUS_GRID1', ...
 'A5_GP_MAPPO','PREVIOUS_GRID1', ...
 'V4A_BEST_V00','V6_SELECT_V00');
trainSeeds=[];formalSeeds=l06FormalSeeds();
selectionSource='PRIOR_VALIDATION_ONLY_NOT_RERUN';
fingerprint=lockDigest(D,s,params,choices);
folder=fileparts(fn);if ~isfolder(folder),mkdir(folder);end
save(fn,'params','choices','fingerprint','trainSeeds', ...
 'formalSeeds','selectionSource','-v7');
M=table(string(fieldnames(choices)), ...
 string(struct2cell(choices)), ...
 'VariableNames',{'Method','FrozenSelection'});
writetable(M,fullfile(folder,'PREVIOUSLY_FROZEN_CONFIGS.csv'));
fprintf('FIXED selections loaded (no tuning): %s\n',fn);
disp(M);
end

function z=readLock(root,D,s)
assert(isfield(s,'gpOptsStages'),'Formal run requires frozen stage GP profiles.');
fn=fullfile(root,'results','TUNING','LOCKED_PARAMS.mat');
assert(isfile(fn),'Fixed-configuration lock not yet initialized. Run RUN_L06_OVERNIGHT(''new'').');
z=load(fn,'params','choices','fingerprint','trainSeeds','formalSeeds');
assert(isstruct(z.params) && isscalar(z.params), ...
 'Corrupted lock: params must be a scalar struct. Use new in a clean run.');
assert(isstruct(z.params.A4_MAPPO) && isstruct(z.params.A5_GP_MAPPO) ...
 && isstruct(z.params.V4A_BEST_V00), ...
 'Corrupted lock: overrides must be structs. Use new in a clean run.');
assert(isfield(z.params,'A4_MAPPO') && isfield(z.params,'A5_GP_MAPPO') && isfield(z.params,'V4A_BEST_V00'));
assert(isempty(z.trainSeeds) && ...
 isequal(z.formalSeeds,l06FormalSeeds()),'Frozen-lock seed provenance mismatch');
expected=loadFrozenConfigs(fileparts(fileparts(root)));
assert(isequaln(z.params,expected), ...
 'Frozen params differ from previously SELECT-chosen configurations.');
assert(strcmp(z.fingerprint,lockDigest(D,s,z.params,z.choices)), ...
 'Data/frozen config changed. Existing lock must not be silently reused.');
end
function fp=lockDigest(D,s,params,choices)
v=jsonencode(struct('source',D.fingerprint,'s',s.id, ...
 'params',params,'choices',choices,'gpOptsStages',{s.gpOptsStages}));
a=double(uint8(v));n=numel(a);
fp=sprintf('OPSD_LOCK_%010d_%d',mod(sum(a.*(1:n)),2147483647),n);
end

function runSuite(root,D,s,S,overrides,group)
if nargin<6||isempty(group),group='DEFAULT';end
Zmeta=load(fullfile(root,'RUN_MANIFEST.mat'),'meta');fresh=Zmeta.meta;
% Historical parameter selection was on SELECT; this run does not tune.
% Formal uses historical CHECK (already inspected; retrospective only).
if strcmp(S.mode,'formal'),evalRows=D.testIdx;else,evalRows=D.valIdx;end
evalRows=chooseEvalRows(evalRows,S.nEval);
Xe=D.X(evalRows,:);Ye=D.Y(evalRows,end)*D.yScale(end);
for seed=S.seeds
 rng(555000+seed,'twister');initRows=D.poolIdx(randperm(numel(D.poolIdx),s.nInitial));
 for mi=1:numel(S.methods)
  method=S.methods{mi};override=struct();
  if isfield(overrides,method),override=overrides.(method);end
  signature=struct('version','OPSD_L06_POOL_GP_MLII_V3','data',D.fingerprint, ...
   'mode',S.mode,'seed',seed,'group',group,'method',method, ...
   'freshRunId',fresh.RunID,'sourceHash',fresh.SourceHash, ...
   'rounds',S.rounds,'nAcq',S.nAcq,'nRef',S.nRef, ...
   'nEval',S.nEval,'rank',S.rank,'nProjection',S.nProjection, ...
   'stageDims',s.stageDims,'nInitial',s.nInitial, ...
   'override',override,'lock',S.lockFingerprint,'gpOptsStages',{s.gpOptsStages}, ...
   'evalRows',evalRows);
  fn=checkpointFile(root,S.mode,group,seed,method);
  if isfile(fn)
   Z=load(fn,'H','signature');
   assert(isequaln(Z.signature,signature), ...
    'Checkpoint mismatch: %s. Do not overwrite; use a new study folder.',fn);
   H=Z.H;
   assert(isequal(H.initRows(:),initRows(:)),'Initial sample changed.');
  else
   H=initRun(D,s,Xe,Ye,evalRows,initRows,method,seed);
   H.FreshRunId=fresh.RunID;H.RoundCompletedAt=cell(0,1);
   saveCheckpoint(fn,H,signature);
  end
  done=numel(H.RMSE)-1;
  assert(isfield(H,'FreshRunId') && strcmp(H.FreshRunId,fresh.RunID) && ...
   isfield(H,'RoundCompletedAt') && numel(H.RoundCompletedAt)==done, ...
   'Non-fresh or damaged checkpoint blocked: %s',fn);
  fprintf('%s | %s seed=%d %d/%d (EUR/MWh)\n', ...
   S.mode,method,seed,done,S.rounds);
  for rr=done+1:S.rounds
   t=tic;
   searchSeed=580000+1000*seed+17*rr;
   [chosen,stats]=selectPool(D,s,H,S,override,searchSeed);
   H.rows(end+1,1)=chosen;
   H.X(end+1,:)=D.X(chosen,:);
   H.Y(end+1,:)=D.Y(chosen,:);  % reveal all four true labels at once
   H.ChosenRows(end+1,1)=chosen;
   H.model=GCF_fit(s,H.X,H.Y,'cascade',H.model);
   H.GPTrace{end+1,1}=snapshotGP(H.model);
   [errorRow,normRow]=stageErrors(H.model,s,D,Xe,evalRows);
   H.StageRMSE(end+1,:)=errorRow;
   H.StageNRMSE(end+1,:)=normRow;
   H.RMSE(end+1,1)=errorRow(end);
   H.ProposedScoreCalls(end+1,1)=stats.nProposed;
   H.ProjectedScoreCalls(end+1,1)=stats.nProjected;
   H.ProjectionDistance(end+1,1)=stats.distance;
   H.SearchSeconds(end+1,1)=stats.searchSec;
   H.RoundSeconds(end+1,1)=toc(t);
   H.RoundCompletedAt{end+1,1}=datestr(now,'yyyy-mm-dd HH:MM:SS.FFF');
   saveCheckpoint(fn,H,signature);
   fprintf('  %02d/%02d RMSE=%.6f score=%d+%d projDistance=%.3f\n', ...
    rr,S.rounds,H.RMSE(end),stats.nProposed,stats.nProjected,stats.distance);
  end
 end % all five methods for this seed
  % Each complete seed is published immediately; continue to the next seed.
  try
   refreshLiveReport(root,S,seed);
  catch liveErr
   fprintf(2,'LIVE report failed after seed %d: %s\n',seed,liveErr.message);
   writeLiveError(root,seed,liveErr);
   % Computed method checkpoints are never discarded because of reporting.
  end
end % next paired seed
end
function writeLiveError(root,seed,E)
f=fullfile(root,sprintf('LIVE_REPORT_seed%d.ERROR.txt',seed));
h=fopen(f,'w');if h<0,return;end
fprintf(h,'%s\n',getReport(E,'extended','hyperlinks','off'));fclose(h);
end

function refreshLiveReport(root,S,latestSeed)
% Rebuild current live tables from this run's signed checkpoints only.
% A completed 5-method seed is the atomic unit for cross-method ranking.
methods=S.methods;seeds=S.seeds;N=numel(seeds);M=numel(methods);
finish=false(N,M);F=NaN(N,M);A=NaN(N,M);INI=NaN(N,M);SEC=NaN(N,M);
bySeed=cell(0,7);
for i=1:N
 for j=1:M
  fn=checkpointFile(root,S.mode,'DEFAULT',seeds(i),methods{j});
  if ~isfile(fn),continue;end
  Z=load(fn,'H','signature');H=Z.H;sig=Z.signature;
  if numel(H.RMSE)~=S.rounds+1,continue;end
  if ~strcmp(sig.method,methods{j}) || sig.seed~=seeds(i) || ...
      sig.rounds~=S.rounds || ~strcmp(sig.mode,'formal')
   error('LIVE: unexpected method/seed/rounds signature in %s',fn);
  end
  if numel(H.ChosenRows)~=S.rounds || ...
      numel(unique(H.ChosenRows))~=S.rounds || any(~isfinite(H.RMSE))
   error('LIVE: invalid completed trajectory in %s',fn);
  end
  finish(i,j)=true;
  rr=H.RMSE(:);
  F(i,j)=rr(end);A(i,j)=trapz(0:S.rounds,rr')/S.rounds;
  INI(i,j)=rr(1);SEC(i,j)=sum(H.RoundSeconds);
  bySeed(end+1,:)={seeds(i),string(methods{j}),INI(i,j),F(i,j), ...
      A(i,j),SEC(i,j),string(sig.freshRunId)}; %#ok<AGROW>
 end
end
res=fullfile(root,'RESULTS');if ~isfolder(res),mkdir(res);end
if ~isempty(bySeed)
 raw=cell2table(bySeed,'VariableNames',{'Seed','Method','InitialRMSE', ...
 'FinalRMSE','AULCRMSE','TotalSeconds','RunID'});
 writeLiveCsv(raw,fullfile(res,'LIVE_SEED_METHOD_RESULTS.csv'));
end
complete=all(finish,2);n=sum(complete);
if n>0
  sums=cell(M,7);
  for j=1:M
   jj=find(complete);
   sums(j,:)={string(methods{j}),n,mean(INI(jj,j)),mean(F(jj,j)), ...
    mean(A(jj,j)),mean(A(jj,j)./INI(jj,j)),mean(SEC(jj,j))};
  end
  R=cell2table(sums,'VariableNames',{'Method','CompletePairedSeeds', ...
   'MeanInitialRMSE','MeanFinalRMSE','MeanAULCRMSE', ...
   'MeanNormalizedAULC','MeanTotalSeconds'});
  R=sortrows(R,'MeanFinalRMSE','ascend');R.FinalRank=(1:M)';
  writeLiveCsv(R,fullfile(res,'LIVE_FIVE_METHOD_SUMMARY.csv'));
  ps=cell(0,6);
  for i=find(complete)'
   for j=1:M-1
    ps(end+1,:)={seeds(i),string(methods{j}), ...
     F(i,M),F(i,j),F(i,j)-F(i,M),A(i,j)-A(i,M)}; %#ok<AGROW>
   end
  end
  pairs=cell2table(ps,'VariableNames',{'Seed','Competitor', ...
   'CoCAQFinalRMSE','CompetitorFinalRMSE', ...
   'CompetitorMinusCoCAQFinal','CompetitorMinusCoCAQAULC'});
  writeLiveCsv(pairs,fullfile(res,'LIVE_PAIRED_BY_SEED.csv'));
  fprintf('\n[LIVE] %d/%d complete paired seeds, latest %d\n', ...
    n,N,latestSeed);disp(R);
else
  fprintf('[LIVE] Waiting for first full 5-method seed.\n');
end
f=fullfile(res,'LIVE_STATUS.txt');h=fopen([f '.tmp'],'w');
assert(h>=0,'Could not open live progress status');
fprintf(h,'Last update: %s\n',datestr(now,'yyyy-mm-dd HH:MM:SS'));
fprintf(h,'Completed paired seeds: %d / %d\n',n,N);
fprintf(h,'Complete method-seed trajectories: %d / %d\n',sum(finish(:)),N*M);
fprintf(h,'Planned rounds per method-seed: %d\n',S.rounds);
fprintf(h,'Latest seed checkpointed: %d\n',latestSeed);
fprintf(h,'No old checkpoint files are read; only current-run checkpoints.\n');
fclose(h);[ok,msg]=movefile([f '.tmp'],f,'f');assert(ok,'%s',msg);
end

function writeLiveCsv(T,fn)
tmp=[fn '.tmp.csv'];writetable(T,tmp);
[ok,msg]=movefile(tmp,fn,'f');assert(ok,'Failed to replace live CSV: %s',msg);
end

function H=initRun(D,s,Xe,Ye,evalRows,initRows,method,seed)
X0=D.X(initRows,:);Y0=D.Y(initRows,:);
model=GCF_fit(s,X0,Y0,'cascade');
[stageRMSE,stageNRMSE]=stageErrors(model,s,D,Xe,evalRows);
H=struct('method',method,'seed',seed,'initRows',initRows(:), ...
 'rows',initRows(:),'X',X0,'Y',Y0,'model',model, ...
 'GPTrace',{{snapshotGP(model)}}, ...
 'StageRMSE',stageRMSE,'StageNRMSE',stageNRMSE, ...
 'RMSE',stageRMSE(end), ...
 'ChosenRows',zeros(0,1),'ProposedScoreCalls',zeros(0,1), ...
 'ProjectedScoreCalls',zeros(0,1),'ProjectionDistance',zeros(0,1), ...
 'SearchSeconds',zeros(0,1),'RoundSeconds',zeros(0,1));
end
function [er,nrmse]=stageErrors(model,s,D,Xe,evalRows)
% Fully cascaded predictions (NEVER test-row oracle inputs).
assert(~isempty(evalRows));
[p,~,~,~,~]=GCF_cascade_predict(model,s,Xe);
truth=D.Y(evalRows,:);
err=bsxfun(@times,p-truth,D.yScale);
er=sqrt(mean(err.^2,1));
spread=std(bsxfun(@times,truth,D.yScale),0,1);
nrmse=er./max(spread,1e-8);
end

function r=chooseEvalRows(allRows,n)
% Fixed deterministic temporal subsample with no seed-dependent test picking.
if numel(allRows)<=n,r=allRows(:);return;end
idx=unique(round(linspace(1,numel(allRows),n)));
r=allRows(idx(:));
end
function [chosen,stat]=selectPool(D,s,H,S,override,seed)
% Optimizers propose continuous [0,1]^D settings; label acquisition is
% restricted to an actual available record. Each uses identical top-proposal
% nearest-neighbor projection and EXACTLY nProjection pool scores.
remaining=setdiff(D.poolIdx,H.rows,'stable');
assert(numel(remaining)>=S.nProjection,'Pool exhausted.');
Xref=GCF_halton(S.nRef,s.d,20000+seed);
if strcmp(H.method,'V4A_BEST_V00')
 F=GCF_fastgi_build(H.model,s,Xref,S.rank);
 evalFn=@(X)GCF_fastgi_eval(F,X);
 gradFn=@(X)fastGiGradient(F,X);
else
 F=GCF_chain_build(H.model,s,Xref);
 evalFn=@(X)GCF_chain_eval(F,X);
 gradFn=[];
end
assert(isstruct(override) && isscalar(override), ...
 'Expected a scalar STRUCT parameter override for %s, got %s. ', ...
 H.method,class(override));
c=mappoConfig(S);fields=fieldnames(override);
for j=1:numel(fields),c.(fields{j})=override.(fields{j});end
t=tic;
switch H.method
 case 'A2'
  [o,meta]=GCF_cmaes(evalFn,[],S.nAcq,s.d,c,seed);
 case {'A3_IPPO','A4_MAPPO','A5_GP_MAPPO'}
  [o,meta]=GCF_gpcoop_ppo(evalFn,H.model,s,S.nAcq,c,H.method,seed);
 case 'V4A_BEST_V00'
  [o,meta]=GCF_mappo_v4(evalFn,gradFn,H.model,s,S.nAcq,c, ...
   'A5GRAD_V4A',seed);
 otherwise,error('Unknown method');
end
assert(meta.RewardCalls==S.nAcq,'Proposal score budget violated.');
% Project the 32 highest-ranked scored continuous proposals to 32 distinct,
% unlabeled, actual historical records. Fill any collisions using fixed pool
% candidates (seeded; does not inspect withheld pool labels).
[~,order]=sort(o.allR(:),'descend');
order=order(1:min(S.nAcq,max(4*S.nProjection,64)));
Xpool=D.X(remaining,:);
used=false(numel(remaining),1);candidate=zeros(S.nProjection,1);
projDistance=zeros(S.nProjection,1);q=0;
for j=1:numel(order)
 x=o.allX(order(j),:);
 dist=sum(bsxfun(@minus,Xpool,x).^2,2);
 dist(used)=inf;
 [best,at]=min(dist);
 if ~isfinite(best),break;end
 % Avoid using the same row if many proposals map to one nearest position.
 if ~used(at)
  q=q+1;used(at)=true;
  candidate(q)=remaining(at);projDistance(q)=sqrt(best);
 end
 if q>=S.nProjection,break;end
end
if q<S.nProjection
 rng(seed+991,'twister');fill=find(~used);
 fill=fill(randperm(numel(fill),S.nProjection-q));
 candidate(q+1:end)=remaining(fill);
 projDistance(q+1:end)=NaN;
end
% Score each projected point under the SAME acquisition objective used by
% this method. Number of *extra* scores is identical for every method.
[r,~]=evalFn(D.X(candidate,:));
assert(numel(r)==S.nProjection && all(isfinite(r)));
[~,ix]=max(r);chosen=candidate(ix);
assert(~ismember(chosen,H.rows) && ismember(chosen,D.poolIdx));
stat=struct('nProposed',S.nAcq,'nProjected',S.nProjection, ...
 'distance',projDistance(ix),'searchSec',toc(t));
end
function g=fastGiGradient(F,X)
[~,~,g]=GCF_fastgi_eval(F,X);
end
function c=mappoConfig(S)
c=GCF_config('full');c=c.mappo;
c.hidden=64;c.batch=32;c.nEpoch=14;c.nHiddenLayers=2;
c.minEpochsV5=14;c.minHiddenV5=64;
c.v4FreshFraction=.50;c.v4DiversityWeight=.20;
c.v4DistanceScale=.30;c.v4CurrentBonus=.05;
c.v4FeedbackCap=16;c.v4FeedbackMinDist=.08;
c.v4MinGainFrac=1e-7;c.v4GainPriority=.55;
c.v4FeedbackLogWeight=.75;
c.nAnchors=S.nAnchors;
c.ppoTargetKL=.03;c.ppoMinEpoch=2;
c.ppoActorGradMaxNorm=1.0;c.ppoCriticGradMaxNorm=3.0;
c.ppoSigmaGradMaxNorm=1.0;c.ppoExploreEntropyCoeff=.005;
c.ppoExploreMinSigma=.60;c.ppoEntropyCoeff=0;
end

function fn=checkpointFile(root,mode,group,seed,method)
fn=fullfile(root,'results',upper(mode),group, ...
 sprintf('seed%05d_%s.mat',seed,method));
end
function saveCheckpoint(fn,H,signature)
folder=fileparts(fn);if ~isfolder(folder),mkdir(folder);end
f=[fn '.tmp.mat'];save(f,'H','signature','-v7.3');
[ok,msg]=movefile(f,fn,'f');assert(ok,'Checkpoint failure: %s',msg);
end
function printStatus(root)
f=fullfile(root,'results');
if ~isfolder(f),fprintf('No studies have been run.\n');return;end
modes={'SMOKE','TUNE','FORMAL'};
for j=1:numel(modes)
 ff=dir(fullfile(f,modes{j},'**','seed*.mat'));
 fprintf('%s: %d checkpoint files\n',modes{j},numel(ff));
end
gplock=fullfile(f,'TUNING','GP_LOCK.mat');
if isfile(gplock),fprintf('GP POLICY LOCK EXISTS: %s\n',gplock);end
lock=fullfile(f,'TUNING','LOCKED_PARAMS.mat');
if isfile(lock),fprintf('LOCK EXISTS: %s\n',lock);else,fprintf('Not tuned yet.\n');end
end
function generateReport(root)
folder=fullfile(root,'results','REPORTS');if ~isfolder(folder),mkdir(folder);end
methods={'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_BEST_V00'};
% Each report row is one completed method/seed; incomplete checkpoints are
% excluded from summary, but can resume without being overwritten.
allRuns=cell(0,11);allCurves=cell(0,6);gpRows=cell(0,14);stageRows=cell(0,8);
for phase={'SMOKE','TUNE','FORMAL'}
 mode=phase{1};files=dir(fullfile(root,'results',mode,'**','seed*.mat'));
 for j=1:numel(files)
  fn=fullfile(files(j).folder,files(j).name);
  z=load(fn,'H','signature');H=z.H;sig=z.signature;
  if numel(H.RMSE)~=sig.rounds+1,continue;end
  curve=H.RMSE(:);
  a=trapz(0:sig.rounds,curve')/sig.rounds;
  allRuns(end+1,:)={string(mode),string(sig.group),string(H.method), ...
   H.seed,curve(1),curve(end),a, ...
   sum(H.ProposedScoreCalls),sum(H.ProjectedScoreCalls), ...
   sum(H.RoundSeconds),mean(H.ProjectionDistance,'omitnan')}; %#ok<AGROW>
  for rr=0:sig.rounds
   allCurves(end+1,:)={string(mode),string(sig.group), ...
    string(H.method),H.seed,rr,curve(rr+1)}; %#ok<AGROW>
  end
  if isfield(H,'StageRMSE') && size(H.StageRMSE,1)==numel(curve)
   for rr=0:sig.rounds
    for kk=1:4
     stageRows(end+1,:)={string(mode),string(sig.group), ...
      string(H.method),H.seed,rr,kk, ...
      H.StageRMSE(rr+1,kk),H.StageNRMSE(rr+1,kk)}; %#ok<AGROW>
    end
   end
  end
  if isfield(H,'GPTrace') && numel(H.GPTrace)==numel(curve)
   for rr=0:sig.rounds
    st=H.GPTrace{rr+1};
    for kk=1:numel(st)
     g=st(kk);
     gpRows(end+1,:)={string(mode),string(sig.group), ...
      string(H.method),H.seed,rr,kk,string(g.Profile),g.NLL, ...
      g.SignalStd,g.NoiseStd,g.NoiseRatio,g.MinEll,g.MedianEll, ...
      g.MaxEll}; %#ok<AGROW>
    end
   end
  end
 end
end
if isempty(allRuns)
 fprintf('No completed runs yet. No report created.\n');return;
end
R=cell2table(allRuns,'VariableNames',{'Phase','Group','Method', ...
 'Seed','InitialRMSE','FinalRMSE','MeanAULCRMSE', ...
 'ProposalCalls','ProjectionCalls','TotalSeconds','MeanProjectionDistance'});
C=cell2table(allCurves,'VariableNames',{'Phase','Group','Method', ...
 'Seed','Round','RMSE'});
writetable(R,fullfile(folder,'ALL_COMPLETED_RUNS.csv'));
writetable(C,fullfile(folder,'ALL_COMPLETED_CURVES.csv'));
if ~isempty(stageRows)
 J=cell2table(stageRows,'VariableNames',{'Phase','Group','Method', ...
  'Seed','Round','Stage','RMSE','NRMSE'});
 writetable(J,fullfile(folder,'STAGE_ALL_CURVES.csv'));
 J=J(J.Phase=="FORMAL" & J.Group=="DEFAULT",:);
 stageSummary=table();
 for kk=1:4
  for mm=1:numel(methods)
   jj=J(J.Stage==kk & J.Method==string(methods{mm}),:);
   ini=jj(jj.Round==0,:);fin=jj(jj.Round==30,:);
   if isempty(ini)||isempty(fin),continue;end
   one=table(kk,string(methods{mm}),height(fin), ...
    mean(ini.RMSE),mean(fin.RMSE),mean(ini.NRMSE),mean(fin.NRMSE), ...
    'VariableNames',{'Stage','Method','CompletedSeeds', ...
    'MeanInitialRMSE','MeanFinalRMSE','MeanInitialNRMSE','MeanFinalNRMSE'});
   stageSummary=[stageSummary;one]; %#ok<AGROW>
  end
 end
 if ~isempty(stageSummary)
  writetable(stageSummary,fullfile(folder,'STAGE_FORMAL_SUMMARY.csv'));
 end
end

if ~isempty(gpRows)
 G=cell2table(gpRows,'VariableNames',{'Phase','Group','Method', ...
  'Seed','Round','Stage','GPProfile','NLL','SignalStd', ...
  'NoiseStd','NoiseRatio','MinLengthscale','MedianLengthscale', ...
  'MaxLengthscale'});
 writetable(G,fullfile(folder,'GP_HYPERPARAMETERS.csv'));
end
summary=cell(0,8);
for phase={'SMOKE','TUNE','FORMAL'}
 pp=phase{1};for k=1:numel(methods)
  ix=R.Phase==string(pp) & R.Method==string(methods{k});
  if ~any(ix),continue;end
  T=R(ix,:);
  summary(end+1,:)={string(pp),string(methods{k}),height(T), ...
   mean(T.InitialRMSE),mean(T.FinalRMSE), ...
   mean(T.MeanAULCRMSE),sum(T.ProposalCalls), ...
   mean(T.MeanProjectionDistance,'omitnan')}; %#ok<AGROW>
 end
end
M=cell2table(summary,'VariableNames',{'Phase','Method','CompletedSeeds', ...
 'MeanInitialRMSE','MeanFinalRMSE','MeanAULCRMSE', ...
 'ProposalCalls','MeanProjectionDistance'});
writetable(M,fullfile(folder,'METHOD_SUMMARY.csv'));
% Strict paired-seed comparisons only, using FORMAL & DEFAULT.
F=R(R.Phase=="FORMAL" & R.Group=="DEFAULT",:);
pair=cell(0,6);
for k=1:numel(methods)
 name=methods{k};if strcmp(name,'V4A_BEST_V00'),continue;end
 A=F(F.Method=="V4A_BEST_V00",:);B=F(F.Method==string(name),:);
 common=intersect(A.Seed,B.Seed);
 for ii=1:numel(common)
  ss=common(ii);aa=A(A.Seed==ss,:);bb=B(B.Seed==ss,:);
  pair(end+1,:)={string(name),ss,aa.FinalRMSE,bb.FinalRMSE, ...
   bb.FinalRMSE-aa.FinalRMSE,bb.MeanAULCRMSE-aa.MeanAULCRMSE}; %#ok<AGROW>
 end
end
if ~isempty(pair)
 P=cell2table(pair,'VariableNames',{'Competitor','Seed','V4AFinalRMSE', ...
 'CompetitorFinalRMSE','CompetitorMinusV4A','CompetitorMinusV4AAULC'});
 writetable(P,fullfile(folder,'PAIRED_TO_V4A.csv'));
end
fprintf('REPORTS: %s\n',folder);
disp(M);
end

function strictFreshReport(root,D,s,meta,z)
% Enforce evidence of exactly N*M newly generated checkpoints and N*M*R rounds.
methods={'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_BEST_V00'};
seeds=l06FormalSeeds();N=numel(seeds);M=5;R=30;
F=zeros(N,M);A=zeros(N,M);INI=zeros(N,M);SEC=zeros(N,M);
curves=zeros(R+1,N,M);roundTimes=zeros(R,N,M);rows=cell(N*M,12);roundLog=cell(N*M*R,9);
q=0;v=0;numVerified=0;
for si=1:N
 seed=seeds(si);
 rng(555000+seed,'twister');expectedInit=D.poolIdx(randperm(numel(D.poolIdx),s.nInitial));
 for mi=1:M
  method=methods{mi};
  fn=checkpointFile(root,'formal','DEFAULT',seed,method);
  assert(isfile(fn),'FRESH FORMAL INCOMPLETE: missing %s',fn);
  X=load(fn,'H','signature');H=X.H;sig=X.signature;
  assert(strcmp(sig.freshRunId,meta.RunID) && ...
   strcmp(sig.sourceHash,meta.SourceHash) && ...
   strcmp(H.FreshRunId,meta.RunID) && strcmp(sig.mode,'formal') && ...
   strcmp(sig.group,'DEFAULT') && strcmp(sig.method,method) && ...
   sig.seed==seed && sig.rounds==30 && sig.nAcq==300 && ...
   sig.nProjection==32 && sig.nRef==256 && sig.rank==32 && ...
   sig.nEval==512 && sig.nInitial==50 && ...
   isequal(sig.stageDims,[5 3 3 2]) && ...
   strcmp(sig.lock,z.fingerprint), 'FRESH PROTOCOL MISMATCH: %s',fn);
  assert(isequaln(sig.gpOptsStages,s.gpOptsStages) && ...
   isequal(sig.evalRows,chooseEvalRows(D.testIdx,512)), ...
   'GP or CHECK rows mismatch: %s',fn);
  assert(isequal(H.initRows(:),expectedInit(:)) && ...
   numel(H.RMSE)==31 && all(isfinite(H.RMSE)) && ...
   numel(H.ChosenRows)==30 && numel(unique(H.ChosenRows))==30 && ...
   isempty(intersect(H.ChosenRows,H.initRows)) && ...
   all(ismember(H.ChosenRows,D.poolIdx)) && ...
   size(H.X,1)==80 && size(H.Y,1)==80 && ...
   isequal(H.rows(:),[H.initRows(:);H.ChosenRows(:)]) && ...
   isequal(H.X,D.X(H.rows,:)) && isequal(H.Y,D.Y(H.rows,:)), ...
   'Training/queries incomplete: %s',fn);
  assert(numel(H.ProposedScoreCalls)==30 && ...
   all(H.ProposedScoreCalls==300) && ...
   numel(H.ProjectedScoreCalls)==30 && ...
   all(H.ProjectedScoreCalls==32) && ...
   numel(H.RoundSeconds)==30 && all(isfinite(H.RoundSeconds)) && ...
   all(H.RoundSeconds>0) && numel(H.RoundCompletedAt)==30, ...
   'Did not record 30 real compute rounds: %s',fn);
  for rr=1:R
   t=datenum(H.RoundCompletedAt{rr},'yyyy-mm-dd HH:MM:SS.FFF');
   assert(t>=meta.CreatedSerial-1/86400 && t<=now+1/86400, ...
    'Checkpoint date predates fresh run: %s',fn);
  end
  if strcmp(method,'A2') || strcmp(method,'A3_IPPO')
   assert(isempty(fieldnames(sig.override)),'Untuned A2 or A3 was overridden.');
  else
   assert(isequaln(sig.override,z.params.(method)), ...
    'Formal override did not match newly frozen tune lock.');
  end
  rr=H.RMSE(:);INI(si,mi)=rr(1);F(si,mi)=rr(end);
  A(si,mi)=trapz(0:R,rr')/R;SEC(si,mi)=sum(H.RoundSeconds);
  curves(:,si,mi)=rr;roundTimes(:,si,mi)=H.RoundSeconds(:);
  q=q+1;
  rows(q,:)={string(method),seed,rr(1),rr(end),A(si,mi), ...
   sum(H.ProposedScoreCalls),sum(H.ProjectedScoreCalls), ...
   SEC(si,mi),string(meta.RunID),numel(H.ChosenRows), ...
   string(sig.sourceHash),string(fn)};
  for j=1:R
   v=v+1;roundLog(v,:)={string(method),seed,j, ...
    H.ChosenRows(j),H.RMSE(j),H.RMSE(j+1), ...
    H.RoundSeconds(j),string(H.RoundCompletedAt{j}),string(meta.RunID)};
  end
  numVerified=numVerified+1;
 end
 assert(max(abs(INI(si,:)-INI(si,1)))<=1e-8, ...
  'Initial RMSE differs by method for seed %d.',seed);
end
assert(numVerified==N*M && v==N*M*R,'Incomplete fresh formal run.');
res=fullfile(root,'RESULTS');if ~isfolder(res),mkdir(res);end
T=cell2table(rows,'VariableNames',{'Method','Seed','InitialRMSE', ...
 'FinalRMSE','AULCRMSE','ProposedScores','ProjectedScores', ...
 'TotalSeconds','RunID','PurchasedLabels','SourceHash','CheckpointPath'});
writetable(T,fullfile(res,'ALL_TRAJECTORIES.csv'));
L=cell2table(roundLog,'VariableNames',{'Method','Seed','Round', ...
 'SelectedPoolRow','RMSEBefore','RMSEAfter','RoundSeconds', ...
 'CompletedAt','RunID'});
writetable(L,fullfile(res,'ALL_NEW_ROUNDS.csv'));
curv=cell(N*M*(R+1),4);cc=0;
for m=1:M
 for i=1:N
  for rr=0:R
   cc=cc+1;curv(cc,:)={string(methods{m}),seeds(i),rr,curves(rr+1,i,m)};
  end
 end
end
C=cell2table(curv,'VariableNames',{'Method','Seed','Round','RMSE'});
writetable(C,fullfile(res,'LEARNING_CURVES_BY_SEED.csv'));
summary=cell(M,9);
for m=1:M
 summary(m,:)={string(methods{m}),N,mean(INI(:,m)),mean(F(:,m)), ...
  mean(A(:,m)),mean(A(:,m)./INI(:,m)),mean(SEC(:,m)), ...
  mean(F(:,m)./INI(:,m)),300+32};
end
Q=cell2table(summary,'VariableNames',{'Method','NSeeds','MeanInitialRMSE', ...
 'MeanFinalRMSE','MeanAULCRMSE','MeanNormalizedAULC', ...
 'MeanTotalSeconds','MeanNormalizedFinal','ScoresPerRound'});
Q=sortrows(Q,{'MeanFinalRMSE','MeanAULCRMSE'},{'ascend','ascend'});
Q.FinalRank=(1:height(Q))';
writetable(Q,fullfile(res,'FIVE_METHOD_SUMMARY.csv'));
% Report intermediate budgets within the fixed 30-round experiment.
% These are descriptive results, not separate model-selection runs.
marks=[0 5 10 15 20 25 30];milestones=cell(numel(marks)*M,8);pos=0;
for mm=1:M
 for tt=marks
  pos=pos+1;
  values=reshape(curves(tt+1,:,mm),[],1);
  if tt==0
    auc=reshape(curves(1,:,mm),[],1);
  else
    auc=zeros(N,1);
    for kk=1:N,auc(kk)=trapz(0:tt,curves(1:tt+1,kk,mm)')/tt;end
  end
  base=reshape(curves(1,:,mm),[],1);
  if tt==0
   elapsed=0;
  else
   elapsed=mean(sum(roundTimes(1:tt,:,mm),1));
  end
  milestones(pos,:)={string(methods{mm}),tt,N,mean(values), ...
   mean(values./base),mean(auc),mean(auc./base),elapsed};
 end
end
milestoneTable=cell2table(milestones,'VariableNames',{ ...
 'Method','Round','NSeeds','MeanRMSE','MeanNormalizedRMSE', ...
 'MeanAULCRMSE','MeanNormalizedAULC','MeanTotalSecondsThroughRound'});
writetable(milestoneTable,fullfile(res,'MILESTONE_SUMMARY.csv'));
% Per-seed paired differences across budgets; no p-hacking or seed dropping.
miles=cell(numel(marks)*N*4,6);miRow=0;
for mm=1:4
 for tt=marks
  for kk=1:N
   miRow=miRow+1;
   miles(miRow,:)={string(methods{mm}),seeds(kk),tt, ...
    curves(tt+1,kk,mm)-curves(tt+1,kk,5), ...
    curves(tt+1,kk,mm),curves(tt+1,kk,5)};
  end
 end
end
milestonePairs=cell2table(miles,'VariableNames',{ ...
 'Competitor','Seed','Round','CompetitorMinusCoCAQ', ...
 'CompetitorRMSE','CoCAQRMSE'});
writetable(milestonePairs,fullfile(res,'MILESTONE_PAIRED_BY_SEED.csv'));
% Paired comparisons: positive competitor minus CoCAQ means CoCAQ better.
pair=cell(N*4,7);stat=cell(4,7);pc=0;
for m=1:4
 d=F(:,m)-F(:,5); da=A(:,m)-A(:,5);
 for i=1:N
  pc=pc+1;pair(pc,:)={string(methods{m}),seeds(i), ...
   F(i,5),F(i,m),d(i),da(i),SEC(i,m)-SEC(i,5)};
 end
 [lo,hi]=simpleBootstrap(d,5000,731+m);
 p=pairedSignFlipP(d,100000,9000+m);
 stat(m,:)={string(methods{m}),mean(d),lo,hi,p,sum(d>0),mean(da)};
end
P=cell2table(pair,'VariableNames',{'Competitor','Seed', ...
 'CoCAQFinalRMSE','CompetitorFinalRMSE', ...
 'CompetitorMinusCoCAQ','CompetitorMinusCoCAQAULC','SecondsDifference'});
writetable(P,fullfile(res,'PAIRED_BY_SEED.csv'));
J=cell2table(stat,'VariableNames',{'Competitor','MeanCompetitorMinusCoCAQ', ...
 'CI95Lower','CI95Upper','PairedSignFlipP','CoCAQWins','AULCDifference'});
writetable(J,fullfile(res,'PAIRED_SIGNIFICANCE.csv'));
provenance=fullfile(res,'FRESH_VERIFICATION.txt');
f=fopen(provenance,'w');assert(f>=0);
fprintf(f,'RUN_ID=%s\nCREATED=%s\nSOURCE_SHA256=%s\n', ...
 meta.RunID,meta.Created,meta.SourceHash);
fprintf(f,'VERIFIED_FORMAL_CHECKPOINTS=%d\nVERIFIED_FRESH_ROUNDS=%d\n',N*M,N*M*R);
if isfile(fullfile(root,'PATCH_MIGRATION_AUDIT.txt'))
 fprintf(f,'LEGACY_CORRUPT_LOCK_REPAIRED=YES\n');
 fprintf(f,'PREVIOUS_UNAFFECTED_A2_A3_CHECKPOINTS_PRESERVED=YES\n');
end
fprintf(f,'SCORES_PER_ROUND=300+32\nPURCHASED_POOL_RECORDS_PER_ROUND=1\n');
fprintf(f,'THIS_RUN_RETUNING=NO\nPARAM_SELECTION=PREVIOUS_SELECT_FROZEN\n');
fprintf(f,'FORMAL_ROUNDS=30\nFORMAL_SEEDS=30501:30600\n');
fprintf(f,'GP_PROFILE_SELECTION=PREVIOUS_L06_HYPER_FIXED\n');
fprintf(f,'A2_CMAES_TUNED=NO\nA3_IPPO_TUNED=NO\n');
fprintf(f,'MAPPO_A4_A5_PREVIOUS_SELECT_GRID1=YES\nCOCAQ_PREVIOUS_V6_SELECT_V00=YES\n');
fprintf(f,'WARNING=CHECK_PREVIOUSLY_INSPECTED_RETROSPECTIVE_NOT_BLIND\n');
fclose(f);
fprintf('100-SEED 30-ROUND FRESH RECOMPUTATION VERIFIED: %d/%d formal, %d/%d recorded rounds.\n',N*M,N*M,N*M*R,N*M*R);
fprintf('RESULTS: %s\n',res);disp(Q);disp(J);
end

function [lo,hi]=simpleBootstrap(x,B,seed)
old=rng;rng(seed,'twister'); n=numel(x);vv=zeros(B,1);
for i=1:B,vv(i)=mean(x(randi(n,n,1)));end
rng(old);vv=sort(vv);lo=vv(max(1,ceil(.025*B)));
hi=vv(min(B,ceil(.975*B)));
end

function p=pairedSignFlipP(d,B,seed)
% Exact when <=20 seeds; seeded Monte Carlo for larger samples.
% Monte Carlo output is estimated p-value, not an exact test.
d=double(d(:));n=numel(d);assert(n>=1 && all(isfinite(d)));
obs=abs(mean(d));
if n<=20
 total=2^n;moreExtreme=0;
 chunk=32768;bitsMask=zeros(1,n,'uint32');
 for k=1:n,bitsMask(k)=bitshift(uint32(1),k-1);end
 for start=0:chunk:(total-1)
  last=min(total-1,start+chunk-1);
  code=uint32((start:last)');
  signs=2*double(bsxfun(@ne,bsxfun(@bitand,code,bitsMask),uint32(0)))-1;
  means=(signs*d)/n;
  moreExtreme=moreExtreme+sum(abs(means)>=obs-1e-12);
 end
 p=moreExtreme/total;
else
 old=rng;cleanup=onCleanup(@()rng(old));rng(seed,'twister');
 extreme=0;batch=2000;done=0;
 while done<B
  k=min(batch,B-done);
  signs=2*double(rand(k,n)>.5)-1;
  extreme=extreme+sum(abs(signs*d/n)>=obs-1e-12);
  done=done+k;
 end
 p=(extreme+1)/(B+1);
end
end

function seeds=l06FormalSeeds()
% Predeclared new 30501-30600 cohort; 100 fixed paired seeds.
seeds=30501:30600;
assert(isnumeric(seeds) && isvector(seeds) && numel(seeds)==100 && ...
 all(isfinite(seeds)) && all(seeds>0) && all(fix(seeds)==seeds) && ...
 numel(unique(seeds))==100,'Expected 100 distinct positive integer seeds.');
seeds=double(seeds(:)).';
end

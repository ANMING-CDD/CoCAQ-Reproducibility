function [mu,v]=GCF_gp_predict(g,Q)
assert(size(Q,2)==size(g.X,2),'GCF GP query dimension mismatch.');
K=GCF_kernel(g.X,Q,g.ell);V=g.L\K;
mu=g.ym+g.ys*(K'*g.alpha);
if nargout>1
 v=(g.ys^2*g.signal2)*max(0,1-sum(V.^2,1)'); % latent uncertainty
end
end

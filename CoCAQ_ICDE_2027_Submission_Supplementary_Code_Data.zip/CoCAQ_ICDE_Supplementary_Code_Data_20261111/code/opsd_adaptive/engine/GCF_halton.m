function X=GCF_halton(n,d,skip)
if nargin<3,skip=128;end
% Preserve the exact original first 30 bases for legacy checkpoint parity.
% Add bases 31..50 for Ackley fixed-3-node horizontal experiments.
pr=[2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 ...
    73 79 83 89 97 101 103 107 109 113 ...
    127 131 137 139 149 151 157 163 167 173 ...
    179 181 191 193 197 199 211 223 227 229];
assert(d<=numel(pr),'Halton prime table too short for dimension %d.',d);
idx=(skip+1:skip+n)';X=zeros(n,d);
for j=1:d
 k=idx;f=1/pr(j);
 while any(k>0)
  X(:,j)=X(:,j)+f*mod(k,pr(j));k=floor(k/pr(j));f=f/pr(j);
 end
end
end

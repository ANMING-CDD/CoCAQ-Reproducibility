function [R,G]=GCF_chain_eval(F,X)
[~,~,Qcell]=GCF_cascade_predict(F.model,F.spec,X);
N=size(X,1);K=F.spec.K;G=zeros(N,K);
for k=1:K
 g=F.model.stage{k};Q=Qcell{k};Vc=g.L\GCF_kernel(g.X,Q,g.ell);
 C=g.ys^2*g.signal2*(GCF_kernel(F.Qref{k},Q,g.ell)-F.Vref{k}'*Vc);
 v=g.ys^2*g.signal2*max(0,1-sum(Vc.^2,1)');
 W=bsxfun(@times,C,F.sens{k});G(:,k)=mean(W.^2,1)'./max(v+g.ys^2*g.noise2,1e-14*g.ys^2*g.signal2);
end
G=max(0,G);R=sum(G,2);
end

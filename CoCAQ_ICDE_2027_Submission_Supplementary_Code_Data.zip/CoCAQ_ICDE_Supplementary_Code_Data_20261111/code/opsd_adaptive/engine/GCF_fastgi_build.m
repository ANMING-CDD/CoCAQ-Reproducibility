function F=GCF_fastgi_build(model,spec,Xref,rank)
% First-order nominal-cascade Nyström approximation of stagewise posterior IVR.
[~,~,Qref]=GCF_cascade_predict(model,spec,Xref);
N=size(Xref,1);K=spec.K;sens=cell(1,K);sens{K}=ones(N,1);
if strcmp(spec.kind,'horizontal_ackley_dag')
 sens{1}=GCF_gp_dmean(model.stage{3},Qref{3},1);
 sens{2}=GCF_gp_dmean(model.stage{3},Qref{3},2);
else
 for k=K-1:-1:1
  [pi,ps]=GCF_prev_coordinate(spec,k+1);
  sens{k}=sens{k+1}.*(GCF_gp_dmean(model.stage{k+1},Qref{k+1},pi)*ps);
 end
end
F=struct('model',model,'spec',spec,'Xref',Xref,'stage',{cell(1,K)}, ...
 'kind','first-order nominal-cascade Nystrom posterior IVR');
for k=1:K
 g=model.stage{k};Q=Qref{k};r=min(rank,N);
 Vref=g.L\GCF_kernel(g.X,Q,g.ell);
 diagC=g.ys^2*g.signal2*max(0,1-sum(Vref.^2,1)');
 PC=zeros(N,r);piv=zeros(r,1);num=0;
 for j=1:r
  [best,ix]=max(diagC);
  if best<=1e-12*max(g.ys^2*g.signal2,realmin),break;end
  num=num+1;piv(num)=ix;
  kc=g.ys^2*g.signal2*(GCF_kernel(Q,Q(ix,:),g.ell)-Vref'*Vref(:,ix));
  if j>1,kc=kc-PC(:,1:j-1)*PC(ix,1:j-1)';end
  PC(:,j)=kc/sqrt(max(best,realmin));diagC=max(0,diagC-PC(:,j).^2);diagC(ix)=0;
 end
 assert(num>0,'Fast-Gi posterior covariance is numerically zero at stage %d.',k);
 U=Q(piv(1:num),:);VU=Vref(:,piv(1:num));
 KUU=g.ys^2*g.signal2*(GCF_kernel(U,U,g.ell)-VU'*VU);KUU=(KUU+KUU')/2;
 ridge=max(1e-8*max(diag(KUU)),1e-14*g.ys^2*g.signal2);[L,p]=chol(KUU+ridge*eye(num),'lower');
 for attempt=1:8
  if p==0,break;end
  ridge=10*ridge;[L,p]=chol(KUU+ridge*eye(num),'lower');
 end
 assert(p==0,'Fast-Gi inducing covariance Cholesky failed at stage %d.',k);
 phi=L\(g.ys^2*g.signal2*(GCF_kernel(U,Q,g.ell)-VU'*Vref));
 ww=(sens{k}.^2)'/N;M=bsxfun(@times,phi,ww)*phi';M=(M+M')/2;
 st=struct('U',U,'L',L,'M',M,'VU',VU,'nRank',num,'sens',sens{k},'Qref',Q);
 F.stage{k}=st;
end
end
function [idx,scale]=GCF_prev_coordinate(spec,k)
if strcmp(spec.kind,'forrester')&&k==2
 idx=1;scale=.04;
elseif strcmp(spec.kind,'cascadebo_rosenbrock')
 idx=1;scale=.5;
elseif strcmp(spec.kind,'horizontal_ackmat')
 idx=2;scale=.05;
elseif strcmp(spec.kind,'horizontal_rosen')
 idx=numel(MSBO_stage_idx(spec,k))+2;scale=spec.rosenPrevScale;
elseif strcmp(spec.kind,'bofn_alpine2')
 idx=2;scale=10^(-(k-1)/2);
else
 idx=numel(MSBO_stage_idx(spec,k))+1;scale=1;
end
end

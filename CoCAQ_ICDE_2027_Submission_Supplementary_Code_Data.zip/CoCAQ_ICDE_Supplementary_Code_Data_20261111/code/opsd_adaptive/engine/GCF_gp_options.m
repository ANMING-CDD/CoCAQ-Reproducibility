function o=GCF_gp_options(name)
% Fixed, preregistered hyperparameter search PROFILES; tuned on validation.
% Each profile still learns distinct ell_1..ell_d, signal2 and noise2 for
% every stage and every data-enrichment step from acquired training labels.
if nargin<1 || isempty(name),name='balanced';end
switch lower(char(name))
 case 'smooth'
  o=struct('name','smooth','ellMin',.08,'ellMax',6, ...
   'noiseMin',.01,'noiseMax',6,'maxIter',42,'maxEvals',180);
 case 'balanced'
  o=struct('name','balanced','ellMin',.035,'ellMax',4, ...
   'noiseMin',.0003,'noiseMax',4,'maxIter',50,'maxEvals',220);
 case 'flexible'
  o=struct('name','flexible','ellMin',.02,'ellMax',3, ...
   'noiseMin',1e-5,'noiseMax',2,'maxIter',55,'maxEvals',240);
 otherwise
  error('Unknown GP profile %s',char(name));
end
end

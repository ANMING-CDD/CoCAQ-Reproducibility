function g=GCF_gp_fit(X,y,previous,opts)
% GCF_GP_FIT  Adaptive ARD-RBF GP with learned noise and signal variance.
% Hyperparameters are refit on TRAINING labels at every acquisition round.
% The kernel linear system is A = K_ARD + (sn2/sf2 + jitter)*I.
% We profile signal variance sf2 analytically during ML-II optimization.
% All GP components use the same normalized kernel factorization; in the
% original output units, latent variance = ys^2 * sf2 * (1-k'*A^-1*k).
% No MATLAB Optimization or Statistics toolbox required (fminsearch).
if nargin<3 || isempty(previous), previous=[];end
if nargin<4 || isempty(opts), opts=GCF_gp_options('balanced');end
assert(isnumeric(X) && isnumeric(y) && size(X,1)==numel(y));
assert(all(isfinite(X(:))) && all(isfinite(y(:))));
y=y(:);n=numel(y);d=size(X,2);
g=struct();g.X=X;g.ym=mean(y);g.ys=std(y);
if ~isfinite(g.ys) || g.ys<1e-10,g.ys=1;end
z=(y-g.ym)/g.ys;
g.gpProfile=opts.name;g.jitter=1e-9;
if isempty(previous) || ~isfield(previous,'fitCount')
 g.fitCount=1;
else
 g.fitCount=previous.fitCount+1;
end
% Candidate starts are deterministic and do not inspect any validation/test labels.
seedEll=max(opts.ellMin,min(opts.ellMax,.6*ones(1,d)));
starts=[log(seedEll),log(.10)];
if isempty(previous)
 starts=[starts;log(max(opts.ellMin,min(opts.ellMax,1.8*ones(1,d)))),log(.70)];
 starts=[starts;log(max(opts.ellMin,min(opts.ellMax,.15*ones(1,d)))),log(.015)];
else
 if isfield(previous,'ell') && numel(previous.ell)==d && ...
    isfield(previous,'noiseRatio') && all(isfinite(previous.ell))
  starts=[log(max(opts.ellMin,min(opts.ellMax,previous.ell(:)'))), ...
      log(max(opts.noiseMin,min(opts.noiseMax,previous.noiseRatio)))];
 end
 if mod(g.fitCount,5)==0
  starts=[starts;log(seedEll),log(.10)];
 end
end
% Enforce feasible parameters using bounds in the objective, rather than
% silently clamping the optimizer's returned values after fitting.
best=inf;theta=starts(1,:);
fo=optimset('Display','off','MaxIter',opts.maxIter, ...
 'MaxFunEvals',opts.maxEvals,'TolX',2e-2,'TolFun',2e-3);
for j=1:size(starts,1)
 [u,score]=fminsearch(@(q)gpNLL(q,X,z,opts,g.jitter),starts(j,:),fo);
 if ~isfinite(score),continue;end
 [v,~,~,~,~]=gpNLL(u,X,z,opts,g.jitter);
 if v<best,best=v;theta=u;end
end
[best,sf2,L,a,eta]=gpNLL(theta,X,z,opts,g.jitter);
if ~isfinite(best) || isempty(L)
 error('Adaptive GP optimization failed: stage input dimension %d, n=%d.',d,n);
end
g.ell=exp(theta(1:d));g.signal2=sf2;g.noiseRatio=eta;
g.noise2=sf2*eta;g.noiseStd=g.ys*sqrt(g.noise2);
g.signalStd=g.ys*sqrt(g.signal2);
g.nll=best;g.L=L;g.alpha=a;
g.fitMode='ARD_RBF_PROFILE_MLII_ADAPTIVE_NOISE_V2';
end

function [val,sf2,L,a,eta]=gpNLL(theta,X,z,opts,jitter)
n=numel(z);d=size(X,2);val=1e12;sf2=NaN;L=[];a=[];eta=NaN;
if any(~isfinite(theta)),return;end
low=[log(opts.ellMin)*ones(1,d),log(opts.noiseMin)];
high=[log(opts.ellMax)*ones(1,d),log(opts.noiseMax)];
if any(theta<low) || any(theta>high)
 val=1e9+1e7*sum(max(0,low-theta).^2+max(0,theta-high).^2);
 return;
end
ell=exp(theta(1:d));eta=exp(theta(end));
try
 K=GCF_kernel(X,X,ell);K=(K+K')/2;
 [L,p]=chol(K+(eta+jitter)*eye(n),'lower');
 if p~=0,L=[];return;end
 a=L'\(L\z);
 quad=max(0,z'*a);
 % Exact profile MLE of signal variance (output already standardized).
 sf2=max(1e-6,min(100,quad/n));
 val=.5*quad/sf2+.5*n*log(sf2)+sum(log(diag(L)))+ ...
     .5*n*log(2*pi);
 if ~isfinite(val),val=1e12;L=[];end
catch
 val=1e12;L=[];
end
end

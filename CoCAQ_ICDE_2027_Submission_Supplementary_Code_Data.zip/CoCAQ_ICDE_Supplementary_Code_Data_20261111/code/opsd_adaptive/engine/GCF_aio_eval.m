function [R,G]=GCF_aio_eval(F,X)
g=F.g;K=GCF_kernel(g.X,X,g.ell);V=g.L\K;
C=g.ys^2*g.signal2*(GCF_kernel(F.Xref,X,g.ell)-F.Vref'*V);
v=g.ys^2*g.signal2*max(0,1-sum(V.^2,1)');
R=mean(C.^2,1)'./max(v+g.ys^2*g.noise2,1e-14*g.ys^2*g.signal2);R=max(0,R);
G=R;
end

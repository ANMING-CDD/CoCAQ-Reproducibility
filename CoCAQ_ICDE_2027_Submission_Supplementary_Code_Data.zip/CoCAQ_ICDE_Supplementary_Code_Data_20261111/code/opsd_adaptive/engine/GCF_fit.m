function model=GCF_fit(spec,X,Y,kind,previous)
if nargin<5,previous=[];end
gpOpts=[];if isfield(spec,'gpOpts'),gpOpts=spec.gpOpts;end
model=struct('kind',kind,'specId',spec.id,'K',spec.K,'p',spec.p,'d',spec.d);
if strcmp(kind,'aio')
 prev=[];if ~isempty(previous)&&isfield(previous,'aio'),prev=previous.aio;end
 model.aio=GCF_gp_fit(X,Y(:,end),prev,gpOpts);return;
end
model.stage=cell(1,spec.K);
for k=1:spec.K
 Q=GCF_stage_input(spec,X,Y,k);prev=[];
 if ~isempty(previous)&&isfield(previous,'stage')&&numel(previous.stage)>=k,prev=previous.stage{k};end
 optsK=gpOpts;
 if isfield(spec,'gpOptsStages') && numel(spec.gpOptsStages)>=k
  optsK=spec.gpOptsStages{k};
 end
 model.stage{k}=GCF_gp_fit(Q,Y(:,k),prev,optsK);
end
end

function [R,G,grad]=GCF_fastgi_eval(F,X)
% Fast-Gi score and exact analytic derivative of this fixed low-rank surrogate.
[~,~,Qcell,Jcell]=GCF_cascade_predict(F.model,F.spec,X);
N=size(X,1);K=F.spec.K;d=F.spec.d;G=zeros(N,K);
if nargout>=3,grad=zeros(N,d);else,grad=[];end
for k=1:K
 g=F.model.stage{k};st=F.stage{k};Q=Qcell{k};J=Jcell{k};
 Kc=GCF_kernel(g.X,Q,g.ell);Vc=g.L\Kc;
 v=g.ys^2*g.signal2*max(0,1-sum(Vc.^2,1)');
 KU=GCF_kernel(st.U,Q,g.ell);cross=g.ys^2*g.signal2*(KU-st.VU'*Vc);
 phi=st.L\cross;Mphi=st.M*phi;
 numer=sum(phi.*Mphi,1)';den=max(v+g.ys^2*g.noise2,1e-14*g.ys^2*g.signal2);
 G(:,k)=max(0,numer./den);
 if nargout>=3
  for n=1:N
   if numer(n)<=0,continue;end
   for j=1:size(Q,2)
    dK=Kc(:,n).*((g.X(:,j)-Q(n,j))/(g.ell(j)^2));dV=g.L\dK;
    dKU=KU(:,n).*((st.U(:,j)-Q(n,j))/(g.ell(j)^2));dphi=st.L\(g.ys^2*g.signal2*(dKU-st.VU'*dV));
    dn=2*dphi'*Mphi(:,n);dv=-2*g.ys^2*g.signal2*(dV'*Vc(:,n));
    ds=dn/den(n)-numer(n)*dv/(den(n)^2);
    jac=reshape(J(n,j,:),1,d);grad(n,:)=grad(n,:)+ds*jac;
   end
  end
 end
end
G=max(0,G);R=sum(G,2);
end

# L06 五算法 · 100 个独立种子 × 30 轮 · 通宵自动运行

## 这次跑什么

- **仅固定参数正式对比**，不进行梯度消融、不再调参。
- 五方法：`A2` (CMA-ES)、`A3_IPPO`、`A4_MAPPO`、`A5_GP_MAPPO`、`V4A_BEST_V00` (CoCAQ)。
- **100 个配对新种子：`30501:30600`**。每个种子五方法共用同一批 50 条初始标注及同一 CHECK 子集。
- 每种方法每 seed **30 轮**；每轮仅买 1 条 L06 历史记录，连续候选 300 次评分 + 投影重评分 32 次。
- 共 100 × 5 × 30 = **15,000 轮**，500 条方法-种子轨迹。
- CoCAQ 使用 V6 SELECT 冻结的 V00；A4/A5 使用此前原 L06 SELECT 的 Grid1；GP profile 仍为 smooth/smooth/smooth/flexible。
- 新种子和 30 轮查询预算是预先固定的；结果无论排名如何，都应报告所有种子。历史 CHECK 已被查看过，仍是回顾性测试，**不是新的独立盲测**。

## 放在哪个目录

**完整 ZIP** 解压后得到：

`C:\MAPPO整合\CoCAQ_L06_OVERNIGHT_100SEEDS_30R\`

其 `data/` 内已经包含 `OPSD_DE_2019_20D_ALIGNED.mat` 和 `FROZEN_LARGE_FOR_COCAQ.mat`，不需要另放数据。

**补丁 ZIP** 则把 `RUN_L06_OVERNIGHT.m`、本说明和冻结文件放进你已有的 `C:\MAPPO整合\CoCAQ_L06_V00_150R_FIXED\`，保留原 `engine/`、`data/`、`OPSD_load_L06.m` 不动。

## 运行命令

```matlab
cd('C:\MAPPO整合\CoCAQ_L06_OVERNIGHT_100SEEDS_30R')
clear functions
rehash
RUN_L06_OVERNIGHT('check');
RUN_L06_OVERNIGHT('new');
```

新实验会运行到 **全部 100 个种子完成为止**，不需要每个 seed 人工操作。MATLAB 保持打开，电脑不要睡眠或休眠。`new` 每次创建一个全新实验，**中断后不要再次执行 `new`**。

意外中断（MATLAB 崩溃、断电或手动 Ctrl+C）后：

```matlab
RUN_L06_OVERNIGHT('status');
RUN_L06_OVERNIGHT('resume');
```

`resume` 从本次目录的本次 seed 已保存的最后一轮继续，已有轮次不重算；每完成一轮就更新 checkpoint。

## 睡醒后在哪里看

`overnight_100seed_runs\FRESH_时间戳\RESULTS\`

运行时每完成一个完整的 seed (五种算法都完成30轮)，以下文件会更新：

- `LIVE_STATUS.txt`：目前完成了多少个种子。
- `LIVE_SEED_METHOD_RESULTS.csv`：逐 seed、逐方法的 Final RMSE、AULC、耗时。
- `LIVE_FIVE_METHOD_SUMMARY.csv`：截止到当前完成的 **成对种子**，五方法平均表现与当前排名（只是中途快照）。
- `LIVE_PAIRED_BY_SEED.csv`：每个已完成 seed，CoCAQ 与各基线的最终 RMSE 差值。

全部完成后还会生成：`FIVE_METHOD_SUMMARY.csv`、`PAIRED_BY_SEED.csv`、`PAIRED_SIGNIFICANCE.csv`、`LEARNING_CURVES_BY_SEED.csv`、`ALL_NEW_ROUNDS.csv`、`FRESH_VERIFICATION.txt`。

终端检验为 `500/500 formal, 15000/15000 recorded rounds`。对于100个种子的配对置换检验，报告给出的是 100,000 次随机符号翻转的 Monte Carlo 估计 p 值，不冒充精确检验。

## 重要提醒

1. 不要为了 CoCAQ 第一名而挑选运行结果最好的 seed。报告 **全部100个**，并保存每个 seed 的曲线。
2. 该脚本是由先前用户已运行成功的 MATLAB 工程改写并经过文件/静态检查；当前容器没有 MATLAB，**无法保证在本机运行前不存在 MATLAB 兼容性问题**。先运行 `check`。
3. `LIVE_*` 是实时快照，不能代替全部 100 个 seed 的最终统计推断。
4. 若你确实希望继续扩大到超过100个 seed，应在新实验开始前预先确定数量，不应根据排名临时调整种子范围。

# CoCAQ 两案例 ICDE 风格 MATLAB 绘图（OPSD 严格限制 0–12 轮）

## 运行

1. 解压这个 ZIP，MATLAB 当前文件夹切换到工程根目录（包含 `RUN_CoCAQ_ICDE_2Cases.m`）。建议 MATLAB R2021a 或更新版本。
2. 执行：

```matlab
RUN_CoCAQ_ICDE_2Cases('alpine') % 现在即可绘制，附带 10 案例原始数据
RUN_CoCAQ_ICDE_2Cases('opsd')   % 拿到真实 OPSD 逐种子曲线 CSV 后运行
% 或：
RUN_CoCAQ_ICDE_2Cases('all')    % OPSD 缺失时先跳过，不生成虚假图
```

输出在 `output/`（每图均导出矢量 PDF 与 400 dpi PNG；另有与图一致的数值审计 CSV）。

## 对应第五节三张图

| 论文图号 | 文件名 | 数据和统计 |
|---|---|---|
| Fig. 5 | `Fig5_Alpine_FinalNRMSE.pdf` | Alpine 2S2D–20S20D；10 种子最终 **原始** NRMSE 均值 ±1 个样本 SD（误差棒），不平滑 |
| Fig. 6 | `Fig6_Alpine_10Panels.pdf` | Alpine 10 场景，2×5；种子先做 5 点对称三角轻度平滑，再取均值；不绘重叠阴影，保留曲线端点原值 |
| Fig. 7 | `Fig7_OPSD_12Rounds.pdf` | L06 工程案例；10 种子 0–12 轮，**只**显示前 12 次新增完整历史记录；与 Fig. 6 同样的线条与平滑规则，原始均值在 CSV 中保留 |

**注意：** 三幅图沿用你原参考稿的白底、空心标记、不同线型、底部两行图例、深红粗实线 CoCAQ。所有方法应用同一平滑规则，禁止按最终优劣挑选种子。**原始均值、SD 和 12 轮终值绝不采用平滑后的数值**。

## 数据已准备好的部分

`data/alpine/ALL_CURVES.csv`：Alpine 原始五种方法 10 场景 × 10 种子 × 31 轮，共 15,500 条曲线行。种子 `16501:16510`。其中 RMSE 与 Alpine 冻结报告的原始曲线逐值一致；NRMSE 来自你此前提供的联合结果 CSV，并已与冻结 Alpine 最终归一化统计逐项校验；并非此次重新采样。

**P1/P2 Alpine 结果当前缺失**。如果你已跑完正式 10 种子补丁，将文件 `P12_JOINT17_ALL_CURVES.csv` 放入 `data/alpine/`，程序会自动读取 P1/P2、检查每个场景的 10×31 点；只有完整匹配的数据才会显示。不使用旧图里少数案例的 P1/P2 预览代替最终实验。

## OPSD 结果怎么放

你之前提过 L06 十种子结果目录：

`RESULTS/EXTRACT_30590_30599/`

**优先复制这个目录下的 `LEARNING_CURVES_BY_SEED.csv`**，放到本包 `data/opsd/LEARNING_CURVES_BY_SEED.csv`。脚本将自动截取第 0–12 轮，哪怕原文件含 0–30 轮也不绘制 13–30 轮。

也可以提供重命名后的 `OPSD_CURVES.csv`，它需要逐种子逐轮的记录，最简格式：

```csv
Case,Seed,Method,Round,RMSE
...
```

* `Seed` 必须包含 `30590`–`30599` **全部 10 个种子**，每个在每种方法中有 `Round=0,1,...,12` 的完整记录。
* `RMSE` 必须是终端日前电价预测的原始 RMSE（EUR/MWh），不能用 `NRMSE` 冒充。
* 代码可识别 `A2`（CMA-ES）、`A3_IPPO`、`A4_MAPPO`、`A5_GP_MAPPO` 和 `V4A_REFERENCE`（CoCAQ）等方法标记。
* OPSD 的 P1/P2 如果存在，可额外把 `P12_L06_ALL_CURVES.csv` 放入 `data/opsd/`，只取其中 P1/P2。
* OPSD 源文件没有提供时，程序会跳过 Fig. 7 并清楚提示；不会虚构或用引用均值填充缺失轮次。

**严谨性提醒：** 旧 MD 记录 `30590`–`30599` 曾被用于查看多个种子窗口的表现。若该窗口是在查看结果后选择的，应在论文中披露，不能称之为无偏随机选取；12 次查询若是事先确定的预算，可以只截取真实 0–12 轮，并须对所有方法统一。

## 绘图代码关键配置

打开 `RUN_CoCAQ_ICDE_2Cases.m` 的 `plotConfig()`：

```matlab
C.smoothCurves = true;       % true=5轮平滑；false=完全未平滑均值
C.showOPSDSeedBand = false; % 真实案例若需要单独显示±SD，可改成 true
C.opsdRounds = 0:12;        % 保持不变：论文真实案例只到12轮
```

表格文件 `Alpine_CurveMean_RawAndSmoothed.csv` 和 `OPSD_Rounds0to12_RawAndSmoothed.csv` 同时保存原始均值、原始 SD 及平滑均值，便于专家核查。

## 嵌入 Overleaf

将三个 PDF 放入论文 Overleaf 项目的 `figures/` 下，项目中 `section_V_zh.tex` 已预设对应路径与 fallback 占位框；文件一旦存在，正常编译即自动插入。

建议最终图注注明：“Learning curves display a five-round symmetric triangular smoother applied per seed before averaging; raw final-round values are used in all quantitative comparisons.”

## 验证范围

本包已基于上传的 Alpine CSV 做行数、种子、轮次一致性检查。这里没有 MATLAB 解释器，故没有宣称 MATLAB 运行截图/实际导图测试已通过；请先运行 `RUN_CoCAQ_ICDE_2Cases('alpine')` 验证你的 MATLAB 版本兼容性。如果报错，直接发完整错误位置。

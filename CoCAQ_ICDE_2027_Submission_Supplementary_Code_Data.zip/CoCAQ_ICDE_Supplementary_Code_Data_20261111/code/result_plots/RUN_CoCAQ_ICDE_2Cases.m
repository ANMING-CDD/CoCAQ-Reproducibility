function RUN_CoCAQ_ICDE_2Cases(mode)
% Two-case ICDE figure producer, run from any MATLAB current directory.
%   RUN_CoCAQ_ICDE_2Cases          -> Alpine figures + OPSD if data supplied
%   RUN_CoCAQ_ICDE_2Cases('alpine') -> Alpine only
%   RUN_CoCAQ_ICDE_2Cases('opsd')   -> OPSD only (must supply real results)
%
% FIGURES: Fig5_Alpine_FinalNRMSE, Fig6_Alpine_10Panels,
%          Fig7_OPSD_12Rounds.  No simulated or cherry-picked data.
% Tested here: input CSV/seed/count checks by Python; MATLAB runtime not available.

if nargin < 1 || isempty(mode), mode = 'all'; end
mode = lower(char(mode));
if ~ismember(mode, {'all','alpine','opsd'})
    error('mode must be all, alpine or opsd.');
end
C = plotConfig();
if ~exist(C.outDir,'dir'), mkdir(C.outDir); end
if ismember(mode, {'all','alpine'})
    fprintf('\n== Alpine 2S2D-20S20D, 10 paired seeds, rounds 0-30 ==\n');
    A = loadAlpine(C);
    [tab,cur] = summarizeAlpine(A,C);
    writetable(tab, fullfile(C.outDir,'Alpine_FinalNRMSE_10Seeds.csv'));
    writetable(cur, fullfile(C.outDir,'Alpine_CurveMean_RawAndSmoothed.csv'));
    fig5(tab,C);
    fig6(cur,C);
    fprintf('Alpine PDF/PNG and audit CSV exported.\n');
end
if ismember(mode, {'all','opsd'})
    fprintf('\n== OPSD L06, 10 seeds, display rounds 0-12 only ==\n');
    [O,fileUsed] = loadOPSD(C);
    if isempty(O)
        if strcmp(mode,'opsd')
            error(['Missing genuine OPSD results. Put LEARNING_CURVES_BY_SEED.csv ' ...
                   'or OPSD_CURVES.csv under data/opsd/.']);
        else
            fprintf('OPSD report not supplied: Fig7 skipped; NEVER substituted synthetic results.\n');
        end
    else
        [tab,cur] = summarizeOPSD(O,C);
        writetable(tab, fullfile(C.outDir,'OPSD_FinalRound12_RMSE_10Seeds.csv'));
        writetable(cur, fullfile(C.outDir,'OPSD_Rounds0to12_RawAndSmoothed.csv'));
        fig7(cur,C);
        fprintf('OPSD source: %s\n',fileUsed);
        fprintf('OPSD output is restricted to round 0 through 12 (inclusive).\n');
    end
end
fprintf('\nFigures are in %s\n',C.outDir);
end

function C = plotConfig()
root = fileparts(mfilename('fullpath'));
C.root = root;
C.outDir = fullfile(root,'output');
C.alpineCSV = fullfile(root,'data','alpine','ALL_CURVES.csv');
C.alpineExtra = fullfile(root,'data','alpine','P12_JOINT17_ALL_CURVES.csv');
C.opsdDir = fullfile(root,'data','opsd');
C.opsdExtra = fullfile(C.opsdDir,'P12_L06_ALL_CURVES.csv');
C.alpineSeeds = (16501:16510)';
C.opsdSeeds = (30590:30599)';
C.alpineRounds = 0:30;
C.opsdRounds = 0:12;
C.stages = 2:2:20;
C.smoothWindow = 5;  % symmetric triangular weights [1,2,3,2,1]
C.smoothCurves = true;  % set false for unsmoothed mean curves
C.showOPSDSeedBand = false; % optional ±1 SD; default avoids visual clutter
C.codes = {'P1','P2','A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_REFERENCE'};
C.labels = {'P1','P2','CMA-ES','IPPO','MAPPO','GP-MAPPO','CoCAQ'};
C.colors = [0.61,0.64,0.68; 0.39,0.47,0.54; 0.66,0.55,0.35; ...
            0.16,0.43,0.63; 0.21,0.57,0.55; 0.75,0.43,0.28; 0.68,0.19,0.23];
C.styles = {'--',':','--','-','-.',':','-'};
C.markers = {'o','s','d','v','>','<','p'};
C.fig5Name = 'Fig5_Alpine_FinalNRMSE';
C.fig6Name = 'Fig6_Alpine_10Panels';
C.fig7Name = 'Fig7_OPSD_12Rounds';
end

function A = loadAlpine(C)
if ~isfile(C.alpineCSV), error('Missing Alpine data: %s',C.alpineCSV); end
A = standardizeCSV(readtable(C.alpineCSV),'alpine');
if isfile(C.alpineExtra)
    extra = standardizeCSV(readtable(C.alpineExtra),'alpine');
    extra = extra(ismember(extra.Method,{'P1','P2'}),:);
    if ~isempty(extra)
        A = [A;extra]; %#ok<AGROW>
        fprintf('Additional Alpine P1/P2 rows loaded: %d\n',height(extra));
    end
end
end

function [O, fileUsed] = loadOPSD(C)
fileUsed = '';
candidates = {fullfile(C.opsdDir,'LEARNING_CURVES_BY_SEED.csv'), ...
              fullfile(C.opsdDir,'OPSD_CURVES.csv'), ...
              fullfile(C.opsdDir,'ALL_CURVES.csv')};
O = table();
for k=1:numel(candidates)
    p = candidates{k};
    if ~isfile(p), continue; end
    T = readtable(p);
    if height(T) == 0, continue; end
    O = standardizeCSV(T,'opsd');
    fileUsed = p;
    break;
end
if isempty(O), return; end
if isfile(C.opsdExtra)
    E = standardizeCSV(readtable(C.opsdExtra),'opsd');
    E = E(ismember(E.Method,{'P1','P2'}),:);
    if ~isempty(E)
        O = [O;E]; %#ok<AGROW>
        fprintf('Additional OPSD P1/P2 rows loaded: %d\n',height(E));
    end
end
end

function T = standardizeCSV(T,whichCase)
if height(T)==0,return;end
keys = T.Properties.VariableNames;
T = renameOne(T,keys,{'Method','Algorithm','Alg','method','method_name'},'Method');
T = renameOne(T,T.Properties.VariableNames,{'Seed','seed','RandomSeed','TrialSeed'},'Seed');
T = renameOne(T,T.Properties.VariableNames,{'Round','round','Iteration','Iter','t'},'Round');
if strcmp(whichCase,'alpine')
    T = renameOne(T,T.Properties.VariableNames,{'NRMSE','nrmse','FinalNRMSE'},'Value');
else
    % Engineering-case labels use RMSE in EUR/MWh. Do not silently relabel NRMSE.
    T = renameOne(T,T.Properties.VariableNames,{'RMSE','rmse','TestRMSE','FinalRMSE'},'Value');
end
required = {'Seed','Method','Round','Value'};
if strcmp(whichCase,'alpine'), required = [required,{'Case'}]; end
for j=1:numel(required)
    if ~ismember(required{j},T.Properties.VariableNames)
        error('%s CSV missing column %s. Found: %s',whichCase,required{j},strjoin(T.Properties.VariableNames,', '));
    end
end
T.Method = strings(height(T),1) + string(T.Method);
for j=1:height(T),T.Method(j)=methodCode(T.Method(j));end
T.Seed = numericColumn(T.Seed);
T.Round = numericColumn(T.Round);
T.Value = numericColumn(T.Value);
if any(~isfinite(T.Seed)|~isfinite(T.Round)|~isfinite(T.Value))
    error('NaN or Inf in Seed/Round/RMSE or NRMSE.');
end
if strcmp(whichCase,'alpine')
    T.Case = string(T.Case);
    T.Stage = nan(height(T),1);
    for i=1:height(T)
        z = regexp(char(T.Case(i)),'_(\d+)S(\d+)D','tokens','once');
        if ~isempty(z) && str2double(z{1})==str2double(z{2})
            T.Stage(i) = str2double(z{1});
        end
    end
end
end

function T=renameOne(T,names,possible,newName)
if ismember(newName,names),return;end
for i=1:numel(possible)
    ix=find(strcmpi(names,possible{i}),1);
    if ~isempty(ix)
        T.Properties.VariableNames{ix}=newName;
        return
    end
end
end

function n=numericColumn(x)
if isnumeric(x)
    n=double(x);
else
    n=str2double(string(x));
end
n=n(:);
end

function s=methodCode(s)
a=upper(strrep(strrep(strtrim(char(s)),'-','_'),' ',''));
if any(strcmp(a,{'P1','LHS_P1'})),s="P1";
elseif any(strcmp(a,{'P2','LHS_P2'})),s="P2";
elseif any(strcmp(a,{'A2','CMAES','CMA_ES','A2_CMAES'})),s="A2";
elseif any(strcmp(a,{'A3','A3_IPPO','IPPO'})),s="A3_IPPO";
elseif any(strcmp(a,{'A4','A4_MAPPO','MAPPO'})),s="A4_MAPPO";
elseif any(strcmp(a,{'A5','A5_GP_MAPPO','GP_MAPPO','GPMAPPO'})),s="A5_GP_MAPPO";
elseif startsWith(a,'V4A')||startsWith(a,'COCAQ')||strcmp(a,'V00')||strcmp(a,'V00_FROZEN')
    s="V4A_REFERENCE";
else
    error('Unrecognized Method "%s": add an explicit mapping in methodCode().',a);
end
end

function [summary,curveTable]=summarizeAlpine(T,C)
T=T(ismember(T.Stage,C.stages),:);
if isempty(T),error('Alpine: no valid BOFN_ALPINE2_* rows.');end
present=methodAvailability(T,C,'alpine');
summary=table(); curveTable=table();
for d=C.stages
    for idx=find(present)
        code=string(C.codes{idx});
        sub=T(T.Stage==d & T.Method==code & ismember(T.Seed,C.alpineSeeds) & ismember(T.Round,C.alpineRounds),:);
        Y=toSeedMatrix(sub,C.alpineSeeds,C.alpineRounds,sprintf('Alpine %dS%dD %s',d,d,code));
        mu=mean(Y,1);sd=std(Y,0,1);
        sm=applySmooth(Y,C);
        r=table(d,d,code,string(C.labels{idx}),numel(C.alpineSeeds),mu(end),sd(end), ...
               'VariableNames',{'Stages','D','Method','DisplayName','NSeeds','FinalMeanNRMSE','FinalSDNRMSE'});
        summary=[summary;r]; %#ok<AGROW>
        for j=1:numel(C.alpineRounds)
            row=table(d,code,string(C.labels{idx}),C.alpineRounds(j),mu(j),sd(j),mean(sm(:,j)), ...
                  'VariableNames',{'Stages','Method','DisplayName','Round','RawMeanNRMSE','RawSDNRMSE','SmoothedMeanNRMSE'});
            curveTable=[curveTable;row]; %#ok<AGROW>
        end
    end
end
fprintf('Alpine: %d methods; all included methods use exactly 10 seeds and 31 rounds.\n',sum(present));
end

function [summary,curveTable]=summarizeOPSD(T,C)
% Truncate FIRST, independently of whether the source contains 13 or 31 rounds.
T=T(ismember(T.Seed,C.opsdSeeds)&ismember(T.Round,C.opsdRounds),:);
if isempty(T),error('OPSD: none of the expected seeds 30590..30599 (rounds 0..12) found.');end
present=methodAvailability(T,C,'opsd');
summary=table();curveTable=table();
for idx=find(present)
    code=string(C.codes{idx});
    sub=T(T.Method==code,:);
    Y=toSeedMatrix(sub,C.opsdSeeds,C.opsdRounds,sprintf('OPSD %s',code));
    mu=mean(Y,1);sd=std(Y,0,1); sm=applySmooth(Y,C);
    r=table(code,string(C.labels{idx}),numel(C.opsdSeeds),mu(1),mu(end),sd(end), ...
            100*(mu(1)-mu(end))/mu(1), ...
            'VariableNames',{'Method','DisplayName','NSeeds','Round0_MeanRMSE','Round12_MeanRMSE','Round12_SDRMSE','ImprovementPct'});
    summary=[summary;r]; %#ok<AGROW>
    for j=1:numel(C.opsdRounds)
        row=table(code,string(C.labels{idx}),C.opsdRounds(j),mu(j),sd(j),mean(sm(:,j)), ...
                  'VariableNames',{'Method','DisplayName','Round','RawMeanRMSE','RawSDRMSE','SmoothedMeanRMSE'});
        curveTable=[curveTable;row]; %#ok<AGROW>
    end
end
fprintf('OPSD: %d methods; 10 seeds x 13 points per method, rounds 0..12.\n',sum(present));
end

function present=methodAvailability(T,C,whichCase)
present=false(1,numel(C.codes));
for i=1:numel(C.codes)
    present(i)=any(T.Method==string(C.codes{i}));
end
if any(~present(3:7))
    warning('%s: only %d/5 active methods found. Not inventing any missing line.',whichCase,sum(present(3:7)));
end
if any(~present(1:2))
    fprintf('%s: P1/P2 missing; draw only available real-data methods.\n',whichCase);
end
end

function Y=toSeedMatrix(T,seeds,rounds,titleStr)
if height(T)~=numel(seeds)*numel(rounds)
    error('%s: expected %d rows (10 seeds x %d rounds), found %d. Missing/duplicate rows?', ...
        titleStr,numel(seeds)*numel(rounds),numel(rounds),height(T));
end
Y=nan(numel(seeds),numel(rounds));
for i=1:numel(seeds)
    sm=T(T.Seed==seeds(i),:);
    if height(sm)~=numel(rounds) || numel(unique(sm.Round))~=numel(rounds)
        error('%s seed %d: rounds missing or repeated.',titleStr,seeds(i));
    end
    [ok,loc]=ismember(sm.Round,rounds);
    if ~all(ok),error('%s seed %d: unexpected round.',titleStr,seeds(i));end
    Y(i,loc)=reshape(sm.Value,1,[]);
end
if any(~isfinite(Y(:))),error('%s: matrix has missing/non-finite values.',titleStr);end
end

function Y=applySmooth(X,C)
if ~C.smoothCurves,Y=X;return;end
if C.smoothWindow~=5,error('Only documented 5-point triangular smoother supported.');end
w=[1 2 3 2 1]; Y=nan(size(X));
for i=1:size(X,1)
    for j=1:size(X,2)
        lo=max(1,j-2);hi=min(size(X,2),j+2);
        widx=(lo:hi)-j+3;
        Y(i,j)=sum(X(i,lo:hi).*w(widx))/sum(w(widx));
    end
end
Y(:,1)=X(:,1);Y(:,end)=X(:,end); % show actual start/end errors
end

function fig5(S,C)
fig=figure('Color','w','Units','inches','Position',[0.5 0.5 6.9 3.6]);
ax=axes('Parent',fig,'Position',[0.10 0.22 0.87 0.70]); hold(ax,'on');
handles=gobjects(0); labels={};
for idx=1:numel(C.codes)
    code=string(C.codes{idx}); Z=S(S.Method==code,:);
    if isempty(Z),continue;end
    [x,ii]=sort(Z.Stages);
    y=Z.FinalMeanNRMSE(ii); sd=Z.FinalSDNRMSE(ii);
    % Tiny horizontal offsets reduce overlapping SD whiskers, not data values.
    xPos=x+0.045*(idx-4);
    h=errorbar(ax,xPos,y,sd,'LineStyle',C.styles{idx},'Marker',C.markers{idx}, ...
        'Color',C.colors(idx,:),'LineWidth',lineWidth(idx), ...
        'MarkerSize',5.5,'MarkerFaceColor','w','CapSize',3);
    handles(end+1)=h;labels{end+1}=C.labels{idx}; %#ok<AGROW>
end
xlim(ax,[1.3 20.7]);xticks(ax,C.stages);xlabel(ax,'Cascade size K = d');
ylabel(ax,'Final held-out NRMSE');
styleAxes(ax);
lg=legend(ax,handles,labels,'Location','southoutside','NumColumns',min(4,numel(labels)));
lg.Box='off';lg.FontSize=8;
set(fig,'PaperPositionMode','auto');
exportPair(fig,fullfile(C.outDir,C.fig5Name));
close(fig);
end

function fig6(S,C)
fig=figure('Color','w','Units','inches','Position',[0.4 0.4 7.2 4.6]);
tl=tiledlayout(fig,2,5,'TileSpacing','compact','Padding','compact');
handles=gobjects(0);labels={};
for di=1:numel(C.stages)
    d=C.stages(di);
    ax=nexttile(tl);hold(ax,'on');
    for idx=1:numel(C.codes)
        code=string(C.codes{idx});
        Z=S(S.Stages==d&S.Method==code,:);
        if isempty(Z),continue;end
        [x,ii]=sort(Z.Round);
        if C.smoothCurves, y=Z.SmoothedMeanNRMSE(ii);else,y=Z.RawMeanNRMSE(ii);end
        h=plot(ax,x,y,'Color',C.colors(idx,:),'LineStyle',C.styles{idx}, ...
                'LineWidth',lineWidth(idx),'Marker',C.markers{idx},'MarkerIndices',1:6:numel(x), ...
                'MarkerFaceColor','w','MarkerSize',3.0);
        if di==1,handles(end+1)=h;labels{end+1}=C.labels{idx};end %#ok<AGROW>
    end
    title(ax,sprintf('%dS%dD',d,d),'FontWeight','normal','FontSize',8);
    xlim(ax,[0 30]);xticks(ax,[0 10 20 30]);
    xlabel(ax,'Queries');ylabel(ax,'NRMSE');
    styleAxes(ax);
    set(ax,'FontSize',7);
end
lg=legend(handles,labels,'NumColumns',min(4,numel(labels)),'Orientation','horizontal');
lg.Layout.Tile='south';lg.Box='off';lg.FontSize=7.4;
exportPair(fig,fullfile(C.outDir,C.fig6Name));
close(fig);
end

function fig7(S,C)
fig=figure('Color','w','Units','inches','Position',[0.5 0.5 6.9 3.1]);
ax=axes('Parent',fig,'Position',[0.10 0.23 0.86 0.70]);hold(ax,'on');
handles=gobjects(0);labels={};
for idx=1:numel(C.codes)
    code=string(C.codes{idx});Z=S(S.Method==code,:);
    if isempty(Z),continue;end
    [x,ii]=sort(Z.Round);
    if C.smoothCurves,y=Z.SmoothedMeanRMSE(ii);else,y=Z.RawMeanRMSE(ii);end
    if C.showOPSDSeedBand
        sd=Z.RawSDRMSE(ii);
        xp=[x;flipud(x)];yp=[y-sd;flipud(y+sd)];
        fill(ax,xp,yp,C.colors(idx,:),'FaceAlpha',0.08,'EdgeColor','none','HandleVisibility','off');
    end
    h=plot(ax,x,y,'Color',C.colors(idx,:),'LineStyle',C.styles{idx}, ...
        'LineWidth',lineWidth(idx),'Marker',C.markers{idx}, ...
        'MarkerIndices',1:2:numel(x),'MarkerFaceColor','w','MarkerSize',4.4);
    handles(end+1)=h;labels{end+1}=C.labels{idx}; %#ok<AGROW>
end
xlim(ax,[0 12]);xticks(ax,0:2:12);xlabel(ax,'Acquired records (0-12)');
ylabel(ax,'Held-out electricity-price RMSE (EUR/MWh)');
styleAxes(ax);
lg=legend(ax,handles,labels,'Location','southoutside','NumColumns',min(4,numel(labels))); 
lg.Box='off'; lg.FontSize=8;
exportPair(fig,fullfile(C.outDir,C.fig7Name));
close(fig);
end

function w=lineWidth(idx)
if idx==7,w=2.5;else,w=1.3;end
end

function styleAxes(ax)
set(ax,'Color','w','FontName','Arial','FontSize',8.5,'LineWidth',0.7, ...
    'Box','off','TickDir','out','Layer','top','XGrid','off','YGrid','on', ...
    'GridColor',[0.88 0.88 0.88],'GridAlpha',0.35);
end

function exportPair(fig,prefix)
set(fig,'InvertHardcopy','off');
exportgraphics(fig,[prefix '.pdf'],'ContentType','vector','BackgroundColor','white');
exportgraphics(fig,[prefix '.png'],'Resolution',400,'BackgroundColor','white');
fprintf('  exported %s.[pdf|png]\n',prefix);
end

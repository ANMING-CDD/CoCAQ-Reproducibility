function p12_set_engine(C,group)
%P12_SET_ENGINE Force MATLAB to use the matching native GP engine.
% Alpine and OPSD share names but have DIFFERENT GP noise/variance models.
a=fullfile(C.root,'engine_alpine');
b=fullfile(C.root,'engine_opsd');
p=strsplit(path,pathsep);
if any(strcmp(p,a)),rmpath(a);end
if any(strcmp(p,b)),rmpath(b);end
switch lower(group)
    case 'alpine',active=a;
    case 'opsd',active=b;
    otherwise,error('P12:UnknownGroup','Unknown native GP engine: %s',group);
end
addpath(active,'-begin');
% rehash alone is NOT sufficient when MATLAB has cached same-name functions
% from the other engine in the current MATLAB session.
clear GCF_fit GCF_gp_fit GCF_gp_predict GCF_kernel GCF_gp_dmean
clear GCF_cascade_predict GCF_stage_query GCF_stage_input
clear GCF_predict_final GCF_lhs GCF_halton MSBO_stage_idx
rehash;
checkNames={'GCF_fit','GCF_gp_fit','GCF_gp_predict','GCF_kernel', ...
    'GCF_cascade_predict','GCF_stage_input','GCF_stage_query', ...
    'GCF_predict_final','GCF_gp_dmean'};
for j=1:numel(checkNames)
    expected=fullfile(active,[checkNames{j} '.m']);
    actual=which(checkNames{j});
    assert(strcmpi(actual,expected),'P12:EnginePath', ...
        'Engine path mismatch for %s. Expected %s but MATLAB uses %s.', ...
        checkNames{j},expected,actual);
end
end

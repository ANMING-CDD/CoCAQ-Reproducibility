function p12_status(C)
for typ={'alpine','opsd'}
    g=typ{1};files=dir(fullfile(C.output,g,'*_P12.mat'));
    complete=0;partial=0;
    fprintf('\n%-7s: %d saved formal checkpoints\n',upper(g),numel(files));
    for i=1:numel(files)
        Q=load(fullfile(files(i).folder,files(i).name),'state');S=Q.state;
        if S.doneRound==S.rounds,complete=complete+1;else,partial=partial+1;end
        fprintf('  %-28s %2d/%2d rounds\n', ...
            sprintf('%s seed%d',S.caseName,S.seed),S.doneRound,S.rounds);
    end
    if strcmp(g,'alpine'),expected=100;else,expected=10;end
    fprintf('%s completed: %d/%d paired P1/P2 trajectories; partial %d\n', ...
        g,complete,expected,partial);
end
end

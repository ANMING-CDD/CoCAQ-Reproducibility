function p12_export(C)
% Export only COMPLETED real checkpoints. No interpolation, no fake runs.
folders={'alpine','opsd'};
allRuns=table();allCurves=table();allSelected=table();
for f=1:numel(folders)
    folder=folders{f};
    dest=fullfile(C.output,folder);
    files=dir(fullfile(dest,'*_P12.mat'));
    for j=1:numel(files)
        Z=load(fullfile(files(j).folder,files(j).name),'state');
        S=Z.state;
        if S.doneRound~=S.rounds
            fprintf('  INCOMPLETE %s (round %d/%d), not included in plots.\n', ...
                files(j).name,S.doneRound,S.rounds);
            continue;
        end
        assert(numel(S.rmse(:,1))==S.rounds+1);
        for m=1:2
            if m==1,method='P1';else,method='P2';end
            r0=S.rmse(1,m);rf=S.rmse(end,m);
            R=table({S.caseName},{S.group},S.K,S.d, ...
                size(S.Xinitial,1),S.seed,{method},r0,rf, ...
                rf/S.truthStd,trapz(0:S.rounds,S.rmse(:,m)')/S.rounds, ...
                trapz(0:S.rounds,S.rmse(:,m)'/S.truthStd)/S.rounds, ...
                S.truthStd,S.rounds, ...
                'VariableNames',{'Case','Family','Stages','D','InitialSamples', ...
                'Seed','Method','InitialRMSE','FinalRMSE','FinalNRMSE', ...
                'AULC','AULC_NRMSE','TruthStd','Rounds'});
            allRuns=p12_append_table(allRuns,R);
            n=S.rounds+1;
            T=table(repmat({S.caseName},n,1),repmat({S.group},n,1), ...
                repmat(S.K,n,1),repmat(S.seed,n,1),repmat({method},n,1), ...
                (0:S.rounds)',S.rmse(:,m),S.rmse(:,m)/S.truthStd, ...
                'VariableNames',{'Case','Family','Stages','Seed','Method', ...
                'Round','RMSE','NRMSE'});
            allCurves=p12_append_table(allCurves,T);
        end
        if strcmp(S.group,'opsd')
            acq=table(repmat({S.caseName},S.rounds,1), ...
                repmat(S.seed,S.rounds,1),(1:S.rounds)',S.planIDs(:), ...
                repmat({'P1_and_P2_shared_pool_LHS'},S.rounds,1), ...
                'VariableNames',{'Case','Seed','Round','RecordID','Acquisition'});
        else
            acq=table(repmat({S.caseName},S.rounds,1), ...
                repmat(S.seed,S.rounds,1),(1:S.rounds)', ...
                repmat({'P1_and_P2_shared_continuous_LHS'},S.rounds,1), ...
                'VariableNames',{'Case','Seed','Round','Acquisition'});
        end
        if strcmp(S.group,'opsd')
            allSelected=p12_append_table(allSelected,acq);
        end
    end
end
if isempty(allRuns)
    fprintf('No fully completed P1/P2 checkpoints yet (formal output).\n');
    return;
end
alpine=strcmp(allRuns.Family,'alpine');
write_if_rows(allRuns(alpine,:),fullfile(C.output,'P12_ALPINE_ALL_RUNS.csv'));
write_if_rows(allCurves(strcmp(allCurves.Family,'alpine'),:), ...
    fullfile(C.output,'P12_ALPINE_ALL_CURVES.csv'));
write_if_rows(allRuns(~alpine,:),fullfile(C.output,'P12_OPSD_ALL_RUNS.csv'));
write_if_rows(allCurves(strcmp(allCurves.Family,'opsd'),:), ...
    fullfile(C.output,'P12_OPSD_ALL_CURVES.csv'));
write_if_rows(allSelected,fullfile(C.output,'P12_OPSD_SHARED_LHS_ROWS.csv'));
writetable(allRuns,fullfile(C.output,'P12_TWO_CASES_ALL_RUNS.csv'));
writetable(allCurves,fullfile(C.output,'P12_TWO_CASES_ALL_CURVES.csv'));

% P2/P1 paired effect table: same seed, same initial data, same acquisitions.
cases=unique(allRuns.Case,'stable');
delta=cell(0,8);
for i=1:numel(cases)
    ca=cases{i};sub=allRuns(strcmp(allRuns.Case,ca),:);
    seeds=unique(sub.Seed);
    for s=seeds'
        a=sub(sub.Seed==s & strcmp(sub.Method,'P1'),:);
        b=sub(sub.Seed==s & strcmp(sub.Method,'P2'),:);
        if height(a)~=1 || height(b)~=1,continue;end
        gain=(a.FinalRMSE-b.FinalRMSE)/max(a.FinalRMSE,eps)*100;
        delta(end+1,:)={ca,a.Family{1},a.Stages,s,a.FinalRMSE, ...
            b.FinalRMSE,gain,a.Rounds}; %#ok<AGROW>
    end
end
if ~isempty(delta)
    % Explicit types prevent cell2table from returning cell-valued Stages
    % or GainPct columns that break numeric comparisons and bar plotting.
    T=table(delta(:,1),delta(:,2),cell2mat(delta(:,3)), ...
        cell2mat(delta(:,4)),cell2mat(delta(:,5)), ...
        cell2mat(delta(:,6)),cell2mat(delta(:,7)),cell2mat(delta(:,8)), ...
        'VariableNames',{'Case','Family','Stages','Seed', ...
        'P1_FinalRMSE','P2_FinalRMSE','P2_GainPct','Rounds'});
    writetable(T,fullfile(C.output,'P12_PAIRED_BENEFIT.csv'));
end

% If (and only if) all Alpine P1/P2 pairs are complete, merge with original 5.
if sum(alpine)==10*10*2
    oldR=readtable(fullfile(C.root,'data','alpine','OLD_FIVE_ALL_RUNS.csv'));
    oldC=readtable(fullfile(C.root,'data','alpine','OLD_FIVE_ALL_CURVES.csv'));
    newR=allRuns(alpine,:);
    newC=allCurves(strcmp(allCurves.Family,'alpine'),:);
    % Preserve original 15-column schema for cross-method plotting.
    P=table(newR.Case,newR.Family,newR.Stages,newR.D, ...
        newR.InitialSamples,newR.Seed,newR.Method, ...
        newR.InitialRMSE,newR.FinalRMSE,newR.FinalNRMSE, ...
        newR.AULC,newR.AULC_NRMSE, ...
        nan(height(newR),1),newR.TruthStd, ...
        repmat({'P12_NATIVE_PAIRED_LHS'},height(newR),1), ...
        'VariableNames',oldR.Properties.VariableNames);
    QC=table(newC.Case,newC.Family,newC.Seed,newC.Method, ...
        newC.Round,newC.RMSE,newC.NRMSE, ...
        'VariableNames',oldC.Properties.VariableNames);
    writetable([oldR;P],fullfile(C.output,'ALPINE_SEVEN_METHODS_ALL_RUNS.csv'));
    writetable([oldC;QC],fullfile(C.output,'ALPINE_SEVEN_METHODS_ALL_CURVES.csv'));
    fprintf('MERGED: 5 original Alpine methods + P1/P2 => 7 methods.\n');
else
    fprintf('Alpine P1/P2 complete runs %d/200; seven-method merge not yet written.\n',sum(alpine));
end
fprintf('EXPORTED %d complete P1/P2 runs, %d curve rows.\n',height(allRuns),height(allCurves));
end

function write_if_rows(T,fp)
if ~isempty(T),writetable(T,fp);end
end

function T=p12_append_table(T,newRows)
% Empty 0x0 MATLAB tables cannot safely be vertically concatenated with
% a populated table having new column names/types.
if width(T)==0
    T=newRows;
else
    T=[T;newRows];
end
end

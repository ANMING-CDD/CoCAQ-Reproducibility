function p12_run_group(C,group,ks,seeds,rounds,isSmoke)
if nargin<6, isSmoke=false; end
assert(rounds>=1 && rounds==floor(rounds));
if isSmoke
    folder=fullfile(C.output,'smoke',group);
else
    folder=fullfile(C.output,group);
end
if ~isfolder(folder),mkdir(folder);end
if strcmp(group,'opsd'),ks=NaN;end
for k=ks
    for seed=seeds
        B=p12_prepare_case(C,group,k,seed,rounds);
        if strcmp(group,'alpine')
            p12_set_engine(C,'alpine');
        else
            p12_set_engine(C,'opsd');
        end
        p12_run_one(C,B,folder);
    end
end
end

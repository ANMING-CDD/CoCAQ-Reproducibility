function C=p12_protocol(root)
C.root=root;
C.output=fullfile(root,'output');
C.figures=fullfile(root,'figures');
C.stages=2:2:20;
C.alpineSeeds=16501:16510;
C.opsdSeeds=30590:30599;
C.alpineRounds=30;
C.opsdRounds=12; % IMPORTANT: paper reports ONLY rounds 0..12 for OPSD.
C.alpineTestBase=1659000;
C.alpineNtest=2048;
C.opsdNeval=512;
C.opDirectProfile='flexible';
C.modelVersion='P12_NATIVE_GP_TWOCASES_20261111_V1';
end

function p12_plot(C)
% Manuscript-ready two-case P1/P2 comparison. Curves are NOT smoothed.
% 95% confidence ribbons use the Student-t critical value and paired seeds.
if ~isfolder(C.figures),mkdir(C.figures);end
pA=fullfile(C.output,'P12_ALPINE_ALL_CURVES.csv');
pO=fullfile(C.output,'P12_OPSD_ALL_CURVES.csv');
A=table();O=table();
if isfile(pA),A=readtable(pA);end
if isfile(pO),O=readtable(pO);end
if isempty(A) && isempty(O)
    fprintf('PLOT SKIPPED: no complete formal P1/P2 runs. Use alpine / opsd first.\n');return;
end

%% Fig 8a: Alpine 10 small multiples: mean +/- 95% CI, no smoothing.
if ~isempty(A)
    f=figure('Color','w','Units','pixels','Position',[70 40 1650 710]);
    t=tiledlayout(f,2,5,'Padding','compact','TileSpacing','compact');
    for i=1:numel(C.stages)
        k=C.stages(i);ax=nexttile(t);hold(ax,'on');p12_axes(ax);
        [Y1,Y2]=p12_alpine_seed_matrices(A,k,C.alpineSeeds,C.alpineRounds);
        if ~any(all(isfinite(Y1),2)) && ~any(all(isfinite(Y2),2))
            text(ax,.5,.5,'Not completed','Units','normalized', ...
                'HorizontalAlignment','center','Color',[.58 .58 .58]);
            title(ax,sprintf('%dS%dD',k,k),'FontWeight','bold');
            xlim(ax,[0 C.alpineRounds]);continue;
        end
        x=0:C.alpineRounds;
        p12_draw_ci(ax,x,Y1,'P1');
        p12_draw_ci(ax,x,Y2,'P2');
        title(ax,sprintf('%dS%dD',k,k),'FontWeight','bold');
        xlabel(ax,'Acquisitions');
        if mod(i-1,5)==0,ylabel(ax,'Terminal NRMSE');end
        xlim(ax,[0 C.alpineRounds]);
        n1=sum(all(isfinite(Y1),2));n2=sum(all(isfinite(Y2),2));
        text(ax,.04,.96,sprintf('n = %d / %d',n1,n2),'Units','normalized', ...
            'VerticalAlignment','top','FontSize',8,'Color',[.45 .45 .45]);
    end
    lg=p12_figure_legend(t); %#ok<NASGU>
    title(t,'Alpine: same LHS observations, direct GP vs. cascaded GPs', ...
        'FontSize',14,'FontWeight','bold');
    p12_save(f,fullfile(C.figures,'Fig8a_P1P2_Alpine_10Panels'));close(f);
end

%% Fig 8b: OPSD (12 rounds only), physical price RMSE.
if ~isempty(O)
    f=figure('Color','w','Units','pixels','Position',[80 80 920 490]);
    ax=axes(f);hold(ax,'on');p12_axes(ax);
    x=0:C.opsdRounds;
    Y1=p12_seed_matrix(O,'P1',C.opsdSeeds,x,'RMSE');
    Y2=p12_seed_matrix(O,'P2',C.opsdSeeds,x,'RMSE');
    p12_draw_ci(ax,x,Y1,'P1');p12_draw_ci(ax,x,Y2,'P2');
    xlabel(ax,'Acquired historical records (rounds 0--12)');
    ylabel(ax,'Terminal day-ahead price RMSE (EUR/MWh)');
    title(ax,'OPSD: same historical LHS records, direct GP vs. cascaded GPs', ...
        'FontSize',13,'FontWeight','bold');
    xlim(ax,[0 C.opsdRounds]);xticks(ax,0:2:C.opsdRounds);
    legend(ax,'show','Location','best','Box','off','FontSize',11);
    n1=sum(all(isfinite(Y1),2));n2=sum(all(isfinite(Y2),2));
    text(ax,.02,.02,sprintf('Full trajectories: P1=%d, P2=%d seeds | shaded: 95%% CI',n1,n2), ...
        'Units','normalized','FontSize',9,'Color',[.38 .38 .38]);
    p12_save(f,fullfile(C.figures,'Fig8b_P1P2_OPSD_12Rounds'));close(f);
end

% Publication figures: Fig8a and Fig8b only.
% The legacy combined panel and Fig8c gain bars are intentionally omitted.
fprintf('P1/P2 PDF+PNG figures are under %s\n',C.figures);
end

function [Y1,Y2]=p12_alpine_seed_matrices(A,k,seeds,R)
T=A(A.Stages==k,:);x=0:R;
Y1=p12_seed_matrix(T,'P1',seeds,x,'NRMSE');
Y2=p12_seed_matrix(T,'P2',seeds,x,'NRMSE');
end

function Y=p12_seed_matrix(T,method,seeds,rounds,metric)
Y=nan(numel(seeds),numel(rounds));
for i=1:numel(seeds)
    sub=T(strcmp(T.Method,method) & T.Seed==seeds(i),:);
    if height(sub)~=numel(rounds),continue;end
    [tf,j]=ismember(rounds,sub.Round);
    if ~all(tf),continue;end
    val=sub.(metric);
    if all(isfinite(val(j))),Y(i,:)=val(j)';end
end
end

function [Y1,Y2]=p12_alpine_macro(A,C)
Y1=nan(numel(C.alpineSeeds),C.alpineRounds+1);
Y2=Y1;
for i=1:numel(C.alpineSeeds)
    seed=C.alpineSeeds(i);
    P=zeros(numel(C.stages),C.alpineRounds+1);
    Q=P;complete=true;
    for j=1:numel(C.stages)
        [p,q]=p12_alpine_seed_matrices(A,C.stages(j),seed,C.alpineRounds);
        if ~all(isfinite(p(:))) || ~all(isfinite(q(:)))
            complete=false;break;
        end
        P(j,:)=p;Q(j,:)=q;
    end
    if complete
        Y1(i,:)=mean(P,1);
        Y2(i,:)=mean(Q,1);
    end
end
end

function p12_draw_ci(ax,x,Y,which)
if isempty(Y),return;end
valid=all(isfinite(Y),2);Y=Y(valid,:);
if isempty(Y),return;end
switch which
    case 'P1',c=[.24 .47 .70];style='--';marker='o';
    case 'P2',c=[.72 .20 .31];style='-';marker='s';
end
n=size(Y,1);mu=mean(Y,1);sd=std(Y,0,1);
if n>1
    ci=p12_tcrit95(n)*sd/sqrt(n);
    lo=mu-ci;hi=mu+ci;
    patch(ax,[x fliplr(x)],[lo fliplr(hi)],c, ...
        'FaceAlpha',.16,'EdgeColor','none','HandleVisibility','off');
end
markEvery=max(1,round((numel(x)-1)/6));
plot(ax,x,mu,'LineStyle',style,'Color',c,'LineWidth',2.15, ...
    'Marker',marker,'MarkerIndices',1:markEvery:numel(x), ...
    'MarkerSize',5.3,'MarkerFaceColor','w','MarkerEdgeColor',c, ...
    'DisplayName',sprintf('%s (n=%d)',which,n));
end

function t=p12_tcrit95(n)
% two-tailed Student-t quantile t_{0.975,n-1} for n=2,...,10.
lookup=[12.706,4.303,3.182,2.776,2.571,2.447,2.365,2.306,2.262];
if n<=1,t=0;elseif n<=10,t=lookup(n-1);else,t=1.96;end
end

function p12_axes(ax)
set(ax,'FontName','Times New Roman','FontSize',10, ...
    'LineWidth',.85,'TickDir','out','Box','off', ...
    'XGrid','on','YGrid','on','GridAlpha',.13, ...
    'GridColor',[.45 .45 .45]);
end

function lg=p12_figure_legend(t)
% Legend with only two method lines, no dummy data in a panel.
% use the LAST axes that has P1/P2 line objects.
axesAll=findall(t.Parent,'Type','axes');
lg=[];
for j=1:numel(axesAll)
    lines=findobj(axesAll(j),'Type','line');
    if numel(lines)>=2
        labels=get(lines,'DisplayName');
        if ischar(labels), labels={labels}; end
        keep=contains(labels,'P1 (')|contains(labels,'P2 (');
        lines=lines(keep);
        if numel(lines)>=2
            lg=legend(axesAll(j),lines(1:2),get(lines(1:2),'DisplayName'), ...
                'Location','southoutside','Orientation','horizontal','Box','off');
            break;
        end
    end
end
end

function p12_save(fig,outBase)
try
    exportgraphics(fig,[outBase '.pdf'],'ContentType','vector');
    exportgraphics(fig,[outBase '.png'],'Resolution',300);
catch E
    warning('P12:Export','exportgraphics failed (%s), falling back to print.',E.message);
    print(fig,[outBase '.pdf'],'-dpdf','-painters');
    print(fig,[outBase '.png'],'-dpng','-r300');
end
end

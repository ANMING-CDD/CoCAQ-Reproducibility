function B=p12_prepare_case(C,group,K,seed,rounds)
% Reconstruct original paired initial and held-out designs, not new splits.
assert(isscalar(seed) && isfinite(seed));
if strcmp(group,'alpine')
    p12_set_engine(C,'alpine');
    assert(ismember(K,C.stages),'Unsupported Alpine K.');
    spec=struct('id',sprintf('BOFN_ALPINE2_%dS%dD',K,K), ...
        'kind','bofn_alpine2','K',K,'d',K,'p',1, ...
        'stageDims',ones(1,K),'nInitial',6*K);
    idx=p12_alpine_registry_index(K);
    % Exact GP_COOP_FORMAL_ENGINE locked-formal held-out protocol.
    Xtest=GCF_halton(C.alpineNtest,K,C.alpineTestBase+1000*idx);
    Ytest=p12_alpine_truth(Xtest);
    rng(1701000+1000*idx+seed,'twister');
    X0=GCF_lhs(spec.nInitial,spec.d);  % native GCF_lhs.m
    Y0=p12_alpine_truth(X0);
    % Separate seed for the LHS acquisition PLAN, never for paired X0/Xtest.
    rng(810000+10000*K+seed,'twister');
    newX=GCF_lhs(rounds,K);
    B=struct('group',group,'caseName',spec.id,'seed',seed,'s',spec, ...
        'X0',X0,'Y0',Y0,'Xtest',Xtest,'Ytest',Ytest, ...
        'yScale',1,'rounds',rounds,'planX',newX, ...
        'planIDs',[],'poolX',[],'poolY',[],'poolIDs',[], ...
        'testIDs',[],'initialIDs',[],'poolFingerprint','FORMULA_ALPINE_20261106');
    R=readtable(fullfile(C.root,'data','alpine','OLD_FIVE_ALL_RUNS.csv'));
    ref=R(strcmp(R.Case,spec.id) & R.Seed==seed,:);
    assert(height(ref)==5,'P12:OldProtocol','Expected exactly 5 old method rows per Alpine case/seed.');
    assert(all(ref.InitialSamples==spec.nInitial),'P12:InitialN','Initial size differs from original.');
    B.expectedStd=ref.TruthStd(1);
    B.expectedInitRMSE=ref.InitialRMSE(1);
    B.trueStd=std(Ytest(:,end));
    assert(abs(B.trueStd-B.expectedStd)<=1e-5*max(1,B.expectedStd), ...
        'P12:AlpineTestMismatch','Original Alpine test set std mismatch. Check registry/testBase.');
elseif strcmp(group,'opsd')
    p12_set_engine(C,'opsd');
    [D,spec]=OPSD_load_L06();
    % Same GP stage profiles as the frozen original L06 5-method experiment.
    spec.gpOptsStages={GCF_gp_options('smooth'),GCF_gp_options('smooth'), ...
        GCF_gp_options('smooth'),GCF_gp_options('flexible')};
    % P1 direct final-output GP uses the terminal-stage flexible profile.
    spec.gpOpts=GCF_gp_options(C.opDirectProfile);
    poolIDs=D.poolIdx(:);
    % Original L06 formal: fixed CHECK subset of 512, deterministic temporal stride.
    testIDs=p12_eval_rows(D.testIdx(:),C.opsdNeval);
    rng(555000+seed,'twister');
    initialIDs=poolIDs(randperm(numel(poolIDs),spec.nInitial));
    eligible=setdiff(poolIDs,initialIDs,'stable');
    assert(numel(eligible)>=rounds);
    rng(920000+seed,'twister');
    planIDs=p12_lhs_pool_rows(D.X,eligible,rounds);
    assert(numel(unique(planIDs))==rounds && ...
        isempty(intersect(planIDs,testIDs)) && ...
        isempty(intersect(planIDs,initialIDs)));
    B=struct('group',group,'caseName','OPSD_L06_13D_4STAGE','seed',seed, ...
        's',spec,'X0',D.X(initialIDs,:), ...
        'Y0',D.Y(initialIDs,:), ...
        'Xtest',D.X(testIDs,:),'Ytest',D.Y(testIDs,:), ...
        'yScale',D.yScale(end),'rounds',rounds,'planX',[], ...
        'planIDs',planIDs,'poolX',D.X,'poolY',D.Y,'poolIDs',poolIDs, ...
        'testIDs',testIDs,'initialIDs',initialIDs,'poolFingerprint',D.fingerprint);
    B.trueStd=std(B.Ytest(:,end)*B.yScale);
    B.expectedStd=NaN;B.expectedInitRMSE=NaN;
    assert(B.trueStd>0 && isfinite(B.trueStd));
    assert(isequal(size(B.X0),[50 13]) && size(B.Y0,2)==4);
    assert(all(ismember(initialIDs,poolIDs)) && ...
        isempty(intersect(initialIDs,testIDs)));
else
    error('P12:Group','Bad group: %s',group);
end
assert(size(B.Xtest,1)==size(B.Ytest,1));
assert(all(isfinite(B.X0(:))) && all(isfinite(B.Y0(:))) && ...
    all(isfinite(B.Xtest(:))) && all(isfinite(B.Ytest(:))));
end

function idx=p12_alpine_registry_index(K)
% Original GP_COOP_FORMAL_specs.m: 6S6D is existing case index 14,
% Rosenbrock is 15, then append K=[2 4 8 10 12 14 16 18 20].
if K==6
    idx=14;
else
    v=[2 4 8 10 12 14 16 18 20];
    j=find(v==K);
    assert(isscalar(j));
    idx=15+j;
end
end

function Y=p12_alpine_truth(X)
a=sqrt(10*X).*sin(10*X);
K=size(X,2);Y=zeros(size(X,1),K);
Y(:,1)=-a(:,1);
for k=2:K
    Y(:,k)=a(:,k).*Y(:,k-1);
end
end

function rows=p12_eval_rows(allRows,n)
if numel(allRows)<=n, rows=allRows(:);return;end
q=unique(round(linspace(1,numel(allRows),n)));
rows=allRows(q(:));
end

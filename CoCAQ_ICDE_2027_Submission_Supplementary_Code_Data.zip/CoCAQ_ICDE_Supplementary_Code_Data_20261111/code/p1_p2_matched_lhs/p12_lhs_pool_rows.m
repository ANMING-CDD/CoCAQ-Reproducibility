function chosen=p12_lhs_pool_rows(X,available,n)
% Generate LHS targets and project to nearest UNLABELLED POOL covariate.
% Select by X only. Never inspect hidden pool Y while choosing points.
available=available(:);
assert(numel(available)>=n && numel(unique(available))==numel(available));
Z=double(X(available,:));
lo=min(Z,[],1);hi=max(Z,[],1);span=max(hi-lo,1e-12);
Z=bsxfun(@rdivide,bsxfun(@minus,Z,lo),span);
N=size(Z,1);d=size(Z,2);
T=zeros(n,d);
for j=1:d
    perm=randperm(n)';
    T(:,j)=(perm-1+rand(n,1))/n;
end
chosen=zeros(n,1);
live=true(N,1);
for r=1:n
    cand=find(live);
    delta=bsxfun(@minus,Z(cand,:),T(r,:));
    [~,ii]=min(sum(delta.*delta,2));
    chosen(r)=available(cand(ii));
    live(cand(ii))=false;
end
assert(all(ismember(chosen,available)) && numel(unique(chosen))==n);
end

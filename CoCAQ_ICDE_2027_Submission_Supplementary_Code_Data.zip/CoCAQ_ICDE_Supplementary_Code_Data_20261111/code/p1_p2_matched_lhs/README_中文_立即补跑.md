# V2 修复提醒（先读这段）

上一版在 `p12_run_one.m` 第54行出现 `Optimized chain mean differs from original native cascade`。这表示自写快速均值路径与原引擎预测在你的 MATLAB 会话中不一致。V2 做了以下修复：

1. 快速均值路径改为调用原引擎同一个 `GCF_stage_query`，而非训练输入函数；并在小批测试点上与原生 `GCF_predict_final` 比较。
2. 如仍有数值差异，将**明确警告、记录差异并自动切换为原生级联预测**，不会忽略校验，更不会篡改 RMSE。
3. 切换 Alpine / OPSD 引擎时清理 MATLAB 已缓存的同名函数，并核验 9 个核心函数路径。
4. 修复 `p12_export.m` 中 0×0 空表拼接及配对结果的列类型问题，避免跑完后再触发报告异常。
5. 两个案例的真值、初始样本、随机种子、LHS 采点、预算、GP 拟合器均未更改。

**如何更新：** 最安全是把本 V2 工程解压为新文件夹。如你已在 V1 工程中有有效检查点，可把原来 `output/` 文件夹拷贝到 V2 工程根目录，保留检查点续跑；不要改动旧 `output` 内的 `.mat`。

在 MATLAB 中把当前目录设为 V2 工程根目录，执行：

```matlab
clear functions
rehash
RUN_P12_TWO_CASES('check')
RUN_P12_TWO_CASES('smoke')
```

然后：

```matlab
RUN_P12_TWO_CASES('alpine')
RUN_P12_TWO_CASES('opsd')
RUN_P12_TWO_CASES('report')
RUN_P12_TWO_CASES('plot')
```

`smoke` 使用 `output/smoke`，不会污染正式实验。若出现 `P12:NativeFallback` 警告，表示使用了原生预测，属于受保护的校验回退；若出现 `P12:AlpineParity`，是初始误差与旧五方法不一致，**必须停下核实，不应直接跳过**。

**注意：** 本环境无法执行 MATLAB/Octave。已做源码静态核查及 ZIP 完整性检查，但需要你的 MATLAB `smoke` 结果验证修复。

---

# P1/P2 两案例完整 LHS 补跑工程（无需另外找 JOINT17 源码）

这是一份 **完整、独立** 的 MATLAB 工程，包含原始 Alpine GP 引擎、原始 L06 GP 引擎、OPSD 冻结数据及旧 Alpine 五方法原始结果。不会读取、覆盖或修改你之前的五方法检查点。

## 先运行什么

解压 ZIP，MATLAB 把“当前文件夹”设置为本工程根目录（看到 `RUN_P12_TWO_CASES.m` 的位置），运行：

```matlab
RUN_P12_TWO_CASES('check')
RUN_P12_TWO_CASES('smoke')
```

检查通过后，可选择只跑一个案例：

```matlab
RUN_P12_TWO_CASES('alpine_case',2)  % 2S2D，十种子，完整30轮
RUN_P12_TWO_CASES('opsd')           % OPSD，十种子，第0到12轮
```

或者**补跑论文保留的两个案例**：

```matlab
RUN_P12_TWO_CASES('all')
```

其中 Alpine 为 **2S2D、4S4D、6S6D、8S8D、10S10D、12S12D、14S14D、16S16D、18S18D、20S20D**；每个 K 十种子，第0到30轮；**不包含 Ackley**。

如果中断，直接重复执行 `RUN_P12_TWO_CASES('all')`，会从每条轨迹的 checkpoint 续跑，不丢已完成的计算。

单独汇总或重绘：

```matlab
RUN_P12_TWO_CASES('status')  % 查看每条轨迹已完成轮数
RUN_P12_TWO_CASES('report')
RUN_P12_TWO_CASES('plot')
```

> **注意：** 在 MATLAB 中运行完成才会有真实结果和正式图片。本包不包含任何伪造的 P1/P2 结果。静态检查与独立数值核对已完成，但交付方没有 MATLAB 环境，首次请先执行 `smoke`。

## 论文协议匹配方式

**Alpine**

- 与旧五方法同一组正式种子：`16501–16510`。
- 用原来的注册表索引、`GCF_halton(2048,K,1659000+1000*index)` 重建相同测试集；真值 std 与十种旧报告一一核对通过。
- 用原版随机化规则重建同一个种子的初始设计 `rng(1701000+1000*index+seed); GCF_lhs(6*K,K)`。
- 运行第0轮 P2 后，自动与旧五方法共享的 InitialRMSE 比较。偏差超过2%就停止，而不是继续生成不可比较的数字。
- 额外的30条 LHS 输入由另一条固定随机序列生成。P1/P2 使用**同一批**额外输入。
- 使用原版 Alpine `GCF_fit/GCF_gp_fit`，每轮更新模型，P2为原始逐阶段 GP 的真实前驱标签训练 + 预测前驱输入推断。

**OPSD（L06_JAN_SEP_EXT）**

- 冻结数据内含德国2019年有效对齐记录，POOL/HYPER/SELECT/CHECK 严格隔离。
- 十个配对种子：`30590–30599`，与之前提取的 L06 十种子窗口一致。
- 初始 `50` 条记录严格使用旧 `RUN_L06_OVERNIGHT` 中的 `rng(555000+seed)` 和 `D.poolIdx(randperm(...,50))` 重建。
- 测试集严格使用冻结 CHECK 的 `chooseEvalRows(D.testIdx,512)` 规则。检查集不会被用来选点。
- 每条轨迹 **只新增12条** POOL 记录，逐轮报告第0–12轮的 EUR/MWh RMSE。
- 连续 LHS 目标投影至 POOL 中最近的合法未获取记录，投影只查看 X；同一个种子的 P1/P2 **完全共享这12个记录ID**。
- P2 原始阶段超参数 profile = `smooth/smooth/smooth/flexible`；P1 使用直接终端 GP `flexible`，仍是同一原生 GCF GP 引擎，但直接和级联模型的超参数搜索维度不同。

**重要科学解释**：P1/P2 获取的记录严格相同，因此差异不来自采样点选择。但直接GP和逐阶段GP的输入组织与训练超参数不同，结果展示的是这两种 **建模方案** 的差异；不能声称严格隔离了全部 GP 超参数的因果影响。P2 是否优于 P1 必须以实际运行结果为准，不能预设。

## 结果输出

运行结果与 CSV（自动累计所有已完成轨迹）：

- `output/alpine/*_P12.mat` — 十种规模逐种子可续跑检查点
- `output/opsd/*_P12.mat` — OPSD 逐种子可续跑检查点
- `output/P12_ALPINE_ALL_RUNS.csv`
- `output/P12_ALPINE_ALL_CURVES.csv`
- `output/P12_OPSD_ALL_RUNS.csv`
- `output/P12_OPSD_ALL_CURVES.csv`
- `output/P12_OPSD_SHARED_LHS_ROWS.csv` — 同种子P1/P2共享历史记录ID审计
- `output/P12_PAIRED_BENEFIT.csv` — 配对增益 (P1 - P2) / P1
- **全部 Alpine 补跑完成**后：`output/ALPINE_SEVEN_METHODS_ALL_RUNS.csv` 及 `...ALL_CURVES.csv`（将五方法原始记录和新P1/P2合并为七方法）

绘图保存在 `figures`：

- `Fig8_P1P2_TwoCases_Comparison.pdf` —— **核心图**：左 Alpine 十规模宏平均 NRMSE，右 OPSD 价格 RMSE；P1/P2 95% CI 带。只有 Alpine 十规模都完成才生成宏平均，避免选择少数容易任务画图。
- `Fig8a_P1P2_Alpine_10Panels.pdf` —— Alpine 2×5 十规模 P1/P2 曲线及95% CI带。
- `Fig8b_P1P2_OPSD_12Rounds.pdf` —— OPSD 单面板，第0–12轮，价格RMSE及95% CI带。
- `Fig8c_P1P2_Alpine_PairedGain.pdf` —— Alpine 十规模配对最终误差增益，带95% CI。

全部图片同时导出300 dpi PNG，方便检查。所有曲线**原始均值、无平滑、无择种子**。若未完成十种子，会在小图中显示真实完成数，不假装十种子都完成。

## 论文 LaTeX 图片段落

详见 `FIG8_LATEX_SNIPPET.tex`：把 `Fig8_P1P2_TwoCases_Comparison.pdf` 放在 Overleaf 的 `figures/` 目录，在第五节真实案例后引入对比图。若 P2 有明显优势，可用“相同数据获取路径下，级联建模获得较低终端误差”；若不是，则应写成“比较直接终端GP与级联GP各自优势和局限”，不能用图名强行推导结论。

## 常见问题

- 报找不到 `OPSD_load_L06` 或冻结 MAT：确认解压了完整 ZIP，且当前 MATLAB 文件夹是工程根目录。
- 报 `P12:AlpineParity`：说明复建第0轮误差与旧正式报告不符，请停下来发错误日志，不能与旧五方法作公平比较。
- 旧实验目录不需要改动；本补跑**不使用** `C:\MAPPO整合\...` 路径。
- 运行时间可能较长，因为 Alpine 20S20D 每轮需要拟合20个原版 GP，加上 P1 的直接 GP；代码每轮保存，可以随时续跑。
- OPSD的 `30590–30599` 是历史已检视的种子窗口；论文不应把这组结果声称为前瞻性盲选十种子。

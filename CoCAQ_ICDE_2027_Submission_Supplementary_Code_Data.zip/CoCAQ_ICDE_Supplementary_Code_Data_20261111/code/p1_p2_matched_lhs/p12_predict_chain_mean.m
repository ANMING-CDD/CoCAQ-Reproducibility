function pred=p12_predict_chain_mean(model,spec,X)
%P12_PREDICT_CHAIN_MEAN Mean-only evaluation using NATIVE stage-query logic.
% The original native cascade uses GCF_stage_query, not the training-time
% GCF_stage_input. For the mean, previous gradients do not affect Q, so
% pass zeros and avoid expensive dmean/variance calculations.
% The runner checks this path against GCF_predict_final before accepting it.
N=size(X,1);
if strcmp(spec.kind,'horizontal_ackley_dag')
    error('P12:UnsupportedDAG','This P1/P2 baseline does not support DAG cases.');
end
prevMu=[];
zeroGrad=zeros(N,spec.d);
for k=1:spec.K
    [Q,~,~,~]=GCF_stage_query(spec,X,k,prevMu,zeroGrad);
    prevMu=GCF_gp_predict(model.stage{k},Q);
    prevMu=prevMu(:);
end
pred=prevMu;
assert(numel(pred)==N && all(isfinite(pred)), ...
    'P12:NonfinitePrediction','Nonfinite predicted cascade mean.');
end

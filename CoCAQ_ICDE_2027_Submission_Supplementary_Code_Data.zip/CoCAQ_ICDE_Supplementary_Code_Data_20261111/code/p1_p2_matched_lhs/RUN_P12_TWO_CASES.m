function RUN_P12_TWO_CASES(mode, varargin)
% RUN_P12_TWO_CASES
% All-in-one baseline experiment: P1=LHS+direct GP, P2=identical LHS+stage GPs.
%   RUN_P12_TWO_CASES('check')       % verify frozen data/source
%   RUN_P12_TWO_CASES('smoke')       % brief 1-seed / 2-round code test
%   RUN_P12_TWO_CASES('alpine')      % all 10 Alpine cases, 10 seeds, 30 rounds
%   RUN_P12_TWO_CASES('alpine_case',6) % only 6S6D, 10 seeds, 30 rounds
%   RUN_P12_TWO_CASES('opsd')        % OPSD 10 seeds, ONLY 12 rounds
%   RUN_P12_TWO_CASES('all')         % Alpine + OPSD
%   RUN_P12_TWO_CASES('status')      % inspect completed/partial checkpoints
%   RUN_P12_TWO_CASES('report')      % rebuild CSV from checkpoints
%   RUN_P12_TWO_CASES('plot')        % render P1/P2 plots with confidence bands
%
% No existing method checkpoint is modified. This code never optimizes
% an acquisition based on held-out targets and never fabricates missing runs.
if nargin<1 || isempty(mode), mode='check'; end
root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');
mode=lower(char(mode));
C=p12_protocol(root);
if ~isfolder(C.output), mkdir(C.output); end
switch mode
    case 'check'
        p12_check(C);
    case 'smoke'
        p12_check(C);
        p12_run_group(C,'alpine',2,16501,2,true);
        p12_run_group(C,'opsd',[],30590,2,true);
        p12_export(C);
    case 'alpine'
        p12_check(C);
        p12_run_group(C,'alpine',C.stages,C.alpineSeeds,C.alpineRounds,false);
        p12_export(C);
        p12_plot(C);
    case 'alpine_case'
        assert(~isempty(varargin),'Second argument must be one of [2 4 ... 20].');
        k=double(varargin{1});
        assert(isscalar(k)&&ismember(k,C.stages),'Only Alpine 2S2D through 20S20D.');
        p12_check(C);
        p12_run_group(C,'alpine',k,C.alpineSeeds,C.alpineRounds,false);
        p12_export(C);p12_plot(C);
    case 'opsd'
        p12_check(C);
        p12_run_group(C,'opsd',[],C.opsdSeeds,C.opsdRounds,false);
        p12_export(C);p12_plot(C);
    case 'all'
        p12_check(C);
        p12_run_group(C,'alpine',C.stages,C.alpineSeeds,C.alpineRounds,false);
        p12_run_group(C,'opsd',[],C.opsdSeeds,C.opsdRounds,false);
        p12_export(C);p12_plot(C);
    case 'status'
        p12_status(C);
    case 'report'
        p12_export(C);
    case 'plot'
        p12_export(C);p12_plot(C);
    otherwise
        error('P12:Mode','Unknown mode: %s',mode);
end
end

function p12_run_one(C,B,out)
% Exact paired queries P1/P2; BOTH use original project's native GP engine.
fn=fullfile(out,sprintf('%s_seed%d_P12.mat',B.caseName,B.seed));
nAdd=B.rounds;
if isfile(fn)
    Z=load(fn,'state');state=Z.state;
    assert(strcmp(state.version,C.modelVersion) && ...
        strcmp(state.caseName,B.caseName) && state.seed==B.seed && ...
        state.rounds==B.rounds && ...
        strcmp(state.poolFingerprint,B.poolFingerprint) && ...
        isequaln(state.Xinitial,B.X0) && isequaln(state.Yinitial,B.Y0) && ...
        abs(state.truthStd-B.trueStd)<1e-8*max(1,B.trueStd), ...
        'P12:UnsafeResume','Existing P12 checkpoint does not match frozen case/seed/protocol.');
else
    state=struct();state.version=C.modelVersion;
    state.group=B.group;state.caseName=B.caseName;state.seed=B.seed;
    state.rounds=nAdd;state.K=B.s.K;state.d=B.s.d;
    state.poolFingerprint=B.poolFingerprint;
    state.Xinitial=B.X0;state.Yinitial=B.Y0;
    state.X=B.X0;state.Y=B.Y0;
    state.XtestSignature=[size(B.Xtest,1),size(B.Xtest,2), ...
        sum(B.Xtest(:)),sum(B.Ytest(:,end))];
    state.truthStd=B.trueStd;
    state.scale=B.yScale;
    state.planX=B.planX;state.planIDs=B.planIDs;
    state.initIDs=B.initialIDs;state.testIDs=B.testIDs;
    state.chosenIDs=zeros(0,1);
    state.rmse=nan(nAdd+1,2);
    state.doneRound=-1;
    state.modelP1=[];state.modelP2=[];
    state.parity='not_checked';
    state.predictionMode='unverified';
end
assert(isequaln(state.XtestSignature,[size(B.Xtest,1),size(B.Xtest,2), ...
    sum(B.Xtest(:)),sum(B.Ytest(:,end))]), ...
    'P12:WrongTest','Frozen held-out set differs from the saved state.');
if ~isfield(state,'predictionMode') || isempty(state.predictionMode)
    state.predictionMode='unverified';
end
if state.doneRound==nAdd
    fprintf('[COMPLETE] %-22s seed=%d (0..%d)\n',B.caseName,B.seed,nAdd);
    return;
end
fprintf('[P1/P2] %-22s seed=%d (resume at round %d/%d)\n', ...
    B.caseName,B.seed,state.doneRound+1,nAdd);
for r=state.doneRound+1:nAdd
    % P1: one GP directly modeling the final output.
    state.modelP1=GCF_fit(B.s,state.X,state.Y,'aio',state.modelP1);
    pred1=GCF_predict_final(B.s,state.modelP1,B.Xtest);
    % P2: independent GP per stage, propagated means in cascade order.
    state.modelP2=GCF_fit(B.s,state.X,state.Y,'cascade',state.modelP2);
    % Safety check: if fast mean-only path disagrees with the original
    % native cascade, keep the NATIVE prediction rather than suppressing
    % the check or saving potentially invalid RMSE. Audit the difference.
    if strcmp(state.predictionMode,'unverified')
        n=min(8,size(B.Xtest,1));
        Xprobe=B.Xtest(1:n,:);
        native=GCF_predict_final(B.s,state.modelP2,Xprobe);
        fast=p12_predict_chain_mean(state.modelP2,B.s,Xprobe);
        diffmax=max(abs(fast(:)-native(:)));
        allowed=1e-8*max(1,max(abs(native(:))));
        if diffmax>allowed || ~isfinite(diffmax)
            state.predictionMode='native';
            state.parity=sprintf('NATIVE_FALLBACK diff %.9g tolerance %.9g',diffmax,allowed);
            warning('P12:NativeFallback', ...
                ['%s seed=%d: mean-only path differs from original ', ...
                 'native cascade (maxdiff=%.9g, tol=%.9g). ', ...
                 'Using NATIVE GCF_predict_final for ALL test rows.'], ...
                B.caseName,B.seed,diffmax,allowed);
        else
            state.predictionMode='fast_verified';
            state.parity=sprintf('Native-mean parity passed: maxdiff %.9g',diffmax);
        end
    end
    if strcmp(state.predictionMode,'native')
        pred2=GCF_predict_final(B.s,state.modelP2,B.Xtest);
    else
        pred2=p12_predict_chain_mean(state.modelP2,B.s,B.Xtest);
    end
    ytrue=B.Ytest(:,end)*B.yScale;
    state.rmse(r+1,1)=sqrt(mean((pred1(:)*B.yScale-ytrue(:)).^2));
    state.rmse(r+1,2)=sqrt(mean((pred2(:)*B.yScale-ytrue(:)).^2));
    assert(all(isfinite(state.rmse(r+1,:))) && all(state.rmse(r+1,:)>=0));
    if r==0 && strcmp(B.group,'alpine')
        relative=abs(state.rmse(1,2)-B.expectedInitRMSE)/max(B.expectedInitRMSE,1e-12);
        if relative>0.02
            error('P12:AlpineParity',[ ...
                'P2 initial RMSE mismatch (%.3g vs original %.3g, %.2f%%). ', ...
                'Stop rather than claim matched experiment.'], ...
                state.rmse(1,2),B.expectedInitRMSE,100*relative);
        end
        state.parity=sprintf('%s | Alpine original round-0 P2 RMSE relative diff %.4g', ...
            state.parity,relative);
    end
    if r<nAdd
        if strcmp(B.group,'alpine')
            x=B.planX(r+1,:);
            y=p12_alpine_truth_local(x);
        else
            id=B.planIDs(r+1);
            assert(ismember(id,B.poolIDs) && ~ismember(id,B.testIDs) && ...
                ~ismember(id,[B.initialIDs(:);state.chosenIDs(:)]), ...
                'P12:Leakage','Illegal or duplicate OPSD acquisition.');
            x=B.poolX(id,:);y=B.poolY(id,:); % labels revealed AFTER X-only selection
            state.chosenIDs(end+1,1)=id;
        end
        state.X(end+1,:)=x;
        state.Y(end+1,:)=y;
    end
    state.doneRound=r;
    tmp=[fn '.tmp'];
    save(tmp,'state','-v7');
    [ok,msg]=movefile(tmp,fn,'f');assert(ok,'P12:Save','Could not save: %s',msg);
    if mod(r,5)==0 || r==nAdd
        fprintf('   round %2d/%2d: P1 RMSE=%11.6g, P2 RMSE=%11.6g\n', ...
            r,nAdd,state.rmse(r+1,1),state.rmse(r+1,2));
    end
end
end

function Y=p12_alpine_truth_local(X)
a=sqrt(10*X).*sin(10*X);K=size(X,2);
Y=zeros(size(X,1),K);Y(:,1)=-a(:,1);
for k=2:K, Y(:,k)=a(:,k).*Y(:,k-1); end
end

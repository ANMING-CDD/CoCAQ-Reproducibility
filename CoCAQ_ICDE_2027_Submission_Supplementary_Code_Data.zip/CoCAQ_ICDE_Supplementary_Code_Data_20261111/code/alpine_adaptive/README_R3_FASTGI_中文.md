# R3 Fast-Gi 真正策略引导版 · MATLAB 使用说明

> **当前状态：** 我已完成源码层面的静态检查与打包；本环境没有 MATLAB R2024a，**不能声称 MATLAB 端到端测试已经通过**。请先 `preflight`、`smoke`，再运行 `pilot`。

## 与 V4A 的本质区别

V4A 仅让 GP 梯度产生的候选和 MAPPO 候选竞争，**没有把成功的梯度调整用于 Actor 更新**。本版将梯度精修改为**受控的策略教师（gradient teacher）**：

1. MAPPO 仍以逐阶段条件策略构造完整的输入向量 `x`，内部状态中的先前 `y` **仅使用 GP 预测值**，没有使用未来真实中间响应；
2. Fast-Gi 对评分好的**完整输入向量**求解析梯度，沿 `[0.04, 0.10]` 两种步长构造候选；每个候选都占用一次 GP 采集评分预算；
3. 仅当新候选评分比起点实际提升至少 **0.1%**（可修改）时，才生成监督教师；无效/数值异常梯度不进入教师集；
4. Actor 仍做原有 PPO on-policy 更新，另外加入 `0.08` 系数的**梯度改善目标回归**，并基于每个阶段的移动幅度控制教师权重；
5. Critic 和 PPO 重要性比率只使用**原策略实际采样的候选**，**不把经过梯度修改的点伪装成 on-policy 样本**；
6. 梯度监督在每批 PPO 训练期间作用于同一个 Actor，下一批候选会从更新后的 Actor 生成，这才形成“Fast-Gi 指引后续探索”的局部闭环。

这里的梯度是**固定级联 GP 后验下 Fast-Gi 采集代理函数的解析梯度**，不是最终真实目标 `y_K` 或测试 RMSE 的梯度。提高该代理分数不能保证减少真实泛化误差。

## 三个必做消融（同一个 GP 采集代理 + 相同候选评分预算）

| 方法 | Fast-Gi 梯度候选 | 梯度教师更新 Actor | 对照目的 |
|---|---|---|---|
| `R3_BASE` | 否 | 否 | 普通 GP-MAPPO，预算全部用于策略候选 |
| `R3_REFINE` | 是；两步长精修 | 否 | 只有候选精修的贡献 |
| **`R3_GUIDED`** | 是；两步长精修 | **是** | 真正梯度策略引导的增量 |
| `A2` | 传统 CMA-ES 级联采集 | — | 强级联主动学习参考基线（采集目标与 R3 三组不同） |

`R3_REFINE` vs `R3_GUIDED` 是最干净的关键对比。两者代码路径及评分预算相同，区别仅在 Actor 是否使用教师监督。`R3_BASE` 与它们的普通 PPO 候选数量不同，因为梯度评估不是免费的，这一点要在论文中说明。

## 运行方式

**完整独立版**直接解压到例如 `C:\MAPPO整合\` 后：

```matlab
cd('C:\MAPPO整合\CoCAQ_R3_GUIDED_STANDALONE_20261106\matlab')
COCAQ_R3_GUIDED_RUN('preflight');  % 检查三套冻结函数和原R2配置
COCAQ_R3_GUIDED_RUN('smoke');      % 3S15D,1个种子,2轮,64候选
COCAQ_R3_GUIDED_RUN('pilot');      % 3S15D,2个种子,12轮,300候选
COCAQ_R3_GUIDED_RUN('report');     % 输出结果汇总CSV
```

**如果使用增量补丁**：将补丁解压到你当前这个目录的上一级：

`C:\MAPPO整合\CoCAQ_Budget300vs600_PILOT_PATCH_20261106\`

确认新增 `.m` 文件处在：

`...\CoCAQ_MASTER_20261106\01_ACTIVE_R2\matlab\`

再 `cd` 到这里运行相同的 `COCAQ_R3_GUIDED_RUN(...)` 命令。**不要把补丁解压为另一个嵌套的独立工程。**

你可以先检查 MATLAB 是否能看到源码：

```matlab
which COCAQ_R3_GUIDED_RUN -all
which MSBO_R3_GUIDED_ENGINE -all
which GCF_mappo_guided -all
```

### 后续扩展（不建议现在就做）

```matlab
COCAQ_R3_GUIDED_RUN('expand');
```

包含 MSBO `3S15D/4S20D/5S20D`、3 个新种子、30 轮、每轮 300 候选，每方法每种子都运行完整级联。和已有 R2 `8301:8310` 种子不重叠。

## 保存位置与判断标准

原 MSBO R2 的 `results/R2_runs` 和已有预算测试的 `results/BUDGET_PILOT_V1` 均**不会被覆盖**。

- R3 每轮 `.mat` 检查点：`matlab/results/R3_GUIDED_runs/`；支持原样续跑。
- R3 报告：`matlab/results/R3_GUIDED_REPORTS/PILOT/`，重点看 `PAIRED_COMPARISON.csv`、`ALL_RUNS.csv`、`ALL_CURVES.csv`。
- 诊断列：`GradientTrials`、`AcceptedGradients`、`TeacherPairs`、`DistillUpdates`、`GradientChosen`；可判断教师实际激活与否。

**判定顺序：**

1. `R3_GUIDED` 的 `TeacherPairs` 与 `DistillUpdates` 是否大于零？若长期为零，梯度实际未能引导训练；
2. `R3_GUIDED` 是否优于 `R3_REFINE`？若否，增加教师机制不值得保留；
3. `R3_REFINE` 是否优于 `R3_BASE`？若否，梯度精修可能挤占了更有用的普通 MAPPO 探索；
4. `R3_GUIDED` 是否优于 `A2` 且额外计算时间合理？
5. 以上只提供小样本的探索性信号，**不能作为 ICDE 正式统计结论**。

## 与原论文结果的关系

- 本 R3 使用全新方法实现，**不是从 R2 检查点继续训练**。
- 这是 3 种 MAPPO 变体共享同一组代码默认超参数的机制验证；**没有假装使用缺失的 R2 冻结参数**。
- 原有 `MSBO_R2_ENGINE.m`、`GCF_mappo_v4.m`、`MSBO_R2_config.m` 全部原样保留。
- 固定 R3 版本后，如需发表，应重新规划独立验证集/冻结配置与从未使用过的正式测试种子。

## 技术限制

- 梯度教师蒸馏是一个新的训练辅助项，并不是标准 PPO 本身；通过组合梯度保留原 PPO 的 on-policy 比率正确性，但并不保证 PPO 单调改进。
- Fast-Gi 的代理与真实泛化误差之间仍存在模型偏差，这是需要真实实验检验的科学问题，无法仅通过“步长更稳健”直接消除。
- 本版 Actor 仍然每次真实采样都重新初始化，闭环发生在**一次采集搜索的内部批次之间**，不是跨 30 次真实采样轮次持续记忆。如果想跨轮温启动，那是另外一项需要对照的设计，不应与本次机制改动混为一谈。

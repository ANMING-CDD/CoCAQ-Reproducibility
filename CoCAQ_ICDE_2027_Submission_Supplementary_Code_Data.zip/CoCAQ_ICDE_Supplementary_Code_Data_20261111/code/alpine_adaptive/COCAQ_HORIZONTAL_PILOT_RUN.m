function COCAQ_HORIZONTAL_PILOT_RUN(action,caseId)
% Horizontal literature-derived function-network SCREENING ONLY.
% 18 cases, 3 independent paired seeds, 8 real rounds, 128 acquisitions/round.
% NO formal claims, NO tuning, NO mutation of original Alpine2/formal runs.
% Unlike the original BO optimization papers, metric here is held-out GP RMSE.
if nargin<1||isempty(action),action='help';end
if nargin<2,caseId='';end
root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
cases=GP_COOP_HORIZONTAL_specs(root);ids={cases.id};
action=lower(char(action));
switch action
 case {'help','?'}
  fprintf(['COCAQ_HORIZONTAL_PILOT_RUN(''preflight'')\n' ...
   'COCAQ_HORIZONTAL_PILOT_RUN(''selftest'')\n' ...
   'COCAQ_HORIZONTAL_PILOT_RUN(''smoke'')    %% 3 families, one seed, 2 rounds, two methods\n' ...
   'COCAQ_HORIZONTAL_PILOT_RUN(''pilot_first'') %% 8 representative cases, checkpoints reused\n' ...
   'COCAQ_HORIZONTAL_PILOT_RUN(''pilot'')    %% 18 cases x 3 seeds x 5 methods x 8 rounds\n' ...
   'COCAQ_HORIZONTAL_PILOT_RUN(''pilot_case'',''H_ACKMAT_2S20D'')\n' ...
   'COCAQ_HORIZONTAL_PILOT_RUN(''status'')\n' ...
   'COCAQ_HORIZONTAL_PILOT_RUN(''report'')\n']);
 case 'preflight'
  localPreflight(root,cases);
 case 'selftest'
  localPreflight(root,cases);
  GP_COOP_HORIZONTAL_SELFTEST(root);
 case 'smoke'
  localPreflight(root,cases);
  S=localProtocol('smoke');
  S.cases={'H_ACKMAT_2S7D','H_ACKLEY_3S6D','H_ROSEN_4S10D'};
  localRun(S);
  fprintf('Smoke checks only, do not use these scores for method ranking.\n');
 case 'pilot_first'
  localPreflight(root,cases);
  S=localProtocol('pilot');
  S.cases={'H_ACKMAT_2S7D','H_ACKMAT_2S30D', ...
   'H_ACKLEY_3S6D','H_ACKLEY_3S30D', ...
   'H_ROSEN_4S10D','H_ROSEN_4S30D', ...
   'H_ROSEN_6S12D','H_ROSEN_6S30D'};
  localRun(S);localReport(root,cases);
 case 'pilot'
  localPreflight(root,cases);
  S=localProtocol('pilot');S.cases=ids;
  localRun(S);localReport(root,cases);
 case 'pilot_case'
  localPreflight(root,cases);
  assert(ischar(caseId)||isstring(caseId),'Provide case ID');
  assert(any(strcmp(ids,char(caseId))),'Unknown horizontal case: %s',char(caseId));
  S=localProtocol('pilot');S.cases={char(caseId)};
  localRun(S);localReport(root,cases);
 case 'report'
  localReport(root,cases);
 case 'status'
  localStatus(root,cases);
 otherwise
  error('Unknown horizontal pilot action. Call COCAQ_HORIZONTAL_PILOT_RUN(''help'').');
end
end

function S=localProtocol(mode)
S=struct('studyID','','phase','SCREENING_ONLY','seeds',[], ...
 'cases',{{}},'methods',{{'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_REFERENCE'}}, ...
 'rounds',8,'nAcq',128,'nAnchors',24,'nTest',1024,'nRef',256,'rank',24, ...
 'testBase',1669000,'methodOverrides',struct(),'lockFingerprint','UNTUNED_PILOT', ...
 'mode','HORIZONTAL_SCREENING');
switch mode
 case 'pilot'
  S.studyID='GP_COOP_HORIZONTAL_PILOT_3SEED_8ROUND_128A_V1';
  S.seeds=16611:16613;
 case 'smoke'
  S.studyID='GP_COOP_HORIZONTAL_SMOKE_1SEED_2ROUND_V1';
  S.seeds=16601;S.rounds=2;S.nAcq=64;S.nAnchors=16;
  S.nTest=128;S.nRef=64;S.rank=12;S.testBase=1667000;
  S.methods={'A2','V4A_REFERENCE'};
 otherwise,error('Unknown protocol mode');
end
end

function localPreflight(root,cases)
assert(numel(cases)==18 && numel(unique(string({cases.id})))==18);
need={'GP_COOP_HORIZONTAL_specs.m','GP_COOP_HORIZONTAL_SELFTEST.m', ...
 'GP_COOP_FORMAL_ENGINE.m','GP_COOP_FORMAL_truth.m', ...
 fullfile('engine','GCF_stage_input.m'), ...
 fullfile('engine','GCF_stage_query.m'), ...
 fullfile('engine','GCF_cascade_predict.m'), ...
 fullfile('engine','GCF_chain_build.m'), ...
 fullfile('engine','GCF_fastgi_build.m')};
for j=1:numel(need)
 assert(isfile(fullfile(root,need{j})),'Missing %s',need{j});
end
P=localProtocol('pilot');
assert(isempty(intersect(P.seeds,16501:16510)));
assert(isempty(intersect(P.seeds,16401:16402)));
for j=1:numel(cases)
 s=cases(j);
 assert(s.d<=30 && all(s.stageDims>=1) && sum(s.stageDims)==s.d);
end
fprintf('HORIZONTAL PREFLIGHT OK: 18 opt-in cases / 3 pilot seeds / 5 methods / 8 rounds.\n');
fprintf('Ackley DAG uses TWO parallel upstream GPs; pilot MAPPO actors control disjoint x partitions.\n');
fprintf('NO per-case tuning in pilot. Legacy 14-case and Alpine2 registries are unchanged.\n');
end

function localRun(S)
fprintf('SCREENING %s: %d cases x %d seeds x %d algorithms = %d runs.\n', ...
 S.studyID,numel(S.cases),numel(S.seeds),numel(S.methods), ...
 numel(S.cases)*numel(S.seeds)*numel(S.methods));
for i=1:numel(S.cases)
 GP_COOP_FORMAL_ENGINE(S,S.cases{i});
end
end

function file=localCheckpoint(root,S,id,seed,method)
file=fullfile(root,'results','GP_COOP_FORMAL_runs',S.studyID,id, ...
 sprintf('%s_seed%d_%s.mat',id,seed,method));
end

function localStatus(root,cases)
S=localProtocol('pilot');rows=cell(numel(cases),5);
for j=1:numel(cases)
 s=cases(j);complete=0;partial=0;
 for seed=S.seeds
  for m=1:numel(S.methods)
   file=localCheckpoint(root,S,s.id,seed,S.methods{m});
   if ~isfile(file),continue;end
   z=load(file,'H','signature');
   assert(strcmp(z.signature.studyID,S.studyID),'Unexpected pilot checkpoint.');
   if numel(z.H.RMSE)==S.rounds+1,complete=complete+1;
   else,partial=partial+1;end
  end
 end
 rows(j,:)={string(s.id),s.K,s.d,complete,partial};
end
T=cell2table(rows,'VariableNames', ...
 {'Case','Nodes','D','CompleteRuns','PartialRuns'});
disp(T);fprintf('Expected per case: 15 complete runs.\n');
end

function localReport(root,cases)
S=localProtocol('pilot');folder=fullfile(root,'results','GP_COOP_HORIZONTAL_PILOT_reports');
if ~isfolder(folder),mkdir(folder);end
runRows=cell(0,13);curveRows=cell(0,7);meanRows=cell(0,10);
pairRows=cell(0,10);coverRows=cell(0,9);
for ci=1:numel(cases)
 s=cases(ci);id=string(s.id);index=100+ci;
 Xtest=GCF_halton(S.nTest,s.d,S.testBase+1000*index);
 Ytest=GP_COOP_FORMAL_truth(s,Xtest);
 yScale=std(Ytest(:,end));
 assert(isfinite(yScale)&&yScale>1e-10,'Degenerate held-out truth scale %s',s.id);
 nMethods=zeros(1,numel(S.methods));
 for mi=1:numel(S.methods)
  method=S.methods{mi};
  for seed=S.seeds
   file=localCheckpoint(root,S,s.id,seed,method);
   if ~isfile(file),continue;end
   z=load(file,'H','signature');H=z.H;sg=z.signature;
   assert(strcmp(sg.studyID,S.studyID) && strcmp(sg.caseId,s.id) && ...
    sg.seed==seed && strcmp(sg.method,method) && ...
    sg.rounds==S.rounds && sg.nAcq==S.nAcq && ...
    sg.nTest==S.nTest && sg.testBase==S.testBase && ...
    strcmp(sg.lockFingerprint,S.lockFingerprint), ...
    'Pilot protocol mismatch: %s',file);
   if numel(H.RMSE)~=S.rounds+1,continue;end
   assert(numel(H.RewardCalls)==S.rounds && ...
    all(H.RewardCalls==S.nAcq), 'Pilot acquisition budget mismatch: %s',file);
   nMethods(mi)=nMethods(mi)+1;
   y=H.RMSE(:);au=trapz((0:S.rounds)',y)/S.rounds;
   secs=sum(H.OptimizeSec(:));
   runRows(end+1,:)={id,s.K,s.d,seed,string(method),y(end), ...
    y(end)/yScale,au,au/yScale,secs,yScale,y(1),S.rounds}; %#ok<AGROW>
   for r=0:S.rounds
    curveRows(end+1,:)={id,seed,string(method),r,y(r+1), ...
     y(r+1)/yScale,s.K}; %#ok<AGROW>
   end
  end
 end
 coverRows(end+1,:)={id,s.K,s.d,nMethods(1),nMethods(2), ...
  nMethods(3),nMethods(4),nMethods(5),min(nMethods)}; %#ok<AGROW>
end
rn={'Case','Stages','D','Seed','Method','FinalRMSE','FinalNRMSE', ...
 'AULC','AULC_NRMSE','SearchSeconds','TruthStd','StartRMSE','Rounds'};
R=localTable(runRows,rn, ...
 {'string','double','double','double','string','double','double', ...
 'double','double','double','double','double','double'});
writetable(R,fullfile(folder,'ALL_RUNS.csv'));
cn={'Case','Seed','Method','Round','RMSE','NRMSE','Stages'};
C=localTable(curveRows,cn, ...
 {'string','double','string','double','double','double','double'});
writetable(C,fullfile(folder,'ALL_CURVES.csv'));
for ci=1:numel(cases)
 s=cases(ci);id=string(s.id);W=R(R.Case==id,:);
 for mi=1:numel(S.methods)
  method=string(S.methods{mi});A=W(W.Method==method,:);
  if isempty(A),continue;end
  meanRows(end+1,:)={id,s.K,s.d,method,height(A), ...
   mean(A.FinalRMSE),mean(A.FinalNRMSE),mean(A.AULC_NRMSE), ...
   mean(A.SearchSeconds),mean(A.TruthStd)}; %#ok<AGROW>
 end
 base=W(W.Method=="A2",:);
 for mi=2:numel(S.methods)
  method=string(S.methods{mi});P=W(W.Method==method,:);
  [common,ia,ib]=intersect(base.Seed,P.Seed);
  if isempty(common),continue;end
  x=base.FinalNRMSE(ia);y=P.FinalNRMSE(ib);
  pairRows(end+1,:)={id,s.K,s.d,method,numel(common), ...
   mean(x),mean(y),100*(mean(x)-mean(y))/max(mean(x),realmin), ...
   sum(y<x),mean(P.SearchSeconds(ib))}; %#ok<AGROW>
 end
end
mn={'Case','Stages','D','Method','NSeeds','MeanRMSE', ...
 'MeanNRMSE','MeanAULC_NRMSE','MeanSearchSeconds','TruthStd'};
M=localTable(meanRows,mn, ...
 {'string','double','double','string','double','double','double', ...
 'double','double','double'});
writetable(M,fullfile(folder,'METHOD_MEANS.csv'));
pn={'Case','Stages','D','Method','NPairedSeeds','A2_MeanNRMSE', ...
 'Method_MeanNRMSE','GainVsA2_pct','WinsVsA2','MethodSearchSeconds'};
P=localTable(pairRows,pn, ...
 {'string','double','double','string','double','double','double', ...
 'double','double','double'});
writetable(P,fullfile(folder,'PAIRED_VS_A2.csv'));
cv={'Case','Stages','D','A2Runs','A3Runs','A4Runs','A5Runs','V4ARuns','MinCompleteRuns'};
V=localTable(coverRows,cv, ...
 {'string','double','double','double','double','double','double','double','double'});
writetable(V,fullfile(folder,'CASE_COVERAGE.csv'));
% Explicitly separate full-case preliminary comparisons from partial data.
Q=P(P.NPairedSeeds==numel(S.seeds),:);
writetable(Q,fullfile(folder,'COMPLETE_THREE_SEED_COMPARISONS.csv'));
% Keep an honest case-comparison view even when the pilot is incomplete.
shortRows=cell(numel(cases),15);
for ci=1:numel(cases)
 s=cases(ci);id=string(s.id);W=R(R.Case==id,:);
 if strcmp(s.kind,'horizontal_ackmat'),family="AckMat";
 elseif strcmp(s.kind,'horizontal_ackley_dag'),family="AckleyDAG";
 else,family="GroupedRosen";end
 A=W(W.Method=="A2",:);
 V=W(W.Method=="V4A_REFERENCE",:);
 T5=W(W.Method=="A5_GP_MAPPO",:);
 [common,ia,iv]=intersect(A.Seed,V.Seed);
 [common5,i5a,i5v]=intersect(T5.Seed,V.Seed);
 gA=NaN;g5=NaN;wins=NaN;ratio=NaN;
 if ~isempty(common)
  xb=A.FinalNRMSE(ia);yv=V.FinalNRMSE(iv);
  gA=100*(mean(xb)-mean(yv))/max(mean(xb),realmin);
  wins=sum(yv<xb);
  if mean(A.SearchSeconds(ia))>0
   ratio=mean(V.SearchSeconds(iv))/mean(A.SearchSeconds(ia));
  end
 end
 if ~isempty(common5)
  xv=T5.FinalNRMSE(i5a);yv=V.FinalNRMSE(i5v);
  g5=100*(mean(xv)-mean(yv))/max(mean(xv),realmin);
 end
 ar=NaN;vr=NaN;a5r=NaN;
 if ~isempty(A),ar=mean(A.FinalNRMSE);end
 if ~isempty(V),vr=mean(V.FinalNRMSE);end
 if ~isempty(T5),a5r=mean(T5.FinalNRMSE);end
 shortRows(ci,:)={id,family,s.K,s.d,height(A),height(V),height(T5), ...
  ar,vr,a5r,numel(common),gA,g5,wins,ratio};
end
sn={'Case','Family','Stages','D','A2Seeds','V4ASeeds','A5Seeds', ...
 'A2_NRMSE','V4A_NRMSE','A5_NRMSE','V4A_A2_PairedSeeds', ...
 'V4A_GainVsA2_pct','V4A_GainVsA5_pct','V4A_WinsVsA2', ...
 'V4A_SearchTimeRatioVsA2'};
Z=localTable(shortRows,sn,{'string','string','double','double', ...
 'double','double','double','double','double','double','double', ...
 'double','double','double','double'});
writetable(Z,fullfile(folder,'SHORTLIST_COMPARISON.csv'));
fprintf('Horizontal pilot reports in: %s\n',folder);
fprintf('Completed: %d / %d runs, full paired case comparisons: %d\n', ...
 height(R),numel(cases)*numel(S.seeds)*numel(S.methods),height(Q));
if ~isempty(Q)
 disp(Q(Q.Method=="V4A_REFERENCE", ...
  {'Case','D','GainVsA2_pct','WinsVsA2','NPairedSeeds'}));
end
end

function T=localTable(rows,names,types)
if isempty(rows)
 T=table('Size',[0 numel(names)], ...
  'VariableTypes',types,'VariableNames',names);
else
 T=cell2table(rows,'VariableNames',names);
end
end

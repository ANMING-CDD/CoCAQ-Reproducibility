function COCAQ_GP_COOP_FORMAL_RUN(action,caseId)
% FINAL 30-round, 10-seed protocol: original 14 cases unchanged.
% Extended opt-in Alpine2 sweep: even K=D=2,4,...,20 (10 cases).
% Optional historical 15th case: CascadeBO Rosenbrock. Tuning only for
% A4_MAPPO and A5_GP_MAPPO. IPPO, CMA-ES, V4A remain fixed across all cases.
% Each case's hyperparameters are locked using different seed IDs, before
% any 30x10 evaluation can start. Historical results are NEVER overwritten.
if nargin<1||isempty(action),action='help';end
if nargin<2,caseId='';end
root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
action=lower(char(action));
allCases=GP_COOP_FORMAL_specs(root);
regular={allCases(1:14).id};extended={allCases.id};
legacy={allCases(1:15).id};
alpineK=2:2:20;
alpine=arrayfun(@(K)sprintf('BOFN_ALPINE2_%dS%dD',K,K), ...
 alpineK,'UniformOutput',false);
switch action
 case {'help','?'}
  fprintf(['COCAQ_GP_COOP_FORMAL_RUN(''preflight'')\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''selftest'')\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''smoke'')\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''tune'')       %% all 14 cases; tune A4/A5 only\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''formal'')     %% 14 cases x 10 seeds x 5 methods\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''all'')        %% tune + formal sequentially\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''all15'')      %% plus optional Rosenbrock\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''tune_case'',''MSBO_3S_15D'')\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''formal_case'',''MSBO_3S_15D'')\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''report'')\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''status'')\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''alpine_smoke'')  %% 2S2D and 20S20D\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''alpine_tune'')   %% only 2/4/.../20\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''alpine_formal'') %% requires tuned locks\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''alpine_all'')    %% tune + formal; resumable\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''alpine_status'')\n' ...
   'COCAQ_GP_COOP_FORMAL_RUN(''alpine_report'')\n']);
 case 'preflight'
  localPreflight(root,allCases);
 case 'selftest'
  localPreflight(root,allCases);
  COCAQ_GP_COOP_SELFTEST(); GP_COOP_FORMAL_SELFTEST(root);
 case 'smoke'
  localPreflight(root,allCases);
  S=localProtocol('smoke');S.cases=regular(1);
  % Choose a function benchmark to exercise the non-MSBO branch as well.
  S.cases={regular{1},'BOFN_ALPINE2_6S6D'};
  localRun(root,S);localReport(root,allCases);
 case 'tune'
  localPreflight(root,allCases);
  for i=1:numel(regular),localTuneCase(root,regular{i});end
  localReport(root,allCases);
 case 'formal'
  localPreflight(root,allCases);
  for i=1:numel(regular)
   S=localFormalProtocol(root,regular{i});localRun(root,S);
   localReport(root,allCases);
  end
 case 'all'
  localPreflight(root,allCases);
  for i=1:numel(regular)
   localTuneCase(root,regular{i});
   S=localFormalProtocol(root,regular{i});localRun(root,S);
   localReport(root,allCases);
  end
 case 'all15'
  localPreflight(root,allCases);
  for i=1:numel(legacy)
   localTuneCase(root,legacy{i});
   S=localFormalProtocol(root,legacy{i});localRun(root,S);
   localReport(root,allCases);
  end
 case 'alpine_smoke'
  localPreflight(root,allCases);
  S=localProtocol('smoke');S.cases={alpine{1},alpine{end}};
  localRun(root,S);
  fprintf('ALPINE SMOKE OK. These are code checks, not formal scores.\n');
 case 'alpine_tune'
  localPreflight(root,allCases);
  for i=1:numel(alpine),localTuneCase(root,alpine{i});end
  localReport(root,allCases,'alpine');
 case 'alpine_formal'
  localPreflight(root,allCases);
  for i=1:numel(alpine)
   S=localFormalProtocol(root,alpine{i});localRun(root,S);
   localReport(root,allCases,'alpine');
  end
 case 'alpine_all'
  localPreflight(root,allCases);
  for i=1:numel(alpine)
   localTuneCase(root,alpine{i});
   S=localFormalProtocol(root,alpine{i});localRun(root,S);
   localReport(root,allCases,'alpine');
  end
 case 'alpine_report'
  localReport(root,allCases,'alpine');
 case 'alpine_status'
  localStatus(root,allCases,'alpine');
 case 'tune_case'
  localPreflight(root,allCases);localValidateCase(extended,caseId);
  localTuneCase(root,caseId);localReport(root,allCases);
 case {'formal_case','resume_case'}
  localPreflight(root,allCases);localValidateCase(extended,caseId);
  S=localFormalProtocol(root,caseId);localRun(root,S);
  localReport(root,allCases);
 case 'report'
  localReport(root,allCases);
 case 'status'
  localStatus(root,allCases);
 otherwise
  error('Unknown mode. Run COCAQ_GP_COOP_FORMAL_RUN(''help'').');
end
end

function S=localProtocol(mode)
S=struct('studyID','','phase','','seeds',[],'cases',{{}}, ...
 'methods',{{'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_REFERENCE'}}, ...
 'rounds',30,'nAcq',300,'nAnchors',48,'nTest',2048, ...
 'nRef',1024,'rank',48,'testBase',1690000, ...
 'methodOverrides',struct(),'lockFingerprint','NONE', ...
 'mode',upper(mode));
switch mode
 case 'smoke'
  S.studyID='GP_COOP_FORMAL_V1_SMOKE';S.phase='CODE_CHECK_ONLY';
  S.seeds=16301;S.rounds=2;S.nAcq=64;S.nAnchors=16;
  S.nTest=128;S.nRef=128;S.rank=16;S.testBase=1639000;
 case 'tune'
  S.studyID='GP_COOP_FORMAL_V1_TUNING';S.phase='TRAIN_SEEDS_ONLY';
  S.seeds=16401:16402;S.rounds=10;S.testBase=1649000;
 case 'formal'
  S.studyID='GP_COOP_FORMAL_V1_30R10S';S.phase='LOCKED_FORMAL';
  S.seeds=16501:16510;S.rounds=30;S.testBase=1659000;
 otherwise,error('Bad formal protocol mode');
end
end

function localPreflight(root,cases)
need={'COCAQ_GP_COOP_FORMAL_RUN.m','GP_COOP_FORMAL_ENGINE.m', ...
 'GP_COOP_FORMAL_specs.m','GP_COOP_FORMAL_truth.m', ...
 'GP_COOP_FORMAL_SELFTEST.m','GP_COOP_ALPINE_SUMMARY.m', ...
 'MSBO_GRID_specs.m','MSBO_GRID_truth.m', ...
 fullfile('engine','GCF_gpcoop_ppo.m'), ...
 fullfile('engine','GCF_mappo_v4.m'), ...
 fullfile('engine','GCF_fit.m'), ...
 fullfile('engine','GCF_chain_build.m'), ...
 fullfile('engine','GCF_chain_eval.m'), ...
 fullfile('engine','GCF_cmaes.m')};
for i=1:numel(need)
 assert(isfile(fullfile(root,need{i})),'Missing %s',need{i});
end
assert(numel(cases)==24 && numel(unique(string({cases.id})))==24);
for K=2:2:20
 id=sprintf('BOFN_ALPINE2_%dS%dD',K,K);
 ix=find(strcmp({cases.id},id));assert(isscalar(ix));
 assert(cases(ix).K==K && cases(ix).d==K && ...
  isequal(cases(ix).stageDims,ones(1,K)) && cases(ix).nInitial==6*K);
end
for i=1:12
 manifest=fullfile(cases(i).folder,'manifest.json');
 assert(isfile(manifest),'Missing oracle %s',manifest);
 m=jsondecode(fileread(manifest));
 assert(m.K==cases(i).K && m.D==cases(i).d && ...
  isequal(double(m.stageDims(:)'),double(cases(i).stageDims)), ...
  'Frozen MSBO oracle dimensions differ: %s',cases(i).id);
end
assert(isempty(intersect(16401:16402,16501:16510)));
assert(isempty(intersect(16501:16510,8301:8310)));
fprintf(['PREFLIGHT OK: 12 frozen MSBO + 3 formula function cases.\n' ...
 'Default FORMAL: 12 MSBO + CASE01 + BOFN_ALPINE2 = 14 cases,\n' ...
 '10 seeds x 30 real rounds x 5 methods; 300 scores per real round.\n' ...
 'Only MAPPO and GP-MAPPO tuned (per case, separate train seeds).\n' ...
 'A2, IPPO and original V4A are frozen; no hidden retuning.\n' ...
 'ALPINE extension: even depths 2S2D..20S20D, opt-in only.\n']);
end

function localValidateCase(ids,caseId)
assert(ischar(caseId)||isstring(caseId),'Provide a case ID');
assert(any(strcmp(ids,char(caseId))),'Unknown case: %s',char(caseId));
end

function localRun(root,S)
fprintf('\n%s: %s, %d seeds x %d methods = %d runs; %d rounds; %d scores\n', ...
 S.studyID,strjoin(S.cases,','),numel(S.seeds),numel(S.methods), ...
 numel(S.cases)*numel(S.seeds)*numel(S.methods),S.rounds,S.nAcq);
for i=1:numel(S.cases),GP_COOP_FORMAL_ENGINE(S,S.cases{i});end
end

function grid=localGrid()
% FROZEN PRE-REGISTERED 4-way grid; not rewritten after formal evaluations.
% Both MAPPO variants get the SAME grid and training protocol.
grid=cell(4,1);
grid{1}=struct('hidden',64,'batch',32,'nEpoch',6, ...
 'actorLR',.002,'criticLR',.004,'sigma',1.10,'minSigma',.25, ...
 'ppoTargetKL',.07,'ppoMinEpoch',3,'ppoEntropyCoeff',0, ...
 'priorMix',.20,'priorTemp',.25,'priorWidth',.40,'priorH',.45);
grid{2}=struct('hidden',64,'batch',32,'nEpoch',10, ...
 'actorLR',.003,'criticLR',.006,'sigma',1.35,'minSigma',.35, ...
 'ppoTargetKL',.12,'ppoMinEpoch',4,'ppoEntropyCoeff',.003, ...
 'priorMix',.30,'priorTemp',.20,'priorWidth',.40,'priorH',.45);
grid{3}=struct('hidden',96,'batch',48,'nEpoch',12, ...
 'actorLR',.0015,'criticLR',.003,'sigma',1.10,'minSigma',.25, ...
 'ppoTargetKL',.10,'ppoMinEpoch',4,'ppoEntropyCoeff',.001, ...
 'priorMix',.35,'priorTemp',.30,'priorWidth',.50,'priorH',.55);
grid{4}=struct('hidden',64,'batch',48,'nEpoch',14, ...
 'actorLR',.002,'criticLR',.004,'sigma',1.50,'minSigma',.40, ...
 'ppoTargetKL',.18,'ppoMinEpoch',5,'ppoEntropyCoeff',.005, ...
 'priorMix',.45,'priorTemp',.20,'priorWidth',.35,'priorH',.40);
end

function localTuneCase(root,caseId)
fn=localLockPath(root,caseId);
if isfile(fn)
 z=load(fn,'params','choices','fingerprint');
 assert(strcmp(z.fingerprint,localFingerprint(z.params,z.choices,caseId)), ...
  'Existing case lock fails signature: %s',caseId);
 fprintf('SKIP TUNE %s: frozen MAPPO configs already exist.\n',caseId);return;
end
S=localProtocol('tune');S.cases={caseId};
S.methods={'A4_MAPPO','A5_GP_MAPPO'};
methods=S.methods;grid=localGrid();
rows=cell(0,9);params=struct();choices=struct();
for mi=1:numel(methods)
 method=methods{mi};score=inf(1,4);
 for j=1:4
  Ss=S;Ss.studyID=sprintf('GP_COOP_FORMAL_V1_TUNE_%s_G%02d',method,j);
  Ss.methodOverrides.(method)=grid{j};
  localRun(root,Ss);
  [a,f,secs,n]=localTuneScore(root,Ss,method);
  assert(n==numel(Ss.seeds),'Incomplete %s grid=%d case=%s',method,j,caseId);
  score(j)=0.65*a+0.35*f;
  rows(end+1,:)={string(caseId),string(method),j,n,a,f,score(j),secs, ...
    string(Ss.studyID)}; %#ok<AGROW>
  fprintf('TUNE %-24s %-15s G%d score %.6g\n',caseId,method,j,score(j));
 end
 [~,jmin]=min(score);params.(method)=grid{jmin};choices.(method)=jmin;
 fprintf('LOCK: %s %s grid %d (TRAIN seeds only)\n',caseId,method,jmin);
end
folder=fileparts(fn);if ~isfolder(folder),mkdir(folder);end
names={'Case','Method','GridIndex','NComplete','MeanNormAULC', ...
 'MeanNormFinal','TuneScore','MeanSearchSeconds','StudyID'};
Tgrid=cell2table(rows,'VariableNames',names);
lockFingerprint=localFingerprint(params,choices,caseId);
fingerprint=lockFingerprint; %#ok<NASGU>
trainSeeds=S.seeds;evalSeeds=16501:16510;
sourceNote='Both A4/A5 independently tuned on identical TRAIN seeds and fixed 4-grid.';
sourceNote=[sourceNote ' A2/IPPO/V4A NOT tuned.'];
save(fn,'params','choices','fingerprint','trainSeeds','evalSeeds', ...
 'Tgrid','grid','sourceNote','-v7');
writetable(Tgrid,fullfile(folder,'GRID_RESULTS.csv'));
fprintf('SAVED LOCK: %s\n',fn);
end

function [a,f,secs,n]=localTuneScore(root,S,method)
a=[];f=[];secs=[];
for i=1:numel(S.cases)
 for seed=S.seeds
  file=localCheckpoint(root,S,S.cases{i},seed,method);
  if ~isfile(file),continue;end
  z=load(file,'H','signature');
  assert(isequaln(z.signature.methodOverrides,S.methodOverrides.(method)), ...
   'Stale tuning checkpoint override mismatch');
  e=z.H.RMSE(:);if numel(e)~=S.rounds+1,continue;end
  assert(all(isfinite(e))&&e(1)>0);
  a(end+1,1)=trapz(0:S.rounds,e')/(S.rounds*e(1)); %#ok<AGROW>
  f(end+1,1)=e(end)/e(1); %#ok<AGROW>
  secs(end+1,1)=sum(z.H.OptimizeSec); %#ok<AGROW>
 end
end
n=numel(a);if n==0,a=NaN;f=NaN;secs=NaN;return;end
a=mean(a);f=mean(f);secs=mean(secs);
end

function S=localFormalProtocol(root,caseId)
z=localLoadLock(root,caseId);
S=localProtocol('formal');S.cases={caseId};
S.methodOverrides=z.params;S.lockFingerprint=z.fingerprint;
end

function fn=localLockPath(root,caseId)
fn=fullfile(root,'results','GP_COOP_FORMAL_TUNING',char(caseId),'LOCKED_PARAMS.mat');
end

function z=localLoadLock(root,caseId)
fn=localLockPath(root,caseId);
assert(isfile(fn),'Missing frozen MAPPO parameters for %s; run tune_case first',caseId);
z=load(fn,'params','choices','fingerprint','trainSeeds','evalSeeds');
assert(strcmp(z.fingerprint,localFingerprint(z.params,z.choices,caseId)), ...
 'Tuning lock fingerprint mismatch');
assert(isequal(z.trainSeeds,16401:16402) && isequal(z.evalSeeds,16501:16510), ...
 'Invalid locked training / evaluation seeds');
assert(isfield(z.params,'A4_MAPPO') && isfield(z.params,'A5_GP_MAPPO'));
end

function fp=localFingerprint(params,choices,caseId)
json=jsonencode(struct('caseId',char(caseId),'params',params,'choices',choices));
b=double(uint8(json));
q=mod(sum(b.*(1:numel(b))),2147483647);
fp=sprintf('GPCOOP_FORMAL_V1_%010d_%d',q,numel(b));
end

function fn=localCheckpoint(root,S,id,seed,method)
fn=fullfile(root,'results','GP_COOP_FORMAL_runs',S.studyID,char(id), ...
 sprintf('%s_seed%d_%s.mat',char(id),seed,char(method)));
end

function localReport(root,allCases,scope)
if nargin<3,scope='legacy';end
if strcmp(scope,'alpine')
 ids=arrayfun(@(K)sprintf('BOFN_ALPINE2_%dS%dD',K,K),2:2:20, ...
  'UniformOutput',false);
 allCases=allCases(ismember({allCases.id},ids));
 [~,order]=sort([allCases.K]);allCases=allCases(order);
 folder=fullfile(root,'results','GP_COOP_FORMAL_ALPINE_2TO20_reports');
 reportTag='ALPINE 10-CASE';
else
 allCases=allCases(1:15); % original 14 + optional Rosenbrock only
 folder=fullfile(root,'results','GP_COOP_FORMAL_reports');
 reportTag='FORMAL 14-CASE';
end
S=localProtocol('formal');
if ~isfolder(folder),mkdir(folder);end
rows=cell(0,15);curves=cell(0,5);settings=cell(0,4);
for ci=1:numel(allCases)
 id=allCases(ci).id;
 if ~isfile(localLockPath(root,id)),continue;end
 z=localLoadLock(root,id);
 settings(end+1,:)={string(id),z.choices.A4_MAPPO,z.choices.A5_GP_MAPPO, ...
  string(z.fingerprint)}; %#ok<AGROW>
 for seed=S.seeds
  for j=1:numel(S.methods)
   method=S.methods{j};fn=localCheckpoint(root,S,id,seed,method);
   if ~isfile(fn),continue;end
   q=load(fn,'H','signature');H=q.H;sg=q.signature;
   assert(strcmp(sg.studyID,S.studyID) && strcmp(sg.caseId,id) && ...
    sg.seed==seed && strcmp(sg.method,method) && ...
    strcmp(sg.lockFingerprint,z.fingerprint), ...
    'Formal checkpoint belongs to a different protocol or lock: %s',fn);
   if isfield(z.params,method)
    assert(isequaln(sg.methodOverrides,z.params.(method)), ...
     'MAPPO hyperparameter lock drift: %s',fn);
   else
    assert(isempty(fieldnames(sg.methodOverrides)), ...
     'Non-MAPPO method was retuned: %s',method);
   end
   rounds=numel(H.RMSE)-1;
   if rounds~=S.rounds,continue;end
   assert(sum(H.RewardCalls)==S.rounds*S.nAcq,'Acquisition budget mismatch');
   y=H.RMSE(:);a=trapz(0:S.rounds,y')/S.rounds;
   dg=localDiag(H);
   rows(end+1,:)={string(id),seed,string(method),rounds,S.nAcq, ...
    string(z.fingerprint),y(end),a,sum(H.OptimizeSec), ...
    dg.PPOUpdates,dg.PPOEarlyStops,dg.MeanKL,dg.MeanSigma, ...
    dg.GPPriorSamples,dg.MeanPrefixShift}; %#ok<AGROW>
   for r=0:S.rounds
    curves(end+1,:)={string(id),seed,string(method),r,y(r+1)}; %#ok<AGROW>
   end
  end
 end
end
Rnames={'Case','Seed','Method','Rounds','CandidateBudget','ParamLock', ...
 'FinalRMSE','AULC','SearchSeconds','PPOUpdates','PPOEarlyStops', ...
 'MeanKL','MeanSigma','GPPriorSamples','MeanPrefixShift'};
if isempty(rows)
 types={'string','double','string','double','double','string', ...
 'double','double','double','double','double','double','double','double','double'};
 T=table('Size',[0 numel(Rnames)],'VariableTypes',types,'VariableNames',Rnames);
else
 T=cell2table(rows,'VariableNames',Rnames);
end
writetable(T,fullfile(folder,'ALL_RUNS.csv'));
Cnames={'Case','Seed','Method','Round','RMSE'};
if isempty(curves)
 C=table('Size',[0 5], ...
  'VariableTypes',{'string','double','string','double','double'}, ...
  'VariableNames',Cnames);
else,C=cell2table(curves,'VariableNames',Cnames);end
writetable(C,fullfile(folder,'ALL_CURVES.csv'));
if isempty(settings)
 U=table('Size',[0 4], ...
  'VariableTypes',{'string','double','double','string'}, ...
  'VariableNames',{'Case','A4GridIndex','A5GridIndex','LockFingerprint'});
else
 U=cell2table(settings,'VariableNames', ...
  {'Case','A4GridIndex','A5GridIndex','LockFingerprint'});
end
writetable(U,fullfile(folder,'FROZEN_PARAM_SUMMARY.csv'));
comp={'A2','A3_IPPO';'A3_IPPO','A4_MAPPO';'A2','A4_MAPPO'; ...
 'A4_MAPPO','A5_GP_MAPPO';'A2','A5_GP_MAPPO'; ...
 'A5_GP_MAPPO','V4A_REFERENCE';'A2','V4A_REFERENCE'};
pr=cell(0,9);meanRows=cell(0,6);pairRows=cell(0,9);
for ci=1:numel(allCases)
 id=string(allCases(ci).id);W=T(T.Case==id,:);
 for j=1:numel(S.methods)
  method=string(S.methods{j});A=W(W.Method==method,:);
  if isempty(A),continue;end
  meanRows(end+1,:)={id,method,height(A),mean(A.FinalRMSE), ...
   mean(A.AULC),mean(A.SearchSeconds)}; %#ok<AGROW>
 end
 for j=1:size(comp,1)
  ba=string(comp{j,1});bb=string(comp{j,2});
  A=W(W.Method==ba,:);B=W(W.Method==bb,:);
  [common,ia,ib]=intersect(A.Seed,B.Seed);
  if isempty(common),continue;end
  x=A.FinalRMSE(ia);y=B.FinalRMSE(ib);
  ax=A.AULC(ia);by=B.AULC(ib);
  pr(end+1,:)={id,ba,bb,numel(common),mean(x),mean(y), ...
   100*(mean(x)-mean(y))/max(mean(x),realmin), ...
   100*(mean(ax)-mean(by))/max(mean(ax),realmin),sum(y<x)}; %#ok<AGROW>
  for t=1:numel(common)
   pairRows(end+1,:)={id,common(t),ba,bb,x(t),y(t), ...
    100*(x(t)-y(t))/max(x(t),realmin),ax(t),by(t)}; %#ok<AGROW>
  end
 end
end
pnames={'Case','Baseline','Proposed','NPairedSeeds', ...
 'BaselineRMSE','ProposedRMSE','GainRMSE_pct','GainAULC_pct','ProposedWins'};
mnames={'Case','Method','NSeeds','MeanRMSE','MeanAULC','MeanSearchSeconds'};
snames={'Case','Seed','Baseline','Proposed','BaselineRMSE','ProposedRMSE', ...
 'GainRMSE_pct','BaselineAULC','ProposedAULC'};
if isempty(pr)
 P=table('Size',[0 9],'VariableTypes', ...
  {'string','string','string','double','double','double','double','double','double'}, ...
  'VariableNames',pnames);
else,P=cell2table(pr,'VariableNames',pnames);end
if isempty(meanRows)
 M=table('Size',[0 6],'VariableTypes', ...
  {'string','string','double','double','double','double'},'VariableNames',mnames);
else,M=cell2table(meanRows,'VariableNames',mnames);end
if isempty(pairRows)
 B=table('Size',[0 9],'VariableTypes', ...
  {'string','double','string','string','double','double','double','double','double'}, ...
  'VariableNames',snames);
else,B=cell2table(pairRows,'VariableNames',snames);end
writetable(P,fullfile(folder,'PAIRED_CASE_COMPARISON.csv'));
writetable(M,fullfile(folder,'METHOD_MEANS.csv'));
writetable(B,fullfile(folder,'PAIRED_SEED_COMPARISON.csv'));
% Report only fully paired 10-seed case means to avoid bias from incomplete cases.
allPair=cell(0,7);
for j=1:size(comp,1)
 ba=string(comp{j,1});bb=string(comp{j,2});
 Q=P(P.Baseline==ba & P.Proposed==bb & P.NPairedSeeds==10,:);
 if isempty(Q),continue;end
 allPair(end+1,:)={ba,bb,height(Q), ...
  mean(Q.GainRMSE_pct),mean(Q.GainAULC_pct), ...
  sum(Q.ProposedWins),10*height(Q)}; %#ok<AGROW>
end
onames={'Baseline','Proposed','NFullyPairedCases','MacroGainRMSE_pct', ...
 'MacroGainAULC_pct','PairedSeedWins','PairedSeedTotal'};
if isempty(allPair)
 O=table('Size',[0 7],'VariableTypes', ...
  {'string','string','double','double','double','double','double'}, ...
  'VariableNames',onames);
else,O=cell2table(allPair,'VariableNames',onames);end
writetable(O,fullfile(folder,'OVERALL_PAIRED_COMPLETE_CASES.csv'));
if strcmp(scope,'alpine')
 expect=10*10*numel(S.methods);finished=height(T);
else
 expect=14*10*numel(S.methods);
 finished=height(T(T.Case~=string(allCases(15).id),:));
end
fprintf('%s: %d/%d complete; %d case comparison rows.\n', ...
 reportTag,finished,expect,height(P));
if strcmp(scope,'alpine')
 GP_COOP_ALPINE_SUMMARY(root,allCases,folder);
end
if ~isempty(O),disp(O);end
end

function localStatus(root,allCases,scope)
if nargin<3,scope='legacy';end
if strcmp(scope,'alpine')
 ids=arrayfun(@(K)sprintf('BOFN_ALPINE2_%dS%dD',K,K),2:2:20, ...
  'UniformOutput',false);
 allCases=allCases(ismember({allCases.id},ids));
 [~,order]=sort([allCases.K]);allCases=allCases(order);
else
 allCases=allCases(1:15);
end
S=localProtocol('formal');
rows=cell(0,5);
for ci=1:numel(allCases)
 id=allCases(ci).id;
 isLocked=isfile(localLockPath(root,id));complete=0;partial=0;
 for seed=S.seeds
  for j=1:numel(S.methods)
   fn=localCheckpoint(root,S,id,seed,S.methods{j});
   if ~isfile(fn),continue;end
   z=load(fn,'H');r=numel(z.H.RMSE)-1;
   if r==S.rounds,complete=complete+1;else,partial=partial+1;end
  end
 end
 rows(end+1,:)={string(id),isLocked,complete,partial,50}; %#ok<AGROW>
end
T=cell2table(rows,'VariableNames', ...
 {'Case','TuningLocked','CompleteRuns','PartialRuns','ExpectedRuns'});
disp(T);
end

function v=localDiag(H)
v=struct('PPOUpdates',0,'PPOEarlyStops',0,'MeanKL',0, ...
 'MeanSigma',0,'GPPriorSamples',0,'MeanPrefixShift',0);
kl=[];sg=[];sh=[];
for i=1:numel(H.PPOStats)
 q=H.PPOStats{i};if ~isstruct(q),continue;end
 if isfield(q,'PPOUpdates'),v.PPOUpdates=v.PPOUpdates+q.PPOUpdates;end
 if isfield(q,'PPOEarlyStops'),v.PPOEarlyStops=v.PPOEarlyStops+q.PPOEarlyStops;end
 if isfield(q,'MeanKL'),kl(end+1)=q.MeanKL;end %#ok<AGROW>
 if isfield(q,'MeanSigma'),sg(end+1)=q.MeanSigma;end %#ok<AGROW>
 if isfield(q,'GPPriorSamples'),v.GPPriorSamples=v.GPPriorSamples+q.GPPriorSamples;end
 if isfield(q,'MeanPrefixShift'),sh(end+1)=q.MeanPrefixShift;end %#ok<AGROW>
end
if ~isempty(kl),v.MeanKL=mean(kl);end
if ~isempty(sg),v.MeanSigma=mean(sg);end
if ~isempty(sh),v.MeanPrefixShift=mean(sh);end
end

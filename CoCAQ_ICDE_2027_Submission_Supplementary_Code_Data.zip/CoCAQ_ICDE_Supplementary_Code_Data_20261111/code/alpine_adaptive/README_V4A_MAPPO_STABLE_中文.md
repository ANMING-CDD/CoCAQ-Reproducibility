# CoCAQ V4A–MAPPO-Stable V1（2026-11-06）

## 设计边界

本工程从 **CoCAQ-R4 完整 MATLAB 工程**提取并保留 **R2 的原版 `GCF_mappo_v4.m`**。新研究分支只修改 MAPPO 的训练稳定性；**不更改级联 GP、Fast-Gi 采集目标、梯度精修、候选生成方式、基线的核心函数或冻结真值**。既往 R2/R3/R4 的结果目录不会被写入。

这不是 R2 冻结超参数的复现；由于你本地生成的 R2 调参文件尚未提供，这版所有 MAPPO 算法采用 **COMMON_UNTUNED_PRESET**（统一明确预设），供开发阶段公平对照。正式论文需要冻结独立调参结果，并用全新测试种子。

## 三条关键方法

- `A5GRAD_V4A`：原始 CoCAQ（无任何源代码修改）。
- `V4A_PPO_STABLE`：完全相同的 GP 和 Fast-Gi 算法，Actor/PPO 训练增加 **混合分布 KL 监控、每阶段 KL 早停、Actor/Critic 全局梯度裁剪**；最多仍为 14 PPO epoch。优势归一化、原始 Critic 结构、先验混合概率和 300 个候选评分保持原样。
- `V4A_PPO_EXPLORE`：在 Stable 基础上，进一步使用 **Actor Gaussian 组件的弱熵正则（0.005）及 latent sigma 下限（0.60）**；不是对整个 GP+Actor 混合分布熵的精确正则。

同时保留 `A3`（同 Fast-Gi 目标的 CMA-ES）、`A4`（基础 MAPPO）、`A5`（GP 增强 MAPPO），合计六种方法。

> 注意：MATLAB 代码允许 PPO early stop，但 **不是每个方法都在相同运算时间下比较**。保证相同的是采集函数评价数（300）、阶段预测真值、初始样本/种子、测试集。必须另行报告训练搜索时间。

## 安装路径

把**完整独立 ZIP**解压到 `C:\MAPPO整合\`。最终应该看到：

```text
C:\MAPPO整合\CoCAQ_V4A_MAPPO_STABLE_20261106\
  README_中文使用说明.md
  matlab\
    COCAQ_V4A_STABLE_RUN.m
    COCAQ_V4A_STABLE_SELFTEST.m
    COCAQ_V4A_OPTIMIZER_AUDIT.m
    MSBO_V4A_STABLE_ENGINE.m
    MSBO_GRID_specs.m
    engine\
      GCF_mappo_v4.m                <- 原 V4A（字节一致）
      GCF_mappo_v4_stable.m         <- 新训练实现
      GCF_ppo_stable_step.m
      GCF_ppo_stable_logpdf.m
      GCF_ppo_stable_clipgrad.m
      ...
    oracles\                         <- 原 12 套冻结 MSBO 数据
```

也可用 **增量补丁 ZIP**，但必须解压至**已有 R4 完整工程的 `matlab` 文件夹中**，使上面新增 `.m` 文件处于相同层级。**更推荐完整版**。

## 操作顺序（MATLAB R2024a）

```matlab
cd('C:\MAPPO整合\CoCAQ_V4A_MAPPO_STABLE_20261106\matlab')
clear functions
COCAQ_V4A_STABLE_RUN('preflight');
COCAQ_V4A_STABLE_RUN('selftest');
COCAQ_V4A_STABLE_RUN('smoke');
COCAQ_V4A_STABLE_RUN('pilot');
COCAQ_V4A_STABLE_RUN('report');
```

- `preflight`：核对 12 套冻结真值、目录和原 R2 协议。
- `selftest`：不用运行真实函数，检查混合策略分布的解析梯度与数值差分一致、梯度裁剪生效。
- `smoke`：1 案例 × 1 种子 × 6 方法 × 2 真实采样轮 = **6 个检查点**；采集评分预算 64。
- `pilot`：3S15D × 3 种子 × 6 方法 × 12 轮 = **18 个检查点**；预算 300。
- `expand`：3 个案例 × 4 新种子 × 6 方法 × 30 轮 = **72 个检查点**。
- `confirm`：12 个 MSBO 案例 × 10 全新种子 × 6 方法 × 30 轮 = **720 个检查点**。**不建议在稳定版确定且独立调参完成之前运行**。

如果 `pilot` 无误并且有初步收益，可继续：

```matlab
COCAQ_V4A_STABLE_RUN('expand');
COCAQ_V4A_STABLE_RUN('report');
```

## 固定 GP 的独立搜索器核验（强烈推荐）

`pilot` 跑完后：

```matlab
COCAQ_V4A_OPTIMIZER_AUDIT('pilot');
```

这项测试从已完成的**原 V4A 真实运行检查点**中读取训练好的 GP 后验；不再次调用真实 oracle，而是在同一个 Fast-Gi 采集函数上，用同样的 300 次采集评分比较：

- `A3`：CMA-ES。
- `A5GRAD_V4A`：原 MAPPO + Fast-Gi。
- `V4A_PPO_STABLE`：训练稳定版。
- `V4A_PPO_EXPLORE`：稳定 + 探索版。

`EXPAND` 完成后也可运行 `COCAQ_V4A_OPTIMIZER_AUDIT('expand')`。固定后验分数更高并**不保证**真实测试 RMSE 必定更低，这正是分开测试的意义。

## 实验结果目录

```text
matlab/results/V4A_STABLE_runs/<STUDY_ID>/<CASE_ID>/*.mat
matlab/results/V4A_STABLE_reports/SMOKE|PILOT|EXPAND|CONFIRM/
  ALL_RUNS.csv
  ALL_CURVES.csv
  METHOD_MEANS.csv
  PAIRED_CASE_COMPARISON.csv
  PAIRED_SEED_COMPARISON.csv
  CHECKPOINT_STATUS.csv
  FIXED_GP_OPTIMIZER_AUDIT.csv  (手动运行审计后生成)
```

报告包含 `PPOUpdates`、`PPOEarlyStops`、`MeanKL`、`KLMax`、`ActorGradClips`、`CriticGradClips`、`MeanSigma`、计算耗时、最终 RMSE 与全程 AULC。

报告中的 `GainRMSE_pct` 和 `GainAULC_pct` **正数代表改进、负数代表退步**。正式验证应先冻结设置并使用未参与设计/调参的新种子；不得按事后获胜种子计算主结论。

## 完成状态

- 已生成完整 MATLAB 源码，并进行程序结构及 ZIP/依赖/源文件一致性静态检查。
- **当前环境没有 MATLAB R2024a，也没有 GNU Octave；尚未执行 MATLAB 端到端 `smoke`**。
- 如果你在 MATLAB 中遇到任何错误，请把第一条报错、调用位置与 `which COCAQ_V4A_STABLE_RUN -all` 的输出发回来。

function COCAQ_R3_GUIDED_RUN(action)
% Independent R3 experiment - does NOT modify/overwrite any R2 checkpoint.
% preflight / smoke / pilot / expand / report
if nargin<1,action='help';end
action=lower(char(action));root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
if any(strcmp(action,{'help','?' }))
 fprintf('\nR3 FAST-GI REAL GUIDANCE: new code and independent checkpoints.\n');
 fprintf(' COCAQ_R3_GUIDED_RUN(''preflight'');\n');
 fprintf(' COCAQ_R3_GUIDED_RUN(''smoke'');\n');
 fprintf(' COCAQ_R3_GUIDED_RUN(''pilot'');\n');
 fprintf(' COCAQ_R3_GUIDED_RUN(''report'');\n');
 fprintf(' COCAQ_R3_GUIDED_RUN(''expand''); %% optional, expensive\n');
 fprintf(' Methods: A2 / R3_BASE / R3_REFINE / R3_GUIDED\n');return;
end
if strcmp(action,'preflight')
 preflight(root);return;
end
if strcmp(action,'report')
 reportOne(root,localPlan('smoke'));
 reportOne(root,localPlan('pilot'));
 reportOne(root,localPlan('expand'));
 fprintf('R3 reports saved under matlab/results/R3_GUIDED_REPORTS/.\n');return;
end
assert(any(strcmp(action,{'smoke','pilot','expand'})), 'Unknown R3 command.');
preflight(root);
Q=localPlan(action);
for j=1:numel(Q.cases)
 cid=Q.cases{j};
 fprintf('\nR3 mode=%s case=%s seeds=%d..%d rounds=%d budget=%d\n', ...
   action,cid,Q.seeds(1),Q.seeds(end),Q.rounds,Q.nAcq);
 MSBO_R3_GUIDED_ENGINE(Q,cid);
 reportOne(root,Q);
end
fprintf('R3 %s complete. Use COCAQ_R3_GUIDED_RUN(''report'').\n',upper(action));
end

function Q=localPlan(action)
Q=struct('studyID','','phase','','seeds',[],'methods',{{'A2', ...
 'R3_BASE','R3_REFINE','R3_GUIDED'}},'rounds',0,'nAcq',300, ...
 'nAnchors',48,'nTest',2048,'nRef',1024,'rank',48, ...
 'testBase',341000,'methodOverrides',struct(),'cases',{{}},'mode',upper(action));
switch action
 case 'smoke'
  Q.studyID='R3_GUIDED_SMOKE_V1';Q.phase='R3_DEBUG_SMOKE';
  Q.cases={'MSBO_3S_15D'};Q.seeds=9701;Q.rounds=2;
  Q.nAcq=64;Q.nAnchors=16;Q.nTest=128;Q.nRef=128;Q.rank=16;
 case 'pilot'
  Q.studyID='R3_GUIDED_PILOT_V1';Q.phase='R3_EXPLORATORY';
  Q.cases={'MSBO_3S_15D'};Q.seeds=9701:9702;Q.rounds=12;
 case 'expand'
  Q.studyID='R3_GUIDED_EXPAND_V1';Q.phase='R3_EXPLORATORY_EXPAND';
  Q.cases={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'};
  Q.seeds=9701:9703;Q.rounds=30;
 otherwise,error('Bad mode');
end
end

function preflight(root)
required={'MSBO_R3_GUIDED_ENGINE.m','COCAQ_R3_GUIDED_RUN.m', ...
 'MSBO_R2_ENGINE.m','MSBO_R2_config.m','MSBO_GRID_specs.m', ...
 fullfile('engine','GCF_mappo_guided.m'), ...
 fullfile('engine','GCF_fastgi_eval.m'), ...
 fullfile('engine','GCF_v4_select_starts.m')};
for j=1:numel(required)
 f=fullfile(root,required{j});
 assert(isfile(f),'Missing file: %s',f);
end
C=MSBO_R2_config();
assert(C.nAcq==300 && C.holdoutRounds==30 && ...
 isequal(C.holdoutSeeds,8301:8310), ...
 'R2 original config changed. Restore it to avoid corrupt provenance.');
A=MSBO_GRID_specs(root);
for cid={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'}
 ii=find(strcmp({A.id},cid{1}));assert(isscalar(ii),'Missing case %s',cid{1});
 s=A(ii);manifest=fullfile(s.folder,'manifest.json');
 assert(isfile(manifest),'Missing frozen oracle: %s',manifest);
 m=jsondecode(fileread(manifest));
 assert(strcmp(char(m.case),cid{1}) && m.K==s.K && ...
  m.D==s.d && numel(char(m.digest))==64, 'Oracle manifest mismatch.');
end
fprintf('R3 PREFLIGHT OK: original R2 intact; frozen MSBO oracle files found.\n');
fprintf('R3 uses one shared preset across its 3 MAPPO variants. NOT tuned / not a paper result.\n');
end

function reportOne(root,Q)
base=fullfile(root,'results','R3_GUIDED_REPORTS',Q.mode);
if ~isfolder(base),mkdir(base);end
runNames={'Case','Seed','Method','Rounds','Budget','FinalRMSE','AULC', ...
 'ScoringCalls','GradientCalls','GradientTrials','AcceptedGradients', ...
 'TeacherPairs','DistillUpdates','GradientChosen', ...
 'SearchSeconds','FitSeconds'};
curveNames={'Case','Seed','Method','Round','RMSE'};
rows=cell(0,numel(runNames));curves=cell(0,numel(curveNames));
status=cell(0,5);
for j=1:numel(Q.cases)
 cid=Q.cases{j};
 for seed=Q.seeds
  for m=1:numel(Q.methods)
   meth=Q.methods{m};
   file=fullfile(root,'results','R3_GUIDED_runs',Q.studyID,cid, ...
    sprintf('%s_seed%d_%s.mat',cid,seed,meth));
   if ~isfile(file),continue;end
   z=load(file,'H','signature');
   assert(isfield(z,'H') && isfield(z,'signature'), 'Malformed checkpoint: %s',file);
   H=z.H;sig=z.signature;
   assert(strcmp(char(sig.studyID),Q.studyID) && sig.seed==seed && ...
     strcmp(char(sig.method),meth) && sig.nAcq==Q.nAcq && ...
     sig.rounds==Q.rounds, 'Checkpoint signature mismatch: %s',file);
   done=numel(H.RMSE)-1;
   assert(done>=0 && done<=Q.rounds, 'Invalid completed rounds.');
   status(end+1,:)={string(cid),seed,string(meth),done,string(file)}; %#ok<AGROW>
   if done~=Q.rounds,continue;end
   assert(sum(H.RewardCalls)==Q.rounds*Q.nAcq, 'Scoring budget mismatch.');
   assert(numel(H.R3Stats)==done, 'R3 diagnostics are incomplete.');
   stat=zeros(1,5);
   for r=1:done
    mt=H.R3Stats{r};
    props={'GradTrials','GradAccepted','TeacherPairs', ...
      'DistillUpdates','GradientChosen'};
    for p=1:5
     if isfield(mt,props{p}),stat(p)=stat(p)+mt.(props{p});end
    end
   end
   if strcmp(meth,'R3_GUIDED') && stat(4)==0
    warning('R3:NoGuidance', ...
      'No teacher update for %s seed %d: gradient guidance inactive.',cid,seed);
   end
   aulc=trapz(0:done,H.RMSE(:)')/done;
   rows(end+1,:)={string(cid),seed,string(meth),done,Q.nAcq, ...
     H.RMSE(end),aulc,sum(H.RewardCalls),sum(H.GradientCalls), ...
     stat(1),stat(2),stat(3),stat(4),stat(5), ...
     sum(H.OptimizeSec),sum(H.FitSec)}; %#ok<AGROW>
   for r=0:done
    curves(end+1,:)={string(cid),seed,string(meth),r,H.RMSE(r+1)}; %#ok<AGROW>
   end
  end
 end
end
% V1.1: MATLAB cell2table(cell(0,N)) creates double-typed empty columns.
% Construct typed empty tables so 'report' also works before 'expand' runs.
runTypes={'string','double','string', ...
 'double','double','double','double','double','double', ...
 'double','double','double','double','double','double','double'};
curveTypes={'string','double','string','double','double'};
statusNames={'Case','Seed','Method','CompletedRounds','File'};
statusTypes={'string','double','string','double','string'};
T=makeTable(rows,runNames,runTypes);
C=makeTable(curves,curveNames,curveTypes);
S=makeTable(status,statusNames,statusTypes);
writetable(T,fullfile(base,'ALL_RUNS.csv'));
writetable(C,fullfile(base,'ALL_CURVES.csv'));
writetable(S,fullfile(base,'CHECKPOINTS.csv'));
compare=cell(0,9);means=cell(0,7);
for cid=Q.cases
 caseID=string(cid{1});W=T(T.Case==caseID,:);
 if isempty(W),continue;end
 for meth=Q.methods
  M=W(W.Method==string(meth{1}),:);
  if isempty(M),continue;end
  means(end+1,:)={caseID,string(meth{1}),height(M), ...
   mean(M.FinalRMSE),mean(M.AULC),mean(M.SearchSeconds), ...
   mean(M.TeacherPairs)}; %#ok<AGROW>
 end
 for baseMeth={'A2','R3_BASE','R3_REFINE'}
  A=W(W.Method==string(baseMeth{1}),:);
  B=W(W.Method=="R3_GUIDED",:);
  [ss,ia,ib]=intersect(A.Seed,B.Seed);
  if isempty(ss),continue;end
  ga=100*(mean(A.FinalRMSE(ia))-mean(B.FinalRMSE(ib)))/ ...
   max(mean(A.FinalRMSE(ia)),realmin);
  gl=100*(mean(A.AULC(ia))-mean(B.AULC(ib)))/ ...
   max(mean(A.AULC(ia)),realmin);
  compare(end+1,:)={caseID,string(baseMeth{1}),numel(ss), ...
    mean(A.FinalRMSE(ia)),mean(B.FinalRMSE(ib)),ga,gl, ...
    sum(B.FinalRMSE(ib)<A.FinalRMSE(ia)), ...
    mean(B.TeacherPairs(ib))}; %#ok<AGROW>
 end
end
meanNames={'Case','Method','NSeeds','MeanRMSE', ...
 'MeanAULC','MeanSearchSeconds','MeanTeacherPairs'};
meanTypes={'string','string','double','double','double','double','double'};
compareNames={'Case','Baseline','NPairedSeeds', ...
 'BaselineRMSE','GuidedRMSE','GuidedRMSEGainPct','GuidedAULCGainPct', ...
 'GuidedWins','MeanGuidedTeacherPairs'};
compareTypes={'string','string','double','double','double', ...
 'double','double','double','double'};
M=makeTable(means,meanNames,meanTypes);
P=makeTable(compare,compareNames,compareTypes);
writetable(M,fullfile(base,'MEANS.csv'));
writetable(P,fullfile(base,'PAIRED_COMPARISON.csv'));
expected=numel(Q.cases)*numel(Q.seeds)*numel(Q.methods);
fprintf('R3 %s: completed %d/%d checkpoints, %d paired comparisons.\n', ...
 Q.mode,height(T),expected,height(P));
if ~isempty(P),disp(P);end
if isempty(T)
 fprintf('R3 %s has no completed runs yet; report is header-only. This is normal if not run.\n',Q.mode);
end
end

function T=makeTable(rows,names,types)
% Preserve column types even for a report containing zero completed runs.
assert(numel(names)==numel(types),'Internal report schema mismatch.');
if isempty(rows)
 T=table('Size',[0 numel(names)],'VariableTypes',types,'VariableNames',names);
else
 T=cell2table(rows,'VariableNames',names);
end
end

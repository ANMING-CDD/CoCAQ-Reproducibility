function cases=GP_COOP_HORIZONTAL_specs(root)
% Opt-in horizontal function-network pilot. Does NOT change original formal case registry.
% The original literature dimensions are H_ACKMAT_2S7D and H_ACKLEY_3S6D.
% All other settings, including the grouped Rosenbrock network, are extensions.
if nargin<1||isempty(root),root=fileparts(mfilename('fullpath'));end
base=GP_COOP_FORMAL_specs(root);t=base(14);
t.edgeCounts=[];t.rosenPrevScale=1;cases=repmat(t,1,0);
for D=[7 10 20 30]
 s=t;s.id=sprintf('H_ACKMAT_2S%dD',D);s.name=s.id;
 s.kind='horizontal_ackmat';s.K=2;s.d=D;s.p=1;
 s.stageDims=[D-1 1];s.nInitial=max(24,3*D);
 s.folder='';s.provisional=false;s.nAdd=8;s.nTest=1024;s.nRef=256;s.rank=24;
 s.source='Buathong et al. ICML 2024 AckMat, original D=7; higher D extended Ackley input';
 cases(end+1)=s; %#ok<AGROW>
end
for D=[6 10 20 30]
 s=t;s.id=sprintf('H_ACKLEY_3S%dD',D);s.name=s.id;
 s.kind='horizontal_ackley_dag';s.K=3;s.d=D;s.p=1;
 % Actor decision ownership only: all first two GP nodes observe the entire X,
 % and GP node 3 receives both parent outputs. No fictitious serial feedback.
 s.stageDims=[D-2 1 1];s.nInitial=max(24,3*D);
 s.folder='';s.provisional=false;s.nAdd=8;s.nTest=1024;s.nRef=256;s.rank=24;
 s.source='Astudillo & Frazier NeurIPS 2021 Ackley DAG, original D=6; D>6 extended';
 cases(end+1)=s; %#ok<AGROW>
end
for K=[4 6]
 if K==4,dimensions=[10 16 20 30];else,dimensions=[12 18 24 30];end
 for D=dimensions
  s=t;s.id=sprintf('H_ROSEN_%dS%dD',K,D);s.name=s.id;
  s.kind='horizontal_rosen';s.K=K;s.d=D;s.p=1;
  % D-1 adjacent Rosenbrock terms, partitioned into K contiguous blocks.
  edgeCounts=floor((D-1)/K)*ones(1,K);
  edgeCounts(1:mod(D-1,K))=edgeCounts(1:mod(D-1,K))+1;
  s.stageDims=[edgeCounts(1)+1 edgeCounts(2:end)];
  s.edgeCounts=edgeCounts;s.rosenPrevScale=1/(5000*(D-1));
  s.nInitial=max(24,3*D);s.nAdd=8;s.nTest=1024;s.nRef=256;s.rank=24;
  s.folder='';s.provisional=false;
  s.source=['Grouped original Rosenbrock sum, NeurIPS 2021 Rosenbrock network inspired; ' ...
   'fixed-K grouped stages are OUR EXTENSION, not original paper nodes'];
  cases(end+1)=s; %#ok<AGROW>
 end
end
% Additional horizontal Ackley scales are appended AFTER all legacy cases.
% CRITICAL: never insert them before the original registry entries: the
% evaluation engine uses the registry index to generate test/Halton points,
% initial designs, and method search seeds. Appending keeps 6D/30D and all
% previously completed pilot checkpoints scientifically comparable.
for D=[15 25]
 s=t;s.id=sprintf('H_ACKLEY_3S%dD',D);s.name=s.id;
 s.kind='horizontal_ackley_dag';s.K=3;s.d=D;s.p=1;
 % Actor owns disjoint x blocks; BOTH first GP nodes receive the entire X.
 % The third GP observes only [y1,y2], exactly as the published DAG.
 s.stageDims=[D-2 1 1];s.nInitial=max(24,3*D);
 s.folder='';s.provisional=false;s.nAdd=8;s.nTest=1024;s.nRef=256;s.rank=24;
 s.source='Astudillo & Frazier NeurIPS 2021 Ackley DAG, D=6 original, D=15/25 extended';
 cases(end+1)=s; %#ok<AGROW>
end
assert(numel(cases)==18 && numel(unique(string({cases.id})))==18);
for i=1:numel(cases)
 s=cases(i);assert(all(s.stageDims>=1)&&sum(s.stageDims)==s.d);
 if strcmp(s.kind,'horizontal_rosen')
  assert(sum(s.edgeCounts)==s.d-1 && numel(s.edgeCounts)==s.K);
 end
end
end

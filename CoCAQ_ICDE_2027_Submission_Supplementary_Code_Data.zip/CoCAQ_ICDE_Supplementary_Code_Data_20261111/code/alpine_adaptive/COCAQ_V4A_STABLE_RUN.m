function COCAQ_V4A_STABLE_RUN(action)
% V4A PPO STABLE V1. MATLAB R2024a. Independent of R2/R3/R4 result folders.
% Actions: preflight, selftest, smoke, pilot, expand, confirm, report.
if nargin<1, action='help';end
action=lower(char(action));root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
switch action
 case {'help','?'}
  fprintf('\nV4A PPO STABLE V1 - GP and Fast-Gi unchanged.\n');
  fprintf('COCAQ_V4A_STABLE_RUN(''preflight'')\n');
  fprintf('COCAQ_V4A_STABLE_RUN(''selftest'')\n');
  fprintf('COCAQ_V4A_STABLE_RUN(''smoke'')\n');
  fprintf('COCAQ_V4A_STABLE_RUN(''pilot'')\n');
  fprintf('COCAQ_V4A_STABLE_RUN(''expand'')\n');
  fprintf('COCAQ_V4A_STABLE_RUN(''report'')\n');
  fprintf('COCAQ_V4A_STABLE_RUN(''confirm'') %% do not run before freezing protocol\n');
  fprintf('COCAQ_V4A_OPTIMIZER_AUDIT(''pilot'') %% fixed-GP optimizer study\n');
 case 'preflight'
  preflight(root);
 case 'selftest'
  preflight(root);COCAQ_V4A_STABLE_SELFTEST();
 case 'report'
  for mode={'smoke','pilot','expand','confirm'}
   reportOne(root,protocol(root,mode{1}));
  end
 case {'smoke','pilot','expand','confirm'}
  preflight(root);S=protocol(root,action);
  fprintf('\nV4A STABLE %s: %d cases x %d seeds x %d methods = %d runs, %d real rounds.\n', ...
   upper(action),numel(S.cases),numel(S.seeds),numel(S.methods), ...
   numel(S.cases)*numel(S.seeds)*numel(S.methods),S.rounds);
  fprintf('Hyperparameters: COMMON_UNTUNED; not R2 frozen tuning.\n');
  for k=1:numel(S.cases)
   MSBO_V4A_STABLE_ENGINE(S,S.cases{k});
   reportOne(root,S);
  end
 otherwise
  error('Unknown action: %s',action);
end
end

function S=protocol(root,mode)
S=struct('studyID','','phase','','seeds',[], ...
 'methods',{{'A3','A4','A5','A5GRAD_V4A','V4A_PPO_STABLE','V4A_PPO_EXPLORE'}}, ...
 'rounds',30,'nAcq',300,'nAnchors',48,'nTest',2048,'nRef',1024, ...
 'rank',48,'testBase',611000,'methodOverrides',struct(), ...
 'cases',{{}},'mode',upper(mode));
switch mode
 case 'smoke'
  S.studyID='V4A_STABLE_V1_SMOKE';S.phase='CODE_CHECK_ONLY';
  S.cases={'MSBO_3S_15D'};S.seeds=11201;S.rounds=2;
  S.nAcq=64;S.nAnchors=16;S.nTest=128;S.nRef=128;S.rank=16;
 case 'pilot'
  S.studyID='V4A_STABLE_V1_PILOT';S.phase='EXPLORATORY';
  S.cases={'MSBO_3S_15D'};S.seeds=11211:11213;S.rounds=12;S.testBase=612000;
 case 'expand'
  S.studyID='V4A_STABLE_V1_EXPAND';S.phase='EXPLORATORY';
  S.cases={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'};
  S.seeds=11221:11224;S.testBase=613000;
 case 'confirm'
  S.studyID='V4A_STABLE_V1_CONFIRM';S.phase='LOCKED_NO_TUNING';
  allCases=MSBO_GRID_specs(root);S.cases={allCases.id};
  S.seeds=11301:11310;S.testBase=614000;
 otherwise
  error('Unknown protocol mode %s',mode);
end
end

function preflight(root)
req={'MSBO_V4A_STABLE_ENGINE.m','MSBO_R2_ENGINE.m', ...
 'MSBO_R2_config.m','MSBO_GRID_specs.m','MSBO_GRID_truth.m', ...
 fullfile('engine','GCF_mappo_v4.m'), ...
 fullfile('engine','GCF_mappo_v4_stable.m'), ...
 fullfile('engine','GCF_mappo.m'), ...
 fullfile('engine','GCF_cmaes.m'), ...
 fullfile('engine','GCF_fastgi_build.m'), ...
 fullfile('engine','GCF_fastgi_eval.m'), ...
 fullfile('engine','GCF_ppo_stable_step.m'), ...
 fullfile('engine','GCF_ppo_stable_logpdf.m'), ...
 fullfile('engine','GCF_ppo_stable_clipgrad.m')};
for k=1:numel(req)
 assert(isfile(fullfile(root,req{k})), 'Missing file: %s',req{k});
end
C=MSBO_R2_config();
assert(C.nAcq==300 && C.holdoutRounds==30 && isequal(C.holdoutSeeds,8301:8310), ...
 'Original R2 protocol has been altered. Do not proceed.');
cases=MSBO_GRID_specs(root);
assert(numel(cases)==12,'12 frozen MSBO cases expected');
for k=1:numel(cases)
 s=cases(k);p=fullfile(s.folder,'manifest.json');
 assert(isfile(p),'Missing frozen oracle manifest: %s',p);
 m=jsondecode(fileread(p));
 assert(strcmp(char(m.case),char(s.id)) && m.K==s.K && m.D==s.d ...
  && length(char(m.digest))==64,'Bad frozen oracle manifest: %s',s.id);
end
assert(isempty(intersect(11301:11310,8301:8310)) && ...
 isempty(intersect(11301:11310,11201:11224)) && ...
 isempty(intersect(11301:11310,10021:10030)), ...
 'Confirmation seeds must be disjoint.');
fprintf('PREFLIGHT OK: 12 frozen MSBO cases, V4A code preserved.\n');
fprintf('MAPPO hyperparameters are COMMON_UNTUNED: no original R2 tuning MAT included.\n');
end

function reportOne(root,S)
folder=fullfile(root,'results','V4A_STABLE_reports',S.mode);
if ~isfolder(folder),mkdir(folder);end
names={'Case','Seed','Method','Rounds','Budget','ParamSource', ...
 'FinalRMSE','AULC','AcqScoringCalls','AnalyticGradientCalls', ...
 'SearchSeconds','FitSeconds','PPOUpdates','PPOEarlyStops','MeanKL', ...
 'KLMax','ActorGradClips','CriticGradClips','MeanSigma'};
rows=cell(0,numel(names));
cnames={'Case','Seed','Method','Round','RMSE'};curves=cell(0,numel(cnames));
snames={'Case','Seed','Method','CompletedRounds','Checkpoint'};
statuses=cell(0,numel(snames));
for i=1:numel(S.cases)
 cid=S.cases{i};
 for seed=S.seeds
  for j=1:numel(S.methods)
   meth=S.methods{j};
   file=fullfile(root,'results','V4A_STABLE_runs',S.studyID,cid, ...
    sprintf('%s_seed%d_%s.mat',cid,seed,meth));
   if ~isfile(file),continue;end
   z=load(file,'H','signature');H=z.H;sig=z.signature;
   assert(strcmp(char(sig.studyID),S.studyID) && sig.seed==seed && ...
    strcmp(char(sig.method),meth) && sig.nAcq==S.nAcq && ...
    sig.rounds==S.rounds && ...
    strcmp(char(sig.engine),'MSBO_V4A_STABLE_V1_20261106'), ...
    'Checkpoint signature mismatch: %s',file);
   completed=numel(H.RMSE)-1;
   statuses(end+1,:)={string(cid),seed,string(meth),completed,string(file)}; %#ok<AGROW>
   if completed~=S.rounds,continue;end
   assert(numel(H.RewardCalls)==completed && ...
    sum(H.RewardCalls)==S.nAcq*completed,'Scoring budget mismatch: %s',file);
   assert(isfield(H,'PPOStats') && numel(H.PPOStats)==completed);
   acc=zeros(1,8); % PPOUpdates/EarlyStops/KLSum/KLCount/KLMax/actor/critic/sigma
   summKL=0;cntKL=0;maxKL=0;sigTotal=0;sigCount=0;
   for r=1:completed
    q=H.PPOStats{r};
    if isfield(q,'PPOUpdates'),acc(1)=acc(1)+q.PPOUpdates;end
    if isfield(q,'PPOEarlyStops'),acc(2)=acc(2)+q.PPOEarlyStops;end
    if isfield(q,'KLSum'),summKL=summKL+q.KLSum;end
    if isfield(q,'KLCount'),cntKL=cntKL+q.KLCount;end
    if isfield(q,'KLMax'),maxKL=max(maxKL,q.KLMax);end
    if isfield(q,'ActorGradClips'),acc(6)=acc(6)+q.ActorGradClips;end
    if isfield(q,'CriticGradClips'),acc(7)=acc(7)+q.CriticGradClips;end
    if isfield(q,'SigmaSum'),sigTotal=sigTotal+q.SigmaSum;end
    if isfield(q,'SigmaCount'),sigCount=sigCount+q.SigmaCount;end
   end
   rmse=H.RMSE(:);aulc=trapz(0:completed,rmse')/completed;
   rows(end+1,:)={string(cid),seed,string(meth),completed,S.nAcq, ...
    "COMMON_UNTUNED_PRESET",rmse(end),aulc,sum(H.RewardCalls), ...
    sum(H.GradientCalls),sum(H.OptimizeSec),sum(H.FitSec), ...
    acc(1),acc(2),summKL/max(1,cntKL),maxKL,acc(6),acc(7), ...
    sigTotal/max(1,sigCount)}; %#ok<AGROW>
   for k=0:completed
    curves(end+1,:)={string(cid),seed,string(meth),k,rmse(k+1)}; %#ok<AGROW>
   end
  end
 end
end
T=toTable(rows,names,{'string','double','string','double','double','string', ...
 'double','double','double','double','double','double','double','double', ...
 'double','double','double','double','double'});
C=toTable(curves,cnames,{'string','double','string','double','double'});
U=toTable(statuses,snames,{'string','double','string','double','string'});
writetable(T,fullfile(folder,'ALL_RUNS.csv'));
writetable(C,fullfile(folder,'ALL_CURVES.csv'));
writetable(U,fullfile(folder,'CHECKPOINT_STATUS.csv'));

mnames={'Case','Method','NSeeds','MeanRMSE','MeanAULC','MeanSearchSeconds', ...
 'MeanPPOUpdates','MeanPPOEarlyStops','MeanKL','MeanSigma'};
means=cell(0,numel(mnames));
pnames={'Case','Baseline','Proposed','NPairedSeeds','BaselineRMSE', ...
 'ProposedRMSE','GainRMSE_pct','GainAULC_pct','ProposedWins'};
pairs=cell(0,numel(pnames));
isnames={'Case','Seed','Baseline','Proposed','BaselineRMSE', ...
 'ProposedRMSE','GainRMSE_pct','GainAULC_pct'};
individual=cell(0,numel(isnames));
for i=1:numel(S.cases)
 cid=string(S.cases{i});W=T(T.Case==cid,:);
 if isempty(W),continue;end
 for j=1:numel(S.methods)
  method=string(S.methods{j});A=W(W.Method==method,:);
  if isempty(A),continue;end
  means(end+1,:)={cid,method,height(A),mean(A.FinalRMSE), ...
   mean(A.AULC),mean(A.SearchSeconds),mean(A.PPOUpdates), ...
   mean(A.PPOEarlyStops),mean(A.MeanKL),mean(A.MeanSigma)}; %#ok<AGROW>
 end
 for proposed={'V4A_PPO_STABLE','V4A_PPO_EXPLORE'}
  G=W(W.Method==string(proposed{1}),:);
  for base={'A3','A4','A5','A5GRAD_V4A'}
   A=W(W.Method==string(base{1}),:);
   [shared,ia,ig]=intersect(A.Seed,G.Seed);
   if isempty(shared),continue;end
   x=A.FinalRMSE(ia);y=G.FinalRMSE(ig);
   ax=A.AULC(ia);gy=G.AULC(ig);
   pairs(end+1,:)={cid,string(base{1}),string(proposed{1}), ...
    numel(shared),mean(x),mean(y), ...
    100*(mean(x)-mean(y))/max(mean(x),realmin), ...
    100*(mean(ax)-mean(gy))/max(mean(ax),realmin),sum(y<x)}; %#ok<AGROW>
   for q=1:numel(shared)
    individual(end+1,:)={cid,shared(q),string(base{1}),string(proposed{1}), ...
     x(q),y(q),100*(x(q)-y(q))/max(x(q),realmin), ...
     100*(ax(q)-gy(q))/max(ax(q),realmin)}; %#ok<AGROW>
   end
  end
 end
end
M=toTable(means,mnames,{'string','string','double','double','double', ...
 'double','double','double','double','double'});
P=toTable(pairs,pnames,{'string','string','string','double', ...
 'double','double','double','double','double'});
I=toTable(individual,isnames,{'string','double','string','string', ...
 'double','double','double','double'});
writetable(M,fullfile(folder,'METHOD_MEANS.csv'));
writetable(P,fullfile(folder,'PAIRED_CASE_COMPARISON.csv'));
writetable(I,fullfile(folder,'PAIRED_SEED_COMPARISON.csv'));
expected=numel(S.cases)*numel(S.seeds)*numel(S.methods);
fprintf('V4A STABLE %s: %d/%d complete, %d comparison rows.\n', ...
 S.mode,height(T),expected,height(P));
if ~isempty(P),disp(P);end
end

function T=toTable(rows,names,types)
assert(numel(names)==numel(types));
if isempty(rows)
 T=table('Size',[0 numel(names)],'VariableTypes',types,'VariableNames',names);
else
 T=cell2table(rows,'VariableNames',names);
end
end

function [P,tags]=MSBO_R2_GRID(mode,best)
% Exactly the 16-screen/12-refine grids from V12, applied per new MSBO case/method.
if nargin<2,best=struct();end
switch lower(char(mode))
 case 'screen'
  [P,tags]=localScreenGrid();
 case 'refine'
  assert(~isempty(fieldnames(best)),'Refine requires a real screen winner.');
  [P,tags]=localRefineGrid(best);
 case 'selftest'
  [P,tags]=localScreenGrid();
  localCheckGrid(P,tags);
  assert(numel(P)==16 && numel(unique(tags))==16);
  for i=[1,2,4,6,8,12,16]
   [Q,T]=localRefineGrid(P{i});localCheckGrid(Q,T);
   assert(numel(Q)==12 && numel(unique(T))==12);
  end
  fprintf('PASS: V12-identical 16-screen/12-refine grids.\n');return;
 otherwise
  error('Unsupported grid mode: %s',mode);
end
localCheckGrid(P,tags);
end

function [P,tags]=localScreenGrid()
% RL-only hyperparameter search: Actor/Critic LR, PPO epochs, Actor sigma,
% PPO clipping, GAE lambda, policy batch size, network hidden width.
% Both MAPPO branches use exactly the same candidate list.
b=struct('actorLR',.003,'criticLR',.006,'nEpoch',14,'sigma',1.10, ...
 'clip',.20,'lambda',.65,'batch',32,'hidden',64);
tags={'S_BASE','S_LR_LOW','S_LR_MED','S_LR_HIGH', ...
 'S_EPOCH_20','S_EPOCH_28','S_SIGMA_LOW','S_SIGMA_HIGH', ...
 'S_CLIP_TIGHT','S_CLIP_WIDE','S_GAE_HIGH','S_GAE_MAX', ...
 'S_BATCH_SMALL','S_BATCH_WIDE','S_NET_WIDE','S_STABLE_COMBO'};
P=cell(1,numel(tags));
P{1}=b;
P{2}=localChange(b,{'actorLR','criticLR'},{.0006,.0012});
P{3}=localChange(b,{'actorLR','criticLR'},{.0015,.0030});
P{4}=localChange(b,{'actorLR','criticLR'},{.0040,.0080});
P{5}=localChange(b,{'nEpoch'},{20});
P{6}=localChange(b,{'nEpoch'},{28});
P{7}=localChange(b,{'sigma'},{.65});
P{8}=localChange(b,{'sigma'},{1.55});
P{9}=localChange(b,{'clip'},{.12});
P{10}=localChange(b,{'clip'},{.26});
P{11}=localChange(b,{'lambda'},{.85});
P{12}=localChange(b,{'lambda'},{.90});
P{13}=localChange(b,{'batch'},{16});
P{14}=localChange(b,{'batch'},{48});
P{15}=localChange(b,{'hidden'},{128});
P{16}=localChange(b, ...
 {'actorLR','criticLR','nEpoch','sigma','clip','lambda','hidden'}, ...
 {.0012,.0024,20,.85,.16,.85,96});
end

function [P,tags]=localRefineGrid(b)
% Candidate proposals depend on the actual SCREEN winner for THIS method.
% Conditional refinement means this is not a static 8-row parameter table.
tags={'R_WINNER','R_LR_HALF','R_LR_UP', ...
 'R_EPOCH_UP','R_EPOCH_DOWN','R_SIGMA_DOWN','R_SIGMA_UP', ...
 'R_CLIP_ADJUST','R_GAE_ADJUST','R_BATCH_ADJUST','R_WIDTH_ADJUST', ...
 'R_STABLE_COMBO'};
P=cell(1,numel(tags));P{1}=b;
P{2}=localChange(b,{'actorLR','criticLR'}, ...
 {max(.0002,b.actorLR*.5),max(.0004,b.criticLR*.5)});
P{3}=localChange(b,{'actorLR','criticLR'}, ...
 {min(.004,b.actorLR*1.5),min(.008,b.criticLR*1.5)});
if b.nEpoch < 36,up=min(36,b.nEpoch+8);else,up=28;end
if b.nEpoch > 14,down=max(14,b.nEpoch-6);else,down=20;end
P{4}=localChange(b,{'nEpoch'},{up});
P{5}=localChange(b,{'nEpoch'},{down});
P{6}=localChange(b,{'sigma'},{max(.55,b.sigma*.78)});
P{7}=localChange(b,{'sigma'},{min(1.9,b.sigma*1.24)});
if b.clip>=.18,cl=.12;else,cl=.24;end
P{8}=localChange(b,{'clip'},{cl});
if b.lambda<=.73,la=.88;else,la=.60;end
P{9}=localChange(b,{'lambda'},{la});
if b.batch==32,bs=48;else,bs=32;end
P{10}=localChange(b,{'batch'},{bs});
if b.hidden<=64,hi=96;else,hi=64;end
P{11}=localChange(b,{'hidden'},{hi});
P{12}=localChange(b, ...
 {'actorLR','criticLR','sigma','lambda'}, ...
 {max(.0002,b.actorLR*.8),max(.0004,b.criticLR*.8), ...
  max(.55,b.sigma*.90),min(.90,b.lambda+.10)});
end

function p=localChange(p,keys,values)
for j=1:numel(keys),p.(keys{j})=values{j};end
end
function localCheckGrid(P,tags)
assert(numel(P)==numel(tags)&&numel(unique(tags))==numel(tags));
required={'actorLR','criticLR','nEpoch','sigma','clip','lambda','batch','hidden'};
for k=1:numel(P)
 p=P{k};assert(all(isfield(p,required)),'RL tuning missing parameter');
 assert(p.actorLR>0 && p.actorLR<=.005 && p.criticLR>0 && p.criticLR<=.01);
 assert(p.nEpoch>=14 && p.nEpoch<=36 && p.nEpoch==floor(p.nEpoch));
 assert(p.sigma>=.5 && p.sigma<=2 && p.clip>=.08 && p.clip<=.30);
 assert(p.lambda>=.5 && p.lambda<=.95);
 assert(ismember(p.batch,[16,32,48]) && ismember(p.hidden,[64,96,128]));
end
end

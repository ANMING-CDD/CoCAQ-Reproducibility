function COCAQ_ACKLEY_3S_HORIZONTAL_RUN(action)
% COCAQ_ACKLEY_3S_HORIZONTAL_RUN - Source-grounded Ackley DAG D-scaling.
%
% FIXED 3 NODES: f1(x) and f2(x) are parallel parents, both see all D coords;
% f3(y1,y2) combines them. NOT a serial 3-stage cascade.
% NeurIPS 2021 original: D=6, x in [-2,2]^D. D>6 are OUR extensions.
%
% D = [6 10 15 20 25 30], exactly the SAME true formula and topology.
% Paired pilot: seeds 16611:16613, 8 rounds, 128 acquisition calls/round,
% 5 methods, no retuning. Existing case IDs/checkpoints remain valid.
%
%   COCAQ_ACKLEY_3S_HORIZONTAL_RUN('preflight')
%   COCAQ_ACKLEY_3S_HORIZONTAL_RUN('selftest')
%   COCAQ_ACKLEY_3S_HORIZONTAL_RUN('run')
%   COCAQ_ACKLEY_3S_HORIZONTAL_RUN('status')
%   COCAQ_ACKLEY_3S_HORIZONTAL_RUN('report')
%
% All new outputs go in the EXISTING horizontal pilot report folder.
if nargin<1||isempty(action),action='help';end
root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
ids=localIDs();
switch lower(char(action))
 case {'help','?'}
  fprintf(['ACKLEY 3-NODE DAG, fixed K=3, varying D=6/10/15/20/25/30.\n' ...
   '  preflight | selftest | run | status | report\n' ...
   '  run: 6 dimensions x 3 seeds x 5 methods; completed checkpoints reused.\n']);
 case 'preflight'
  COCAQ_HORIZONTAL_PILOT_RUN('preflight');
  specs=GP_COOP_HORIZONTAL_specs(root);
  ix=zeros(1,numel(ids));ds=localDims();
  for j=1:numel(ids)
   k=find(strcmp({specs.id},char(ids(j))));
   assert(isscalar(k),'Ackley horizontal scale missing: %s',ids(j));
   s=specs(k);
   assert(s.K==3 && s.d==ds(j) && ...
    strcmp(s.kind,'horizontal_ackley_dag') && ...
    sum(s.stageDims)==s.d,'Wrong topology/scale for %s',ids(j));
   ix(j)=k;
  end
  % Regression guarantee: all old registry indices are unchanged.
  assert(isequal(ix([1 2 4 6]),[5 6 7 8]), ...
   'Old Ackley registry index changed: old checkpoints would not be comparable');
  assert(isequal(ix([3 5]),[17 18]), ...
   'New Ackley scales must be appended after legacy horizontal cases');
  fprintf('ACKLEY 3-NODE PREFLIGHT OK: D=6 10 15 20 25 30.\n');
  fprintf('Original paper: D=6. All higher D are our extensions.\n');
 case 'selftest'
  COCAQ_ACKLEY_3S_HORIZONTAL_RUN('preflight');
  GP_COOP_HORIZONTAL_SELFTEST(root);
 case 'run'
  COCAQ_ACKLEY_3S_HORIZONTAL_RUN('preflight');
  fprintf('Ackley D-scaling: 6 cases x 3 seeds x 5 methods = 90 total pilot runs.\n');
  fprintf('Existing 6D/30D checkpoints may reduce NEW runs to 60.\n');
  for j=1:numel(ids)
   COCAQ_HORIZONTAL_PILOT_RUN('pilot_case',char(ids(j)));
  end
  localReport(root);
 case 'report'
  COCAQ_HORIZONTAL_PILOT_RUN('report');
  localReport(root);
 case 'status'
  COCAQ_HORIZONTAL_PILOT_RUN('report');
  localReport(root);
 otherwise
  error('Unsupported action %s. Use ''help''.',char(action));
end
end

function ids=localIDs()
ids=["H_ACKLEY_3S6D","H_ACKLEY_3S10D", ...
     "H_ACKLEY_3S15D","H_ACKLEY_3S20D", ...
     "H_ACKLEY_3S25D","H_ACKLEY_3S30D"];
end
function ds=localDims()
ds=[6 10 15 20 25 30];
end

function localReport(root)
folder=fullfile(root,'results','GP_COOP_HORIZONTAL_PILOT_reports');
source=fullfile(folder,'ALL_RUNS.csv');
if ~isfile(source)
 fprintf('No pilot ALL_RUNS.csv yet. Run ''run'' to create checkpoints.\n');return;
end
R=readtable(source,'TextType','string');
required={'Case','Seed','Method','FinalNRMSE','AULC_NRMSE', ...
 'SearchSeconds','StartRMSE','TruthStd'};
assert(all(ismember(required,R.Properties.VariableNames)), ...
 'Expected columns missing from ALL_RUNS.csv');
ids=localIDs();ds=localDims();seeds=16611:16613;
methods=["A2","A3_IPPO","A4_MAPPO","A5_GP_MAPPO","V4A_REFERENCE"];
summary=cell(numel(ids),17);paired=cell(0,13);meanRows=cell(0,7);
for j=1:numel(ids)
 id=ids(j);D=ds(j);
 W=R(R.Case==id & ismember(R.Seed,seeds) & ...
    ismember(R.Method,methods),:);
 key=strcat(string(W.Seed),"/",W.Method);
 assert(numel(unique(key))==numel(key),'Duplicate seed/method in %s',id);
 for mi=1:numel(methods)
  T=W(W.Method==methods(mi),:);
  if isempty(T)
   meanRows(end+1,:)={id,D,methods(mi),0,NaN,NaN,NaN}; %#ok<AGROW>
  else
   meanRows(end+1,:)={id,D,methods(mi),height(T), ...
    mean(T.FinalNRMSE),mean(T.AULC_NRMSE),mean(T.SearchSeconds)}; %#ok<AGROW>
  end
 end
 a2=[];a5=[];v=[];a2auc=[];vauc=[];a2sec=[];vsec=[];vstart=[];
 winsA2=0;winsA5=0;bestAll=0;
 for seed=seeds
  T=W(W.Seed==seed,:);
  a=T(T.Method=="A2",:);
  b=T(T.Method=="A5_GP_MAPPO",:);
  q=T(T.Method=="V4A_REFERENCE",:);
  if height(a)~=1||height(b)~=1||height(q)~=1,continue;end
  a2(end+1)=a.FinalNRMSE; %#ok<AGROW>
  a5(end+1)=b.FinalNRMSE; %#ok<AGROW>
  v(end+1)=q.FinalNRMSE; %#ok<AGROW>
  a2auc(end+1)=a.AULC_NRMSE; %#ok<AGROW>
  vauc(end+1)=q.AULC_NRMSE; %#ok<AGROW>
  a2sec(end+1)=a.SearchSeconds; %#ok<AGROW>
  vsec(end+1)=q.SearchSeconds; %#ok<AGROW>
  vstart(end+1)=q.StartRMSE/q.TruthStd; %#ok<AGROW>
  winsA2=winsA2+(q.FinalNRMSE<a.FinalNRMSE);
  winsA5=winsA5+(q.FinalNRMSE<b.FinalNRMSE);
  isBest=false;
  if height(T)==5 && all(ismember(methods,T.Method))
   isBest=q.FinalNRMSE==min(T.FinalNRMSE);
   bestAll=bestAll+isBest;
  end
  paired(end+1,:)={id,3,D,seed,a.FinalNRMSE,b.FinalNRMSE, ...
   q.FinalNRMSE,localGain(a.FinalNRMSE,q.FinalNRMSE), ...
   localGain(b.FinalNRMSE,q.FinalNRMSE), ...
   q.FinalNRMSE<a.FinalNRMSE,q.FinalNRMSE<b.FinalNRMSE, ...
   isBest,q.SearchSeconds}; %#ok<AGROW>
 end
 n=numel(v);
 ma=NaN;mv=NaN;ga=NaN;gb=NaN;gaulc=NaN;gp=NaN;tr=NaN;
 if n>0
  ma=mean(a2);mv=mean(v);
  ga=localGain(mean(a2),mean(v));
  gb=localGain(mean(a5),mean(v));
  gaulc=localGain(mean(a2auc),mean(vauc));
  gp=localGain(mean(vstart),mean(v));
  tr=mean(vsec)/max(mean(a2sec),realmin);
 end
 summary(j,:)={id,3,D,height(W),15,n,ma,mv,ga,gb, ...
  winsA2,winsA5,bestAll,gaulc,gp,tr,n==3};
end
S=cell2table(summary,'VariableNames',{'Case','Nodes','D', ...
 'CompletedRuns','ExpectedRuns','PairedSeeds','A2_MeanNRMSE', ...
 'V4A_MeanNRMSE','V4A_GainVsA2_pct','V4A_GainVsA5_pct', ...
 'V4A_WinsVsA2','V4A_WinsVsA5','V4A_BestOfFiveSeeds', ...
 'V4A_AULCGainVsA2_pct','V4A_ImprovementVsInitial_pct', ...
 'V4A_SearchTimeRatioVsA2','Complete'});
P=localToTable(paired,{'Case','Nodes','D','Seed','A2_NRMSE', ...
 'A5_NRMSE','V4A_NRMSE','V4A_GainVsA2_pct','V4A_GainVsA5_pct', ...
 'V4A_WinVsA2','V4A_WinVsA5','V4A_BestOfFive','V4A_SearchSeconds'}, ...
 {'string','double','double','double','double','double','double', ...
 'double','double','logical','logical','logical','double'});
M=cell2table(meanRows,'VariableNames',{'Case','D','Method','Seeds', ...
 'MeanNRMSE','MeanAULC_NRMSE','MeanSearchSeconds'});
writetable(S,fullfile(folder,'ACKLEY_3NODE_SCALE_SUMMARY.csv'));
writetable(P,fullfile(folder,'ACKLEY_3NODE_PAIRED_SEEDS.csv'));
writetable(M,fullfile(folder,'ACKLEY_3NODE_ALL_METHODS.csv'));
fprintf('\n=== ACKLEY 3-NODE DAG horizontal scaling ===\n');
disp(S(:,{'Case','PairedSeeds','V4A_GainVsA2_pct', ...
 'V4A_GainVsA5_pct','V4A_WinsVsA2','V4A_BestOfFiveSeeds', ...
 'V4A_ImprovementVsInitial_pct'}));
if ~all(S.Complete)
 fprintf('INCOMPLETE: %d/6 dimensions have 3 full paired seeds.\n',sum(S.Complete));
 fprintf('Do not interpret NaN scales or choose final winner from incomplete pilot.\n');
else
 fprintf('COMPLETE: all 6 dimensions x 3 paired seeds x 5 methods.\n');
end
try
 f=figure('Visible','off','Position',[100,100,840,440]);
 ga=S.V4A_GainVsA2_pct;gb=S.V4A_GainVsA5_pct;
 ga(~S.Complete)=NaN;gb(~S.Complete)=NaN;
 plot(ds,ga,'-o','LineWidth',1.8,'MarkerSize',7);hold on;
 plot(ds,gb,'-s','LineWidth',1.8,'MarkerSize',7);
 plot([min(ds),max(ds)],[0 0],'k--');hold off;grid on;
 xlabel('Decision input dimension D (three DAG nodes fixed)');
 ylabel('V4A final NRMSE reduction (%)');
 title('Ackley DAG fixed K=3: dimensional scaling pilot');
 legend('V4A vs A2','V4A vs A5','No advantage','Location','best');
 set(gca,'XTick',ds);
 saveas(f,fullfile(folder,'ACKLEY_3NODE_GAIN_VS_D.png'));close(f);
catch ME
 warning('Ackley plot skipped: %s',ME.message);
end
fprintf('ACKLEY CSV + PNG reports: %s\n',folder);
end

function val=localGain(base,method)
val=100*(base-method)/max(abs(base),realmin);
end
function T=localToTable(rows,names,types)
if isempty(rows)
 T=table('Size',[0,numel(names)], ...
  'VariableTypes',types,'VariableNames',names);
else
 T=cell2table(rows,'VariableNames',names);
end
end

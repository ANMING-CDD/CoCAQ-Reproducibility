function COCAQ_RUN_OVERNIGHT(order)
% COCAQ_RUN_OVERNIGHT  One-process, resumable R2 experiment runner.
%
% Install this file in the SAME matlab/ directory as MSBO_R2_RUN.m and
% IQ_R2_RUN.m.  Does not modify experiment configs, seeds or algorithms.
%
% COCAQ_RUN_OVERNIGHT                 IMDb first, then 12 MSBO cases
% COCAQ_RUN_OVERNIGHT('msbo-first')   12 MSBO cases first, then IMDb
% COCAQ_RUN_OVERNIGHT('status')       Display current holdout progress
%
% Uses each study's OWN screen/refine/frozen/holdout protocol and results.
% A failed case is logged and the next independent case is attempted.
% Existing checkpoints are reused by the underlying R2 engines.

if nargin < 1 || isempty(order), order = 'imdb-first'; end
order = lower(char(order));
assert(any(strcmp(order,{'imdb-first','msbo-first','status'})), ...
    'Allowed choices: imdb-first, msbo-first, status');

root = fileparts(mfilename('fullpath'));
assert(isfile(fullfile(root,'MSBO_R2_RUN.m')), ...
    'Place COCAQ_RUN_OVERNIGHT.m beside MSBO_R2_RUN.m in the R2 matlab folder.');
assert(isfile(fullfile(root,'IQ_R2_RUN.m')), ...
    'Place the IMDb R2 add-on (IQ_R2_RUN.m and other IQ_R2_*.m files) in the same matlab folder.');
assert(isfile(fullfile(root,'python','imdb_query_bridge.py')), ...
    'Missing matlab/python/imdb_query_bridge.py: install the IMDb bridge patch.');

cd(root);
addpath(root,'-begin');
addpath(fullfile(root,'engine'),'-begin');
% Check for stale functions shadowing the ones in THIS project.
a = which('MSBO_R2_RUN'); b = which('IQ_R2_RUN');
assert(strcmpi(fileparts(a),root) && strcmpi(fileparts(b),root), ...
    'Wrong R2 project on the MATLAB search path; check which -all.');

% A new MATLAB -batch session does not inherit setenv calls made in an
% earlier interactive MATLAB session. Resolve the usual bundled snapshot.
if isempty(strtrim(getenv('IMDB_ORACLE_FILE')))
    oracle = fullfile(root,'oracles','imdb_official_4s8d_v1.duckdb');
    if isfile(oracle), setenv('IMDB_ORACLE_FILE',oracle); end
end
if isempty(strtrim(getenv('IMDB_PYTHON_EXE')))
    setenv('IMDB_PYTHON_EXE','python');
end

if strcmp(order,'status')
    fprintf('\n==== MSBO R2 status ====\n');
    try, MSBO_R2_RUN('status');
    catch ME, fprintf(2,'MSBO status error: %s\n',ME.message); end
    fprintf('\n==== IMDb SQL R2 status ====\n');
    try, IQ_R2_RUN('status');
    catch ME, fprintf(2,'IMDb status error: %s\n',ME.message); end
    fprintf('\nResults and logs are under:\n%s\n',fullfile(root,'results'));
    return;
end

logBase = fullfile(root,'results','R2_overnight');
if ~isfolder(logBase), mkdir(logBase); end
stamp = datestr(now,'yyyymmdd_HHMMSS');
runDir = fullfile(logBase,['SESSION_' stamp]);
if ~isfolder(runDir), mkdir(runDir); end
logFile = fullfile(runDir,'MATLAB_CONSOLE.log');
ledgerFile = fullfile(runDir,'TASK_LEDGER.csv');
latest = fullfile(logBase,'LATEST_SESSION.txt');
fid = fopen(latest,'wt');
if fid > 0, fprintf(fid,'%s\n',runDir); fclose(fid); end

ledger = table('Size',[0 8], ...
    'VariableTypes',{'string','string','string','string', ...
                     'string','double','string','string'}, ...
    'VariableNames',{'Timestamp','Family','Case','Step', ...
                     'Status','Seconds','ErrorID','Message'});

diary(logFile); diary on;
cleaner = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('\n========== CoCAQ R2 OVERNIGHT ==========\n');
fprintf('Started: %s\nProject: %s\nLog: %s\n',datestr(now),root,logFile);
fprintf('Order: %s\n',order);
fprintf('IMDb oracle: %s\n',getenv('IMDB_ORACLE_FILE'));
fprintf('Python: %s\n',getenv('IMDB_PYTHON_EXE'));
fprintf('Protocol: per-method validation -> frozen parameters -> new 10-seed holdout.\n');
fprintf('IMPORTANT: This workload may take MORE than one night.\n');

if strcmp(order,'imdb-first')
    families = {'IMDB','MSBO'};
else
    families = {'MSBO','IMDB'};
end

for fi = 1:numel(families)
    family = families{fi};
    switch family
        case 'IMDB'
            fprintf('\n========== REAL IMDb SQL 4S8D ==========\n');
            [ledger,ok] = localStep(ledger,ledgerFile,runDir,'IMDB','IMDB_SQL_4S8D', ...
                'selftest',@() IQ_R2_RUN('selftest'));
            if ok
                [ledger,ok] = localStep(ledger,ledgerFile,runDir,'IMDB','IMDB_SQL_4S8D', ...
                    'preflight',@() IQ_R2_RUN('preflight'));
            end
            if ok
                [ledger,ok] = localStep(ledger,ledgerFile,runDir,'IMDB','IMDB_SQL_4S8D', ...
                    'gradientcheck',@() IQ_R2_RUN('gradientcheck'));
            end
            if ok
                [ledger,tuned] = localStep(ledger,ledgerFile,runDir,'IMDB','IMDB_SQL_4S8D', ...
                    'tune',@() IQ_R2_RUN('tune'));
                if tuned
                    [ledger,evaluated] = localStep(ledger,ledgerFile,runDir,'IMDB','IMDB_SQL_4S8D', ...
                        'evaluate',@() IQ_R2_RUN('evaluate'));
                else
                    evaluated = false;
                end
            else
                evaluated = false;
                fprintf(2,'IMDb preflight/audit failed. Skipping its tuning/holdout.\n');
            end
            [ledger,~] = localStep(ledger,ledgerFile,runDir,'IMDB','IMDB_SQL_4S8D', ...
                'status',@() IQ_R2_RUN('status'));
            [ledger,~] = localStep(ledger,ledgerFile,runDir,'IMDB','IMDB_SQL_4S8D', ...
                'report',@() IQ_R2_RUN('report'));
            if evaluated
                [ledger,~] = localStep(ledger,ledgerFile,runDir,'IMDB','IMDB_SQL_4S8D', ...
                    'plot',@() IQ_R2_RUN('plot'));
            end

        case 'MSBO'
            fprintf('\n========== MSBO 12-CASE R2 ==========\n');
            [ledger,ok] = localStep(ledger,ledgerFile,runDir,'MSBO','ALL_12', ...
                'selftest',@() MSBO_R2_RUN('selftest'));
            if ok
                [ledger,ok] = localStep(ledger,ledgerFile,runDir,'MSBO','ALL_12', ...
                    'preflight',@() MSBO_R2_RUN('preflight'));
            end
            if ok
                [ledger,ok] = localStep(ledger,ledgerFile,runDir,'MSBO','ALL_12', ...
                    'gradientcheck',@() MSBO_R2_RUN('gradientcheck'));
            end
            allEvaluated = ok;
            if ok
                cases = MSBO_GRID_specs(root);
                assert(numel(cases)==12,'Expected exactly 12 MSBO configs');
                for ci = 1:numel(cases)
                    cid = cases(ci).id;
                    fprintf('\n--- MSBO %d/12: %s ---\n',ci,cid);
                    [ledger,tuned] = localStep(ledger,ledgerFile,runDir,'MSBO',cid, ...
                        'tune',@() MSBO_R2_RUN('tune',cid));
                    if tuned
                        [ledger,evaluated] = localStep(ledger,ledgerFile,runDir,'MSBO',cid, ...
                            'evaluate',@() MSBO_R2_RUN('evaluate',cid));
                    else
                        evaluated = false;
                        fprintf(2,'Skipped holdout for %s: tuning incomplete.\n',cid);
                    end
                    allEvaluated = allEvaluated && evaluated;
                end
            else
                fprintf(2,'MSBO selftest/preflight/gradient audit failed. Skipping all MSBO tuning/holdout.\n');
            end
            [ledger,~] = localStep(ledger,ledgerFile,runDir,'MSBO','ALL_12', ...
                'status',@() MSBO_R2_RUN('status'));
            [ledger,~] = localStep(ledger,ledgerFile,runDir,'MSBO','ALL_12', ...
                'report',@() MSBO_R2_RUN('report'));
            if allEvaluated
                [ledger,~] = localStep(ledger,ledgerFile,runDir,'MSBO','ALL_12', ...
                    'heatmap',@() MSBO_R2_RUN('heatmap'));
            else
                fprintf('MSBO heatmap deferred: need all 960 unselected holdout runs.\n');
            end
    end
end

fprintf('\n========== SESSION FINISHED ==========\n');
fprintf('Finished: %s\n',datestr(now));
fprintf('Tasks recorded: %d, passed: %d, failed: %d\n', ...
    height(ledger),sum(ledger.Status=="DONE"),sum(ledger.Status=="FAILED"));
fprintf('Task ledger: %s\nConsole log: %s\n',ledgerFile,logFile);
fprintf('MSBO results: %s\n',fullfile(root,'results','R2_runs','MSBO_R2_HOLDOUT_V1'));
fprintf('IMDb results: %s\n',fullfile(root,'results','IQ_R2_runs','IQR_IMDB_R2_HOLDOUT_V1'));
fprintf('Re-run this function to resume incomplete underlying checkpoints.\n');
end

function [T,ok] = localStep(T,ledgerFile,runDir,family,caseId,step,action)
% Record RUNNING before launching expensive work, DONE or FAILED afterwards.
idx = height(T)+1;
T(idx,:)={string(datestr(now,'yyyy-mm-dd HH:MM:SS')), ...
    string(family),string(caseId),string(step),"RUNNING",NaN,"",""};
localWriteLedger(T,ledgerFile);
fprintf('\n[START] %s / %s / %s — %s\n',family,caseId,step,datestr(now));
t0=tic;
try
    action();
    ok=true; errid=""; msg="";
    fprintf('[DONE] %s / %s / %s — %.1f sec\n',family,caseId,step,toc(t0));
catch ME
    ok=false; errid=string(ME.identifier); msg=string(ME.message);
    fprintf(2,'[FAILED] %s / %s / %s — %s\n',family,caseId,step,ME.message);
    fullReport=getReport(ME,'extended','hyperlinks','off');
    fid=fopen(fullfile(runDir,sprintf('ERROR_%03d.txt',idx)),'wt');
    if fid>0, fprintf(fid,'%s\n',fullReport); fclose(fid); end
    fprintf(2,'%s\n',fullReport);
end
T.Status(idx)=string(localIf(ok,'DONE','FAILED'));
T.Seconds(idx)=toc(t0);
T.ErrorID(idx)=errid;
T.Message(idx)=regexprep(msg,'[\r\n\t]+',' ');
localWriteLedger(T,ledgerFile);
end

function localWriteLedger(T,p)
tmp=[p '.tmp'];
writetable(T,tmp,'FileType','text');
[success,msg]=movefile(tmp,p,'f');
if ~success, error('Could not commit overnight task ledger: %s',msg); end
end

function v=localIf(test,a,b)
if test,v=a;else,v=b;end
end

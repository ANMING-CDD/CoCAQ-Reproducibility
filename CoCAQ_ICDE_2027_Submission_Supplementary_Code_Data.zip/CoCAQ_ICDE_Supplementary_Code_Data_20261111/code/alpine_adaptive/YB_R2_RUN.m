function YB_R2_RUN(mode)
% Independent R2-style experiment on PROVISIONAL 4-stage Yb-fiber model.
% Run in existing R2 matlab folder; does not modify or rerun MSBO 12 cases.
if nargin<1||isempty(mode),mode='preflight';end
mode=lower(char(mode));
root=fileparts(mfilename('fullpath'));addpath(fullfile(root,'engine'),'-begin');
C=YB_R2_config();s=YB_R2_spec(root);
localValidate(C,s);
switch mode
 case 'selftest'
  MSBO_R2_GRID('selftest');
  assert(s.K==4 && s.d==8 && s.nInitial==24 && s.nAdd==12);
  assert(isequal(s.stageDims,[2 2 2 2]));
  for k=1:4
   assert(numel(MSBO_stage_idx(s,k))==2);
  end
  fprintf('PASS YB case protocol: 4S8D, 24 initial, 12 added, 8 methods.\n');
 case 'preflight'
  localPreflight(C,s);
 case 'gradientcheck'
  localPreflight(C,s);
  rng(79499,'twister');X=GCF_lhs(s.nInitial,s.d);
  Y=YB_R2_truth(s,X);model=GCF_fit(s,X,Y,'cascade');
  Xref=GCF_halton(64,s.d,15420);
  F=GCF_fastgi_build(model,s,Xref,16);
  x=.20+.60*rand(1,s.d);h=1e-5;
  [val,~,ga]=GCF_fastgi_eval(F,x);fd=zeros(1,s.d);
  for j=1:s.d
   xp=x;xm=x;xp(j)=xp(j)+h;xm(j)=xm(j)-h;
   fd(j)=(GCF_fastgi_eval(F,xp)-GCF_fastgi_eval(F,xm))/(2*h);
  end
  ea=norm(fd-ga);er=ea/max([norm(ga),norm(fd),1e-7]);
  fprintf('YB Fast-Gi gradient check: value %.6g, abs %.3g, relative %.3g\n',val,ea,er);
  assert(all(isfinite(ga)) && (er<.08 || ea<1e-4),'Yb Fast-Gi gradient finite-diff failure');
  audit=struct('passed',true,'protocol',C.protocol,'digest',YB_R2_digest(C), ...
   'errorAbs',ea,'errorRel',er);
  p=fullfile(root,'results','YB_R2_audit');if ~isfolder(p),mkdir(p);end
  save(fullfile(p,'FASTGI_YB_AUDIT_PASS.mat'),'audit','-v7');
  fprintf('PASS Yb Fast-Gi audit, locked to external bridge digest.\n');
 case 'smoke'
  localPreflight(C,s);
  [P,~]=MSBO_R2_GRID('screen');
  S=localRunSpec(C,'SMOKE','YBF_R2_SMOKE_V1',C.screenSeeds(1),2, ...
   C.screenTestBase,{'P2','A5GRAD_V4A'});
  S.nAcq=64;S.nAnchors=16;S.nTest=8;S.nRef=64;S.rank=16;
  S.methodOverrides.A5GRAD_V4A=P{1};
  YB_R2_ENGINE(S,s.id);
  fprintf('Yb smoke succeeded (2 methods, 1 seed, 2 rounds).\n');
 case {'screen','refine','tune'}
  localRequireAudit(root,C);localPreflight(C,s);
  YB_R2_TUNE(mode,s.id);
 case {'evaluate','all'}
  localRequireAudit(root,C);localPreflight(C,s);
  if strcmp(mode,'all'),YB_R2_TUNE('tune',s.id);end
  P=localLoadFrozen(C,root,s);
  localHoldoutLock(C,root,s,P);
  S=localRunSpec(C,'HOLDOUT',C.holdoutStudyID,C.holdoutSeeds, ...
   C.holdoutRounds,C.holdoutTestBase,C.methods);
  S.methodOverrides=P;
  YB_R2_ENGINE(S,s.id);
  YB_R2_REPORT('report');
 case {'status','report'}
  YB_R2_REPORT(mode);
 case 'plot'
  YB_R2_REPORT('plot');
 otherwise
  error('Use selftest/preflight/gradientcheck/smoke/screen/refine/tune/evaluate/all/status/report/plot');
end
end

function localValidate(C,s)
assert(strcmp(C.caseId,s.id) && numel(C.methods)==8);
assert(isequal(C.rlMethods,{'A4','A5','A5GRAD_V4A'}));
assert(numel(C.screenSeeds)==4 && numel(C.refineSeeds)==4 && numel(C.holdoutSeeds)==10);
assert(isempty(intersect(C.screenSeeds,C.refineSeeds)) && ...
 isempty(intersect(C.screenSeeds,C.holdoutSeeds)) && ...
 isempty(intersect(C.refineSeeds,C.holdoutSeeds)));
assert(C.screenRounds<=12 && C.refineRounds==12 && C.holdoutRounds==12);
assert(C.nAcq==300 && C.nTest>0 && C.nRef>0);
end

function localPreflight(C,s)
[bridge,batch,py]=YB_R2_paths(C);
fprintf('Yb source bridge: %s\nV9 batch adapter: %s\nPython: %s\n',bridge,batch,py);
[code,log]=system(sprintf('"%s" -c "import pyfiberamp; print(''pyfiberamp import OK'')"',py));
assert(code==0,'Existing Python cannot import pyfiberamp: %s',log);
x=.5*ones(1,s.d);
Y=YB_R2_truth(s,x,true);Z=YB_R2_truth(s,x,true);
assert(isequal(size(Y),[1 4]) && all(isfinite(Y(:))));
assert(norm(Y-Z)<=1e-7*(1+norm(Y)), ...
 'Physical Yb oracle is not deterministic at fixed input; do not use memoization.');
fprintf('PASS Yb physical bridge: one full 4-stage evaluation; source digest %s\n',YB_R2_digest(C));
end

function localRequireAudit(root,C)
f=fullfile(root,'results','YB_R2_audit','FASTGI_YB_AUDIT_PASS.mat');
assert(isfile(f),'Run YB_R2_RUN(''gradientcheck'') first.');
z=load(f,'audit');
assert(z.audit.passed && strcmp(z.audit.protocol,C.protocol) && ...
 strcmp(z.audit.digest,YB_R2_digest(C)), ...
 'Yb oracle bridge changed since gradient audit; rerun gradientcheck.');
end

function S=localRunSpec(C,phase,studyID,seeds,rounds,testBase,methods)
S=struct('studyID',studyID,'phase',phase,'seeds',seeds, ...
 'methods',{methods},'rounds',rounds,'nAcq',C.nAcq, ...
 'nAnchors',C.nAnchors,'nTest',C.nTest,'nRef',C.nRef, ...
 'rank',C.rank,'testBase',testBase,'methodOverrides',struct());
end

function P=localLoadFrozen(C,root,s)
f=fullfile(root,'results','YB_R2_tuning','FROZEN_METHOD_CONFIGS.mat');
assert(isfile(f),'First run YB_R2_RUN(''tune'').');
z=load(f,'frozen');
assert(isequaln(z.frozen.protocol,C),'Frozen Yb protocol changed.');
assert(isfield(z.frozen.params,s.id),'No frozen parameters for Yb.');
assert(strcmp(z.frozen.oracles.(s.id),YB_R2_digest(C)), ...
 'Physical simulator changed after tuning; do not mix physics versions.');
P=z.frozen.params.(s.id);
assert(isequal(sort(fieldnames(P)),sort(C.rlMethods(:))));
end

function localHoldoutLock(C,root,s,P)
p=fullfile(root,'results','YB_R2_tuning','HOLDOUT_LOCKS');
if ~isfolder(p),mkdir(p);end
lock=struct('protocol',C,'caseId',s.id,'oracleDigest',YB_R2_digest(C), ...
 'frozenParams',P,'holdoutSeeds',C.holdoutSeeds);
f=fullfile(p,[s.id '_LOCK.mat']);
if isfile(f)
 z=load(f,'lock');assert(isequaln(z.lock,lock), ...
 'Yb holdout protocol was modified; use a new study ID.');
else
 save(f,'lock','-v7');
end
end

function C=MSBO_R2_config()
% Prospective R2 protocol: do not change after starting tuning/holdout.
% Old 6901:6910 R1 seeds and 7301/7401/7901 V12 seeds are EXCLUDED.
C=struct();
C.protocol='MSBO_R2_V12STYLE_SCREEN_REFINE_HOLDOUT_V1';
C.tuneTag='MSBO_R2_TUNE_V1';
C.holdoutStudyID='MSBO_R2_HOLDOUT_V1';
C.methods={'P1','P2','A1','A2','A3','A4','A5','A5GRAD_V4A'};
C.rlMethods={'A4','A5','A5GRAD_V4A'};
C.screenSeeds=8101:8104;
C.refineSeeds=8201:8204;
C.holdoutSeeds=8301:8310;
C.screenRounds=12;
C.refineRounds=30;
C.holdoutRounds=30;
C.nAcq=300;
C.nAnchors=48;
C.nTest=2048;
C.nRef=1024;
C.rank=48;
C.screenTestBase=211000;
C.refineTestBase=221000;
C.holdoutTestBase=231000;
C.tieRelativeTol=1e-6;
end

This directory intentionally contains NO trained oracle weights.
First clone https://github.com/aimat-lab/Multi-stage-Bayesian-optimisation,
then run python/freeze_msbo_oracles.py --repo <path-to-cloned-repository>.
Do NOT copy old V10 frozen oracles here or merge their outcome files.

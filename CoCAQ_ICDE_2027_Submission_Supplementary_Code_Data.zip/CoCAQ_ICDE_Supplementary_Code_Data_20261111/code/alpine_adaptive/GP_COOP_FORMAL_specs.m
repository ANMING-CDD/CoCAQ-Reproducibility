function cases=GP_COOP_FORMAL_specs(root)
% LEGACY: 12 frozen MSBO + CASE01 + Alpine2 6S6D + optional Rosenbrock.
% NEW OPT-IN: Alpine2 even stages/dimensions 2S2D to 20S20D.
% Keep original first 15 positions unchanged to preserve previous test seeds,
% checkpoint identities, and the default 14-case experiment.
if nargin<1||isempty(root),root=fileparts(mfilename('fullpath'));end
cases=MSBO_GRID_specs(root);
t=cases(1);
t.id='CASE01';t.name='Forrester_Branin_2S2D';t.kind='forrester';
t.K=2;t.d=2;t.p=1;t.stageDims=[1 1];t.nInitial=16;
t.nAdd=30;t.nTest=2048;t.nRef=1024;t.rank=32;
t.folder='';t.provisional=false;
t.source='Legacy R9 Forrester-Branin cascade_truth.m (exact formula)';
cases(end+1)=t;
t=cases(1);
t.id='BOFN_ALPINE2_6S6D';t.name=t.id;t.kind='bofn_alpine2';
t.K=6;t.d=6;t.p=1;t.stageDims=ones(1,6);t.nInitial=36;
t.nAdd=30;t.nTest=2048;t.nRef=1024;t.rank=48;
t.folder='';t.provisional=false;
t.source='BOFN Alpine2 cascade function, as preserved by legacy R9';
cases(end+1)=t;
t=cases(1);
t.id='CASCADEBO_ROSENBROCK_3S6D';t.name=t.id;
t.kind='cascadebo_rosenbrock';t.K=3;t.d=6;t.p=2;
t.stageDims=[2 2 2];t.nInitial=36;
t.nAdd=30;t.nTest=2048;t.nRef=1024;t.rank=48;
t.folder='';t.provisional=false;
t.source='CascadeBO Rosenbrock s3d2, source-consistent legacy R9';
cases(end+1)=t;
% Append ONLY new Alpine2 cases; the existing 6S6D remains index 14.
for K=[2 4 8 10 12 14 16 18 20]
 t=cases(14);
 t.id=sprintf('BOFN_ALPINE2_%dS%dD',K,K);t.name=t.id;
 t.K=K;t.d=K;t.p=1;t.stageDims=ones(1,K);
 t.nInitial=6*K; % original 6S6D has 36 samples; scale rule is predeclared
 t.nAdd=30;t.nTest=2048;t.nRef=1024;t.rank=48;
 t.folder='';t.provisional=false;
 t.source='Extended BOFN Alpine2 product cascade, K even (2..20)';
 cases(end+1)=t; %#ok<AGROW>
end
alpineIDs=arrayfun(@(K)sprintf('BOFN_ALPINE2_%dS%dD',K,K), ...
 2:2:20,'UniformOutput',false);
assert(numel(cases)==24 && numel(unique(string({cases.id})))==24 && ...
 all(ismember(alpineIDs,{cases.id})), ...
 'Alpine2 2S2D to 20S20D registration failed');
end

function COCAQ_BUDGET_PILOT(mode)
% Independent exploratory comparison: CMA-ES (A2), GP-MAPPO (A5),
% CoCAQ (A5GRAD_V4A), with 300 vs 600 acquisition scores per REAL round.
%
% Usage from the 01_ACTIVE_R2/matlab directory:
%   COCAQ_BUDGET_PILOT('preflight')   % no experiment is run
%   COCAQ_BUDGET_PILOT('audit')       % finite-difference gradient audit
%   COCAQ_BUDGET_PILOT('smoke')       % one case, 2 rounds, budgets 64/96
%   COCAQ_BUDGET_PILOT('pilot')       % 3S15D, 2 seeds, 12 rounds, 300/600
%   COCAQ_BUDGET_PILOT('expand')      % 3 cases, 3 seeds, 30 rounds, 300/600
%   COCAQ_BUDGET_PILOT('report')      % scan saved checkpoints; CSV only
%
% No original engine files are edited. All checkpoints use distinct study IDs.
% Missing R2 tuning files -> the engine's DEFAULT hyperparameters are used,
% prominently labeled DEFAULT. Such exploratory results are NOT R2 holdout.
% Do NOT select favorable seeds/budgets and claim a prospective test.

if nargin<1 || isempty(mode),mode='preflight';end
mode=lower(char(mode));
root=fileparts(mfilename('fullpath'));
need={fullfile(root,'MSBO_R2_ENGINE.m'), ...
      fullfile(root,'MSBO_R2_config.m'), ...
      fullfile(root,'engine','GCF_mappo_v4.m'), ...
      fullfile(root,'oracles','MSBO_3S_15D','manifest.json')};
missing=need(~cellfun(@isfile,need));
if ~isempty(missing)
    fprintf(2,'\nBudget pilot is not installed into a complete R2 project.\n');
    fprintf(2,'Current MATLAB directory: %s\n',root);
    for ii=1:numel(missing),fprintf(2,'Missing: %s\n',missing{ii});end
    error('COCAQ_BUDGET_PILOT:IncompleteInstall', ...
        'Extract the dependency-fix ZIP into the patch parent folder, merging CoCAQ_MASTER_20261106.');
end
addpath(root,'-begin');
addpath(fullfile(root,'engine'),'-begin');

switch mode
 case 'preflight'
  localPreflight(root);
  localPrintPlans();
 case 'audit'
  localPreflight(root);
  fprintf('\nRunning the original Fast-Gi gradient/finite-difference audit...\n');
  MSBO_R2_GRADIENTCHECK();
 case {'smoke','pilot','expand'}
  Q=localPlan(mode);
  localPreflight(root,Q.cases);
  fprintf('\n===== INDEPENDENT BUDGET EXPERIMENT: %s =====\n',upper(mode));
  fprintf('Cases: %s | seeds: %s | rounds: %d | budgets: %s\n', ...
      strjoin(Q.cases,', '),mat2str(Q.seeds),Q.rounds,mat2str(Q.budgets));
  fprintf('Methods: A2/CMA-ES, A5/GP-MAPPO, CoCAQ/A5GRAD_V4A\n');
  fprintf('These are NEW exploratory seeds. R2 holdout checkpoints are untouched.\n');
  for ci=1:numel(Q.cases)
   caseID=Q.cases{ci};
   [overrides,source]=localFrozenOrDefault(root,caseID);
   if strcmp(source,'DEFAULT')
    warning('COCAQ_BUDGET_PILOT:NoFrozen', ...
      ['NO R2 frozen parameters for %s. Using engine DEFAULTS for A5 and ' ...
       'CoCAQ. This is a budget-mechanism pilot, NOT an R2 parameter-frozen replication.'],caseID);
   else
    fprintf('CASE %s: using independently tuned FROZEN R2 configs.\n',caseID);
   end
   for budget=Q.budgets
    S=localRunSpec(Q,budget,source);
    S.methodOverrides=overrides;
    fprintf('\nCASE %s BUDGET %d [%s]; checkpoints: %s\n', ...
        caseID,budget,source,fullfile(root,'results','R2_runs',S.studyID,caseID));
    % Existing MSBO_R2_ENGINE enforces exact acquisition-call budgets,
    % deterministic paired initial designs, unique checkpoint signatures,
    % and resume without restarting already completed sampling rounds.
    MSBO_R2_ENGINE(S,caseID);
    localReportOne(root,Q);
   end
  end
  localReportOne(root,Q);
  fprintf('\nFINISHED %s. Results: %s\n',upper(mode), ...
      fullfile(root,'results','BUDGET_PILOT_V1',upper(mode)));
 case 'report'
  localReportOne(root,localPlan('smoke'));
  localReportOne(root,localPlan('pilot'));
  localReportOne(root,localPlan('expand'));
  fprintf('\nReports saved under matlab/results/BUDGET_PILOT_V1/.\n');
 otherwise
  error('Expected preflight, audit, smoke, pilot, expand, or report.');
end
end

function Q=localPlan(mode)
Q=struct();Q.mode=upper(char(mode));
Q.methods={'A2','A5','A5GRAD_V4A'};
Q.nAnchors=48;Q.nTest=2048;Q.nRef=1024;Q.rank=48;
% Separate evaluation test set from screen/refine and the observed R2 holdout.
Q.testBase=291000;
switch mode
 case 'smoke'
  Q.cases={'MSBO_3S_15D'};Q.seeds=9601;Q.rounds=2;
  Q.budgets=[64 96];Q.nAnchors=16;Q.nTest=128;Q.nRef=128;
 case 'pilot'
  Q.cases={'MSBO_3S_15D'};Q.seeds=9601:9602;Q.rounds=12;
  Q.budgets=[300 600];
 case 'expand'
  Q.cases={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'};
  Q.seeds=9601:9603;Q.rounds=30;Q.budgets=[300 600];
 otherwise
  error('Unsupported plan.');
end
end

function localPreflight(root,requested)
if nargin<2,requested={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'};end
C=MSBO_R2_config();
assert(C.nAcq==300 && C.holdoutRounds==30, ...
 'Original R2 configuration has been modified. Restore R2 before running.');
assert(isequal(C.holdoutSeeds,8301:8310),'Original R2 seeds changed.');
A=MSBO_GRID_specs(root);
for i=1:numel(requested)
 idx=find(strcmp({A.id},requested{i}));
 assert(numel(idx)==1,'Unknown MSBO case: %s',requested{i});
 s=A(idx);
 f=fullfile(s.folder,'manifest.json');
 assert(isfile(f),'Missing frozen oracle file: %s',f);
 M=jsondecode(fileread(f));
 assert(strcmp(char(M.case),s.id) && M.K==s.K && M.D==s.d && ...
        isequal(double(M.stageDims(:)'),s.stageDims),'Oracle manifest mismatch.');
 assert(isfield(M,'digest')&&strlength(string(M.digest))==64, ...
        'Oracle digest missing or malformed.');
 % Only reads the existing frozen truth; does not change it.
 y=MSBO_GRID_truth(s,[zeros(1,s.d);ones(1,s.d)]);
 assert(isequal(size(y),[2,s.K])&&all(isfinite(y(:))), ...
        'Failed truth self-check for %s.',s.id);
 [~,source]=localFrozenOrDefault(root,s.id);
 fprintf('READY %-14s  oracle=%s  hyperparameters=%s\n', ...
   s.id,char(M.digest(1:12)),source);
end
fprintf('Preflight passed. Original R2 source code and results are unchanged.\n');
end

function localPrintPlans()
fprintf('\nTEST COMMANDS:\n');
fprintf('  COCAQ_BUDGET_PILOT(''smoke'')   %% 1 seed, 2 rounds, 64 vs 96\n');
fprintf('  COCAQ_BUDGET_PILOT(''pilot'')   %% 1 case, 2 seeds, 12 rounds, 300 vs 600\n');
fprintf('  COCAQ_BUDGET_PILOT(''report'')  %% export CSV, no new runs\n');
fprintf('  COCAQ_BUDGET_PILOT(''expand'')  %% 3 cases, 3 seeds, 30 rounds; expensive\n');
end

function S=localRunSpec(Q,budget,source)
S=struct();
S.studyID=sprintf('COCAQ_BUDGET_%s_B%d_%s_V1',Q.mode,budget,source);
S.phase=['EXPLORATORY_BUDGET_' Q.mode];
S.seeds=Q.seeds;S.methods=Q.methods;S.rounds=Q.rounds;
S.nAcq=budget;S.nAnchors=Q.nAnchors;S.nTest=Q.nTest;
S.nRef=Q.nRef;S.rank=Q.rank;S.testBase=Q.testBase;
S.methodOverrides=struct();
end

function [overrides,source]=localFrozenOrDefault(root,caseID)
overrides=struct();source='DEFAULT';
C=MSBO_R2_config();
A=MSBO_GRID_specs(root);
s=A(strcmp({A.id},caseID));
manifest=jsondecode(fileread(fullfile(s.folder,'manifest.json')));
master=fullfile(root,'results','R2_tuning','FROZEN_METHOD_CONFIGS.mat');
if isfile(master)
 z=load(master,'frozen');
 if ~isfield(z,'frozen') || ~isfield(z.frozen,'protocol') || ...
    ~isequaln(z.frozen.protocol,C)
   error('Frozen master exists but its R2 protocol does not match: %s',master);
 end
 if isfield(z.frozen.params,caseID)
  assert(isfield(z.frozen.oracles,caseID) && ...
    strcmp(char(z.frozen.oracles.(caseID)),char(manifest.digest)), ...
    'Frozen parameters and truth network do not match for %s.',caseID);
  overrides=localCheckOverrides(z.frozen.params.(caseID));
  source='FROZEN';return;
 end
end
% Support a single case's authentic freeze file when aggregate is absent.
caseFile=fullfile(root,'results','R2_tuning',caseID,'FROZEN_CASE.mat');
if isfile(caseFile)
 z=load(caseFile,'caseFreeze');
 assert(isfield(z,'caseFreeze') && isequaln(z.caseFreeze.protocol,C) && ...
   strcmp(char(z.caseFreeze.oracleDigest),char(manifest.digest)), ...
   'Invalid case-level R2 freeze: %s',caseFile);
 overrides=localCheckOverrides(z.caseFreeze.params);
 source='FROZEN';return;
end
end

function overrides=localCheckOverrides(overrides)
assert(isstruct(overrides) && ...
  isfield(overrides,'A5') && isfield(overrides,'A5GRAD_V4A'), ...
  'Frozen config lacks separate A5 and CoCAQ settings.');
end

function localReportOne(root,Q)
base=fullfile(root,'results','BUDGET_PILOT_V1',Q.mode);
if ~isfolder(base),mkdir(base);end
names={'Mode','Case','Seed','Budget','Method','ParamSource','Rounds', ...
 'FinalRMSE','AULC','RewardCalls','GradientCalls','AcqBuildSec','SearchSec','FitSec'};
cnames={'Mode','Case','Seed','Budget','Method','ParamSource','Round','RMSE'};
runs=cell(0,numel(names));curves=cell(0,numel(cnames));
state=cell(0,8);
for ci=1:numel(Q.cases)
 caseID=Q.cases{ci};
 for budget=Q.budgets
  for sources={'DEFAULT','FROZEN'}
   source=sources{1};S=localRunSpec(Q,budget,source);
   for seed=Q.seeds
    for mi=1:numel(Q.methods)
     meth=Q.methods{mi};
     filename=fullfile(root,'results','R2_runs',S.studyID,caseID, ...
        sprintf('%s_seed%d_%s.mat',caseID,seed,meth));
     if ~isfile(filename),continue;end
     z=load(filename,'H','signature');
     assert(isfield(z,'H')&&isfield(z,'signature'), ...
        'Checkpoint missing fields: %s',filename);
     H=z.H;sig=z.signature;
     assert(strcmp(char(sig.studyID),S.studyID) && ...
       strcmp(char(sig.phase),S.phase) && ...
       strcmp(char(sig.caseId),caseID) && ...
       strcmp(char(sig.method),meth) && sig.seed==seed && ...
       sig.nAcq==budget && sig.rounds==Q.rounds, ...
       'Checkpoint signature does not match plan: %s',filename);
     nDone=numel(H.RMSE)-1;
     assert(nDone>=0 && nDone<=Q.rounds && ...
       numel(H.RewardCalls)==nDone, 'Malformed checkpoint: %s',filename);
     status='PARTIAL';if nDone==Q.rounds,status='COMPLETE';end
     state(end+1,:)={string(Q.mode),string(caseID),seed,budget, ...
       string(meth),string(source),nDone,string(status)}; %#ok<AGROW>
     if nDone~=Q.rounds,continue;end
     assert(sum(H.RewardCalls)==nDone*budget, ...
       'Budget accounting mismatch: %s',filename);
     if strcmp(meth,'A5GRAD_V4A')
      assert(sum(H.GradientCalls)>0, ...
       'Completed CoCAQ checkpoint has no gradient proposals: %s',filename);
     end
     aulc=trapz(0:nDone,H.RMSE(:)')/nDone;
     runs(end+1,:)={string(Q.mode),string(caseID),seed,budget, ...
       string(meth),string(source),nDone,H.RMSE(end),aulc, ...
       sum(H.RewardCalls),sum(H.GradientCalls), ...
       sum(H.AcqBuildSec),sum(H.OptimizeSec),sum(H.FitSec)}; %#ok<AGROW>
     for k=0:nDone
      curves(end+1,:)={string(Q.mode),string(caseID),seed,budget, ...
        string(meth),string(source),k,H.RMSE(k+1)}; %#ok<AGROW>
     end
    end
   end
  end
 end
end
R=cell2table(runs,'VariableNames',names);
T=cell2table(curves,'VariableNames',cnames);
if ~isempty(R),R=sortrows(R,{'Case','Budget','ParamSource','Seed','Method'});end
if ~isempty(T),T=sortrows(T,{'Case','Budget','ParamSource','Seed','Method','Round'});end
writetable(R,fullfile(base,'ALL_RUNS.csv'));
writetable(T,fullfile(base,'ALL_CURVES.csv'));
ST=cell2table(state,'VariableNames', ...
 {'Mode','Case','Seed','Budget','Method','ParamSource','CompletedRounds','Status'});
writetable(ST,fullfile(base,'CHECKPOINT_STATUS.csv'));

% Paired comparisons, never select a winning seed post hoc.
paired=cell(0,10);means=cell(0,9);
if ~isempty(R)
for ci=1:numel(Q.cases)
 caseID=string(Q.cases{ci});
 for budget=Q.budgets
  for sources={'DEFAULT','FROZEN'}
   src=string(sources{1});
   sel=strcmp(string(R.Case),caseID) & R.Budget==budget & ...
     strcmp(string(R.ParamSource),src);
   W=R(sel,:);if isempty(W),continue;end
   for mi=1:numel(Q.methods)
    method=string(Q.methods{mi});V=W(strcmp(string(W.Method),method),:);
    if isempty(V),continue;end
    means(end+1,:)={caseID,budget,src,method,height(V), ...
      mean(V.FinalRMSE),mean(V.AULC),mean(V.SearchSec), ...
      mean(V.GradientCalls)}; %#ok<AGROW>
   end
   for bm={'A2','A5'}
    baseline=string(bm{1});
    A=W(strcmp(string(W.Method),baseline),:);
    B=W(strcmp(string(W.Method),"A5GRAD_V4A"),:);
    [ss,ia,ib]=intersect(A.Seed,B.Seed);
    if isempty(ss),continue;end
    a=A.FinalRMSE(ia);b=B.FinalRMSE(ib);
    av=A.AULC(ia);bv=B.AULC(ib);
    paired(end+1,:)={caseID,budget,src,baseline,numel(ss), ...
      mean(a),mean(b),100*(mean(a)-mean(b))/max(mean(a),realmin), ...
      100*(mean(av)-mean(bv))/max(mean(av),realmin),sum(b<a)}; %#ok<AGROW>
   end
  end
 end
end
end % only compare saved, completed trajectories
ME=cell2table(means,'VariableNames',{'Case','Budget','ParamSource','Method', ...
 'NSeeds','MeanFinalRMSE','MeanAULC','MeanSearchSeconds','MeanGradientCalls'});
PA=cell2table(paired,'VariableNames',{'Case','Budget','ParamSource', ...
 'Baseline','PairedSeeds','BaselineRMSE','CoCAQRMSE', ...
 'CoCAQFinalGainPct','CoCAQAULCGainPct','CoCAQWins'});
writetable(ME,fullfile(base,'MEAN_BY_METHOD.csv'));
writetable(PA,fullfile(base,'PAIRED_COMPARISON.csv'));
fprintf('%s: completed %d / expected %d checkpoints; paired rows %d\n', ...
 Q.mode,height(R),numel(Q.cases)*numel(Q.budgets)* ...
 numel(Q.seeds)*numel(Q.methods),height(PA));
if ~isempty(PA),disp(PA);end
end

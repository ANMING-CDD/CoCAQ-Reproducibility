function C=YB_R2_config()
% INDEPENDENT Yb-fiber R2 protocol. Does NOT change existing MSBO R2 results.
% Physics evaluator comes from user's existing acceptance/source_bridge.py.
C=struct();
C.protocol='YBF_R2_FOUR_STAGE_PHYSICAL_BRIDGE_V1';
C.tuneTag='YBF_R2_TUNE_V1';
C.holdoutStudyID='YBF_R2_HOLDOUT_V1';
C.methods={'P1','P2','A1','A2','A3','A4','A5','A5GRAD_V4A'};
C.rlMethods={'A4','A5','A5GRAD_V4A'};
C.caseId='YB_FIBER_4S8D';
% DISJOINT from previously reported 5901:5910 and R2 MSBO 8101:8310.
C.screenSeeds=8501:8504;
C.refineSeeds=8601:8604;
C.holdoutSeeds=8701:8710;
% Original V9 fiber physical acquisition BUDGET is 12 complete runs.
% Tuning stage lengths are adapted to this 12-run physical budget.
C.screenRounds=6;C.refineRounds=12;C.holdoutRounds=12;
C.nAcq=300;C.nAnchors=48;C.nTest=32;C.nRef=256;C.rank=32;
C.screenTestBase=311000;C.refineTestBase=321000;C.holdoutTestBase=331000;
C.acceptanceRoot=getenv('CASCADE_ACCEPTANCE_ROOT');
C.pythonExe=getenv('CASCADE_PYTHON_EXE');
if isempty(C.pythonExe) && ispc
 C.pythonExe=fullfile(getenv('USERPROFILE'),'venvs','cascade-msbo','Scripts','python.exe');
end
end

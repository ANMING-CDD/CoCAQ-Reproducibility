function COCAQ_R4_RUN(action)
% Independent CoCAQ R4 experiment: terminal target, bidirectional GP
% communication, LOO-gated Fast-Gi teacher, optional policy warm start.
% No original R2/R3 code/checkpoint is overwritten.
if nargin<1,action='help';end
action=lower(char(action));root=fileparts(mfilename('fullpath'));
assert(isfolder(fullfile(root,'engine')),'Missing engine directory: use FULL R4 zip.');
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
switch action
 case {'help','?'}
  fprintf('\nCoCAQ-R4 goal-oriented GP communication validation\n');
  fprintf(' COCAQ_R4_RUN(''preflight'')  %% file+protocol validation\n');
  fprintf(' COCAQ_R4_RUN(''selftest'')   %% model/fantasy/gradient tests\n');
  fprintf(' COCAQ_R4_RUN(''smoke'')      %% 11 methods x 1 seed x 2 rounds\n');
  fprintf(' COCAQ_R4_RUN(''pilot'')      %% 11 methods x 3 seeds x 12 rounds\n');
  fprintf(' COCAQ_R4_RUN(''expand'')     %% 11 methods x 3 cases x 4 seeds x 30 rounds\n');
  fprintf(' COCAQ_R4_RUN(''confirm'')    %% 11 methods x 12 cases x 10 new seeds x 30 rounds\n');
  fprintf(' COCAQ_R4_RUN(''report'')     %% report only (no retraining)\n');
 case 'preflight'
  preflight(root);
 case 'selftest'
  preflight(root);COCAQ_R4_SELFTEST();
 case 'report'
  for phase={'smoke','pilot','expand','confirm'}
   writeReport(root,protocol(root,phase{1}));
  end
 case {'smoke','pilot','expand','confirm'}
  preflight(root);S=protocol(root,action);
  fprintf('\nR4 %s: %d cases x %d seeds x %d methods = %d runs (%d rounds).\n', ...
   upper(action),numel(S.cases),numel(S.seeds),numel(S.methods), ...
   numel(S.cases)*numel(S.seeds)*numel(S.methods),S.rounds);
  fprintf('Proxy budget=%d; terminal re-rank=%d; fantasy samples=%d.\n', ...
   S.nAcq,S.nShort,S.nFantasy);
  for ci=1:numel(S.cases)
   MSBO_R4_ENGINE(S,S.cases{ci});
   writeReport(root,S);
  end
  fprintf('R4 %s finished. Reports in results/R4_reports/%s\n',upper(action),upper(action));
 otherwise
  error('Unsupported R4 command: %s',action);
end
end

function S=protocol(root,action)
S=struct('studyID','','phase','','seeds',[], ...
 'methods',{{'A2','A3','A4','A5','A5GRAD_V4A', ...
  'R4_TERM','R4_COMM','R4_NOCOMM','R4_FULL','R4_FULL_WARM','R4_CMA'}}, ...
 'rounds',30,'nAcq',300,'nAnchors',48,'nTest',2048,'nRef',512, ...
 'rank',48,'nFantasy',3,'nShort',12,'teacherWeight',.04, ...
 'testBase',671000,'methodOverrides',struct(), ...
 'cases',{{}},'mode',upper(action));
switch action
 case 'smoke'
  S.studyID='R4_V1_SMOKE';S.phase='CODE_CHECK_ONLY';
  S.cases={'MSBO_3S_15D'};S.seeds=11101;S.rounds=2;
  S.nAcq=64;S.nAnchors=16;S.nTest=128;S.nRef=64;
  S.rank=12;S.nFantasy=2;S.nShort=6;
 case 'pilot'
  S.studyID='R4_V1_PILOT';S.phase='EXPLORATORY';
  S.cases={'MSBO_3S_15D'};S.seeds=11111:11113;
  S.rounds=12;S.testBase=672000;
 case 'expand'
  S.studyID='R4_V1_EXPAND';S.phase='EXPLORATORY';
  S.cases={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'};
  S.seeds=11201:11204;S.testBase=673000;
 case 'confirm'
  S.studyID='R4_V1_CONFIRM';S.phase='LOCKED_CONFIRMATORY';
  allCases=MSBO_GRID_specs(root);S.cases={allCases.id};
  S.seeds=11301:11310;S.testBase=674000;
 otherwise,error('Unsupported R4 phase');
end
end

function preflight(root)
files={'MSBO_R4_ENGINE.m','MSBO_GRID_specs.m','MSBO_GRID_truth.m', ...
 fullfile('engine','GCF_r4_build.m'), ...
 fullfile('engine','GCF_r4_proxy_eval.m'), ...
 fullfile('engine','GCF_r4_terminal_eval.m'), ...
 fullfile('engine','GCF_r4_rerank.m'), ...
 fullfile('engine','GCF_r4_messages.m'), ...
 fullfile('engine','GCF_r4_state.m'), ...
 fullfile('engine','GCF_r4_mappo.m'), ...
 fullfile('engine','GCF_mappo.m'),fullfile('engine','GCF_mappo_v4.m'), ...
 fullfile('engine','GCF_cmaes.m'),fullfile('engine','GCF_fastgi_build.m')};
for i=1:numel(files)
 assert(isfile(fullfile(root,files{i})),'Missing R4 dependency: %s',files{i});
end
cases=MSBO_GRID_specs(root);
assert(numel(cases)==12,'Expected twelve frozen MSBO cases.');
for i=1:12
 f=fullfile(cases(i).folder,'manifest.json');
 assert(isfile(f),'Missing oracle manifest: %s',f);
 j=jsondecode(fileread(f));
 assert(strcmp(char(j.case),cases(i).id) && ...
  j.K==cases(i).K && j.D==cases(i).d && numel(char(j.digest))==64, ...
  'Oracle manifest mismatch for %s',cases(i).id);
end
old=MSBO_R2_config();
assert(old.nAcq==300 && old.holdoutRounds==30 && ...
 isequal(old.holdoutSeeds,8301:8310),'Legacy R2 config has changed.');
assert(isempty(intersect(11301:11310,[8301:8310,9821:9823,9921:9924,10021:10030,11101,11111:11113,11201:11204])));
fprintf('R4 PREFLIGHT PASS: 12 frozen MSBO oracles and 11 methods.\n');
fprintf('IMPORTANT: default GP/MAPPO/CMA hyperparameters are NOT independently tuned.\n');
fprintf('R4 candidates score %d fast-proxy calls plus extra terminal fantasy evaluations.\n',300);
end

function writeReport(root,S)
folder=fullfile(root,'results','R4_reports',S.mode);
if ~isfolder(folder),mkdir(folder);end
names={'Case','Seed','Method','Rounds','FastProxyBudget','FinalRMSE','AULC', ...
 'GradientCalls','GradAccepted','TeacherPairs','DistillUpdates', ...
 'Communication','WarmStartRounds','LookaheadCalls','LookaheadChanged', ...
 'SearchSeconds','BuildSeconds','FitSeconds', ...
 'TeacherLookaheadCalls','TeacherLookaheadSeconds','TerminalGatePassed'};
types={'string','double','string','double','double','double','double', ...
 'double','double','double','double','double','double','double', ...
 'double','double','double','double','double','double','double'};
rows=cell(0,numel(names));
curves=cell(0,5);statuses=cell(0,5);
for ci=1:numel(S.cases)
 cid=S.cases{ci};
 for seed=S.seeds
  for mi=1:numel(S.methods)
   meth=S.methods{mi};
   fn=fullfile(root,'results','R4_runs',S.studyID,cid, ...
    sprintf('%s_seed%d_%s.mat',cid,seed,meth));
   if ~isfile(fn),continue;end
   z=load(fn,'H','signature');assert(isfield(z,'H')&&isfield(z,'signature'));
   H=z.H;sig=z.signature;
   assert(strcmp(char(sig.studyID),S.studyID) && ...
    strcmp(char(sig.method),meth) && sig.seed==seed && ...
    sig.nAcq==S.nAcq && sig.rounds==S.rounds, ...
    'R4 checkpoint signature inconsistent: %s',fn);
   done=numel(H.RMSE)-1;
   statuses(end+1,:)={string(cid),seed,string(meth),done,string(fn)}; %#ok<AGROW>
   if done~=S.rounds,continue;end
   assert(sum(H.RewardCalls)==S.nAcq*done,'R4 fast budget mismatch');
   fields={'GradAccepted','TeacherPairs','DistillUpdates', ...
    'CommunicationEnabled','WarmStartUsed', ...
    'TerminalLookaheadCalls','ProxyWinnerChanged', ...
    'TeacherTerminalCalls','TeacherTerminalSeconds','TerminalGatePassed'};
   agg=zeros(1,numel(fields));
   for r=1:done
    q=H.R4Stats{r};
    for k=1:numel(fields)
     if isfield(q,fields{k}),agg(k)=agg(k)+q.(fields{k});end
    end
   end
   aulc=trapz(0:done,H.RMSE(:)')/done;
   rows(end+1,:)={string(cid),seed,string(meth),done,S.nAcq, ...
    H.RMSE(end),aulc,sum(H.GradientCalls),agg(1),agg(2),agg(3), ...
    agg(4),agg(5),agg(6),agg(7),sum(H.OptimizeSec),sum(H.AcqBuildSec), ...
    sum(H.FitSec),agg(8),agg(9),agg(10)}; %#ok<AGROW>
   for rr=0:done
    curves(end+1,:)={string(cid),seed,string(meth),rr,H.RMSE(rr+1)}; %#ok<AGROW>
   end
  end
 end
end
T=makeTable(rows,names,types);
C=makeTable(curves,{'Case','Seed','Method','Round','RMSE'}, ...
 {'string','double','string','double','double'});
U=makeTable(statuses,{'Case','Seed','Method','CompletedRounds','Checkpoint'}, ...
 {'string','double','string','double','string'});
writetable(T,fullfile(folder,'ALL_RUNS.csv'));
writetable(C,fullfile(folder,'ALL_CURVES.csv'));
writetable(U,fullfile(folder,'CHECKPOINT_STATUS.csv'));
pairNames={'Case','Seed','Baseline','BaselineRMSE','R4FullRMSE', ...
 'R4GainRMSE_pct','BaselineAULC','R4FullAULC','R4GainAULC_pct'};
pairs=cell(0,numel(pairNames));
caseNames={'Case','Baseline','NPairedSeeds','BaselineRMSE','R4FullRMSE', ...
 'R4GainRMSE_pct','R4GainAULC_pct','R4Wins'};
caserows=cell(0,numel(caseNames));
for ci=1:numel(S.cases)
 cid=string(S.cases{ci});W=T(T.Case==cid,:);
 if isempty(W),continue;end
 G=W(W.Method=="R4_FULL",:);
 for mi=1:numel(S.methods)
  baseline=S.methods{mi};
  if strcmp(baseline,'R4_FULL'),continue;end
  B=W(W.Method==string(baseline),:);
  [seeds,ib,ig]=intersect(B.Seed,G.Seed);
  if isempty(seeds),continue;end
  br=B.FinalRMSE(ib);gr=G.FinalRMSE(ig);
  ba=B.AULC(ib);ga=G.AULC(ig);
  caserows(end+1,:)={cid,string(baseline),numel(seeds), ...
   mean(br),mean(gr),100*(mean(br)-mean(gr))/max(mean(br),realmin), ...
   100*(mean(ba)-mean(ga))/max(mean(ba),realmin),sum(gr<br)}; %#ok<AGROW>
  for j=1:numel(seeds)
   pairs(end+1,:)={cid,seeds(j),string(baseline),br(j),gr(j), ...
    100*(br(j)-gr(j))/max(br(j),realmin),ba(j),ga(j), ...
    100*(ba(j)-ga(j))/max(ba(j),realmin)}; %#ok<AGROW>
  end
 end
end
P=makeTable(caserows,caseNames, ...
 {'string','string','double','double','double','double','double','double'});
I=makeTable(pairs,pairNames, ...
 {'string','double','string','double','double','double','double','double','double'});
writetable(P,fullfile(folder,'PAIRED_CASE_COMPARISON.csv'));
writetable(I,fullfile(folder,'PAIRED_SEED_COMPARISON.csv'));
expect=numel(S.cases)*numel(S.seeds)*numel(S.methods);
fprintf('R4 %s: %d/%d complete, %d paired case comparisons.\n',S.mode,height(T),expect,height(P));
if ~isempty(P),disp(P);end
end
function T=makeTable(rows,names,types)
if isempty(rows)
 T=table('Size',[0 numel(names)],'VariableTypes',types,'VariableNames',names);
else
 T=cell2table(rows,'VariableNames',names);
end
end

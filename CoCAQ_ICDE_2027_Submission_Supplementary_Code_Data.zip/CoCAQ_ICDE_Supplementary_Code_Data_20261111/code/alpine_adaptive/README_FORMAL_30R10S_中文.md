请先阅读工程根目录的 README_中文运行说明.md。正式命令：
COCAQ_GP_COOP_FORMAL_RUN('preflight');
COCAQ_GP_COOP_FORMAL_RUN('selftest');
COCAQ_GP_COOP_FORMAL_RUN('smoke');
COCAQ_GP_COOP_FORMAL_RUN('all');
仅MAPPO和GP-MAPPO自动调参；正式14案例×10种子×30轮，A2/IPPO/V4A固定。

function C=IQ_R2_config()
% Independent official IMDb real-data SQL cascade; not the GRACEFUL
% UDF cost-estimation task. Does not modify MSBO R2.
C=struct();
C.protocol='IQR_IMDB_R2_4STAGE_OFFICIAL_IMDB_V1';
C.tuneTag='IQR_IMDB_R2_TUNE_V1';
C.holdoutStudyID='IQR_IMDB_R2_HOLDOUT_V1';
C.methods={'P1','P2','A1','A2','A3','A4','A5','A5GRAD_V4A'};
C.rlMethods={'A4','A5','A5GRAD_V4A'};
C.caseId='IMDB_SQL_4S8D';
C.screenSeeds=8801:8804;C.refineSeeds=8901:8904;C.holdoutSeeds=9001:9010;
C.screenRounds=12;C.refineRounds=30;C.holdoutRounds=30;
C.nAcq=300;C.nAnchors=48;C.nTest=256;C.nRef=256;C.rank=32;
C.screenTestBase=411000;C.refineTestBase=421000;C.holdoutTestBase=431000;
C.oracleFile=strtrim(getenv('IMDB_ORACLE_FILE'));
C.pythonExe=strtrim(getenv('IMDB_PYTHON_EXE'));
if isempty(C.pythonExe),C.pythonExe='python';end
end

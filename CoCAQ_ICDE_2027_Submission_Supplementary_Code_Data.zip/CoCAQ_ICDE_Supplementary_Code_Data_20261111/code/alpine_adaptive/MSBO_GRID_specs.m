function cases=MSBO_GRID_specs(root)
% Fixed 4x3 MSBO-like scalar cascade grid. Extra controls go to earlier stages.
if nargin<1 || isempty(root),root=fileparts(mfilename('fullpath'));end
Kvec=2:5;Dvec=[10 15 20];cases=struct([]);j=0;
for K=Kvec
 for D=Dvec
  j=j+1;q=floor(D/K);r=mod(D,K);
  dims=q*ones(1,K);dims(1:r)=dims(1:r)+1;
  s=struct();s.id=sprintf('MSBO_%dS_%dD',K,D);
  s.name=s.id;s.kind='msbo_grid12';s.K=K;s.d=D;s.p=q;
  s.stageDims=dims;s.nInitial=3*D;s.nAdd=30;
  s.nTest=2048;s.nRef=1024;s.rank=48;
  s.folder=fullfile(root,'oracles',s.id);
  s.provisional=false;s.source='Upstream MSBO NN_func; NEW frozen scalar-output adaptation';
  assert(sum(dims)==D && numel(dims)==K && all(dims>=1));
  % MATLAB cannot assign a populated struct into a 0-field struct([]).
  % Initialize with the first fully defined spec, then append like-for-like.
  if j==1
   cases=s;
  else
   cases(j)=s;
  end
 end
end
assert(numel(cases)==numel(Kvec)*numel(Dvec), ...
 'MSBO_GRID_specs: wrong number of cases.');
end

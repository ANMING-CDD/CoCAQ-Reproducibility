function COCAQ_V4A_STABLE_SELFTEST()
% Numeric tests do NOT run actual oracle or change experiment checkpoints.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'engine'),'-begin');
rng(71981,'twister');
B=9;p=2;
Z=.3*randn(B,p);mu=.2*randn(B,p);ls=log([.9 1.2]);sig=exp(ls);
eps0=.08;eta=.30;q=1.8*ones(B,1);
[l,resp]=GCF_ppo_stable_logpdf(Z,mu,sig,eps0,eta,q);
assert(all(isfinite(l))&&all(resp>=0 & resp<=1));
rr=5;cc=1;h=1e-5;
mp=mu;mm=mu;mp(rr,cc)=mp(rr,cc)+h;mm(rr,cc)=mm(rr,cc)-h;
lp=GCF_ppo_stable_logpdf(Z,mp,sig,eps0,eta,q);
lm=GCF_ppo_stable_logpdf(Z,mm,sig,eps0,eta,q);
fd=(lp(rr)-lm(rr))/(2*h);
an=resp(rr)*(Z(rr,cc)-mu(rr,cc))/(sig(cc)^2);
assert(abs(fd-an)<1e-5,'Mixture-policy mean score derivative incorrect');
sp=sig;sm=sig;sp(cc)=sig(cc)*exp(h);sm(cc)=sig(cc)*exp(-h);
lp=GCF_ppo_stable_logpdf(Z,mu,sp,eps0,eta,q);
lm=GCF_ppo_stable_logpdf(Z,mu,sm,eps0,eta,q);
fd=(lp(rr)-lm(rr))/(2*h);
an=resp(rr)*(((Z(rr,cc)-mu(rr,cc))/sig(cc))^2-1);
assert(abs(fd-an)<1e-5,'Mixture-policy log-sigma derivative incorrect');
g=struct('W1',ones(8,4),'b1',ones(1,4),'W2',zeros(4,2),'b2',zeros(1,2));
[g,clipped,norm0]=GCF_ppo_stable_clipgrad(g,1);
assert(clipped==1 && norm0>1 && ...
 abs(sqrt(sum(g.W1(:).^2)+sum(g.b1(:).^2))-1)<1e-9);
% Same policy log density, same saved old distribution -> initial KL zero.
k3=mean(expm1(l-l)-(l-l));assert(k3==0);
% No scorer called here; search budget is tested at runtime by the engine.
fprintf('V4A STABLE SELFTEST PASS: mixture density, analytic score derivatives, clipping, zero-KL.\n');
end

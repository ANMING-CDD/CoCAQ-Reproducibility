function COCAQ_HORIZONTAL_FOCUSED_RUN(action)
% COCAQ_HORIZONTAL_FOCUSED_RUN  Complete the TWO most promising horizontal curves.
%
% This entry point REUSES the existing horizontal pilot protocol (not a new
% experiment): paired seeds 16611:16613, 8 rounds, 128 scores per round,
% same GP settings/test sets/checkpoint study ID, and 5 original methods.
%
% 3-node ACKLEY DAG: D = [6,10,20,30]
% 6-stage grouped ROSENBROCK: D = [12,18,24,30]
%
% Previously completed endpoints are left intact; 'run' fills ONLY the four
% intermediate cases, then produces a focused comparison and figure.
%
% Example:
%   COCAQ_HORIZONTAL_FOCUSED_RUN('preflight');
%   COCAQ_HORIZONTAL_FOCUSED_RUN('run');
%   COCAQ_HORIZONTAL_FOCUSED_RUN('report');
%   COCAQ_HORIZONTAL_FOCUSED_RUN('status');
%
% No MATLAB results are built into this code. Numbers come from checkpoints.
if nargin < 1 || isempty(action),action='help';end
root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');
addpath(fullfile(root,'engine'),'-begin');

switch lower(char(action))
    case {'help','?'}
        fprintf(['FOCUSED HORIZONTAL PILOT: Ackley DAG 3S and Rosenbrock 6S, up to 30D\n' ...
                 '  COCAQ_HORIZONTAL_FOCUSED_RUN(''preflight'')\n' ...
                 '  COCAQ_HORIZONTAL_FOCUSED_RUN(''run'')     %% fill 4 intermediate cases\n' ...
                 '  COCAQ_HORIZONTAL_FOCUSED_RUN(''status'')  %% print coverage and summary\n' ...
                 '  COCAQ_HORIZONTAL_FOCUSED_RUN(''report'')  %% CSV + PNG plot\n']);
    case 'preflight'
        COCAQ_HORIZONTAL_PILOT_RUN('preflight');
        spec=GP_COOP_HORIZONTAL_specs(root);
        required=localCases();
        assert(all(ismember(required,string({spec.id}))), ...
            'Focused cases absent from GP_COOP_HORIZONTAL_specs.m');
        fprintf('FOCUSED PREFLIGHT OK: 8 cases, 3 fixed paired seeds, 5 methods.\n');
    case 'run'
        COCAQ_HORIZONTAL_FOCUSED_RUN('preflight');
        missing=["H_ACKLEY_3S10D","H_ACKLEY_3S20D", ...
                 "H_ROSEN_6S18D","H_ROSEN_6S24D"];
        fprintf('Completing four intermediate cases: 4 x 3 seeds x 5 methods = 60 runs.\n');
        fprintf('Existing checkpoints are reused; no tuning or protocol changes.\n');
        for i=1:numel(missing)
            COCAQ_HORIZONTAL_PILOT_RUN('pilot_case',char(missing(i)));
        end
        localReport(root);
    case 'report'
        COCAQ_HORIZONTAL_PILOT_RUN('report');
        localReport(root);
    case 'status'
        COCAQ_HORIZONTAL_PILOT_RUN('status');
        COCAQ_HORIZONTAL_PILOT_RUN('report');
        localReport(root);
    otherwise
        error('Unknown action %s. Use ''help''.',char(action));
end
end

function ids=localCases()
ids=["H_ACKLEY_3S6D","H_ACKLEY_3S10D", ...
     "H_ACKLEY_3S20D","H_ACKLEY_3S30D", ...
     "H_ROSEN_6S12D","H_ROSEN_6S18D", ...
     "H_ROSEN_6S24D","H_ROSEN_6S30D"];
end

function localReport(root)
folder=fullfile(root,'results','GP_COOP_HORIZONTAL_PILOT_reports');
source=fullfile(folder,'ALL_RUNS.csv');
if ~isfile(source)
    fprintf('No ALL_RUNS.csv yet. Run the horizontal pilot first.\n');
    return;
end
R=readtable(source,'TextType','string');
requiredCols={'Case','Seed','Method','FinalNRMSE','AULC_NRMSE', ...
              'SearchSeconds','StartRMSE','TruthStd'};
assert(all(ismember(requiredCols,R.Properties.VariableNames)), ...
       'Report missing required columns. Rebuild with horizontal pilot report.');

ids=localCases();seeds=16611:16613;
methods=["A2","A3_IPPO","A4_MAPPO","A5_GP_MAPPO","V4A_REFERENCE"];
n= numel(ids);
rows=cell(n,17);
paired=cell(0,10);
for k=1:n
    id=ids(k);
    family="AckleyDAG";D=sscanf(char(id),'H_ACKLEY_3S%dD');stages=3;
    if startsWith(id,"H_ROSEN_")
        family="GroupedRosen";D=sscanf(char(id),'H_ROSEN_6S%dD');stages=6;
    end
    W=R(R.Case==id & ismember(R.Seed,seeds) & ismember(R.Method,methods),:);
    completeRuns=height(W);
    uniqueKeys=strcat(string(W.Seed),"/",W.Method);
    assert(numel(unique(uniqueKeys))==completeRuns,'Duplicate (seed,method) run for %s',id);
    nPaired=0;winA2=0;winA5=0;bestOfFive=0;
    a2List=[];a5List=[];vList=[];a2Sec=[];vSec=[];vAulc=[];a2Aulc=[];
    startList=[];
    for seed=seeds
        T=W(W.Seed==seed,:);
        a=T(T.Method=="A2",:);
        b=T(T.Method=="A5_GP_MAPPO",:);
        v=T(T.Method=="V4A_REFERENCE",:);
        if height(a)~=1 || height(b)~=1 || height(v)~=1,continue;end
        nPaired=nPaired+1;
        a2List(end+1)=a.FinalNRMSE; %#ok<AGROW>
        a5List(end+1)=b.FinalNRMSE; %#ok<AGROW>
        vList(end+1)=v.FinalNRMSE; %#ok<AGROW>
        a2Sec(end+1)=a.SearchSeconds; %#ok<AGROW>
        vSec(end+1)=v.SearchSeconds; %#ok<AGROW>
        a2Aulc(end+1)=a.AULC_NRMSE; %#ok<AGROW>
        vAulc(end+1)=v.AULC_NRMSE; %#ok<AGROW>
        startList(end+1)=v.StartRMSE/v.TruthStd; %#ok<AGROW>
        winA2=winA2+(v.FinalNRMSE<a.FinalNRMSE);
        winA5=winA5+(v.FinalNRMSE<b.FinalNRMSE);
        if height(T)==5 && all(ismember(methods,T.Method))
            bestOfFive=bestOfFive+(v.FinalNRMSE==min(T.FinalNRMSE));
        end
        paired(end+1,:)={id,family,stages,D,seed, ...
            a.FinalNRMSE,b.FinalNRMSE,v.FinalNRMSE, ...
            100*(a.FinalNRMSE-v.FinalNRMSE)/max(a.FinalNRMSE,realmin), ...
            v.FinalNRMSE<min(T.FinalNRMSE(T.Method~="V4A_REFERENCE"))}; %#ok<AGROW>
    end
    a2=NaN;v=NaN;gainA2=NaN;gainA5=NaN;gainAulc=NaN;
    improvement=NaN;speed=NaN;stdV=NaN;
    if nPaired>0
        a2=mean(a2List);v=mean(vList);
        gainA2=100*(mean(a2List)-mean(vList))/max(mean(a2List),realmin);
        gainA5=100*(mean(a5List)-mean(vList))/max(mean(a5List),realmin);
        gainAulc=100*(mean(a2Aulc)-mean(vAulc))/max(mean(a2Aulc),realmin);
        improvement=100*(mean(startList)-mean(vList))/max(mean(startList),realmin);
        speed=mean(vSec)/max(mean(a2Sec),realmin);
        if nPaired>1,stdV=std(vList);end
    end
    rows(k,:)={id,family,stages,D,completeRuns,15,nPaired, ...
        a2,v,gainA2,gainA5,winA2,winA5,bestOfFive, ...
        improvement,gainAulc,speed};
end
columns={'Case','Family','Stages','D','CompletedRuns','ExpectedRuns','PairedSeeds', ...
 'A2_MeanNRMSE','V4A_MeanNRMSE','V4A_GainVsA2_pct','V4A_GainVsA5_pct', ...
 'V4A_WinsVsA2','V4A_WinsVsA5','V4A_BestOfFiveSeeds', ...
 'V4A_ImproveVsInitial_pct','V4A_AULCGainVsA2_pct','V4A_SearchTimeRatioVsA2'};
T=cell2table(rows,'VariableNames',columns);
file=fullfile(folder,'FOCUSED_3S6S_SCALE_COMPARISON.csv');
writetable(T,file);
P=cell2table(paired,'VariableNames', ...
  {'Case','Family','Stages','D','Seed','A2_NRMSE','A5_NRMSE','V4A_NRMSE', ...
   'V4A_GainVsA2_pct','V4A_BestOfFive'});
writetable(P,fullfile(folder,'FOCUSED_3S6S_PAIRED_SEEDS.csv'));

fprintf('\n--- Focused 3S / 6S pilot, max 30D ---\n');
disp(T(:,{'Case','PairedSeeds','V4A_GainVsA2_pct', ...
 'V4A_GainVsA5_pct','V4A_WinsVsA2','V4A_BestOfFiveSeeds', ...
 'V4A_ImproveVsInitial_pct'}));
if all(T.PairedSeeds==3)
    fprintf('COMPLETE: all 8 scale cases x 3 paired seeds.\n');
else
    fprintf('INCOMPLETE: %d of 8 cases have all 3 paired seeds.\n', ...
        sum(T.PairedSeeds==3));
    fprintf('Do NOT use missing / partial cases to select a winner.\n');
end
fprintf('CSV: %s\n',file);

try
    f=figure('Visible','off','Position',[100,100,1000,390]);
    for j=1:2
        subplot(1,2,j);
        if j==1,ix=T.Family=="AckleyDAG";ttl='Ackley DAG: 3 nodes';
        else,ix=T.Family=="GroupedRosen";ttl='Grouped Rosenbrock: 6 stages';end
        U=T(ix,:);
        x=U.D;y=U.V4A_GainVsA2_pct;
        y(U.PairedSeeds~=3)=NaN;
        plot(x,y,'-o','LineWidth',1.7,'MarkerSize',7);
        hold on;plot([min(x),max(x)],[0,0],'k--');hold off;
        xlabel('Decision dimension D');ylabel('V4A vs A2: NRMSE gain (%)');
        title(ttl);grid on; xlim([min(x)-1,max(x)+1]);
        set(gca,'XTick',x);
    end
    saveas(f,fullfile(folder,'FOCUSED_3S6S_GAIN_VS_DIMENSION.png'));
    close(f);
catch ME
    warning('Figure generation skipped: %s',ME.message);
end
end

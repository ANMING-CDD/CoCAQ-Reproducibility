function MSBO_R3_VALIDATE_ENGINE(S,caseId)
% V2 validation: R2 legacy methods + matched Fast-Gi CMA + R3 guidance.
% MAPPO variants share the same explicitly declared (not tuned) preset.
% CMA baselines share the same CMA defaults. Holdout seeds are NEVER used for tuning.
% Checkpoints: results/R3_VALIDATE_runs/<studyID>/<caseID>.
assert(isstruct(S) && isfield(S,'studyID') && isfield(S,'phase'));
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'engine'),'-begin');
cases=MSBO_GRID_specs(root);
ix=find(strcmp({cases.id},char(caseId)));
assert(isscalar(ix),'Unknown R3 case ID: %s',char(caseId));
s=cases(ix);
assert(numel(unique(S.seeds))==numel(S.seeds) && S.rounds>0);
assert(all(ismember(S.methods,{'A2','A3','A4','A5','A5GRAD_V4A', ...
 'R3_BASE','R3_REFINE','R3_GUIDED'})), ...
 'Unknown validation method; protect existing R2 methods.');
assert(isfile(fullfile(s.folder,'manifest.json')),'Missing frozen oracle');
localRunCase(s,S,root);
end

function localRunCase(s,S,root)
% Preserve deterministic initial design and shared held-out set per CASE.
registry=MSBO_GRID_specs(root);index=find(strcmp({registry.id},s.id));
assert(isscalar(index));
mdir=fullfile(root,'results','R3_VALIDATE_runs',S.studyID,s.id);
if ~exist(mdir,'dir'),mkdir(mdir);end
orac=jsondecode(fileread(fullfile(s.folder,'manifest.json')));
Xtest=GCF_halton(S.nTest,s.d,S.testBase+1000*index);
Ytest=MSBO_GRID_truth(s,Xtest);ytest=Ytest(:,end);
for seed=S.seeds
 rng(701000+1000*index+seed,'twister');X0=GCF_lhs(s.nInitial,s.d);
 Y0=MSBO_GRID_truth(s,X0);
 rng(702000+1000*index+seed,'twister');lhsAdd=GCF_lhs(S.rounds,s.d);
 for mi=1:numel(S.methods)
  method=S.methods{mi};
  file=fullfile(mdir,sprintf('%s_seed%d_%s.mat',s.id,seed,method));
  prm=struct();
  if isfield(S,'methodOverrides') && isfield(S.methodOverrides,method)
   prm=S.methodOverrides.(method);
  end
  signature=struct('engine','MSBO_R3_VALIDATE_V2_20261106', ...
   'phase',S.phase,'studyID',S.studyID,'caseId',s.id,'K',s.K,'D',s.d, ...
   'stageDims',s.stageDims,'oracleDigest',char(orac.digest), ...
   'seed',seed,'method',method,'methodOverrides',prm, ...
   'nInitial',s.nInitial,'rounds',S.rounds,'nAcq',S.nAcq, ...
   'nAnchors',S.nAnchors,'nTest',S.nTest,'nRef',S.nRef, ...
   'rank',S.rank,'testBase',S.testBase,'mappo',localMAPPO(S));
  if exist(file,'file')==2
   z=load(file,'H','signature');
   assert(isfield(z,'H')&&isfield(z,'signature')&&isequaln(z.signature,signature), ...
    'Unsafe resume: signature mismatch in %s. Keep old checkpoint, use new studyID.',file);
   H=z.H;
   assert(isequaln(H.X(1:s.nInitial,:),X0) && ...
    isequaln(H.Y(1:s.nInitial,:),Y0),'Initial paired design changed.');
  else
   kind='cascade';if any(strcmp(method,{'P1','A1'})),kind='aio';end
   tf=tic;model=GCF_fit(s,X0,Y0,kind);fitSec=toc(tf);
   pred=GCF_predict_final(s,model,Xtest);
   H=struct('Case',s.id,'Stages',s.K,'Dim',s.d,'StageDims',s.stageDims, ...
    'Seed',seed,'Method',method,'X',X0,'Y',Y0,'model',model, ...
    'RMSE',sqrt(mean((pred-ytest).^2)), ...
    'RewardCalls',zeros(0,1),'GradientCalls',zeros(0,1),'R3Stats',{cell(0,1)}, ...
    'AcqBuildSec',zeros(0,1),'OptimizeSec',zeros(0,1), ...
    'FitSec',fitSec,'TruthSec',zeros(0,1),'Chosen',zeros(0,s.d));
   localCheckpoint(file,H,signature);
  end
  done=numel(H.RMSE)-1;
  fprintf('%s seed=%d method=%s, resume round %d/%d\n',s.id,seed,method,done,S.rounds);
  for rr=done+1:S.rounds
   if any(strcmp(method,{'P1','P2'}))
    x=lhsAdd(rr,:);
    mt=struct('RewardCalls',0,'GradientCalls',0,'AcquisitionBuildSeconds',0,'OptimizationSeconds',0);
   else
    searchSeed=4800000+100000*index+10000*seed+50*rr;
    [o,mt]=localSearch(s,method,H.model,S,prm,searchSeed);
    x=o.bestX;
    assert(mt.RewardCalls==S.nAcq,'Acquisition budget mismatch.');
   end
   assert(all(isfinite(x))&&all(x>=0 & x<=1));
   tt=tic;y=MSBO_GRID_truth(s,x);truthSec=toc(tt);
   H.X=[H.X;x];H.Y=[H.Y;y];H.Chosen=[H.Chosen;x];
   kind='cascade';if any(strcmp(method,{'P1','A1'})),kind='aio';end
   tf=tic;model=GCF_fit(s,H.X,H.Y,kind,H.model);fitSec=toc(tf);
   pred=GCF_predict_final(s,model,Xtest);
   H.model=model;H.RMSE(end+1,1)=sqrt(mean((pred-ytest).^2));
   H.RewardCalls(end+1,1)=mt.RewardCalls;
   H.GradientCalls(end+1,1)=mt.GradientCalls;
   H.AcqBuildSec(end+1,1)=mt.AcquisitionBuildSeconds;
   H.OptimizeSec(end+1,1)=mt.OptimizationSeconds;
   H.FitSec(end+1,1)=fitSec;H.TruthSec(end+1,1)=truthSec;
   H.R3Stats{end+1,1}=mt;
   localCheckpoint(file,H,signature);
   fprintf('  %d/%d  held-out RMSE=%.6g\n',rr,S.rounds,H.RMSE(end));
  end
 end
end
end

function c=localMAPPO(S)
c=GCF_config('full');c=c.mappo;
c.hidden=64;c.batch=32;c.nEpoch=14;c.nHiddenLayers=2;
c.minEpochsV5=14;c.minHiddenV5=64;
c.v4FreshFraction=.50;c.v4DiversityWeight=.20;
c.v4DistanceScale=.30;c.v4CurrentBonus=.05;
c.v4FeedbackCap=16;c.v4FeedbackMinDist=.08;
c.v4MinGainFrac=1e-7;c.v4GainPriority=.55;
c.v4FeedbackLogWeight=.75;
c.nAnchors=S.nAnchors;
% New R3 parameters; no effect on the original R2 execution.
c.r3StepGrid=[0.04,0.10];    % 2 scored proposals per selected parent
c.r3DistillWeight=0.08;    % PPO + weighted supervised teacher gradient
c.r3TeacherRowClip=2.5;   % bound individual teacher gradients
c.r3MinGradNorm=1e-12;
c.r3TeacherMinRelativeGain=0.001; % 0.1% guaranteed surrogate improvement
end

function [out,meta]=localSearch(spec,method,model,S,override,seed)
Xref=GCF_halton(S.nRef,spec.d,20000+seed);
tb=tic;
if strcmp(method,'A2')
 F=GCF_chain_build(model,spec,Xref);
 evalFn=@(X)GCF_chain_eval(F,X);gradFn=[];
else
 F=GCF_fastgi_build(model,spec,Xref,S.rank);
 evalFn=@(X)GCF_fastgi_eval(F,X);
 gradFn=@(X)localFastGiGradient(F,X);
end
buildSec=toc(tb);tt=tic;
c=localMAPPO(S);
fn=fieldnames(override);
for j=1:numel(fn),c.(fn{j})=override.(fn{j});end
if any(strcmp(method,{'R3_BASE','R3_REFINE','R3_GUIDED'}))
 [out,meta]=GCF_mappo_guided(evalFn,gradFn,model,spec,S.nAcq,c,method,seed);
elseif any(strcmp(method,{'A4','A5'}))
 % Preserve ORIGINAL MAPPO implementations from MSBO R2.
 [out,meta]=GCF_mappo(evalFn,[],model,spec,S.nAcq,c,method,seed);
elseif strcmp(method,'A5GRAD_V4A')
 % Original CoCAQ V4A, not a new R3 variant.
 [out,meta]=GCF_mappo_v4(evalFn,gradFn,model,spec,S.nAcq,c,method,seed);
elseif any(strcmp(method,{'A2','A3'}))
 % A2: chain acquisition; A3: EXACT Fast-Gi acquisition optimized by CMA-ES.
 [out,meta]=GCF_cmaes(evalFn,[],S.nAcq,spec.d,c,seed);
else
 error('Unsupported R3 validation method');
end
meta.AcquisitionBuildSeconds=buildSec;meta.OptimizationSeconds=toc(tt);
assert(isfield(meta,'RewardCalls') && meta.RewardCalls==S.nAcq);
if ~isfield(meta,'GradientCalls'),meta.GradientCalls=0;end
end

function gg=localFastGiGradient(F,X)
[~,~,gg]=GCF_fastgi_eval(F,X);
end

function localCheckpoint(file,H,signature)
tmp=[file '.tmp.mat'];save(tmp,'H','signature','-v7.3');
[ok,msg]=movefile(tmp,file,'f');
assert(ok,'Checkpoint move failed: %s',msg);
end

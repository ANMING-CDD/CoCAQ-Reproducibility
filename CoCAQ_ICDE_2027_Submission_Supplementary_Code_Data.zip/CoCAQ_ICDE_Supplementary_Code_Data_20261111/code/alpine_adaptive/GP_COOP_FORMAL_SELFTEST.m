function GP_COOP_FORMAL_SELFTEST(root)
% Deterministic case truth tests and stage input conventions.
if nargin<1||isempty(root),root=fileparts(mfilename('fullpath'));end
addpath(fullfile(root,'engine'),'-begin');
S=GP_COOP_FORMAL_specs(root);
assert(numel(S)==24);
for i=1:numel(S)
 s=S(i);
 X=[.1*ones(1,s.d);.5*ones(1,s.d);.9*ones(1,s.d)];
 Y=GP_COOP_FORMAL_truth(s,X);
 assert(isequal(size(Y),[3,s.K]) && all(isfinite(Y(:))));
 for k=1:s.K
  Q=GCF_stage_input(s,X,Y,k);
  assert(size(Q,2)==s.stageDims(k)+(k>1), ...
   'Stage GP training dimension mismatch %s stage %d',s.id,k);
 end
 fprintf('SOURCE TRUTH OK %-32s K=%d D=%d\n',s.id,s.K,s.d);
end
% CASE01 exact preserved legacy truth formula at a nontrivial deterministic point.
s=S(13);X=[.37,.61];Y=GP_COOP_FORMAL_truth(s,X);
y1=(6*.37-2)^2*sin(12*.37-4);
z=.6*y1;v=15*.61;
y2=(v-5.1*z^2/(4*pi^2)+5*z/pi-6)^2 + 10*(1-1/(8*pi))*cos(z)+10;
assert(max(abs(Y-[y1,y2]))<1e-11);
% BOFN: stage 1 negative Alpine term and each subsequent node multiplied.
s=S(14);X=.35*ones(1,6);Y=GP_COOP_FORMAL_truth(s,X);
a=sqrt(3.5)*sin(3.5);
assert(abs(Y(1,end)+a^6)<1e-10);
% CascadeBO: normalized center (all physical 1) yields zero Rosenbrock loss.
s=S(15);X=.75*ones(1,6);Y=GP_COOP_FORMAL_truth(s,X);
assert(isequal(size(Y),[1,3]));
% Check no function benchmark accidentally inherits an MSBO oracle path.
assert(all(cellfun(@isempty,{S(13:end).folder})));
% Even-depth Alpine2: exact product identity, true-stage scalar dependency,
% stage GP input order [x_k, scaled y_{k-1}], and 20-D Halton support.
for K=2:2:20
 id=sprintf('BOFN_ALPINE2_%dS%dD',K,K);
 ix=find(strcmp({S.id},id));assert(isscalar(ix));s=S(ix);
 X=[.10*ones(1,K);.35*ones(1,K);.75*ones(1,K)];
 Y=GP_COOP_FORMAL_truth(s,X);
 a=sqrt(10*X).*sin(10*X);
 expected=-cumprod(a,2);
 assert(max(abs(Y(:)-expected(:))) <= ...
   1e-11*max(1,max(abs(expected(:)))), ...
   'Alpine2 product parity mismatch %s',id);
 for k=2:K
  q=GCF_stage_input(s,X,Y,k);
  qExpected=[X(:,k),10^(-(k-1)/2)*Y(:,k-1)];
  assert(max(abs(q(:)-qExpected(:)))<1e-11, ...
   'Alpine2 normalized GP stage input mismatch %s k=%d',id,k);
 end
 Q=GCF_halton(12,K,100);
 assert(isequal(size(Q),[12,K]) && all(Q(:)>0 & Q(:)<1));
 fprintf('ALPINE2 SELFTEST OK %s\n',id);
end
fprintf('FORMAL SELFTEST OK: 12 MSBO + 3 historical functions + 9 new Alpine2 scales.\n');
end

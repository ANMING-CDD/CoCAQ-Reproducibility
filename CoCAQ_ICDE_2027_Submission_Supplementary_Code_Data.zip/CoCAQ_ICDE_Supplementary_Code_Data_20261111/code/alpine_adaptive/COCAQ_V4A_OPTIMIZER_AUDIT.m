function COCAQ_V4A_OPTIMIZER_AUDIT(mode)
% Compare optimizer quality on FROZEN (previously observed) GP posterior.
% No real MSBO calls; objective is best Fast-Gi acquisition score (not RMSE).
if nargin<1,mode='pilot';end
mode=lower(char(mode));
assert(any(strcmp(mode,{'pilot','expand'})));
root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
allCases=MSBO_GRID_specs(root);
if strcmp(mode,'pilot')
 caseIDs={'MSBO_3S_15D'};seeds=11211:11213;
 studyID='V4A_STABLE_V1_PILOT';nRef=1024;rankN=48;
else
 caseIDs={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'};
 seeds=11221:11224;studyID='V4A_STABLE_V1_EXPAND';nRef=1024;rankN=48;
end
folder=fullfile(root,'results','V4A_STABLE_reports',upper(mode));
if ~isfolder(folder),mkdir(folder);end
names={'Case','GPTrainingSeed','OptimizerSeed','Method','FastGiBestScore', ...
 'ScoringCalls','GradientCalls','OptimizationSeconds','AcquisitionBuildSeconds'};
rows=cell(0,numel(names));
methods={'A3','A5GRAD_V4A','V4A_PPO_STABLE','V4A_PPO_EXPLORE'};
for i=1:numel(caseIDs)
 cid=caseIDs{i};ix=find(strcmp({allCases.id},cid));assert(isscalar(ix));s=allCases(ix);
 for seed=seeds
  file=fullfile(root,'results','V4A_STABLE_runs',studyID,cid, ...
   sprintf('%s_seed%d_A5GRAD_V4A.mat',cid,seed));
  if ~isfile(file)
   fprintf('Missing completed GP snapshot: %s\n',file);
   continue;
  end
  z=load(file,'H');H=z.H;
  model=H.model;
  for rep=1:3
   optSeed=72000000+100000*ix+1000*seed+rep;
   Xref=GCF_halton(nRef,s.d,20000+optSeed);
   tt=tic;F=GCF_fastgi_build(model,s,Xref,rankN);buildSec=toc(tt);
   evalFn=@(X)GCF_fastgi_eval(F,X);
   gradFn=@(X)gradientOnly(F,X);
   c=baseConfig();c.nAnchors=48;
   for k=1:numel(methods)
    meth=methods{k};
    tw=tic;
    if strcmp(meth,'A3')
     [out,meta]=GCF_cmaes(evalFn,[],300,s.d,c,optSeed);
    elseif strcmp(meth,'A5GRAD_V4A')
     [out,meta]=GCF_mappo_v4(evalFn,gradFn,model,s,300,c,meth,optSeed);
    else
     [out,meta]=GCF_mappo_v4_stable(evalFn,gradFn,model,s,300,c,meth,optSeed);
    end
    seconds=toc(tw);
    assert(meta.RewardCalls==300);
    assert(abs(out.best-max(out.allR))<=1e-9*max(1,abs(out.best)));
    rows(end+1,:)={string(cid),seed,optSeed,string(meth), ...
     out.best,meta.RewardCalls,meta.GradientCalls,seconds,buildSec}; %#ok<AGROW>
   end
  end
 end
end
T=toTable(rows,names,{'string','double','double','string','double', ...
 'double','double','double','double'});
writetable(T,fullfile(folder,'FIXED_GP_OPTIMIZER_AUDIT.csv'));
fprintf('FIXED GP AUDIT %s: %d rows (no real oracle calls).\n',upper(mode),height(T));
if ~isempty(T)
 methods=unique(T.Method);
 for j=1:numel(methods)
  A=T(T.Method==methods(j),:);
  fprintf('%s: mean best score %.6g, time %.3f s\n', ...
   char(methods(j)),mean(A.FastGiBestScore),mean(A.OptimizationSeconds));
 end
end
end

function gg=gradientOnly(F,X)
[~,~,gg]=GCF_fastgi_eval(F,X);
end

function c=baseConfig()
c=GCF_config('full');c=c.mappo;
c.hidden=64;c.batch=32;c.nEpoch=14;c.nHiddenLayers=2;
c.minEpochsV5=14;c.minHiddenV5=64;
c.v4FreshFraction=.50;c.v4DiversityWeight=.20;
c.v4DistanceScale=.30;c.v4CurrentBonus=.05;
c.v4FeedbackCap=16;c.v4FeedbackMinDist=.08;
c.v4MinGainFrac=1e-7;c.v4GainPriority=.55;
c.v4FeedbackLogWeight=.75;
c.ppoTargetKL=.03;c.ppoMinEpoch=2;
c.ppoActorGradMaxNorm=1.0;c.ppoCriticGradMaxNorm=3.0;
c.ppoSigmaGradMaxNorm=1.0;
c.ppoExploreEntropyCoeff=.005;c.ppoExploreMinSigma=.60;
end

function T=toTable(rows,names,types)
if isempty(rows)
 T=table('Size',[0 numel(names)],'VariableTypes',types,'VariableNames',names);
else
 T=cell2table(rows,'VariableNames',names);
end
end

function COCAQ_MASTER(action, suite, caseID)
% Unified entry point; NEVER combines different study IDs or seeds.
% In MATLAB: cd .../01_ACTIVE_R2/matlab; COCAQ_MASTER('status');
if nargin < 1 || isempty(action), action='help'; end
if nargin < 2, suite=''; end
if nargin < 3, caseID=''; end
root=fileparts(mfilename('fullpath'));
active=fileparts(root);
archive=fullfile(fileparts(active),'02_RESULTS_ARCHIVE');
addpath(root,'-begin');
if isfolder(fullfile(root,'engine')),addpath(fullfile(root,'engine'),'-begin');end
action=lower(char(action)); suite=lower(char(suite));
switch action
    case {'help','inventory'}
        fprintf('\n========== CoCAQ MASTER 2026-11-06 ==========\n');
        fprintf('Active MATLAB code: %s\nArchive: %s\n',root,archive);
        fprintf('Available: MSBO R2 (12), IMDb R2 (1), Yb Fiber R2 (requires external bridge).\n');
        fprintf('Historic V9/V10/V12 code is ISOLATED in 03_LEGACY_CODE.\n');
        fprintf('Commands:\n');
        fprintf('  COCAQ_MASTER(''status'')\n');
        fprintf('  COCAQ_MASTER(''preflight'',''msbo'')\n');
        fprintf('  COCAQ_MASTER(''gradientcheck'',''imdb'')\n');
        fprintf('  COCAQ_MASTER(''tune'',''msbo'',''MSBO_2S_10D'')\n');
        fprintf('  COCAQ_MASTER(''evaluate'',''imdb'')\n');
        fprintf('  COCAQ_MASTER(''report'',''msbo'')\n');
        fprintf('  COCAQ_MASTER(''heatmap'',''msbo'')\n');
        fprintf('  COCAQ_MASTER(''overnight'')  %% Only MSBO R2 + IMDb R2\n');
        localPaths(root,archive);
    case 'status'
        localPaths(root,archive);
        localArchiveStatus(archive,'MSBO_R2',960);
        localArchiveStatus(archive,'IMDB_R2',80);
        localArchiveStatus(archive,'MSBO_R1',960);
        fprintf('Archived CSVs DO NOT restore MATLAB .mat checkpoint/frozen files.\n');
        fprintf('To check ACTIVE study checkpoints, run the respective *_RUN(''status'').\n');
    case 'overnight'
        if ~isempty(suite), error('Overnight uses existing MSBO+IMDb runner; no suite argument.'); end
        COCAQ_RUN_OVERNIGHT;
    otherwise
        suites={'msbo','imdb','yb'};
        if ~any(strcmp(suite,suites))
            error('Use suite msbo / imdb / yb. Example: COCAQ_MASTER(''preflight'',''msbo'').');
        end
        switch suite
            case 'msbo'
                if isempty(caseID), MSBO_R2_RUN(action);
                else, MSBO_R2_RUN(action,caseID); end
            case 'imdb'
                assert(isempty(caseID),'IMDb R2 handles one case; omit caseID.');
                IQ_R2_RUN(action);
            case 'yb'
                assert(isempty(caseID),'Yb R2 handles one case; omit caseID.');
                YB_R2_RUN(action);
        end
end
end
function localPaths(root,archive)
checks={...
    'MSBO oracles',fullfile(root,'oracles','MSBO_2S_10D','manifest.json');...
    'IMDb snapshot',fullfile(root,'oracles','imdb_official_4s8d_v1.duckdb');...
    'IMDb manifest',fullfile(root,'oracles','imdb_official_4s8d_v1.duckdb.json');...
    'IMDb bridge',fullfile(root,'python','imdb_query_bridge.py');...
    'Yb bridge',fullfile(root,'python','fiber_eval_batch.py')};
for i=1:size(checks,1)
    state='MISSING';if isfile(checks{i,2}),state='PRESENT';end
    fprintf('%-18s %-7s %s\n',checks{i,1},state,checks{i,2});
end
fprintf('External PyFiberAmp source_bridge.py must be supplied via CASCADE_ACCEPTANCE_ROOT.\n');
end
function localArchiveStatus(archive,family,expected)
file=fullfile(archive,family,'ALL_RUNS.csv');
if ~isfile(file),fprintf('%s: no consolidated ALL_RUNS.csv\n',family);return;end
T=readtable(file,'TextType','string');
fprintf('%s: %d/%d archived runs.\n',family,height(T),expected);
if ismember('Method',T.Properties.VariableNames)
    fprintf('  Methods: %s\n',strjoin(unique(T.Method)',', '));
end
if ismember('Case',T.Properties.VariableNames)
    fprintf('  Cases: %d\n',numel(unique(T.Case)));
end
end

function Y=GP_COOP_FORMAL_truth(s,X)
% A candidate is one COMPLETE x; return ALL deterministic true stage outputs.
% No later input is selected after observing a true intermediate output.
assert(size(X,2)==s.d && all(isfinite(X(:))) && ...
 all(X(:)>=0 & X(:)<=1),'Candidate x must be in [0,1]^D');
switch s.kind
 case 'msbo_grid12'
  Y=MSBO_GRID_truth(s,X);
 case 'forrester'
  % Verbatim formula from R9 truth/cascade_truth.m.
  x1=X(:,1);x2=X(:,2);
  y1=(6*x1-2).^2.*sin(12*x1-4);
  z=.6*y1;v=15*x2;
  y2=(v-5.1*z.^2/(4*pi^2)+5*z/pi-6).^2 ...
     +10*(1-1/(8*pi))*cos(z)+10;
  Y=[y1(:),y2(:)];
 case 'bofn_alpine2'
  assert(s.K==s.d && all(s.stageDims==1), ...
   'Alpine2 requires K=D with exactly one control per stage');
  a=sqrt(10*X).*sin(10*X);
  Y=zeros(size(X,1),s.K);Y(:,1)=-a(:,1);
  for k=2:s.K,Y(:,k)=a(:,k).*Y(:,k-1);end
 case 'horizontal_ackmat'
  % ICML 2024 AckMat: first node Ackley_D, second node NEGATED Matyas.
  % Physical domains: x_1..x_(D-1) in [-2,2], x_D in [-10,10].
  xp=4*X(:,1:end-1)-2;D=size(xp,2);
  r=sqrt(mean(xp.^2,2));c=mean(cos(2*pi*xp),2);
  y1=-20*exp(-.2*r)-exp(c)+20+exp(1);
  z=20*X(:,end)-10;
  y2=-.26*(y1.^2+z.^2)+.48*y1.*z;
  Y=[y1,y2];
 case 'horizontal_ackley_dag'
  % NeurIPS 2021 Ackley DAG: two parallel parents on SAME full X,
  % then known mathematical aggregation in node three.
  xp=4*X-2;
  y1=mean(xp.^2,2);
  y2=mean(cos(2*pi*xp),2);
  y3=20*exp(-.2*sqrt(y1))+exp(y2)-20-exp(1);
  Y=[y1,y2,y3];
 case 'horizontal_rosen'
  % Original negative Rosenbrock sum, each stage accumulates contiguous
  % groups of adjacent pair penalties; stage boundary x is shared.
  xp=4*X-2;Y=zeros(size(X,1),s.K);firstEdge=1;
  for k=1:s.K
   lastEdge=firstEdge+s.edgeCounts(k)-1;
   lhs=xp(:,firstEdge:lastEdge);
   rhs=xp(:,firstEdge+1:lastEdge+1);
   block=sum(100*(rhs-lhs.^2).^2+(1-lhs).^2,2);
   if k==1,Y(:,k)=-block;else,Y(:,k)=Y(:,k-1)-block;end
   firstEdge=lastEdge+1;
  end
 case 'cascadebo_rosenbrock'
  xp=-2+4*X;Y=zeros(size(X,1),s.K);
  for k=1:s.K
   ii=MSBO_stage_idx(s,k);
   if k==1,Z=xp(:,ii);else,Z=[Y(:,k-1),xp(:,ii)];end
   R=sum(100*(Z(:,2:end)-Z(:,1:end-1).^2).^2 + ...
       (Z(:,1:end-1)-1).^2,2);
   raw=-R;rawMin=-3609*(size(Z,2)-1);
   Y(:,k)=((raw-rawMin)/(0-rawMin))*4-2;
  end
 otherwise
  error('Unsupported frozen formula kind: %s',s.kind);
end
assert(isequal(size(Y),[size(X,1),s.K]) && all(isfinite(Y(:))), ...
 'Invalid frozen truth outputs for case %s',s.id);
end

function COCAQ_GP_COOP_SELFTEST()
% No GP fitting required. Checks mixture-policy PPO score / responsibility.
% The actor must be differentiated through the exact mixture density.
root=fileparts(mfilename('fullpath'));addpath(fullfile(root,'engine'),'-begin');
rng(95231,'twister');B=5;p=4;
mu=.2*randn(B,p);z=.4*randn(B,p);sig=1.2*ones(1,p);
eta=.31;eps0=.08;q=.3+3*rand(B,1);
[lp,resp]=GCF_ppo_stable_logpdf(z,mu,sig,eps0,eta,q);
assert(all(isfinite(lp)) && all(resp>=0 & resp<=1));
h=1e-5;E=zeros(B,p);
for k=1:p
 pp=mu;pm=mu;pp(:,k)=pp(:,k)+h;pm(:,k)=pm(:,k)-h;
 f1=GCF_ppo_stable_logpdf(z,pp,sig,eps0,eta,q);
 f0=GCF_ppo_stable_logpdf(z,pm,sig,eps0,eta,q);
 E(:,k)=(f1-f0)/(2*h);
end
A=bsxfun(@times,resp,bsxfun(@rdivide,z-mu,sig.^2));
err=max(abs(A(:)-E(:)));
assert(err<1e-6,'Mixture policy finite-difference mismatch: %g',err);
% Probability mass from two branch weights should stay nonnegative.
assert(eta+eps0<1 && eta>0 && eps0>0);
fprintf('SELFTEST OK: mixture log-density analytic score, max error %.3e\n',err);
fprintf('Full optimizer / GP message integration is checked by smoke in MATLAB.\n');
end

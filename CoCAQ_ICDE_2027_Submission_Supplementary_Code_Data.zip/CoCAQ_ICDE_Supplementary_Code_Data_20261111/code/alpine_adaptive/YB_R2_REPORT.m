function YB_R2_REPORT(mode)
% Independent Yb R2 report. No post-hoc seed selection.
if nargin<1,mode='report';end
root=fileparts(mfilename('fullpath'));addpath(fullfile(root,'engine'),'-begin');
S=YB_R2_config();cases=YB_R2_spec(root);
S.studyID=S.holdoutStudyID;S.seeds=S.holdoutSeeds;S.rounds=S.holdoutRounds;
base=fullfile(root,'results','YB_R2_runs',S.studyID);
if ~exist(base,'dir'),mkdir(base);end
methods=S.methods;seeds=S.seeds;
statusRows=cell(0,6);allRows=cell(0,12);curveRows=cell(0,7);
for ci=1:numel(cases)
 s=cases(ci);complete=0;partial=0;missing=0;
 digest=YB_R2_digest(S);
 for si=1:numel(seeds)
  seed=seeds(si);
  for mi=1:numel(methods)
   meth=methods{mi};
   path=fullfile(base,s.id,sprintf('%s_seed%d_%s.mat',s.id,seed,meth));
   if exist(path,'file')~=2,missing=missing+1;continue;end
   z=load(path,'H','signature');
   assert(isfield(z,'H')&&isfield(z,'signature'),'Invalid checkpoint: %s',path);
   H=z.H;sig=z.signature;
   assert(strcmp(char(sig.phase),'HOLDOUT') && strcmp(char(sig.studyID),S.studyID) && ...
    strcmp(char(sig.caseId),s.id) && strcmp(char(sig.method),meth) && ...
    sig.seed==seed && strcmp(char(sig.oracleDigest),digest), ...
    'Checkpoint oracle/study mismatch: %s',path);
   rounds=numel(H.RMSE)-1;
   assert(rounds<=S.rounds && numel(H.RewardCalls)==rounds && ...
    size(H.X,1)==s.nInitial+rounds && numel(H.Chosen(:,1))==rounds, ...
    'Checkpoint violates budget/shape audit: %s',path);
   if rounds<S.rounds,partial=partial+1;continue;end
   localVerifyFrozen(root,s,meth,sig);
   assert(all(isfinite(H.RMSE))&&all(H.RMSE>=0), ...
    'Invalid RMSE values for %s',path);
   if strcmp(meth,'A5GRAD_V4A')
    assert(sum(H.GradientCalls)>0, ...
     'CoCAQ run completed without any Fast-Gi gradient evaluations: %s',path);
   else
    assert(sum(H.GradientCalls)==0, ...
     'Unexpected gradient calls in baseline method: %s',path);
   end
   if any(strcmp(meth,{'P1','P2'}))
    assert(sum(H.RewardCalls)==0,'Random design counted acquisition calls');
   else
    assert(sum(H.RewardCalls)==rounds*S.nAcq, ...
     'Acquisition budget mismatch in %s',path);
   end
   complete=complete+1;
   aulc=trapz(0:rounds,H.RMSE)/rounds;
   allRows(end+1,:)={string(s.id),s.K,s.d,seed,string(meth), ...
    H.RMSE(end),aulc,sum(H.RewardCalls),sum(H.GradientCalls), ...
    sum(H.AcqBuildSec),sum(H.OptimizeSec),sum(H.FitSec)}; %#ok<AGROW>
   for rr=0:S.rounds
    curveRows(end+1,:)={string(s.id),s.K,s.d,seed, ...
     string(meth),rr,H.RMSE(rr+1)}; %#ok<AGROW>
   end
  end
 end
 statusRows(end+1,:)={string(s.id),s.K,s.d,complete,partial,missing}; %#ok<AGROW>
end
V=cell2table(statusRows,'VariableNames', ...
 {'Case','Stages','Dimensions','Complete','Partial','Missing'});
writetable(V,fullfile(base,'GRID_STATUS.csv'));
if strcmpi(mode,'status')
 disp(V);fprintf('Completed %d / %d runs.\n',sum(V.Complete),80);return;
end
if isempty(allRows)
 fprintf('No complete runs yet: %s\n',base);
 if strcmpi(mode,'plot'),error('Need all 80 complete Yb runs for plotting.');end
 return;
end
A=cell2table(allRows,'VariableNames',{'Case','Stages','Dimensions','Seed', ...
 'Method','FinalRMSE','AULC','RewardCalls','GradientCalls','AcqBuildSec','OptimizeSec','FitSec'});
C=cell2table(curveRows,'VariableNames',{'Case','Stages','Dimensions', ...
 'Seed','Method','Round','RMSE'});
writetable(A,fullfile(base,'ALL_RUNS.csv'));
writetable(C,fullfile(base,'ALL_CURVES.csv'));
agg=cell(1,11);
for ci=1:numel(cases)
 s=cases(ci);B=nan(numel(seeds),numel(methods));
 for si=1:numel(seeds)
  for mi=1:numel(methods)
   ix=find(A.Case==string(s.id)&A.Seed==seeds(si)&A.Method==string(methods{mi}));
   assert(numel(ix)<=1);
   if numel(ix)==1,B(si,mi)=A.FinalRMSE(ix);end
  end
 end
 fullRows=all(isfinite(B),2);npaired=sum(fullRows);
 imp=NaN;gainA5=NaN;strict=NaN;coMean=NaN;baselineMean=NaN;
 baselineName="INCOMPLETE";delta=NaN;
 if npaired==numel(seeds)
  co=B(:,8);baselines=B(:,1:7);
  means=mean(baselines,1);
  [baselineMean,ib]=min(means);baselineName=string(methods{ib});
  coMean=mean(co);
  imp=100*(baselineMean-coMean)/max(baselineMean,realmin);
  gainA5=100*(mean(B(:,7))-coMean)/max(mean(B(:,7)),realmin);
  strict=100*mean(co<min(baselines,[],2));
  delta=mean(baselines(:,ib)-co); % paired seeds, lower RMSE is better
 end
 agg(ci,:)={string(s.id),s.K,s.d,npaired,string(baselineName), ...
  coMean,baselineMean,imp,gainA5,strict,delta};
end
G=cell2table(agg,'VariableNames',{'Case','Stages','Dimensions','PairedSeeds', ...
 'BestBaseline','CoCAQMeanRMSE','BestBaselineMeanRMSE', ...
 'ImprovementVsBestPct','ImprovementVsA5Pct', ...
 'StrictWinRatePct','MeanPairedRMSEGain'});
writetable(G,fullfile(base,'YB_FINAL_SUMMARY.csv'));
fprintf('Wrote Yb ALL_RUNS, ALL_CURVES, YB_FINAL_SUMMARY: %d/%d complete runs.\n',height(A),80);
if strcmpi(mode,'plot')
 assert(height(A)==80 && all(G.PairedSeeds==10) && sum(V.Partial)==0 && sum(V.Missing)==0, ...
  'Yb Fig.7 requires 1 x 8 x 10 completed unselected runs.');
 YB_R2_PLOT();
elseif ~strcmpi(mode,'report')
 error('Unknown reporting mode: %s',mode);
end
end

function localVerifyFrozen(root,s,method,sig)
% A completed holdout is accepted ONLY if it used the locked tuning result.
p=fullfile(root,'results','YB_R2_tuning','FROZEN_METHOD_CONFIGS.mat');
assert(isfile(p),'Missing frozen tuning parameters for R2 holdout.');
z=load(p,'frozen');
assert(isfield(z.frozen.params,s.id),'Missing frozen case %s',s.id);
lock=fullfile(root,'results','YB_R2_tuning','HOLDOUT_LOCKS',[s.id '_LOCK.mat']);
assert(isfile(lock),'Missing holdout lock for %s',s.id);
v=load(lock,'lock');
assert(isequaln(v.lock.frozenParams,z.frozen.params.(s.id)), ...
 'Frozen params modified after holdout began: %s',s.id);
if any(strcmp(method,{'A4','A5','A5GRAD_V4A'}))
 assert(isequaln(sig.methodOverrides,z.frozen.params.(s.id).(method)), ...
  'Holdout hyperparameters did not match frozen tuning for %s/%s',s.id,method);
else
 assert(isempty(fieldnames(sig.methodOverrides)), ...
  'Unexpected tuned overrides on a baseline method.');
end
end

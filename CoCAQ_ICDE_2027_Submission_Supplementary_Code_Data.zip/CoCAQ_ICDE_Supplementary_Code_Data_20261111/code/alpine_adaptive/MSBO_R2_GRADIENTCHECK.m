function MSBO_R2_GRADIENTCHECK()
% Numerical audit: compare analytic d(Fast-Gi)/dx vs central differences.
% Includes nondivisible stage layouts 3S10D, 4S15D.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'engine'),'-begin');
allCases=MSBO_GRID_specs(root);
wanted={'MSBO_3S_10D','MSBO_4S_15D'};
h=1e-5;
for i=1:numel(wanted)
 s=allCases(strcmp({allCases.id},wanted{i}));
 rng(99100+i,'twister');X=GCF_lhs(s.nInitial,s.d);
 Y=MSBO_GRID_truth(s,X);
 model=GCF_fit(s,X,Y,'cascade');
 Xref=GCF_halton(64,s.d,35000+i*100);
 F=GCF_fastgi_build(model,s,Xref,16);
 x=.20+.60*rand(1,s.d);
 [val,~,ga]=GCF_fastgi_eval(F,x);
 fd=zeros(1,s.d);
 for j=1:s.d
  xp=x;xm=x;xp(j)=xp(j)+h;xm(j)=xm(j)-h;
  a=GCF_fastgi_eval(F,xp);b=GCF_fastgi_eval(F,xm);
  fd(j)=(a-b)/(2*h);
 end
 scale=max([norm(ga),norm(fd),1e-7]);
 errorAbs=norm(fd-ga);errorRel=errorAbs/scale;
 fprintf('GRADIENT %s: value %.5g, relative error %.4g, absolute %.4g\n', ...
  s.id,val,errorRel,errorAbs);
 assert(all(isfinite(ga)) && all(isfinite(fd)) && ...
  (errorRel<.08 || errorAbs<1e-4), ...
  'Fast-Gi analytic derivative FAILED finite-difference audit for %s',s.id);
end
% Store a mandatory test-gate for official R2 jobs.
C=MSBO_R2_config();allCases=MSBO_GRID_specs(root);
oracles=struct();
for i=1:numel(wanted)
 s=allCases(strcmp({allCases.id},wanted{i}));
 m=jsondecode(fileread(fullfile(s.folder,'manifest.json')));
 oracles.(s.id)=char(m.digest);
end
audit=struct('protocol',C.protocol,'cases',{wanted}, ...
 'oracles',oracles,'passed',true,'finiteDifferenceStep',h);
auditDir=fullfile(root,'results','R2_audit');
if ~isfolder(auditDir),mkdir(auditDir);end
save(fullfile(auditDir,'FASTGI_GRADIENT_AUDIT_PASS.mat'),'audit','-v7');
fprintf('PASS: analytical Fast-Gi gradient vs finite differences.\n');
end

function YB_R2_PLOT()
% ICDE V4-style Fig7, physical-model surrogate learning. Requires 80/80 runs.
root=fileparts(mfilename('fullpath'));C=YB_R2_config();
base=fullfile(root,'results','YB_R2_runs',C.holdoutStudyID);
csvfile=fullfile(base,'ALL_CURVES.csv');
assert(isfile(csvfile),'Run YB_R2_RUN(''report'') after 80/80 holdout runs.');
T=readtable(csvfile,'TextType','string');
assert(height(T)==8*10*13,'Expected complete 8 x 10 x 13 learning curves');
colors=[.55 .58 .63; .34 .48 .60; .47 .50 .35; .61 .45 .27; ...
 .45 .37 .61; .23 .58 .60; .69 .47 .20; .77 .22 .19];
styles={'--',':','-','--','-.','--',':','-'};
marks={'s','d','^','v','>','<','p','o'};
fig=figure('Color','w','Units','inches','Position',[1 1 7.16 3.8], ...
 'Name','Fig.7 - Yb-fiber simulator (4S8D)','Renderer','painters');
ax=axes(fig,'Units','normalized','Position',[.115 .29 .84 .61]);
hold(ax,'on');h=gobjects(1,8);
for j=1:8
 sub=T(T.Method==string(C.methods{j}),:);
 assert(height(sub)==130,'Missing one or more seeds for %s',C.methods{j});
 X=zeros(10,13);
 for k=1:10
  z=sub(sub.Seed==C.holdoutSeeds(k),:);
  assert(height(z)==13,'Missing round or seed');
  [rr,order]=sort(z.Round);assert(isequal(rr,(0:12)'));
  X(k,:)=z.RMSE(order)';
 end
 mu=mean(X,1);
 h(j)=plot(ax,0:12,mu,'Color',colors(j,:),'LineStyle',styles{j}, ...
  'Marker',marks{j},'MarkerIndices',[1 4 7 10 13], ...
  'MarkerSize',4.5,'MarkerFaceColor','w','LineWidth',1.4);
 if j==8
  set(h(j),'LineWidth',2,'MarkerFaceColor',colors(j,:));
 end
end
xlabel(ax,'Additional complete cascade evaluations');
ylabel(ax,'Held-out RMSE');
set(ax,'TickDir','out','Box','off','FontName','Arial','FontSize',10, ...
 'XTick',0:2:12,'LineWidth',.85,'XLim',[0 12]);
title(ax,'Yb-fiber amplifier (4 stages, 8 controls)','FontSize',11,'FontWeight','normal');
L=legend(ax,h,{'P1','P2','A1','A2','A3','A4','A5','CoCAQ'}, ...
 'Location','southoutside','NumColumns',4,'Box','off','FontSize',9);
L.Position(2)=.065;
out=fullfile(root,'output','YB_R2');if ~isfolder(out),mkdir(out);end
savefig(fig,fullfile(out,'Fig7_YbFiber_R2.fig'));
exportgraphics(fig,fullfile(out,'Fig7_YbFiber_R2.pdf'), ...
 'ContentType','vector','BackgroundColor','white');
exportgraphics(fig,fullfile(out,'Fig7_YbFiber_R2.png'), ...
 'Resolution',600,'BackgroundColor','white');
fprintf('Yb-fiber Fig7 exported to %s\n',out);
end

function MSBO_R2_RUN(mode,caseFilter)
% R2 prospective benchmark, MATLAB only; contains PRE-FROZEN oracle CSV files.
% Modes: selftest/preflight/gradientcheck/smoke/screen/refine/tune/evaluate/
%        all/status/report/heatmap. 'all' requires substantial computation.
if nargin<1 || isempty(mode),mode='preflight';end
if nargin<2,caseFilter='';end
mode=lower(char(mode));
root=fileparts(mfilename('fullpath'));addpath(fullfile(root,'engine'),'-begin');
C=MSBO_R2_config();cases=MSBO_GRID_specs(root);
localValidateProtocol(C,cases);
if ~isempty(caseFilter)
 cases=cases(strcmp({cases.id},char(caseFilter)));
 assert(numel(cases)==1,'Unknown case ID: %s',char(caseFilter));
end
switch mode
 case 'selftest'
  MSBO_R2_GRID('selftest');localGeometryTest(cases);
 case 'preflight'
  localPreflight(cases);
 case 'gradientcheck'
  localPreflight(cases);
  MSBO_R2_GRADIENTCHECK();
 case 'smoke'
  s=cases(1);localPreflight(s);
  [P,~]=MSBO_R2_GRID('screen');
  S=localRunSpec(C,'SMOKE','MSBO_R2_SMOKE_V1',C.screenSeeds(1),2, ...
   C.screenTestBase,{'P2','A5GRAD_V4A'});
  S.nAcq=64;S.nAnchors=16;S.nTest=128;S.nRef=128;S.rank=16;
  S.methodOverrides.A5GRAD_V4A=P{1};
  MSBO_R2_ENGINE(S,s.id);
  fprintf('SMOKE completed for %s, separate from official tuning/holdout.\n',s.id);
 case {'screen','refine','tune'}
  localRequireGradientAudit(root,C);
  localPreflight(cases);
  for i=1:numel(cases)
   MSBO_R2_TUNE(mode,cases(i).id);
  end
 case {'evaluate','all'}
  localRequireGradientAudit(root,C);
  localPreflight(cases);
  for i=1:numel(cases)
   s=cases(i);
   if strcmp(mode,'all'),MSBO_R2_TUNE('tune',s.id);end
   P=localLoadFrozen(C,root,s);
   localHoldoutLock(C,root,s,P);
   S=localRunSpec(C,'HOLDOUT',C.holdoutStudyID,C.holdoutSeeds, ...
    C.holdoutRounds,C.holdoutTestBase,C.methods);
   S.methodOverrides=P;
   fprintf('\n================ HOLDOUT %s: 8 methods x 10 unseen seeds ================\n',s.id);
   MSBO_R2_ENGINE(S,s.id);
   MSBO_R2_REPORT('report');
  end
 case 'status'
  MSBO_R2_REPORT('status');
  localTuneStatus(root,cases,C);
 case 'report'
  MSBO_R2_REPORT('report');
 case 'heatmap'
  MSBO_R2_REPORT('heatmap');
 otherwise
  error('Mode must be selftest/preflight/gradientcheck/smoke/screen/refine/tune/evaluate/all/status/report/heatmap.');
end
end

function localValidateProtocol(C,cases)
assert(numel(cases)==12 && numel(C.methods)==8);
assert(isequal(C.methods,{'P1','P2','A1','A2','A3','A4','A5','A5GRAD_V4A'}));
assert(isequal(C.rlMethods,{'A4','A5','A5GRAD_V4A'}));
a=C.screenSeeds(:);b=C.refineSeeds(:);c=C.holdoutSeeds(:);
assert(numel(a)==4 && numel(b)==4 && numel(c)==10);
assert(isempty(intersect(a,b))&&isempty(intersect(a,c))&&isempty(intersect(b,c)));
previous=[5901:5910 6901:6910 7301:7304 7401:7404 7901:7910];
assert(isempty(intersect([a;b;c],previous(:))),'R2 seeds overlap previously used campaigns.');
assert(C.screenRounds==12&&C.refineRounds==30&&C.holdoutRounds==30);
assert(C.nAcq==300 && C.nAnchors==48);
end

function localGeometryTest(cases)
for s=cases
 dims=floor(s.d/s.K)*ones(1,s.K);
 dims(1:mod(s.d,s.K))=dims(1:mod(s.d,s.K))+1;
 assert(isequal(s.stageDims,dims),'Invalid stage partition');
 for k=1:s.K
  jj=MSBO_stage_idx(s,k);
  assert(numel(jj)==dims(k));
  X=rand(3,s.d);Y=rand(3,s.K);
  Q=GCF_stage_input(s,X,Y,k);
  assert(size(Q,2)==dims(k)+(k>1));
  [Q2,J]=GCF_stage_query(s,X,k,rand(3,1),rand(3,s.d));
  assert(isequal(size(Q2),size(Q)) && size(J,3)==s.d);
 end
end
fprintf('PASS: 12 MSBO stage-dimension layouts.\n');
end

function localPreflight(cases)
for s=cases
 f=fullfile(s.folder,'manifest.json');
 assert(isfile(f),'Missing frozen MSBO truth: %s',f);
 m=jsondecode(fileread(f));
 assert(strcmp(char(m.case),s.id) && m.K==s.K && m.D==s.d && ...
  isequal(double(m.stageDims(:)'),s.stageDims),'Invalid oracle manifest');
 assert(isfield(m,'digest')&&strlength(string(m.digest))==64);
 Y=MSBO_GRID_truth(s,[zeros(1,s.d);ones(1,s.d)]);
 assert(isequal(size(Y),[2,s.K]) && all(isfinite(Y(:))) && ...
  all(Y(:)>0 & Y(:)<1),'Oracle failed for %s',s.id);
 fprintf('READY %s, oracle %s\n',s.id,char(m.digest(1:12)));
end
end

function S=localRunSpec(C,phase,studyID,seeds,rounds,testBase,methods)
S=struct('studyID',studyID,'phase',phase, ...
 'seeds',seeds,'methods',{methods},'rounds',rounds, ...
 'nAcq',C.nAcq,'nAnchors',C.nAnchors,'nTest',C.nTest, ...
 'nRef',C.nRef,'rank',C.rank,'testBase',testBase, ...
 'methodOverrides',struct());
end

function P=localLoadFrozen(C,root,s)
p=fullfile(root,'results','R2_tuning','FROZEN_METHOD_CONFIGS.mat');
assert(isfile(p),'No frozen params. Run MSBO_R2_RUN(''tune'',''%s'') first.',s.id);
z=load(p,'frozen');
assert(isfield(z,'frozen') && isequaln(z.frozen.protocol,C), ...
 'Frozen protocol differs from current R2 configuration.');
assert(isfield(z.frozen.params,s.id),'No frozen params for %s',s.id);
m=jsondecode(fileread(fullfile(s.folder,'manifest.json')));
assert(strcmp(z.frozen.oracles.(s.id),char(m.digest)), ...
 'Oracle mismatch between tuning and holdout.');
P=z.frozen.params.(s.id);
assert(isequal(sort(fieldnames(P)),sort(C.rlMethods(:))), ...
 'Missing A4/A5/CoCAQ independently selected tuning configurations.');
end

function localHoldoutLock(C,root,s,P)
base=fullfile(root,'results','R2_tuning','HOLDOUT_LOCKS');
if ~isfolder(base),mkdir(base);end
m=jsondecode(fileread(fullfile(s.folder,'manifest.json')));
lock=struct('protocol',C,'caseId',s.id,'oracleDigest',char(m.digest), ...
 'frozenParams',P,'testSeeds',C.holdoutSeeds, ...
 'testBase',C.holdoutTestBase,'rounds',C.holdoutRounds);
f=fullfile(base,[s.id '_LOCK.mat']);
if isfile(f)
 a=load(f,'lock');
 assert(isfield(a,'lock')&&isequaln(a.lock,lock), ...
  'HOLDOUT protocol changed: use a new run ID, do not reuse old runs.');
else
 save(f,'lock','-v7');
end
end

function localTuneStatus(root,cases,C)
for s=cases
 base=fullfile(root,'results','R2_tuning',s.id);
 frozen=isfile(fullfile(base,'FROZEN_CASE.mat'));
 scr=0;ref=0;
 for j=1:numel(C.rlMethods)
  method=C.rlMethods{j};
  scr=scr+isfile(fullfile(base,['SCREEN_' method '_SELECTED.mat']));
  ref=ref+isfile(fullfile(base,['REFINE_' method '_SELECTED.mat']));
 end
 fprintf('TUNING %s: screen %d/3, refine %d/3, frozen %d\n',s.id,scr,ref,frozen);
end
end

function localRequireGradientAudit(root,C)
f=fullfile(root,'results','R2_audit','FASTGI_GRADIENT_AUDIT_PASS.mat');
assert(isfile(f),'Gradient finite-difference audit missing. Run MSBO_R2_RUN(''gradientcheck'') before R2 tuning/holdout.');
z=load(f,'audit');
assert(isfield(z,'audit')&&z.audit.passed&&strcmp(z.audit.protocol,C.protocol), ...
 'Gradient audit is invalid for this R2 protocol. Re-run gradientcheck.');
for j=1:numel(z.audit.cases)
 id=char(z.audit.cases{j});
 root2=fullfile(root,'oracles',id);
 m=jsondecode(fileread(fullfile(root2,'manifest.json')));
 assert(strcmp(z.audit.oracles.(id),char(m.digest)), ...
  'Oracle changed since Fast-Gi audit.');
end
end

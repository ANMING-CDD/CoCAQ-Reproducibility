"""Batch adapter around the project's existing source_bridge.eval_fiber function."""
import argparse
import importlib.util
from pathlib import Path
import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--bridge', required=True)
    ap.add_argument('--input', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()
    bridge_path = Path(args.bridge).resolve()
    spec = importlib.util.spec_from_file_location('cascade_source_bridge', bridge_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Cannot load source bridge: {bridge_path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    X = np.atleast_2d(np.loadtxt(args.input, delimiter=','))
    if X.shape[1] != 8:
        raise ValueError(f'Expected N x 8 input, got {X.shape}')
    Y = np.asarray([module.eval_fiber(row) for row in X], dtype=float)
    if Y.shape != (X.shape[0], 4) or not np.isfinite(Y).all():
        raise RuntimeError(f'Invalid fiber result shape/values: {Y.shape}')
    np.savetxt(args.output, Y, delimiter=',', fmt='%.17g')
    print(f'OK: {X.shape[0]} complete four-stage fiber queries')


if __name__ == '__main__':
    main()

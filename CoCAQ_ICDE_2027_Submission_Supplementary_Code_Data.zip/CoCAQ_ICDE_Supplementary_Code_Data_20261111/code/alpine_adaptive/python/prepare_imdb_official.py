#!/usr/bin/env python3
"""Prepare a reproducible IMDb-official 4S8D DuckDB oracle.

Input: title.basics.tsv.gz and title.ratings.tsv.gz downloaded from
       https://datasets.imdbws.com/ (one may also use uncompressed .tsv files).
Output: immutable .duckdb snapshot + JSON provenance for imdb_query_bridge.py.
This is a newly designed SQL workload, NOT a GRACEFUL benchmark or UDF model.
"""
import argparse
import csv
import gzip
import hashlib
import heapq
import json
import math
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
VERSION = 'imdb-official-4stage-sql-v1'

def open_tsv(path):
    return gzip.open(path, 'rt', encoding='utf-8', newline='', errors='replace') if str(path).lower().endswith('.gz') else open(path,'r',encoding='utf-8',newline='',errors='replace')

def stable_key(tconst):
    return int.from_bytes(hashlib.blake2b(tconst.encode('ascii'),digest_size=8).digest(),'big')

def locate(folder, stem):
    for name in (stem+'.tsv.gz',stem+'.tsv'):
        p=folder/name
        if p.is_file(): return p
    raise FileNotFoundError(f'Missing {stem}.tsv.gz in {folder}; download from https://datasets.imdbws.com/{stem}.tsv.gz')

def read_candidates(basics, pool):
    h=[];scanned=0;eligible=0
    with open_tsv(basics) as fh:
        reader=csv.DictReader(fh,delimiter='\t')
        for col in ('tconst','titleType','startYear','runtimeMinutes'):
            if col not in (reader.fieldnames or []): raise ValueError(f'{basics} missing IMDb column {col}')
        for rec in reader:
            scanned += 1
            if rec['titleType']!='movie': continue
            try:
                year=int(rec['startYear']); runtime=int(rec['runtimeMinutes'])
            except (ValueError,TypeError): continue
            if not (1970 <= year <= 2026 and 40<=runtime<=300): continue
            tid=rec['tconst']; eligible+=1
            key=stable_key(tid); item=(-key,tid,year,runtime)
            if len(h)<pool: heapq.heappush(h,item)
            elif key < -h[0][0]: heapq.heapreplace(h,item)
    if not h: raise RuntimeError('No qualifying IMDb movie rows with year and runtime. Check title.basics.')
    return {tid:(-nkey,year,runtime) for nkey,tid,year,runtime in h},scanned,eligible

def join_ratings(ratings,chosen):
    got=[];scanned=0
    with open_tsv(ratings) as fh:
        reader=csv.DictReader(fh,delimiter='\t')
        for col in ('tconst','averageRating','numVotes'):
            if col not in (reader.fieldnames or []): raise ValueError(f'{ratings} missing IMDb column {col}')
        for rec in reader:
            scanned+=1
            t=rec['tconst']
            if t not in chosen: continue
            try:
                r=float(rec['averageRating']); n=int(rec['numVotes'])
            except (ValueError,TypeError): continue
            if not (math.isfinite(r) and 0<r<=10 and n>0): continue
            key,year,runtime=chosen[t]
            got.append((key,t,year,runtime,r,n))
    got.sort(key=lambda r:(r[0],r[1]))
    return got,scanned

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def run(args):
    folder=Path(args.folder).expanduser().resolve()
    basics=locate(folder,'title.basics')
    ratings=locate(folder,'title.ratings')
    target=Path(args.target).expanduser().resolve()
    bridge=HERE/'imdb_query_bridge.py'
    if not bridge.is_file(): raise FileNotFoundError('Missing sibling imdb_query_bridge.py; keep the package together.')
    if target.exists() or Path(str(target)+'.json').exists():
        raise FileExistsError(f'Frozen oracle already exists and will not be overwritten: {target}')
    print('Reading IMDb basics:',basics, flush=True)
    chosen,scanb,qual=read_candidates(basics,max(args.rows*12,60000))
    print(f'  scanned={scanb:,}, eligible={qual:,}, candidate_pool={len(chosen):,}',flush=True)
    print('Joining IMDb ratings:',ratings,flush=True)
    joined,scanr=join_ratings(ratings,chosen)
    print(f'  scanned={scanr:,}, valid_joined_movies={len(joined):,}',flush=True)
    if len(joined)<100: raise RuntimeError('Fewer than 100 joined movies; cannot create stable oracle.')
    selected=joined[:args.rows]
    if len(selected)<args.rows: print(f'WARNING: requested {args.rows} but only {len(selected)} joined movies available.')
    ys=[v[2] for v in selected]; rs=[v[4] for v in selected]
    ymin,ymax=min(ys),max(ys);rmin,rmax=min(rs),max(rs)
    if ymin==ymax or rmin==rmax: raise RuntimeError('Need varying movie release year and rating; choose more rows.')
    aa=[(float(y)-ymin)/(ymax-ymin) for y in ys]
    bb=[(float(r)-rmin)/(rmax-rmin) for r in rs]
    if args.dry_run:
        print(f'DRY RUN PASS: rows={len(selected)} years={ymin}..{ymax} ratings={rmin}..{rmax}')
        return
    try:
        import duckdb
    except ImportError as ex:
        raise RuntimeError('DuckDB missing. Run: python -m pip install duckdb') from ex
    target.parent.mkdir(parents=True,exist_ok=True)
    try:
        con=duckdb.connect(str(target))
        con.execute('CREATE TABLE src (a DOUBLE, b DOUBLE)')
        con.executemany('INSERT INTO src VALUES (?, ?)',list(zip(aa,bb)))
        con.execute('CREATE TABLE imdb_provenance (tconst VARCHAR, startYear INTEGER, runtimeMinutes INTEGER, averageRating DOUBLE, numVotes BIGINT)')
        con.executemany('INSERT INTO imdb_provenance VALUES (?, ?, ?, ?, ?)',[(t,y,rt,r,n) for _,t,y,rt,r,n in selected])
        assert con.execute('SELECT count(*) FROM src').fetchone()[0]==len(selected)
        con.close()
        manifest={
            'version':VERSION,
            'origin':'IMDb official non-commercial datasets, not the GRACEFUL official archive',
            'sourceDB':str(folder),
            'sourceDBSizeBytes':basics.stat().st_size+ratings.stat().st_size,
            'sourceTable':'title.basics INNER JOIN title.ratings USING(tconst) (author-built)',
            'columnA':'startYear', 'columnB':'averageRating',
            'rows':len(selected),
            'columnALimits':[ymin,ymax], 'columnBLimits':[rmin,rmax],
            'selection':'Movie records with valid year/runtime, deterministic BLAKE2b ID-based sampling; rating join; frozen sample',
            'dataFiles':[{'path':str(p),'bytes':p.stat().st_size} for p in (basics,ratings)],
            'snapshotSha256':sha256(target),
            'bridgeScriptSha256':sha256(bridge),
            'description':'Author-constructed four-stage scalar SQL cascade over a fixed snapshot of official IMDb records; not original GRACEFUL UDF workload'
        }
        with open(str(target)+'.json','w',encoding='utf-8') as fh:json.dump(manifest,fh,indent=2,ensure_ascii=False)
        print('SUCCESS - IMDb SQL oracle:',target)
        print('Rows:',len(selected),'years:',ymin,ymax,'ratings:',rmin,rmax)
        print('Snapshot hash:',manifest['snapshotSha256'])
        print("Next set IMDB_ORACLE_FILE and run IQ_R2_RUN('preflight') in MATLAB.")
    except BaseException:
        try:
            if target.exists(): target.unlink()
        except OSError: pass
        raise

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--folder',required=True,help='Folder containing both title.basics.tsv.gz and title.ratings.tsv.gz')
    p.add_argument('--target',required=True,help='New output .duckdb filename (will not overwrite)')
    p.add_argument('--rows',type=int,default=8000)
    p.add_argument('--dry-run',action='store_true')
    args=p.parse_args()
    if not 100<=args.rows<=100000: p.error('--rows must be between 100 and 100000')
    run(args)

if __name__=='__main__':
    try:main()
    except Exception as ex:
        print('ERROR:',type(ex).__name__+':',ex,file=sys.stderr)
        sys.exit(1)

#!/usr/bin/env python3
"""Reproducible four-stage DuckDB SQL oracle on IMDb official published movie data.

IMPORTANT: This is an author-designed workload derived from real official IMDb data,
NOT GRACEFUL's original SQL/UDF learned-cost workload.
One 'evaluate' call returns y1,...,y4 for every complete 8D control input.
Requires only Python 3.x + `pip install duckdb` (no GRACEFUL ML environment).
"""
import argparse, csv, hashlib, json, os, pathlib, sys

VERSION = 'imdb-official-4stage-sql-v1'

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def q(s):
    return '"' + s.replace('"', '""') + '"'

def connect(path, readonly=True):
    import duckdb
    return duckdb.connect(str(path), read_only=readonly)

def probe(path):
    con = connect(path)
    rows = con.execute("""SELECT table_schema,table_name,column_name,data_type
        FROM information_schema.columns
        WHERE data_type IN ('TINYINT','SMALLINT','INTEGER','BIGINT','UTINYINT',
        'USMALLINT','UINTEGER','UBIGINT','FLOAT','DOUBLE','DECIMAL','HUGEINT')
        ORDER BY table_schema,table_name,ordinal_position""").fetchall()
    con.close()
    if not rows:
        raise RuntimeError('No numeric columns found. Select another IMDb DuckDB dataset.')
    print('Numeric columns (schema / table / column / type):')
    for row in rows[:150]: print(' / '.join(map(str, row)))
    if len(rows)>150: print(f'... and {len(rows)-150} more columns')

def prepare(source, target, schema, table, col_a, col_b, max_rows):
    import duckdb
    source = pathlib.Path(source).resolve(); target = pathlib.Path(target).resolve()
    if not source.is_file(): raise FileNotFoundError(source)
    if source == target: raise ValueError('Target snapshot must differ from source database.')
    if target.exists() or pathlib.Path(str(target)+'.json').exists():
        raise FileExistsError(f'Output exists. Never overwrite a frozen oracle: {target}')
    if max_rows < 100: raise ValueError('Require >=100 actual database rows.')
    c = connect(source)
    cols = c.execute("""SELECT column_name, data_type FROM information_schema.columns
        WHERE table_schema=? AND table_name=?""", [schema, table]).fetchall()
    types = dict(cols)
    numeric = ('INT','FLOAT','DOUBLE','DECIMAL','HUGEINT')
    for col in (col_a,col_b):
        if col not in types or not any(k in types[col].upper() for k in numeric):
            raise ValueError(f'Expected numeric column {col} in {schema}.{table}; run probe.')
    # Explicit sort ensures exact deterministic source row selection and snapshot.
    raw = f"""SELECT CAST({q(col_a)} AS DOUBLE) AS a, CAST({q(col_b)} AS DOUBLE) AS b
       FROM {q(schema)}.{q(table)}
       WHERE {q(col_a)} IS NOT NULL AND {q(col_b)} IS NOT NULL
       ORDER BY 1,2 LIMIT {int(max_rows)}"""
    rows = c.execute(raw).fetchall(); c.close()
    rows = [(a,b) for a,b in rows if a is not None and b is not None and
            -1e300 < a < 1e300 and -1e300 < b < 1e300]
    if len(rows)<100: raise ValueError('Fewer than 100 valid numeric rows.')
    lo_a=min(t[0] for t in rows); hi_a=max(t[0] for t in rows)
    lo_b=min(t[1] for t in rows); hi_b=max(t[1] for t in rows)
    if not hi_a>lo_a or not hi_b>lo_b:
        raise ValueError('Both numeric columns must vary. Choose different columns.')
    target.parent.mkdir(parents=True,exist_ok=True)
    try:
        con=connect(target, readonly=False)
        con.execute('CREATE TABLE src (a DOUBLE, b DOUBLE)')
        con.executemany('INSERT INTO src VALUES (?,?)', [
            ((a-lo_a)/(hi_a-lo_a),(b-lo_b)/(hi_b-lo_b)) for a,b in rows])
        n=con.execute('SELECT COUNT(*) FROM src').fetchone()[0]
        con.close()
        assert n==len(rows)
        meta={'version': VERSION,'sourceDB':str(source),'sourceDBSizeBytes':source.stat().st_size,
              'sourceTable':f'{schema}.{table}','columnA':col_a,'columnB':col_b,
              'rows':n,'columnALimits':[lo_a,hi_a],'columnBLimits':[lo_b,hi_b],
              'snapshotSha256':sha256(target),'bridgeScriptSha256':sha256(__file__),
              'description':'Author-constructed scalar SQL cascade on IMDb official movie records; not the original IMDb cost workload'}
        with open(str(target)+'.json','w',encoding='utf8') as f: json.dump(meta,f,indent=2)
    except Exception:
        if target.exists(): target.unlink()
        raise
    print('PREPARED:',target)
    print('Rows:',n,'source table:',meta['sourceTable'])
    print('Snapshot SHA256:',meta['snapshotSha256'])

def info(oracle):
    p=pathlib.Path(str(oracle)+'.json')
    if not oracle.is_file() or not p.is_file(): raise FileNotFoundError('Snapshot or .json manifest missing')
    with open(p,encoding='utf8') as f: m=json.load(f)
    if m['version'] != VERSION: raise ValueError('Oracle version changed. Recreate a new oracle ID.')
    if sha256(oracle)!=m['snapshotSha256']: raise ValueError('Oracle has been changed since preparation!')
    if sha256(__file__)!=m['bridgeScriptSha256']: raise ValueError('Query bridge has changed since preparation!')
    con=connect(oracle)
    n=con.execute('SELECT COUNT(*) FROM src').fetchone()[0]
    con.close()
    if n!=m['rows']: raise ValueError('Invalid snapshot row count')
    print(f'IMDB_ORACLE_READY rows={n} source={m["sourceTable"]} sha256={m["snapshotSha256"][:12]}')

def sigmoid_sql(expr):
    return f'(1.0 / (1.0 + EXP(-({expr}))))'

def evaluate(oracle, inputs, output, batch_size=64):
    with open(inputs,newline='',encoding='utf8') as f:
        X=[[float(v) for v in r] for r in csv.reader(f) if r]
    if not X: raise ValueError('No input rows.')
    if any(len(row)!=8 or any((v<0 or v>1 or not float('-inf')<v<float('inf')) for v in row) for row in X):
        raise ValueError('Each row must be 8 normalized finite controls in [0,1].')
    con=connect(oracle)
    con.execute('PRAGMA threads=2')
    # This computes the four actual SQL aggregates over the real-data snapshot;
    # each query k explicitly uses scalar output of query k-1.
    y1=sigmoid_sql('(s.a - (0.10 + 0.80 * i.x1)) / (0.03 + 0.17 * i.x2)')
    y2=sigmoid_sql('(s.b - (0.15 + 0.70 * i.x3 + 0.22 * (p.y - 0.5))) / (0.03 + 0.15 * i.x4)')
    y3=sigmoid_sql('(s.a - (0.10 + 0.75 * i.x5 + 0.20 * (p.y - 0.5))) / (0.03 + 0.16 * i.x6)')
    y4=sigmoid_sql('(s.b - (0.10 + 0.70 * i.x7 + 0.22 * (p.y - 0.5))) / (0.025 + 0.14 * i.x8)')
    expressions=[y1, y2, f'{y3} * (0.35 + 0.65 * s.b)', f'{y4} * (0.35 + 0.65 * s.a)']
    Y=[]
    for lo in range(0,len(X),batch_size):
        batch=X[lo:lo+batch_size]
        con.execute('CREATE TEMP TABLE input (id INTEGER, x1 DOUBLE, x2 DOUBLE, x3 DOUBLE, x4 DOUBLE, x5 DOUBLE, x6 DOUBLE, x7 DOUBLE, x8 DOUBLE)')
        con.executemany('INSERT INTO input VALUES (?,?,?,?,?,?,?,?,?)',[(i,*v) for i,v in enumerate(batch)])
        for k,expr in enumerate(expressions,1):
            from_clause='input i CROSS JOIN src s' if k==1 else f'input i JOIN y{k-1} p ON p.id=i.id CROSS JOIN src s'
            con.execute(f'CREATE TEMP TABLE y{k} AS SELECT i.id, AVG({expr}) AS y FROM {from_clause} GROUP BY i.id')
        ans=con.execute('SELECT y1.y,y2.y,y3.y,y4.y FROM y1 JOIN y2 USING(id) JOIN y3 USING(id) JOIN y4 USING(id) ORDER BY y1.id').fetchall()
        if len(ans)!=len(batch) or any(any(v is None or not (-1e10 < v < 1e10) for v in row) for row in ans):
            raise RuntimeError('Nonfinite or missing SQL stage outputs')
        Y.extend(ans)
        for k in range(1,5): con.execute(f'DROP TABLE y{k}')
        con.execute('DROP TABLE input')
    con.close()
    if any(any(v < -1e-8 or v >1.00000001 for v in r) for r in Y):
        raise RuntimeError('Unexpected stage output outside [0,1].')
    with open(output,'w',newline='',encoding='utf8') as f:
        writer=csv.writer(f);writer.writerows([[format(v,'.17g') for v in row] for row in Y])
    print(f'EVALUATED {len(Y)} complete 4-stage SQL chains')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='cmd',required=True)
    pp=sub.add_parser('probe');pp.add_argument('--source',required=True)
    p=sub.add_parser('prepare');p.add_argument('--source',required=True);p.add_argument('--target',required=True)
    p.add_argument('--schema',default='main');p.add_argument('--table',required=True)
    p.add_argument('--col-a',required=True);p.add_argument('--col-b',required=True,type=str)
    p.add_argument('--max-rows',type=int,default=20000)
    p=sub.add_parser('info');p.add_argument('--oracle',required=True)
    p=sub.add_parser('evaluate');p.add_argument('--oracle',required=True);p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    args=parser.parse_args()
    if args.cmd=='probe': probe(pathlib.Path(args.source))
    elif args.cmd=='prepare': prepare(args.source,args.target,args.schema,args.table,args.col_a,args.col_b,args.max_rows)
    elif args.cmd=='info': info(pathlib.Path(args.oracle))
    else: evaluate(pathlib.Path(args.oracle),args.input,args.output)

if __name__=='__main__':
    try: main()
    except Exception as ex:
        print(f'ERROR: {type(ex).__name__}: {ex}',file=sys.stderr)
        sys.exit(1)

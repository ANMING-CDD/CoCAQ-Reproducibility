function GP_COOP_FORMAL_ENGINE(S,caseId)
% Frozen benchmark suite: A2, IPPO, MAPPO, GP-conditional MAPPO, original V4A.
% IPPO/MAPPO/GP-MAPPO share an architecture and independently tune PPO.
% CMA/IPPO/V4A use default fixed params; A4/A5 tuned on separate training seeds.
% Checkpoints: results/GP_COOP_runs/<studyID>/<caseID>.
assert(isstruct(S) && isfield(S,'studyID') && isfield(S,'phase'));
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'engine'),'-begin');
if strncmp(char(caseId),'H_',2)
 cases=GP_COOP_HORIZONTAL_specs(root);
else
 cases=GP_COOP_FORMAL_specs(root);
end
ix=find(strcmp({cases.id},char(caseId)));
assert(isscalar(ix),'Unknown GP-coop case ID: %s',char(caseId));
s=cases(ix);
assert(numel(unique(S.seeds))==numel(S.seeds) && S.rounds>0);
assert(all(ismember(S.methods,{'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_REFERENCE'})), ...
 'Unsupported GP-coop method.');
if strcmp(s.kind,'msbo_grid12')
 assert(isfile(fullfile(s.folder,'manifest.json')),'Missing frozen MSBO oracle');
end
localRunCase(s,S,root);
end

function localRunCase(s,S,root)
% Preserve deterministic initial design and shared held-out set per CASE.
if strncmp(s.id,'H_',2)
 registry=GP_COOP_HORIZONTAL_specs(root);
 index=100+find(strcmp({registry.id},s.id));
else
 registry=GP_COOP_FORMAL_specs(root);
 index=find(strcmp({registry.id},s.id));
end
assert(isscalar(index));
mdir=fullfile(root,'results','GP_COOP_FORMAL_runs',S.studyID,s.id);
if ~exist(mdir,'dir'),mkdir(mdir);end
if strcmp(s.kind,'msbo_grid12')
 orac=jsondecode(fileread(fullfile(s.folder,'manifest.json')));
 oracleDigest=char(orac.digest);
else
 oracleDigest=['FORMULA_V1_' s.id];
end
Xtest=GCF_halton(S.nTest,s.d,S.testBase+1000*index);
Ytest=GP_COOP_FORMAL_truth(s,Xtest);ytest=Ytest(:,end);
for seed=S.seeds
 rng(1701000+1000*index+seed,'twister');X0=GCF_lhs(s.nInitial,s.d);
 Y0=GP_COOP_FORMAL_truth(s,X0);
 % No LHS method in this focused optimizer comparison.
 for mi=1:numel(S.methods)
  method=S.methods{mi};
  file=fullfile(mdir,sprintf('%s_seed%d_%s.mat',s.id,seed,method));
  prm=struct();
  if isfield(S,'methodOverrides') && isfield(S.methodOverrides,method)
   prm=S.methodOverrides.(method);
  end
  signature=struct('engine','GP_COOP_FORMAL_30R10S_V1_20261106', ...
   'phase',S.phase,'lockFingerprint',S.lockFingerprint,'studyID',S.studyID,'caseId',s.id,'K',s.K,'D',s.d, ...
   'stageDims',s.stageDims,'oracleDigest',oracleDigest, ...
   'seed',seed,'method',method,'methodOverrides',prm, ...
   'nInitial',s.nInitial,'rounds',S.rounds,'nAcq',S.nAcq, ...
   'nAnchors',S.nAnchors,'nTest',S.nTest,'nRef',S.nRef, ...
   'rank',S.rank,'testBase',S.testBase,'mappo',localMAPPO(S));
  if exist(file,'file')==2
   z=load(file,'H','signature');
   assert(isfield(z,'H')&&isfield(z,'signature')&&isequaln(z.signature,signature), ...
    'Unsafe resume: signature mismatch in %s. Keep old checkpoint, use new studyID.',file);
   H=z.H;
   assert(isequaln(H.X(1:s.nInitial,:),X0) && ...
    isequaln(H.Y(1:s.nInitial,:),Y0),'Initial paired design changed.');
  else
   kind='cascade';
   tf=tic;model=GCF_fit(s,X0,Y0,kind);fitSec=toc(tf);
   pred=GCF_predict_final(s,model,Xtest);
   H=struct('Case',s.id,'Stages',s.K,'Dim',s.d,'StageDims',s.stageDims, ...
    'Seed',seed,'Method',method,'X',X0,'Y',Y0,'model',model, ...
    'RMSE',sqrt(mean((pred-ytest).^2)), ...
    'RewardCalls',zeros(0,1),'GradientCalls',zeros(0,1),'PPOStats',{cell(0,1)}, ...
    'AcqBuildSec',zeros(0,1),'OptimizeSec',zeros(0,1), ...
    'FitSec',fitSec,'TruthSec',zeros(0,1),'Chosen',zeros(0,s.d));
   localCheckpoint(file,H,signature);
  end
  done=numel(H.RMSE)-1;
  fprintf('%s seed=%d method=%s, resume round %d/%d\n',s.id,seed,method,done,S.rounds);
  for rr=done+1:S.rounds
   o=struct();
   searchSeed=5800000+100000*index+10000*seed+50*rr;
   [o,mt]=localSearch(s,method,H.model,S,prm,searchSeed);
   x=o.bestX;
   assert(mt.RewardCalls==S.nAcq,'Acquisition budget mismatch.');
   assert(all(isfinite(x))&&all(x>=0 & x<=1));
   tt=tic;y=GP_COOP_FORMAL_truth(s,x);truthSec=toc(tt);
   H.X=[H.X;x];H.Y=[H.Y;y];H.Chosen=[H.Chosen;x];
   kind='cascade';
   tf=tic;model=GCF_fit(s,H.X,H.Y,kind,H.model);fitSec=toc(tf);
   pred=GCF_predict_final(s,model,Xtest);
   H.model=model;H.RMSE(end+1,1)=sqrt(mean((pred-ytest).^2));
   H.RewardCalls(end+1,1)=mt.RewardCalls;
   H.GradientCalls(end+1,1)=mt.GradientCalls;
   H.AcqBuildSec(end+1,1)=mt.AcquisitionBuildSeconds;
   H.OptimizeSec(end+1,1)=mt.OptimizationSeconds;
   H.FitSec(end+1,1)=fitSec;H.TruthSec(end+1,1)=truthSec;
   if isfield(o,'stats')
    H.PPOStats{end+1,1}=o.stats;
   else
    H.PPOStats{end+1,1}=struct(); % CMA-ES does not expose PPO stats.
   end
   localCheckpoint(file,H,signature);
   fprintf('  %d/%d  held-out RMSE=%.6g\n',rr,S.rounds,H.RMSE(end));
  end
 end
end
end

function c=localMAPPO(S)
c=GCF_config('full');c=c.mappo;
c.hidden=64;c.batch=32;c.nEpoch=14;c.nHiddenLayers=2;
c.minEpochsV5=14;c.minHiddenV5=64;
c.v4FreshFraction=.50;c.v4DiversityWeight=.20;
c.v4DistanceScale=.30;c.v4CurrentBonus=.05;
c.v4FeedbackCap=16;c.v4FeedbackMinDist=.08;
c.v4MinGainFrac=1e-7;c.v4GainPriority=.55;
c.v4FeedbackLogWeight=.75;
c.nAnchors=S.nAnchors;
% The original 14 PPO epochs are a maximum, not mandatory.
% PPO stability applies to IPPO/MAPPO/GP-MAPPO; original V4A unchanged.
c.ppoTargetKL=0.03;
c.ppoMinEpoch=2;
c.ppoActorGradMaxNorm=1.0;
c.ppoCriticGradMaxNorm=3.0;
c.ppoSigmaGradMaxNorm=1.0;
c.ppoExploreEntropyCoeff=0.005;
c.ppoExploreMinSigma=0.60;
c.ppoEntropyCoeff=0; % matched default; tuning overrides independently
end

function [out,meta]=localSearch(spec,method,model,S,override,seed)
Xref=GCF_halton(S.nRef,spec.d,20000+seed);
tb=tic;
if strcmp(method,'V4A_REFERENCE')
 F=GCF_fastgi_build(model,spec,Xref,S.rank);
 evalFn=@(X)GCF_fastgi_eval(F,X);
 gradFn=@(X)localFastGiGradient(F,X);
else
 F=GCF_chain_build(model,spec,Xref);
 evalFn=@(X)GCF_chain_eval(F,X);
 gradFn=[];
end
buildSec=toc(tb);tt=tic;
c=localMAPPO(S);
fn=fieldnames(override);
for j=1:numel(fn),c.(fn{j})=override.(fn{j});end
if any(strcmp(method,{'A3_IPPO','A4_MAPPO','A5_GP_MAPPO'}))
 [out,meta]=GCF_gpcoop_ppo(evalFn,model,spec,S.nAcq,c,method,seed);
elseif strcmp(method,'V4A_REFERENCE')
 [out,meta]=GCF_mappo_v4(evalFn,gradFn,model,spec,S.nAcq,c, ...
  'A5GRAD_V4A',seed);
elseif strcmp(method,'A2')
 [out,meta]=GCF_cmaes(evalFn,[],S.nAcq,spec.d,c,seed);
else
 error('Unsupported GP-COOP method: %s',method);
end
meta.AcquisitionBuildSeconds=buildSec;meta.OptimizationSeconds=toc(tt);
assert(isfield(meta,'RewardCalls') && meta.RewardCalls==S.nAcq);
if ~isfield(meta,'GradientCalls'),meta.GradientCalls=0;end
end

function gg=localFastGiGradient(F,X)
[~,~,gg]=GCF_fastgi_eval(F,X);
end

function localCheckpoint(file,H,signature)
tmp=[file '.tmp.mat'];save(tmp,'H','signature','-v7.3');
[ok,msg]=movefile(tmp,file,'f');
assert(ok,'Checkpoint move failed: %s',msg);
end

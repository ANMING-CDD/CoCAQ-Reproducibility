function Y=YB_R2_truth(spec,X,forceFresh)
% Exact legacy V9 batch interface. NO synthetic truth substitute.
% Each row: ONE complete four-stage PyFiberAmp simulator call.
% In-process memoisation avoids repeating identical held-out/initial points.
% Force fresh when checking physical determinism in the preflight.
if nargin<3,forceFresh=false;end
assert(strcmp(spec.id,'YB_FIBER_4S8D') && spec.K==4 && spec.d==8);
assert(size(X,2)==8 && all(isfinite(X(:))) && ...
 all(X(:)>=0 & X(:)<=1),'Fiber truth X must be N-by-8 in [0,1]');
C=YB_R2_config();[bridge,batch,py]=YB_R2_paths(C);
digest=YB_R2_digest(C);
persistent memo lastDigest
if isempty(memo) || ~strcmp(lastDigest,digest)
 memo=containers.Map('KeyType','char','ValueType','any');
 lastDigest=digest;
end
N=size(X,1);Y=nan(N,4);keys=cell(N,1);need=false(N,1);
for i=1:N
 keys{i}=sprintf('%.17g,',X(i,:));
 if ~forceFresh && isKey(memo,keys{i})
  Y(i,:)=memo(keys{i});
 else
  need(i)=true;
 end
end
idx=find(need);
if ~isempty(idx)
 infile=[tempname '.csv'];outfile=[tempname '.csv'];
 cleanup=onCleanup(@()localCleanup({infile,outfile})); %#ok<NASGU>
 % Original V9 GCF_fiber_truth mapping from normalized controls.
 Xphys=0.08+0.84*X(idx,:);
 writematrix(Xphys,infile,'Delimiter',',');
 cmd=sprintf('"%s" "%s" --bridge "%s" --input "%s" --output "%s"', ...
  py,batch,bridge,infile,outfile);
 [code,log]=system(cmd);
 assert(code==0,'Physical PyFiberAmp bridge FAILED: %s',log);
 assert(isfile(outfile),'Physical bridge returned no output CSV');
 Ymiss=readmatrix(outfile);
 assert(isequal(size(Ymiss),[numel(idx) 4]) && all(isfinite(Ymiss(:))), ...
  'Fiber oracle must return N-by-4 finite stage outputs');
 Y(idx,:)=Ymiss;
 if ~forceFresh
  for j=1:numel(idx),memo(keys{idx(j)})=Ymiss(j,:);end
 end
end
assert(isequal(size(Y),[N 4]) && all(isfinite(Y(:))));
end
function localCleanup(paths)
for i=1:numel(paths)
 if isfile(paths{i}),delete(paths{i});end
end
end

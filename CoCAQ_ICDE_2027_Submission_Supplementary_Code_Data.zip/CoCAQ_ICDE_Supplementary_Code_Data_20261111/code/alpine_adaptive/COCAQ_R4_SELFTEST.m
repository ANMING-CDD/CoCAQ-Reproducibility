function COCAQ_R4_SELFTEST()
% Synthetic internal consistency tests on one frozen MSBO case.
% This does not report scientific performance on hold-out test seeds.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'engine'),'-begin');
S=MSBO_GRID_specs(root);ix=find(strcmp({S.id},'MSBO_3S_15D'));
s=S(ix);
rng(77662,'twister');X=GCF_lhs(s.nInitial,s.d);
Y=MSBO_GRID_truth(s,X);mdl=GCF_fit(s,X,Y,'cascade');
ref=GCF_halton(48,s.d,70177);
F=GCF_r4_build(mdl,s,ref,12,2,123);
testX=GCF_halton(2,s.d,77277);
[R,G,g]=GCF_r4_proxy_eval(F,testX);
assert(all(isfinite(R)) && all(R>=0) && all(isfinite(g(:))));
assert(max(abs(R-sum(G,2)))<1e-8);
[look,~]=GCF_r4_terminal_eval(F,testX);
assert(all(isfinite(look)) && all(look>=0));
M=GCF_r4_messages(F,testX,true);
M0=GCF_r4_messages(F,testX,false);
assert(any(M.backSensitivity(:)~=M0.backSensitivity(:)) || ...
 any(M.terminalImportance(:)~=M0.terminalImportance(:)), ...
 'Bidirectional GP message did not change the actor state.');
for k=1:s.K
 z=GCF_r4_state(M,zeros(2,s.d),k);
 assert(all(size(z)==[2,2*s.d+6*s.K+2]) && all(isfinite(z(:))));
end
coords=[1,round(s.d/2),s.d];h=1e-5;err=zeros(1,numel(coords));
for i=1:numel(coords)
 xx=testX(1,:);xm=xx;xp=xx;xp(coords(i))=min(.99999,xx(coords(i))+h);
 xm(coords(i))=max(.00001,xx(coords(i))-h);
 fp=GCF_r4_proxy_eval(F,xp);fm=GCF_r4_proxy_eval(F,xm);
 fd=(fp-fm)/(xp(coords(i))-xm(coords(i)));
 err(i)=abs(fd-g(1,coords(i)))/max([1,abs(fd),abs(g(1,coords(i)))]);
end
fprintf('R4 gradient relative discrepancies: %s\n',mat2str(err,4));
assert(max(err)<.10,'R4 analytic gradient failed finite difference check.');
assert(numel(F.stageWeight)==s.K && all(F.trust>0));
% Check deterministic common-random-number terminal fantasies.
a=GCF_r4_terminal_eval(F,testX);
b=GCF_r4_terminal_eval(F,testX);
assert(isequaln(a,b),'Terminal lookahead must be deterministic for fixed GP');
fprintf('R4 SELFTEST PASS: gradient, terminal IVR, GP reverse messages, determinism.\n');
end

function IQ_R2_TUNE(phase,caseId)
% V12-style per-case, per-method tuning. Phase: screen/refine/tune.
% Never reads R1 results or HOLDOUT data. Final 10 seeds are untouched.
if nargin<1,phase='tune';end
if nargin<2 || isempty(caseId),error('Supply IMDB_SQL_4S8D caseID');end
phase=lower(char(phase));
assert(any(strcmp(phase,{'screen','refine','tune'})));
root=fileparts(mfilename('fullpath'));addpath(fullfile(root,'engine'),'-begin');
C=IQ_R2_config();cases=IQ_R2_spec(root);
ix=find(strcmp({cases.id},char(caseId)));
assert(isscalar(ix),'Unknown case: %s',caseId);
s=cases(ix);
base=fullfile(root,'results','IQ_R2_tuning',s.id);
if ~isfolder(base),mkdir(base);end
localProtocolLock(base,C,s);
if any(strcmp(phase,{'screen','tune'}))
 for m=1:numel(C.rlMethods)
  method=C.rlMethods{m};
  fprintf('\n========== SCREEN %s / %s =========\n',s.id,method);
  [P,tags]=MSBO_R2_GRID('screen');
  localEvaluateGrid('SCREEN',s,method,P,tags,C,root,base);
 end
end
if any(strcmp(phase,{'refine','tune'}))
 for m=1:numel(C.rlMethods)
  method=C.rlMethods{m};
  pfile=fullfile(base,sprintf('SCREEN_%s_SELECTED.mat',method));
  assert(isfile(pfile),'Screen winner missing: %s; run screen first.',pfile);
  q=load(pfile,'selection');
  assert(strcmp(q.selection.method,method) && ...
   strcmp(q.selection.stage,'SCREEN'),'Invalid screen selection file.');
  [P,tags]=MSBO_R2_GRID('refine',q.selection.params);
  fprintf('\n========== REFINE %s / %s (screen=%s) =========\n', ...
   s.id,method,q.selection.candidate);
  localEvaluateGrid('REFINE',s,method,P,tags,C,root,base);
 end
 localFreeze(C,s,base,root);
end
end

function localProtocolLock(base,C,s)
protocol=struct('config',C,'caseId',s.id,'stageDims',s.stageDims, ...
 'nInitial',s.nInitial,'nAcq',C.nAcq,'oracleDigest',IQ_R2_digest(C));
p=fullfile(base,'R2_TUNE_PROTOCOL_LOCK.mat');
if isfile(p)
 z=load(p,'protocol');
 assert(isfield(z,'protocol') && isequaln(z.protocol,protocol), ...
  'Tuning protocol changed for %s: use a NEW study ID.',s.id);
else
 save(p,'protocol','-v7');
end
end

function localEvaluateGrid(stage,s,method,P,tags,C,root,base)
if strcmp(stage,'SCREEN')
 seeds=C.screenSeeds;rounds=C.screenRounds;testBase=C.screenTestBase;
 code='R2S';
else
 seeds=C.refineSeeds;rounds=C.refineRounds;testBase=C.refineTestBase;
 code='R2F';
end
rows=cell(numel(P),8);scores=nan(numel(P),1);
for j=1:numel(P)
 p=P{j}; tag=tags{j};
 S=localRunSpec(C,seeds,rounds,testBase,stage, ...
  sprintf('%s_%s_%s_%s',code,s.id,method,tag),method,p);
 % Resume unfinished candidate from individual GP/MAPPO checkpoints.
 IQ_R2_ENGINE(S,s.id);
 score=localScore(root,S,s,method,p);
 scores(j)=score;
 rows(j,:)={string(s.id),string(stage),string(method),string(tag), ...
  string(jsonencode(p)),numel(seeds),rounds,score};
 fprintf(' %s %s %s [%d/%d] final RMSE=%.8g\n', ...
  stage,s.id,method,j,numel(P),score);
 % Progress report, independently durable after each completed candidate.
 Q=cell2table(rows(1:j,:),'VariableNames', ...
  {'Case','Stage','Method','Candidate','ParamsJSON','Seeds','Rounds','MeanFinalRMSE'});
 writetable(Q,fullfile(base,sprintf('%s_%s_ALL_CANDIDATES.csv',stage,method)));
end
[bestVal,bestIx]=min(scores);
selection=struct('caseId',s.id,'stage',stage,'method',method, ...
 'candidate',tags{bestIx},'params',P{bestIx}, ...
 'meanFinalRMSE',bestVal,'validationSeeds',seeds, ...
 'rounds',rounds,'testBase',testBase,'allScores',scores, ...
 'allTags',{tags},'protocol',C.protocol);
selFile=fullfile(base,sprintf('%s_%s_SELECTED.mat',stage,method));
if isfile(selFile)
 old=load(selFile,'selection');
 assert(isfield(old,'selection') && isequaln(old.selection,selection), ...
  'Validation selection changed: preserve old data and use a fresh study tag.');
else
 save(selFile,'selection','-v7');
end
fprintf('WINNER %s %s %s: %s, mean RMSE %.8g\n', ...
 stage,s.id,method,selection.candidate,bestVal);
end

function S=localRunSpec(C,seeds,rounds,testBase,phase,studyID,method,params)
S=struct('studyID',studyID,'phase',phase,'seeds',seeds, ...
 'methods',{{method}},'rounds',rounds,'nAcq',C.nAcq, ...
 'nAnchors',C.nAnchors,'nTest',C.nTest,'nRef',C.nRef, ...
 'rank',C.rank,'testBase',testBase,'methodOverrides',struct());
S.methodOverrides.(method)=params;
end

function score=localScore(root,S,s,method,p)
x=zeros(numel(S.seeds),1);
for k=1:numel(S.seeds)
 seed=S.seeds(k);
 f=fullfile(root,'results','IQ_R2_runs',S.studyID,s.id, ...
  sprintf('%s_seed%d_%s.mat',s.id,seed,method));
 assert(isfile(f),'Incomplete candidate: %s',f);
 z=load(f,'H','signature');
 assert(numel(z.H.RMSE)==S.rounds+1 && ...
  isequaln(z.signature.methodOverrides,p) && ...
  strcmp(char(z.signature.studyID),S.studyID) && ...
  strcmp(char(z.signature.phase),S.phase), ...
  'Candidate checkpoint mismatched stage/params/rounds: %s',f);
 if strcmp(method,'A5GRAD_V4A')
  assert(sum(z.H.GradientCalls)>0, ...
   'Gradient tuner candidate used no Fast-Gi gradient evaluations.');
 end
 x(k)=z.H.RMSE(end);
end
assert(all(isfinite(x)) && all(x>=0),'Nonfinite candidate RMSE');
score=mean(x);
end

function localFreeze(C,s,base,root)
params=struct();selectionMeta=struct();
for j=1:numel(C.rlMethods)
 m=C.rlMethods{j};
 f=fullfile(base,sprintf('REFINE_%s_SELECTED.mat',m));
 assert(isfile(f),'Missing refinement selection for %s',m);
 q=load(f,'selection');
 assert(strcmp(q.selection.stage,'REFINE')&&strcmp(q.selection.method,m));
 params.(m)=q.selection.params;
 selectionMeta.(m)=struct('tag',q.selection.candidate, ...
  'score',q.selection.meanFinalRMSE);
end
digest=IQ_R2_digest(C);
caseFreeze=struct('caseId',s.id,'params',params,'selected',selectionMeta, ...
 'oracleDigest',digest,'protocol',C);
fp=fullfile(base,'FROZEN_CASE.mat');
if isfile(fp)
 a=load(fp,'caseFreeze');
 assert(isfield(a,'caseFreeze')&&isequaln(a.caseFreeze,caseFreeze), ...
  'Frozen config already exists and differs. Do not overwrite.');
else
 save(fp,'caseFreeze','-v7');
end
% Aggregate into a discoverable V12-style frozen-config MAT.
master=fullfile(root,'results','IQ_R2_tuning','FROZEN_METHOD_CONFIGS.mat');
if isfile(master)
 z=load(master,'frozen');
 frozen=z.frozen;
 assert(isequaln(frozen.protocol,C),'Frozen master protocol mismatch.');
else
 frozen=struct('protocol',C,'params',struct(),'oracles',struct());
end
if isfield(frozen.params,s.id)
 assert(isequaln(frozen.params.(s.id),params) && ...
  strcmp(frozen.oracles.(s.id),digest), ...
  'Frozen master differs for %s',s.id);
else
 frozen.params.(s.id)=params;
 frozen.oracles.(s.id)=digest;
 tmp=[master '.tmp.mat'];save(tmp,'frozen','-v7');
 [ok,msg]=movefile(tmp,master,'f');
 assert(ok,'Unable to commit frozen master: %s',msg);
end
fprintf('FROZEN %s: A4/A5/A5GRAD_V4A, independent holdout can begin.\n',s.id);
end

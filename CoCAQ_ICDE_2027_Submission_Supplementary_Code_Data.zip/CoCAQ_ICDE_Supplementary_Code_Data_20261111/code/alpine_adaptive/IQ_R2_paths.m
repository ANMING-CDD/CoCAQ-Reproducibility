function [bridge,oracle,py]=IQ_R2_paths(C)
if nargin<1,C=IQ_R2_config();end
root=fileparts(mfilename('fullpath'));
bridge=fullfile(root,'python','imdb_query_bridge.py');
oracle=C.oracleFile;py=C.pythonExe;
assert(isfile(bridge),'Missing SQL bridge script: %s',bridge);
assert(~isempty(oracle) && isfile(oracle), ...
 'Set IMDB_ORACLE_FILE to the prepared .duckdb snapshot (not raw IMDb source DB).');
assert(isfile([oracle '.json']),'Missing prepared snapshot manifest: %s.json',oracle);
end

function Y=MSBO_GRID_truth(spec,X)
% Evaluate original-upstream-generated frozen NN_func layers, no Python in loop.
% Each stage uses local controls (+ scalar previous output for stages >1).
assert(size(X,2)==spec.d && all(isfinite(X(:))) && ...
 all(X(:)>=0 & X(:)<=1),'Oracle input must be N-by-D in [0,1].');
persistent cache;
if isempty(cache),cache=containers.Map('KeyType','char','ValueType','any');end
key=[spec.folder filesep 'manifest.json'];
if ~isKey(cache,key)
 manifest=fullfile(spec.folder,'manifest.json');
 assert(exist(manifest,'file')==2,'Missing frozen oracle: %s. Use the MATLAB-only full package with bundled frozen oracles.',manifest);
 m=jsondecode(fileread(manifest));
 assert(m.K==spec.K && m.D==spec.d && isequal(double(m.stageDims(:)'),double(spec.stageDims)), ...
  'Frozen oracle dimensions differ from experiment spec.');
 M=cell(spec.K,4);B=cell(spec.K,4);
 for k=1:spec.K
  for j=1:4
   M{k,j}=readmatrix(fullfile(spec.folder,sprintf('stage%d_W%d.csv',k,j)));
   B{k,j}=readmatrix(fullfile(spec.folder,sprintf('stage%d_b%d.csv',k,j)));
   B{k,j}=reshape(B{k,j},1,[]);
   assert(size(M{k,j},1)==numel(B{k,j}),'Weight/bias shape mismatch.');
  end
  ni=numel(MSBO_stage_idx(spec,k))+(k>1);
  assert(size(M{k,1},2)==ni,'Stage input dimension mismatch.');
 end
 cache(key)=struct('W',{M},'b',{B});
end
S=cache(key);Y=zeros(size(X,1),spec.K);
for k=1:spec.K
 ii=MSBO_stage_idx(spec,k);Z=X(:,ii);
 if k>1,Z=[Z Y(:,k-1)];end
 for j=1:4
  Z=Z*S.W{k,j}'+S.b{k,j};
  if j<4,Z=max(Z,0.1*Z);end % upstream LeakyReLU(slope=0.1)
 end
 Y(:,k)=1./(1+exp(-0.8*Z)); % upstream squash_out=True
end
assert(isequal(size(Y),[size(X,1),spec.K]) && all(isfinite(Y(:))), ...
 'Non-finite or invalid output from frozen oracle.');
end

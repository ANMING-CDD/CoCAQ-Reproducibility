function IQ_R2_RUN(mode)
% Independent R2-style experiment on adapted 4-stage real-data DuckDB SQL cascade.
% Run in existing R2 matlab folder; does not modify or rerun MSBO 12 cases.
if nargin<1||isempty(mode),mode='preflight';end
mode=lower(char(mode));
root=fileparts(mfilename('fullpath'));addpath(fullfile(root,'engine'),'-begin');
C=IQ_R2_config();s=IQ_R2_spec(root);
localValidate(C,s);
switch mode
 case 'selftest'
  MSBO_R2_GRID('selftest');
  assert(s.K==4 && s.d==8 && s.nInitial==24 && s.nAdd==30);
  assert(isequal(s.stageDims,[2 2 2 2]));
  for k=1:4
   assert(numel(MSBO_stage_idx(s,k))==2);
  end
  fprintf('PASS IMDb query case protocol: 4S8D, 24 initial, 30 added, 8 methods.\n');
 case 'preflight'
  localPreflight(C,s);
 case 'gradientcheck'
  localPreflight(C,s);
  rng(79499,'twister');X=GCF_lhs(s.nInitial,s.d);
  Y=IQ_R2_truth(s,X);model=GCF_fit(s,X,Y,'cascade');
  Xref=GCF_halton(64,s.d,15420);
  F=GCF_fastgi_build(model,s,Xref,16);
  x=.20+.60*rand(1,s.d);h=1e-5;
  [val,~,ga]=GCF_fastgi_eval(F,x);fd=zeros(1,s.d);
  for j=1:s.d
   xp=x;xm=x;xp(j)=xp(j)+h;xm(j)=xm(j)-h;
   fd(j)=(GCF_fastgi_eval(F,xp)-GCF_fastgi_eval(F,xm))/(2*h);
  end
  ea=norm(fd-ga);er=ea/max([norm(ga),norm(fd),1e-7]);
  fprintf('IMDb SQL Fast-Gi gradient check: value %.6g, abs %.3g, relative %.3g\n',val,ea,er);
  assert(all(isfinite(ga)) && (er<.08 || ea<1e-4),'IMDb SQL Fast-Gi gradient finite-diff failure');
  audit=struct('passed',true,'protocol',C.protocol,'digest',IQ_R2_digest(C), ...
   'errorAbs',ea,'errorRel',er);
  p=fullfile(root,'results','IQ_R2_audit');if ~isfolder(p),mkdir(p);end
  save(fullfile(p,'FASTGI_GQ_AUDIT_PASS.mat'),'audit','-v7');
  fprintf('PASS IMDb SQL Fast-Gi audit, locked to external bridge digest.\n');
 case 'smoke'
  localPreflight(C,s);
  [P,~]=MSBO_R2_GRID('screen');
  S=localRunSpec(C,'SMOKE','IQR_IMDB_R2_SMOKE_V1',C.screenSeeds(1),2, ...
   C.screenTestBase,{'P2','A5GRAD_V4A'});
  S.nAcq=64;S.nAnchors=16;S.nTest=8;S.nRef=64;S.rank=16;
  S.methodOverrides.A5GRAD_V4A=P{1};
  IQ_R2_ENGINE(S,s.id);
  fprintf('IMDb SQL smoke succeeded (2 methods, 1 seed, 2 rounds).\n');
 case {'screen','refine','tune'}
  localRequireAudit(root,C);localPreflight(C,s);
  IQ_R2_TUNE(mode,s.id);
 case {'evaluate','all'}
  localRequireAudit(root,C);localPreflight(C,s);
  if strcmp(mode,'all'),IQ_R2_TUNE('tune',s.id);end
  P=localLoadFrozen(C,root,s);
  localHoldoutLock(C,root,s,P);
  S=localRunSpec(C,'HOLDOUT',C.holdoutStudyID,C.holdoutSeeds, ...
   C.holdoutRounds,C.holdoutTestBase,C.methods);
  S.methodOverrides=P;
  IQ_R2_ENGINE(S,s.id);
  IQ_R2_REPORT('report');
 case {'status','report'}
  IQ_R2_REPORT(mode);
 case 'plot'
  IQ_R2_REPORT('plot');
 otherwise
  error('Use selftest/preflight/gradientcheck/smoke/screen/refine/tune/evaluate/all/status/report/plot');
end
end

function localValidate(C,s)
assert(strcmp(C.caseId,s.id) && numel(C.methods)==8);
assert(isequal(C.rlMethods,{'A4','A5','A5GRAD_V4A'}));
assert(numel(C.screenSeeds)==4 && numel(C.refineSeeds)==4 && numel(C.holdoutSeeds)==10);
assert(isempty(intersect(C.screenSeeds,C.refineSeeds)) && ...
 isempty(intersect(C.screenSeeds,C.holdoutSeeds)) && ...
 isempty(intersect(C.refineSeeds,C.holdoutSeeds)));
assert(C.screenRounds<=30 && C.refineRounds==30 && C.holdoutRounds==30);
assert(C.nAcq==300 && C.nTest>0 && C.nRef>0);
end

function localPreflight(C,s)
[bridge,oracle,py]=IQ_R2_paths(C);
fprintf('IMDb snapshot: %s\nSQL bridge: %s\nPython: %s\n',oracle,bridge,py);
[code,log]=system(sprintf('"%s" "%s" info --oracle "%s"',py,bridge,oracle));
assert(code==0,'DuckDB bridge not ready (is pip install duckdb needed?): %s',log);
assert(~isempty(strfind(log,'IMDB_ORACLE_READY')),'Snapshot probe missing readiness marker'); %#ok<STREMP>
x=.5*ones(1,s.d);Y=IQ_R2_truth(s,x,true);Z=IQ_R2_truth(s,x,true);
assert(isequal(size(Y),[1 4]) && all(isfinite(Y(:))));
assert(norm(Y-Z)<=1e-10*(1+norm(Y)), ...
 'Queries are not deterministic on the pinned snapshot.');
a=x;a(1)=.3;b=x;b(1)=.7;
qa=IQ_R2_truth(s,a);qb=IQ_R2_truth(s,b);
assert(abs(qa(1,1)-qb(1,1))>1e-5, ...
 'Stage 1 is insensitive to input control; check the selected real data columns.');
fprintf('PASS 4-stage real-data SQL query oracle. Snapshot+SQL digest: %s\n',IQ_R2_digest(C));
end

function localRequireAudit(root,C)
f=fullfile(root,'results','IQ_R2_audit','FASTGI_GQ_AUDIT_PASS.mat');
assert(isfile(f),'Run IQ_R2_RUN(''gradientcheck'') first.');
z=load(f,'audit');
assert(z.audit.passed && strcmp(z.audit.protocol,C.protocol) && ...
 strcmp(z.audit.digest,IQ_R2_digest(C)), ...
 'IMDb SQL oracle bridge changed since gradient audit; rerun gradientcheck.');
end

function S=localRunSpec(C,phase,studyID,seeds,rounds,testBase,methods)
S=struct('studyID',studyID,'phase',phase,'seeds',seeds, ...
 'methods',{methods},'rounds',rounds,'nAcq',C.nAcq, ...
 'nAnchors',C.nAnchors,'nTest',C.nTest,'nRef',C.nRef, ...
 'rank',C.rank,'testBase',testBase,'methodOverrides',struct());
end

function P=localLoadFrozen(C,root,s)
f=fullfile(root,'results','IQ_R2_tuning','FROZEN_METHOD_CONFIGS.mat');
assert(isfile(f),'First run IQ_R2_RUN(''tune'').');
z=load(f,'frozen');
assert(isequaln(z.frozen.protocol,C),'Frozen IMDb SQL protocol changed.');
assert(isfield(z.frozen.params,s.id),'No frozen parameters for IMDb.');
assert(strcmp(z.frozen.oracles.(s.id),IQ_R2_digest(C)), ...
 'Physical simulator changed after tuning; do not mix physics versions.');
P=z.frozen.params.(s.id);
assert(isequal(sort(fieldnames(P)),sort(C.rlMethods(:))));
end

function localHoldoutLock(C,root,s,P)
p=fullfile(root,'results','IQ_R2_tuning','HOLDOUT_LOCKS');
if ~isfolder(p),mkdir(p);end
lock=struct('protocol',C,'caseId',s.id,'oracleDigest',IQ_R2_digest(C), ...
 'frozenParams',P,'holdoutSeeds',C.holdoutSeeds);
f=fullfile(p,[s.id '_LOCK.mat']);
if isfile(f)
 z=load(f,'lock');assert(isequaln(z.lock,lock), ...
 'IMDb SQL holdout protocol was modified; use a new study ID.');
else
 save(f,'lock','-v7');
end
end

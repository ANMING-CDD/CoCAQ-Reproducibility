function MSBO_R2_HEATMAP(G)
% ICDE compact double-column, two-panel figure; data must be a full 4x3 grid.
% Panel (a) Δ=(best baseline mean - CoCAQ mean)/best baseline mean × 100%.
% Panel (b) fraction of paired seeds CoCAQ strictly beats ALL 7 baselines.
if nargin<1
 root=fileparts(mfilename('fullpath'));S=MSBO_R2_config();
 G=readtable(fullfile(root,'results','R2_runs',S.holdoutStudyID,'GRID_HEATMAP_DATA.csv'), ...
  'TextType','string');
end
assert(height(G)==12 && all(G.PairedSeeds==10),'Plot only complete 10-seed results.');
K=2:5;D=[10 15 20];A=nan(4,3);B=nan(4,3);
for i=1:4
 for j=1:3
  row=find(G.Stages==K(i)&G.Dimensions==D(j));
  assert(numel(row)==1);
  A(i,j)=G.ImprovementVsBestPct(row);
  B(i,j)=G.StrictWinRatePct(row);
 end
end
assert(all(isfinite(A(:)))&&all(isfinite(B(:))));
lim=max(5,ceil(max(abs(A(:)))/5)*5); % symmetric around 0, no clipping
neg=[0.77 .42 .27];neutral=[.98 .98 .97];pos=[.16 .45 .63];
t=linspace(0,1,128)';C1=[neg+(neutral-neg).*t;neutral+(pos-neutral).*t];
C2=[linspace(.96,.20,256)' linspace(.98,.57,256)' linspace(.97,.68,256)'];
fig=figure('Color','w','Units','inches','Position',[1 1 7.16 3.42], ...
 'Name','Fig6-MSBO complexity boundary','Renderer','painters');
ax1=axes(fig,'Units','normalized','Position',[.10 .22 .35 .62]);
ax2=axes(fig,'Units','normalized','Position',[.60 .22 .35 .62]);
localPanel(ax1,A,K,D,'(a) RMSE improvement vs. strongest baseline',C1,[-lim lim],'%+.1f%%');
localPanel(ax2,B,K,D,'(b) Strict seed-level win rate',C2,[0 100],'%.0f%%');
c1=colorbar(ax1,'southoutside');c1.Position=[.125 .055 .30 .025];
c1.Ticks=[-lim 0 lim];c1.FontSize=8;c1.TickDirection='out';
c2=colorbar(ax2,'southoutside');c2.Position=[.625 .055 .30 .025];
c2.Ticks=[0 50 100];c2.FontSize=8;c2.TickDirection='out';
set([ax1 ax2],'FontName','Arial','FontSize',9,'LineWidth',.8,'TickDir','out');
root=fileparts(mfilename('fullpath'));out=fullfile(root,'output','R2');
if ~exist(out,'dir'),mkdir(out);end
savefig(fig,fullfile(out,'Fig6_MSBO_R2_Complexity_Boundary.fig'));
exportgraphics(fig,fullfile(out,'Fig6_MSBO_R2_Complexity_Boundary.pdf'), ...
 'ContentType','vector','BackgroundColor','white');
exportgraphics(fig,fullfile(out,'Fig6_MSBO_R2_Complexity_Boundary.png'), ...
 'Resolution',600,'BackgroundColor','white');
fprintf('Fig6 complete 12-cell MSBO heatmap exported: %s\n',out);
end
function localPanel(ax,M,K,D,ttl,cmap,clims,fmt)
imagesc(ax,M);colormap(ax,cmap);caxis(ax,clims);
set(ax,'XTick',1:3,'XTickLabel',string(D), ...
 'YTick',1:4,'YTickLabel',string(K), ...
 'YDir','normal','Box','on','TickLength',[0 0]);
xlabel(ax,'Total dimension D');ylabel(ax,'Stages K');
title(ax,ttl,'FontWeight','normal','FontSize',10,'Interpreter','none');
for i=1:4
 for j=1:3
  val=M(i,j);p=(val-clims(1))/(clims(2)-clims(1));
  imax=size(cmap,1);rgb=cmap(max(1,min(imax,1+round(p*(imax-1)))),:);
  lum=.2126*rgb(1)+.7152*rgb(2)+.0722*rgb(3);
  if lum<.53,tc=[1 1 1];else,tc=[.14 .20 .25];end
  text(ax,j,i,sprintf(fmt,val),'HorizontalAlignment','center', ...
   'VerticalAlignment','middle','FontName','Arial','FontSize',9, ...
   'FontWeight','bold','Color',tc);
 end
end
xlim(ax,[.5 3.5]);ylim(ax,[.5 4.5]);
end

function MSBO_SEVEN_ENGINE(S,caseId)
% Seven-method experiment: P1 P2 A1 A2 IPPO MAPPO-PLUS original V4A.
% MAPPO variants share the same explicitly declared (not tuned) preset.
% CMA baselines share the same CMA defaults. Holdout seeds are NEVER used for tuning.
% Checkpoints: results/SEVEN_METHOD_runs/<studyID>/<caseID>.
assert(isstruct(S) && isfield(S,'studyID') && isfield(S,'phase'));
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'engine'),'-begin');
cases=MSBO_GRID_specs(root);
ix=find(strcmp({cases.id},char(caseId)));
assert(isscalar(ix),'Unknown Seven-Method case ID: %s',char(caseId));
s=cases(ix);
assert(numel(unique(S.seeds))==numel(S.seeds) && S.rounds>0);
assert(all(ismember(S.methods,{'P1','P2','A1','A2','A3_IPPO','A4_MAPPO_PLUS','A5_COCAQ_V4A'})), ...
 'Unsupported seven-method name.');
assert(isfile(fullfile(s.folder,'manifest.json')),'Missing frozen oracle');
localRunCase(s,S,root);
end

function localRunCase(s,S,root)
% Preserve deterministic initial design and shared held-out set per CASE.
registry=MSBO_GRID_specs(root);index=find(strcmp({registry.id},s.id));
assert(isscalar(index));
mdir=fullfile(root,'results','SEVEN_METHOD_runs',S.studyID,s.id);
if ~exist(mdir,'dir'),mkdir(mdir);end
orac=jsondecode(fileread(fullfile(s.folder,'manifest.json')));
Xtest=GCF_halton(S.nTest,s.d,S.testBase+1000*index);
Ytest=MSBO_GRID_truth(s,Xtest);ytest=Ytest(:,end);
for seed=S.seeds
 rng(701000+1000*index+seed,'twister');X0=GCF_lhs(s.nInitial,s.d);
 Y0=MSBO_GRID_truth(s,X0);
 rng(702000+1000*index+seed,'twister');lhsAdd=GCF_lhs(S.rounds,s.d);
 for mi=1:numel(S.methods)
  method=S.methods{mi};
  file=fullfile(mdir,sprintf('%s_seed%d_%s.mat',s.id,seed,method));
  prm=struct();
  if isfield(S,'methodOverrides') && isfield(S.methodOverrides,method)
   prm=S.methodOverrides.(method);
  end
  signature=struct('engine','MSBO_SEVEN_V1_20261106', ...
   'phase',S.phase,'studyID',S.studyID,'caseId',s.id,'K',s.K,'D',s.d, ...
   'stageDims',s.stageDims,'oracleDigest',char(orac.digest), ...
   'seed',seed,'method',method,'methodOverrides',prm, ...
   'nInitial',s.nInitial,'rounds',S.rounds,'nAcq',S.nAcq, ...
   'nAnchors',S.nAnchors,'nTest',S.nTest,'nRef',S.nRef, ...
   'rank',S.rank,'testBase',S.testBase,'mappo',localMAPPO(S));
  if exist(file,'file')==2
   z=load(file,'H','signature');
   assert(isfield(z,'H')&&isfield(z,'signature')&&isequaln(z.signature,signature), ...
    'Unsafe resume: signature mismatch in %s. Keep old checkpoint, use new studyID.',file);
   H=z.H;
   assert(isequaln(H.X(1:s.nInitial,:),X0) && ...
    isequaln(H.Y(1:s.nInitial,:),Y0),'Initial paired design changed.');
  else
   kind='cascade';if any(strcmp(method,{'P1','A1'})),kind='aio';end
   tf=tic;model=GCF_fit(s,X0,Y0,kind);fitSec=toc(tf);
   pred=GCF_predict_final(s,model,Xtest);
   H=struct('Case',s.id,'Stages',s.K,'Dim',s.d,'StageDims',s.stageDims, ...
    'Seed',seed,'Method',method,'X',X0,'Y',Y0,'model',model, ...
    'RMSE',sqrt(mean((pred-ytest).^2)), ...
    'RewardCalls',zeros(0,1),'GradientCalls',zeros(0,1),'PPOStats',{cell(0,1)}, ...
    'AcqBuildSec',zeros(0,1),'OptimizeSec',zeros(0,1), ...
    'FitSec',fitSec,'TruthSec',zeros(0,1),'Chosen',zeros(0,s.d));
   localCheckpoint(file,H,signature);
  end
  done=numel(H.RMSE)-1;
  fprintf('%s seed=%d method=%s, resume round %d/%d\n',s.id,seed,method,done,S.rounds);
  for rr=done+1:S.rounds
   o=struct();
   if any(strcmp(method,{'P1','P2'}))
    x=lhsAdd(rr,:);
    mt=struct('RewardCalls',0,'GradientCalls',0,'AcquisitionBuildSeconds',0,'OptimizationSeconds',0);
   else
    searchSeed=4800000+100000*index+10000*seed+50*rr;
    [o,mt]=localSearch(s,method,H.model,S,prm,searchSeed);
    x=o.bestX;
    assert(mt.RewardCalls==S.nAcq,'Acquisition budget mismatch.');
   end
   assert(all(isfinite(x))&&all(x>=0 & x<=1));
   tt=tic;y=MSBO_GRID_truth(s,x);truthSec=toc(tt);
   H.X=[H.X;x];H.Y=[H.Y;y];H.Chosen=[H.Chosen;x];
   kind='cascade';if any(strcmp(method,{'P1','A1'})),kind='aio';end
   tf=tic;model=GCF_fit(s,H.X,H.Y,kind,H.model);fitSec=toc(tf);
   pred=GCF_predict_final(s,model,Xtest);
   H.model=model;H.RMSE(end+1,1)=sqrt(mean((pred-ytest).^2));
   H.RewardCalls(end+1,1)=mt.RewardCalls;
   H.GradientCalls(end+1,1)=mt.GradientCalls;
   H.AcqBuildSec(end+1,1)=mt.AcquisitionBuildSeconds;
   H.OptimizeSec(end+1,1)=mt.OptimizationSeconds;
   H.FitSec(end+1,1)=fitSec;H.TruthSec(end+1,1)=truthSec;
   if isfield(o,'stats')
    H.PPOStats{end+1,1}=o.stats;
   else
    H.PPOStats{end+1,1}=struct(); % CMA-ES does not expose PPO stats.
   end
   localCheckpoint(file,H,signature);
   fprintf('  %d/%d  held-out RMSE=%.6g\n',rr,S.rounds,H.RMSE(end));
  end
 end
end
end

function c=localMAPPO(S)
c=GCF_config('full');c=c.mappo;
c.hidden=64;c.batch=32;c.nEpoch=14;c.nHiddenLayers=2;
c.minEpochsV5=14;c.minHiddenV5=64;
c.v4FreshFraction=.50;c.v4DiversityWeight=.20;
c.v4DistanceScale=.30;c.v4CurrentBonus=.05;
c.v4FeedbackCap=16;c.v4FeedbackMinDist=.08;
c.v4MinGainFrac=1e-7;c.v4GainPriority=.55;
c.v4FeedbackLogWeight=.75;
c.nAnchors=S.nAnchors;
% The original 14 PPO epochs are a maximum, not mandatory.
% PPO stability applies to A3_IPPO and A4_MAPPO_PLUS; original V4A unchanged.
c.ppoTargetKL=0.03;
c.ppoMinEpoch=2;
c.ppoActorGradMaxNorm=1.0;
c.ppoCriticGradMaxNorm=3.0;
c.ppoSigmaGradMaxNorm=1.0;
c.ppoExploreEntropyCoeff=0.005;
c.ppoExploreMinSigma=0.60;
c.ppoEntropyCoeff=0; % IPPO & MAPPO compare identical exploration regularizer
end

function [out,meta]=localSearch(spec,method,model,S,override,seed)
Xref=GCF_halton(S.nRef,spec.d,20000+seed);
tb=tic;
if strcmp(method,'A1')
 F=GCF_aio_build(model,Xref);
 evalFn=@(X)GCF_aio_eval(F,X);gradFn=[];
elseif any(strcmp(method,{'A2','A3_IPPO','A4_MAPPO_PLUS'}))
 F=GCF_chain_build(model,spec,Xref);
 evalFn=@(X)GCF_chain_eval(F,X);gradFn=[];
else
 F=GCF_fastgi_build(model,spec,Xref,S.rank);
 evalFn=@(X)GCF_fastgi_eval(F,X);
 gradFn=@(X)localFastGiGradient(F,X);
end
buildSec=toc(tb);tt=tic;
c=localMAPPO(S);
fn=fieldnames(override);
for j=1:numel(fn),c.(fn{j})=override.(fn{j});end
if any(strcmp(method,{'A3_IPPO','A4_MAPPO_PLUS'}))
 [out,meta]=GCF_seven_base_ppo(evalFn,model,spec,S.nAcq,c,method,seed);
elseif strcmp(method,'A5_COCAQ_V4A')
 % Byte-identical original V4A optimizer, including Fast-Gi and GP prior.
 [out,meta]=GCF_mappo_v4(evalFn,gradFn,model,spec,S.nAcq,c,'A5GRAD_V4A',seed);
elseif any(strcmp(method,{'A1','A2'}))
 [out,meta]=GCF_cmaes(evalFn,[],S.nAcq,spec.d,c,seed);
else
 error('Unsupported Seven Method experiment');
end
meta.AcquisitionBuildSeconds=buildSec;meta.OptimizationSeconds=toc(tt);
assert(isfield(meta,'RewardCalls') && meta.RewardCalls==S.nAcq);
if ~isfield(meta,'GradientCalls'),meta.GradientCalls=0;end
end

function gg=localFastGiGradient(F,X)
[~,~,gg]=GCF_fastgi_eval(F,X);
end

function localCheckpoint(file,H,signature)
tmp=[file '.tmp.mat'];save(tmp,'H','signature','-v7.3');
[ok,msg]=movefile(tmp,file,'f');
assert(ok,'Checkpoint move failed: %s',msg);
end

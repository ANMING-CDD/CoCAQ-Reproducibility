function [bridge,batch,py]=YB_R2_paths(C)
if nargin<1,C=YB_R2_config();end
root=fileparts(mfilename('fullpath'));
assert(~isempty(C.acceptanceRoot), ...
 'CASCADE_ACCEPTANCE_ROOT is empty. Point it to your legacy acceptance project folder.');
assert(~isempty(C.pythonExe), ...
 'CASCADE_PYTHON_EXE is empty. Point it to the EXISTING Python environment used by V9.');
bridge=fullfile(C.acceptanceRoot,'python','source_bridge.py');
batch=fullfile(root,'python','fiber_eval_batch.py');py=C.pythonExe;
assert(isfile(bridge),'Real fiber simulator bridge missing: %s',bridge);
assert(isfile(batch),'Legacy V9 batch adapter missing: %s',batch);
assert(isfile(py),'Python exe missing: %s',py);
end

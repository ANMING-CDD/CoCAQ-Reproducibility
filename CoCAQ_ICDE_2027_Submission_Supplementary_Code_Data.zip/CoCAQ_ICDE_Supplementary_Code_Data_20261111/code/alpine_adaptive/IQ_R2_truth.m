function Y=IQ_R2_truth(spec,X,forceFresh)
% One oracle call = execute all four dependent SQL stages on fixed real data.
% No surrogate/synthetic values are used as ground truth.
if nargin<3,forceFresh=false;end
assert(strcmp(spec.id,'IMDB_SQL_4S8D') && spec.K==4 && spec.d==8);
assert(size(X,2)==8 && all(isfinite(X(:))) && ...
 all(X(:)>=0 & X(:)<=1),'Normalized controls must be N-by-8 in [0,1]');
C=IQ_R2_config();[bridge,oracle,py]=IQ_R2_paths(C);
digest=IQ_R2_digest(C);
persistent memo lastDigest
if isempty(memo) || ~strcmp(lastDigest,digest)
 memo=containers.Map('KeyType','char','ValueType','any');
 lastDigest=digest;
end
N=size(X,1);Y=nan(N,4);keys=cell(N,1);need=false(N,1);
for i=1:N
 keys{i}=sprintf('%.17g,',X(i,:));
 if ~forceFresh && isKey(memo,keys{i})
  Y(i,:)=memo(keys{i});
 else
  need(i)=true;
 end
end
idx=find(need);
if ~isempty(idx)
 infile=[tempname '.csv'];outfile=[tempname '.csv'];
 cleanup=onCleanup(@()cleanupTmp({infile,outfile}));
 writematrix(X(idx,:),infile,'Delimiter',',');
 cmd=sprintf('"%s" "%s" evaluate --oracle "%s" --input "%s" --output "%s"', ...
  py,bridge,oracle,infile,outfile);
 [status,log]=system(cmd);
 assert(status==0,'IMDb DuckDB query bridge failed: %s',log);
 assert(isfile(outfile),'Bridge output is missing.');
 vals=readmatrix(outfile);
 assert(isequal(size(vals),[numel(idx),4]) && all(isfinite(vals(:))), ...
  'Bridge must return N-by-4 finite dependent SQL stage outputs');
 Y(idx,:)=vals;
 if ~forceFresh
  for j=1:numel(idx),memo(keys{idx(j)})=vals(j,:);end
 end
 clear cleanup;
end
assert(isequal(size(Y),[N 4]) && all(isfinite(Y(:))));
end
function cleanupTmp(paths)
for j=1:numel(paths),if isfile(paths{j}),delete(paths{j});end,end
end

function COCAQ_GP_COOP_RUN(action)
% Fully paired, explicitly two-stage (tune/eval) GP-cooperative PPO study.
% MATLAB R2024a. This is exploration, NOT evidence of any preordained ranking.
% Tune seeds 14511:14512; evaluation seeds 14611:14613 (disjoint).
% V4A is a byte-unchanged reference and optimizes Fast-Gi, unlike 4 peers.
if nargin<1,action='help';end
root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
action=lower(char(action));
switch action
 case {'help','?'}
  fprintf('COCAQ_GP_COOP_RUN(''preflight'')\n');
  fprintf('COCAQ_GP_COOP_RUN(''selftest'')\n');
  fprintf('COCAQ_GP_COOP_RUN(''smoke'')\n');
  fprintf('COCAQ_GP_COOP_RUN(''tune'')\n');
  fprintf('COCAQ_GP_COOP_RUN(''eval'')\n');
  fprintf('COCAQ_GP_COOP_RUN(''expand'')\n');
  fprintf('COCAQ_GP_COOP_RUN(''report'')\n');
 case 'preflight'
  localPreflight(root);
 case 'selftest'
  localPreflight(root);
  COCAQ_GP_COOP_SELFTEST();
 case 'smoke'
  localPreflight(root);
  S=localProtocol('smoke');localRun(root,S);localReport(root,S);
 case 'tune'
  localPreflight(root);
  localTune(root);
 case {'eval','expand'}
  localPreflight(root);
  lock=localLoadLock(root);
  S=localProtocol(action);S.methodOverrides=lock.params;
  S.lockFingerprint=lock.fingerprint;
  localRun(root,S);localReport(root,S);
 case 'report'
  for ph={'smoke','eval','expand'}
   S=localProtocol(ph{1});
   if ~strcmp(ph{1},'smoke')
    lockfile=localLockPath(root);
    if isfile(lockfile)
     lock=load(lockfile,'params','fingerprint');
     S.methodOverrides=lock.params;
     S.lockFingerprint=lock.fingerprint;
    end
   end
   localReport(root,S);
  end
 otherwise
  error('Unknown action. Run COCAQ_GP_COOP_RUN(''help'').');
end
end

function S=localProtocol(phase)
S=struct('studyID','','phase','','seeds',[], ...
 'methods',{{'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_REFERENCE'}}, ...
 'rounds',12,'nAcq',300,'nAnchors',48,'nTest',2048, ...
 'nRef',1024,'rank',48,'testBase',1460000, ...
 'methodOverrides',struct(),'lockFingerprint','NONE', ...
 'cases',{{}},'mode',upper(phase));
switch phase
 case 'smoke'
  S.studyID='GP_COOP_V1_SMOKE';S.phase='CODE_CHECK_ONLY';
  S.cases={'MSBO_3S_15D'};S.seeds=14501;S.rounds=2;
  S.nAcq=64;S.nAnchors=16;S.nTest=128;S.nRef=128;S.rank=16;
 case 'tune'
  S.studyID='GP_COOP_V1_TUNE';S.phase='TUNING_ONLY';
  S.cases={'MSBO_3S_15D','MSBO_5S_20D'};
  S.seeds=14511:14512;S.rounds=8;
  S.nTest=512;S.nRef=512;S.testBase=1455000;
 case 'eval'
  S.studyID='GP_COOP_V1_EVAL_LOCKED';S.phase='EVALUATION_EXPLORATORY';
  S.cases={'MSBO_3S_15D','MSBO_5S_20D'};
  S.seeds=14611:14613;S.rounds=12;S.testBase=1465000;
 case 'expand'
  S.studyID='GP_COOP_V1_EXPAND_LOCKED';S.phase='EVALUATION_EXPLORATORY';
  S.cases={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'};
  S.seeds=14621:14624;S.rounds=30;S.testBase=1475000;
 otherwise
  error('Bad protocol phase');
end
end

function localPreflight(root)
files={'MSBO_GP_COOP_ENGINE.m','MSBO_GRID_specs.m','MSBO_GRID_truth.m', ...
 fullfile('engine','GCF_gpcoop_ppo.m'), ...
 'COCAQ_GP_COOP_SELFTEST.m', ...
 fullfile('engine','GCF_ppo_stable_step.m'), ...
 fullfile('engine','GCF_ppo_stable_logpdf.m'), ...
 fullfile('engine','GCF_mappo_v4.m'), ...
 fullfile('engine','GCF_chain_build.m'), ...
 fullfile('engine','GCF_chain_eval.m'), ...
 fullfile('engine','GCF_cmaes.m')};
for j=1:numel(files)
 assert(isfile(fullfile(root,files{j})),'Missing source %s',files{j});
end
Q=MSBO_GRID_specs(root);assert(numel(Q)==12);
for j=1:12
 assert(isfile(fullfile(Q(j).folder,'manifest.json')), ...
  'Missing oracle: %s',Q(j).id);
end
assert(isempty(intersect(14501:14699,8301:8310)),'R2 holdout overlap');
assert(isempty(intersect(14511:14512,14611:14624)), ...
 'Tuning and evaluation seed overlap');
c=GCF_config('full');assert(c.mappo.uniformMix+c.mappo.priorMix<1);
fprintf('PREFLIGHT OK. 12 immutable oracles; tune/eval seeds disjoint.\n');
fprintf('Shared objective: A2 / IPPO / MAPPO / GP-MAPPO = chain IVR.\n');
fprintf('V4A_REFERENCE uses ORIGINAL Fast-Gi, cannot isolate optimizer effect.\n');
end

function localRun(root,S)
fprintf('\n%s: %d cases x %d seeds x %d methods = %d runs, %d rounds, %d scores each.\n', ...
 S.studyID,numel(S.cases),numel(S.seeds),numel(S.methods), ...
 numel(S.cases)*numel(S.seeds)*numel(S.methods),S.rounds,S.nAcq);
for j=1:numel(S.cases)
 MSBO_GP_COOP_ENGINE(S,S.cases{j});
 localReport(root,S);
end
end

function grid=localGrid()
% Same four bounded PPO hyperparameter candidate classes for all PPO methods.
% GP-specific prior strength is calibrated within A5_GP_MAPPO candidates.
% No reward or test-seed-derived adjustments to this grid.
grid=cell(4,1);
grid{1}=struct('hidden',64,'batch',32,'nEpoch',6, ...
 'actorLR',.002,'criticLR',.004,'sigma',1.10,'minSigma',.25, ...
 'ppoTargetKL',.07,'ppoMinEpoch',3,'ppoEntropyCoeff',0, ...
 'priorMix',.20,'priorTemp',.25,'priorWidth',.40,'priorH',.45);
grid{2}=struct('hidden',64,'batch',32,'nEpoch',10, ...
 'actorLR',.003,'criticLR',.006,'sigma',1.35,'minSigma',.35, ...
 'ppoTargetKL',.12,'ppoMinEpoch',4,'ppoEntropyCoeff',.003, ...
 'priorMix',.30,'priorTemp',.20,'priorWidth',.40,'priorH',.45);
grid{3}=struct('hidden',96,'batch',48,'nEpoch',12, ...
 'actorLR',.0015,'criticLR',.003,'sigma',1.10,'minSigma',.25, ...
 'ppoTargetKL',.10,'ppoMinEpoch',4,'ppoEntropyCoeff',.001, ...
 'priorMix',.35,'priorTemp',.30,'priorWidth',.50,'priorH',.55);
grid{4}=struct('hidden',64,'batch',48,'nEpoch',14, ...
 'actorLR',.002,'criticLR',.004,'sigma',1.50,'minSigma',.40, ...
 'ppoTargetKL',.18,'ppoMinEpoch',5,'ppoEntropyCoeff',.005, ...
 'priorMix',.45,'priorTemp',.20,'priorWidth',.35,'priorH',.40);
end

function p=localCMAGrid(j)
% CMA-ES also receives an independent, equal-size four-choice tuning grid.
% This prevents presenting MAPPO against an arbitrarily weak CMA-ES preset.
switch j
 case 1
  p=struct('cmaesRestarts',1,'cmaesPopScale',1,'cmaesSigma0',1.0);
 case 2
  p=struct('cmaesRestarts',2,'cmaesPopScale',1,'cmaesSigma0',1.1);
 case 3
  p=struct('cmaesRestarts',3,'cmaesPopScale',1.4,'cmaesSigma0',1.1);
 case 4
  p=struct('cmaesRestarts',4,'cmaesPopScale',1,'cmaesSigma0',.8);
 otherwise
  error('Unknown CMA-ES tuning grid index');
end
end

function localTune(root)
lockPath=localLockPath(root);
if isfile(lockPath)
 error(['Frozen hyperparameter lock already exists: %s. ' ...
  'Do not retune after seeing evaluation results.'],lockPath);
end
methods={'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO'};
grid=localGrid();T=localProtocol('tune');
rows=cell(0,7);rn={'Method','GridIndex','NComplete','MeanNormAULC', ...
 'MeanNormFinal','TuneScore','MeanSearchSeconds'};
params=struct();choices=struct();
for mi=1:numel(methods)
 method=methods{mi};scores=inf(1,numel(grid));
 for j=1:numel(grid)
  S=T;S.methods={method};S.studyID=sprintf('GP_COOP_V1_TUNE_%s_G%02d',method,j);
  S.methodOverrides=struct();
  if strcmp(method,'A2')
   candidate=localCMAGrid(j);
  else
   candidate=grid{j};
  end
  S.methodOverrides.(method)=candidate;
  localRun(root,S);
  [a,f,secs,n]=localTuneScore(root,S,method);
  assert(n==numel(S.cases)*numel(S.seeds),'Incomplete tuning checkpoint count');
  scores(j)=.65*a+.35*f;
  rows(end+1,:)={string(method),j,n,a,f,scores(j),secs}; %#ok<AGROW>
  fprintf('TUNE %-16s grid=%d: score=%.6f (norm AULC %.6f, final %.6f)\n', ...
   method,j,scores(j),a,f);
 end
 [~,best]=min(scores);
 if strcmp(method,'A2')
  params.(method)=localCMAGrid(best);
 else
  params.(method)=grid{best};
 end
 choices.(method)=best;
 fprintf('FROZEN %s: grid candidate %d (training seeds only).\n',method,best);
end
folder=fullfile(root,'results','GP_COOP_TUNING');
if ~isfolder(folder),mkdir(folder);end
Tgrid=cell2table(rows,'VariableNames',rn);
writetable(Tgrid,fullfile(folder,'TUNING_GRID_RESULTS.csv'));
fingerprint=localFingerprint(params,choices);
seedDisclosure='TUNE 14511:14512 only; EVAL 14611:14613 untouched';
save(lockPath,'params','choices','grid','Tgrid','fingerprint','seedDisclosure','-v7');
fprintf('PARAMETERS LOCKED (%s)\n',fingerprint);
fprintf('Next: COCAQ_GP_COOP_RUN(''eval'')\n');
end

function [a,f,secs,n]=localTuneScore(root,S,method)
a=[];f=[];secs=[];
for j=1:numel(S.cases)
 for seed=S.seeds
  fn=localFile(root,S,S.cases{j},seed,method);
  if ~isfile(fn),continue;end
  z=load(fn,'H','signature');
  assert(isequaln(z.signature.methodOverrides, ...
   S.methodOverrides.(method)),'Wrong tuned candidate checkpoint.');
  e=z.H.RMSE(:);
  if numel(e)~=S.rounds+1,continue;end
  assert(e(1)>0 && all(isfinite(e)));
  a(end+1,1)=trapz(0:S.rounds,e')/(S.rounds*e(1)); %#ok<AGROW>
  f(end+1,1)=e(end)/e(1); %#ok<AGROW>
  secs(end+1,1)=sum(z.H.OptimizeSec); %#ok<AGROW>
 end
end
n=numel(a);a=mean(a);f=mean(f);secs=mean(secs);
end

function lock=localLoadLock(root)
file=localLockPath(root);
assert(isfile(file), ...
 'You must tune on separate training seeds first: COCAQ_GP_COOP_RUN(''tune'')');
lock=load(file,'params','choices','fingerprint');
assert(strcmp(lock.fingerprint,localFingerprint(lock.params,lock.choices)), ...
 'Frozen tuning manifest inconsistent.');
for method={'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO'}
 assert(isfield(lock.params,method{1}),'Missing tuned parameter set');
end
end

function fp=localFingerprint(params,choices)
% Lightweight deterministic lock signature; strong file hashes in manifest.
s=jsonencode(struct('params',params,'choices',choices));
v=double(uint8(s));
z=mod(sum(v.*(1:numel(v))),2147483647);
fp=sprintf('GP_COOP_V1_LOCK_%010d_%d',z,numel(v));
end

function p=localLockPath(root)
p=fullfile(root,'results','GP_COOP_TUNING','LOCKED_PARAMS.mat');
end

function fn=localFile(root,S,id,seed,method)
fn=fullfile(root,'results','GP_COOP_runs',S.studyID,id, ...
 sprintf('%s_seed%d_%s.mat',id,seed,method));
end

function localReport(root,S)
folder=fullfile(root,'results','GP_COOP_reports',S.mode);
if ~isfolder(folder),mkdir(folder);end
rows=cell(0,15);curves=cell(0,5);
for ci=1:numel(S.cases)
 id=S.cases{ci};
 for seed=S.seeds
  for j=1:numel(S.methods)
   method=S.methods{j};fn=localFile(root,S,id,seed,method);
   if ~isfile(fn),continue;end
   z=load(fn,'H','signature');H=z.H;sg=z.signature;
   assert(strcmp(sg.studyID,S.studyID) && sg.seed==seed && ...
    strcmp(sg.method,method),'Invalid study checkpoint');
   if ~strcmp(S.lockFingerprint,'NONE') && ...
    isfield(S.methodOverrides,method)
    assert(isequaln(sg.methodOverrides,S.methodOverrides.(method)), ...
     'Do not mix different tuned configurations');
   end
   done=numel(H.RMSE)-1;
   if done~=S.rounds,continue;end
   assert(sum(H.RewardCalls)==done*S.nAcq,'Score budget mismatch');
   y=H.RMSE(:);aulc=trapz(0:done,y')/done;
   diag=localDiag(H);
   rows(end+1,:)={string(id),seed,string(method),done,S.nAcq, ...
    S.lockFingerprint,y(end),aulc,sum(H.OptimizeSec), ...
    diag.PPOUpdates,diag.PPOEarlyStops,diag.MeanKL, ...
    diag.MeanSigma,diag.GPPriorSamples,diag.MeanPrefixShift}; %#ok<AGROW>
   for r=0:done
    curves(end+1,:)={string(id),seed,string(method),r,y(r+1)}; %#ok<AGROW>
   end
  end
 end
end
names={'Case','Seed','Method','Rounds','CandidateBudget', ...
 'ParamLock','FinalRMSE','AULC','SearchSeconds','PPOUpdates', ...
 'PPOEarlyStops','MeanKL','MeanSigma','GPPriorSamples','MeanPrefixShift'};
if isempty(rows)
 types={'string','double','string','double','double','string', ...
  'double','double','double','double','double','double', ...
  'double','double','double'};
 T=table('Size',[0 numel(names)],'VariableTypes',types, ...
  'VariableNames',names);
else,T=cell2table(rows,'VariableNames',names);end
writetable(T,fullfile(folder,'ALL_RUNS.csv'));
namesC={'Case','Seed','Method','Round','RMSE'};
if isempty(curves)
 C=table('Size',[0 5], ...
  'VariableTypes',{'string','double','string','double','double'}, ...
  'VariableNames',namesC);
else,C=cell2table(curves,'VariableNames',namesC);end
writetable(C,fullfile(folder,'ALL_CURVES.csv'));
comp={'A2','A3_IPPO';'A3_IPPO','A4_MAPPO';'A2','A4_MAPPO'; ...
 'A4_MAPPO','A5_GP_MAPPO';'A2','A5_GP_MAPPO'; ...
 'A5_GP_MAPPO','V4A_REFERENCE';'A2','V4A_REFERENCE'};
pr=cell(0,9);means=cell(0,6);
for ci=1:numel(S.cases)
 id=string(S.cases{ci});W=T(T.Case==id,:);
 for j=1:numel(S.methods)
  method=string(S.methods{j});A=W(W.Method==method,:);
  if isempty(A),continue;end
  means(end+1,:)={id,method,height(A),mean(A.FinalRMSE), ...
   mean(A.AULC),mean(A.SearchSeconds)}; %#ok<AGROW>
 end
 for j=1:size(comp,1)
  ba=string(comp{j,1});bb=string(comp{j,2});
  A=W(W.Method==ba,:);B=W(W.Method==bb,:);
  [common,ia,ib]=intersect(A.Seed,B.Seed);
  if isempty(common),continue;end
  x=A.FinalRMSE(ia);y=B.FinalRMSE(ib);
  ax=A.AULC(ia);by=B.AULC(ib);
  pr(end+1,:)={id,ba,bb,numel(common),mean(x),mean(y), ...
   100*(mean(x)-mean(y))/max(mean(x),realmin), ...
   100*(mean(ax)-mean(by))/max(mean(ax),realmin),sum(y<x)}; %#ok<AGROW>
 end
end
mnames={'Case','Method','NSeeds','MeanRMSE','MeanAULC','MeanSearchSeconds'};
pnames={'Case','Baseline','Proposed','NPairedSeeds', ...
 'BaselineRMSE','ProposedRMSE','GainRMSE_pct','GainAULC_pct','ProposedWins'};
writetable(cell2table(means,'VariableNames',mnames), ...
 fullfile(folder,'METHOD_MEANS.csv'));
writetable(cell2table(pr,'VariableNames',pnames), ...
 fullfile(folder,'PAIRED_CASE_COMPARISON.csv'));
expected=numel(S.cases)*numel(S.seeds)*numel(S.methods);
fprintf('%s: %d/%d fully completed, %d paired comparison rows.\n', ...
 S.mode,height(T),expected,size(pr,1));
if ~isempty(pr),disp(cell2table(pr,'VariableNames',pnames));end
end

function v=localDiag(H)
v=struct('PPOUpdates',0,'PPOEarlyStops',0,'MeanKL',0, ...
 'MeanSigma',0,'GPPriorSamples',0,'MeanPrefixShift',0);
kl=[];sigma=[];shift=[];
for j=1:numel(H.PPOStats)
 s=H.PPOStats{j};
 if ~isstruct(s),continue;end
 if isfield(s,'PPOUpdates'),v.PPOUpdates=v.PPOUpdates+s.PPOUpdates;end
 if isfield(s,'PPOEarlyStops'),v.PPOEarlyStops=v.PPOEarlyStops+s.PPOEarlyStops;end
 if isfield(s,'MeanKL'),kl(end+1)=s.MeanKL;end %#ok<AGROW>
 if isfield(s,'MeanSigma'),sigma(end+1)=s.MeanSigma;end %#ok<AGROW>
 if isfield(s,'GPPriorSamples')
  v.GPPriorSamples=v.GPPriorSamples+s.GPPriorSamples;
 end
 if isfield(s,'MeanPrefixShift')
  shift(end+1)=s.MeanPrefixShift;end %#ok<AGROW>
end
if ~isempty(kl),v.MeanKL=mean(kl);end
if ~isempty(sigma),v.MeanSigma=mean(sigma);end
if ~isempty(shift),v.MeanPrefixShift=mean(shift);end
end

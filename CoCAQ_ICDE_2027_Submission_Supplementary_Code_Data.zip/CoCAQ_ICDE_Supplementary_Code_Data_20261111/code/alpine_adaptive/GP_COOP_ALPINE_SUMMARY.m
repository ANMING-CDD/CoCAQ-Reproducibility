function GP_COOP_ALPINE_SUMMARY(root,alpineCases,reportFolder)
% Scale-aware Alpine2 analysis. Called by alpine_report / alpine_all.
% All methods use the SAME fixed heldout test set within each K.
% NRMSE = RMSE / std(y_test). Do not mix raw RMSE across cascade depths.
if nargin<1||isempty(root),root=fileparts(mfilename('fullpath'));end
if nargin<2||isempty(alpineCases)
 S=GP_COOP_FORMAL_specs(root);
 ids=arrayfun(@(k)sprintf('BOFN_ALPINE2_%dS%dD',k,k),2:2:20, ...
  'UniformOutput',false);
 alpineCases=S(ismember({S.id},ids));
end
if nargin<3||isempty(reportFolder)
 reportFolder=fullfile(root,'results','GP_COOP_FORMAL_ALPINE_2TO20_reports');
end
if ~isfolder(reportFolder),mkdir(reportFolder);end
fn=fullfile(reportFolder,'ALL_RUNS.csv');
assert(isfile(fn),'Missing ALPINE ALL_RUNS.csv: run alpine_report first.');
T=readtable(fn);T.Case=string(T.Case);T.Method=string(T.Method);
methods={'A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_REFERENCE'};
registry=GP_COOP_FORMAL_specs(root);
rows=cell(0,10);scaleRows=cell(0,7);
for ci=1:numel(alpineCases)
 s=alpineCases(ci);idx=find(strcmp({registry.id},s.id));
 assert(isscalar(idx),'Unknown registry entry for %s',s.id);
 Xtest=GCF_halton(2048,s.d,1659000+1000*idx);
 Ytest=GP_COOP_FORMAL_truth(s,Xtest);
 ystd=std(Ytest(:,end));
 assert(isfinite(ystd) && ystd>1e-10,'Degenerate Alpine2 heldout scale %s',s.id);
 W=T(T.Case==string(s.id),:);
 for j=1:numel(methods)
  method=string(methods{j});Z=W(W.Method==method,:);
  if isempty(Z),continue;end
  nrmse=Z.FinalRMSE/ystd;naulc=Z.AULC/ystd;
  rows(end+1,:)={string(s.id),s.K,s.d,method,height(Z),ystd, ...
   mean(nrmse),std(nrmse),mean(naulc),mean(Z.SearchSeconds)}; %#ok<AGROW>
 end
 A=W(W.Method=="A2",:);V=W(W.Method=="V4A_REFERENCE",:);
 [seed,ia,iv]=intersect(A.Seed,V.Seed);n=numel(seed);
 if n==0,continue;end
 a=A.FinalRMSE(ia);v=V.FinalRMSE(iv);
 gain=100*(mean(a)-mean(v))/max(mean(a),realmin);
 scaleRows(end+1,:)={string(s.id),s.K,n,sum(v<a), ...
   gain,mean(a)/ystd,mean(v)/ystd}; %#ok<AGROW>
end
names={'Case','Stages','Dimension','Method','NSeeds','TestOutputStd', ...
 'MeanNRMSE','StdNRMSE','MeanNAULC','MeanSearchSeconds'};
if isempty(rows)
 M=table('Size',[0 numel(names)], ...
 'VariableTypes',{'string','double','double','string','double', ...
 'double','double','double','double','double'}, ...
 'VariableNames',names);
else
 M=cell2table(rows,'VariableNames',names);
end
writetable(M,fullfile(reportFolder,'ALPINE_NORMALIZED_METHOD_MEANS.csv'));
snames={'Case','Stages','PairedSeeds','V4AWins','V4A_GainRMSE_pct', ...
 'A2_MeanNRMSE','V4A_MeanNRMSE'};
if isempty(scaleRows)
 C=table('Size',[0 7],'VariableTypes', ...
 {'string','double','double','double','double','double','double'}, ...
 'VariableNames',snames);
else
 C=cell2table(scaleRows,'VariableNames',snames);
end
writetable(C,fullfile(reportFolder,'ALPINE_V4A_VS_A2_BY_SCALE.csv'));
% Rank only if every one of the 10 scales has the full 10 seeds per method.
rankRows=cell(0,5);
for j=1:numel(methods)
 Q=M(M.Method==string(methods{j}) & M.NSeeds==10,:);
 if height(Q)~=10,continue;end
 rankRows(end+1,:)={string(methods{j}),10,mean(Q.MeanNRMSE), ...
  mean(Q.MeanNAULC),mean(Q.MeanSearchSeconds)}; %#ok<AGROW>
end
rnames={'Method','FullyPairedScales','MacroMeanNRMSE','MacroMeanNAULC', ...
 'MacroMeanSearchSeconds'};
if isempty(rankRows)
 R=table('Size',[0 5],'VariableTypes', ...
 {'string','double','double','double','double'},'VariableNames',rnames);
else
 R=sortrows(cell2table(rankRows,'VariableNames',rnames), ...
  'MacroMeanNRMSE','ascend');
end
writetable(R,fullfile(reportFolder,'ALPINE_OVERALL_NRMSE_RANKING.csv'));
fprintf('ALPINE normalized report: %d case/method rows; %d complete-scale methods.\n', ...
 height(M),height(R));
if ~isempty(R),disp(R);else
 fprintf('ALPINE ranking is withheld until all 10 scales x 10 seeds complete.\n');
end
end

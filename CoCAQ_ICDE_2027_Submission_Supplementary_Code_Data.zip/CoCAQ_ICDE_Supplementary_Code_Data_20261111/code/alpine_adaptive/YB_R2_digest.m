function digest=YB_R2_digest(C)
% Hash BOTH Python source-bridge and original V9 batch adapter.
% This does not certify installed pyfiberamp or hardware, record separately.
if nargin<1,C=YB_R2_config();end
[bridge,batch]=YB_R2_paths(C);
md=java.security.MessageDigest.getInstance('SHA-256');
paths={bridge,batch};
for j=1:numel(paths)
 fid=fopen(paths{j},'rb');
 assert(fid>0,'Cannot read source file for digest: %s',paths{j});
 b=fread(fid,inf,'*uint8');fclose(fid);
 md.update(typecast(b(:),'int8'));
end
bytes=mod(double(md.digest()),256);
digest=lower(reshape(dec2hex(bytes,2).',1,[]));
assert(numel(digest)==64,'Invalid SHA256 digest');
end

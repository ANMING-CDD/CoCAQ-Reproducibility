function GP_COOP_HORIZONTAL_SELFTEST(root)
% True-function parity, network topology and GP stage-interface checks.
if nargin<1||isempty(root),root=fileparts(mfilename('fullpath'));end
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
cases=GP_COOP_HORIZONTAL_specs(root);
for i=1:numel(cases)
 s=cases(i);X=[.13*ones(1,s.d);.37*ones(1,s.d); ...
    .71*ones(1,s.d);linspace(.12,.88,s.d)];
 Y=GP_COOP_FORMAL_truth(s,X);
 assert(isequal(size(Y),[4 s.K]) && all(isfinite(Y(:))));
 switch s.kind
  case 'horizontal_ackmat'
   xp=4*X(:,1:end-1)-2;
   a=-20*exp(-.2*sqrt(mean(xp.^2,2)))- ...
       exp(mean(cos(2*pi*xp),2))+20+exp(1);
   z=20*X(:,end)-10;
   v=-.26*(a.^2+z.^2)+.48*a.*z;
   assert(max(abs(Y(:,1)-a))<1e-10);
   assert(max(abs(Y(:,end)-v))<1e-10);
  case 'horizontal_ackley_dag'
   xp=4*X-2;
   f1=mean(xp.^2,2);f2=mean(cos(2*pi*xp),2);
   assert(max(abs(Y(:,1)-f1))<1e-12);
   assert(max(abs(Y(:,2)-f2))<1e-12);
   v=20*exp(-.2*sqrt(f1))+exp(f2)-20-exp(1);
   assert(max(abs(Y(:,end)-v))<1e-10);
  case 'horizontal_rosen'
   xp=4*X-2;
   exact=-sum(100*(xp(:,2:end)-xp(:,1:end-1).^2).^2+ ...
    (1-xp(:,1:end-1)).^2,2);
   assert(max(abs(Y(:,end)-exact))<1e-8*max(1,max(abs(exact))));
 end
 for k=1:s.K
  Q=GCF_stage_input(s,X,Y,k);
  assert(size(Q,1)==size(X,1) && all(isfinite(Q(:))));
  switch s.kind
   case 'horizontal_ackley_dag'
    if k<=2,expect=s.d;else,expect=2;end
   case 'horizontal_rosen'
    expect=s.stageDims(k)+(k>1)*2;
   otherwise
    expect=s.stageDims(k)+(k>1);
  end
  assert(size(Q,2)==expect,'Stage input dimension wrong %s stage=%d',s.id,k);
 end
 fprintf('HORIZONTAL TRUE-FUNCTION OK %-24s K=%d D=%d\n',s.id,s.K,s.d);
end
% Fit a small independent GP for every stage and verify graph predictions,
% the chain acquisition and Fast-Gi acquisition, including analytic gradient.
probe={'H_ACKMAT_2S7D','H_ACKLEY_3S6D','H_ROSEN_4S10D'};
for i=1:numel(probe)
 ix=find(strcmp({cases.id},probe{i}));s=cases(ix);
 X=GCF_halton(12,s.d,700+i*20);Y=GP_COOP_FORMAL_truth(s,X);
 model=GCF_fit(s,X,Y,'cascade');
 Xt=GCF_halton(7,s.d,920+i*20);
 [Ym,Yv,Q,J]=GCF_cascade_predict(model,s,Xt);
 assert(isequal(size(Ym),[7 s.K])&&isequal(size(Yv),[7 s.K]));
 assert(all(isfinite(Ym(:))) && all(isfinite(Yv(:))) && all(Yv(:)>=0));
 for k=1:s.K
  assert(size(Q{k},2)==size(model.stage{k}.X,2));
  assert(size(J{k},1)==7 && size(J{k},3)==s.d);
 end
 F=GCF_chain_build(model,s,GCF_halton(24,s.d,1100+i*40));
 [r,g]=GCF_chain_eval(F,Xt);
 assert(isequal(size(g),[7 s.K]) && all(isfinite(r)) && all(r>=0));
 F=GCF_fastgi_build(model,s,GCF_halton(24,s.d,1180+i*40),8);
 [r,g,dg]=GCF_fastgi_eval(F,Xt(1,:));
 assert(isscalar(r) && all(isfinite(g(:))) && ...
  isequal(size(dg),[1 s.d]) && all(isfinite(dg(:))));
 fprintf('HORIZONTAL GP/ACQ OK %s\n',s.id);
end
fprintf('HORIZONTAL SELFTEST PASSED: 18 truths + three GP/acquisition topology probes.\n');
end

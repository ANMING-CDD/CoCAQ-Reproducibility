function digest=IQ_R2_digest(C)
% PINNED SHA256 across the DuckDB snapshot + manifest + Python query definitions.
% Prevents accidental reuse of tuning/holdout if the SQL workload changes.
if nargin<1,C=IQ_R2_config();end
[bridge,oracle]=IQ_R2_paths(C);
md=java.security.MessageDigest.getInstance('SHA-256');
paths={bridge,oracle,[oracle '.json']};
for j=1:numel(paths)
 fid=fopen(paths{j},'rb');assert(fid>0,'Cannot open oracle file: %s',paths{j});
 cleanup=onCleanup(@()fclose(fid));
 while true
  b=fread(fid,1024*1024,'*uint8');
  if isempty(b),break;end
  md.update(typecast(b(:),'int8'));
 end
 clear cleanup;
end
bytes=mod(double(md.digest()),256);
digest=lower(reshape(dec2hex(bytes,2).',1,[]));
assert(numel(digest)==64);
end

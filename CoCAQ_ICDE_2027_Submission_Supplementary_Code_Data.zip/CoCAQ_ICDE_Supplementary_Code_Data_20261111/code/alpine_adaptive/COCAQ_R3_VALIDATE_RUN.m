function COCAQ_R3_VALIDATE_RUN(action)
% CoCAQ R3 VALIDATION V2: A2/A3/A4/A5/V4A/R3_BASE/R3_REFINE/R3_GUIDED.
% The original R2 and R3 pilot files are NEVER changed by this entry point.
% MATLAB R2024a. All final-validation seeds are separate from earlier studies.
if nargin<1,action='help';end
action=lower(char(action));root=fileparts(mfilename('fullpath'));
assert(isfile(fullfile(root,'MSBO_R3_VALIDATE_ENGINE.m')), ...
 'Missing MSBO_R3_VALIDATE_ENGINE.m; use the FULL V2 package or merge patch into R3 matlab folder.');
assert(isfolder(fullfile(root,'engine')), 'Missing engine folder; use the FULL V2 package.');
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
switch action
 case {'help','?'}
  fprintf('\nCoCAQ R3 VALIDATION V2, eight methods, original R2/R3 never overwritten.\n');
  fprintf(' COCAQ_R3_VALIDATE_RUN(''preflight'')\n');
  fprintf(' COCAQ_R3_VALIDATE_RUN(''smoke'')     %% 8 checkpoints, 2 rounds\n');
  fprintf(' COCAQ_R3_VALIDATE_RUN(''pilot'')     %% 1 case, 3 seeds, 12 rounds\n');
  fprintf(' COCAQ_R3_VALIDATE_RUN(''expand'')    %% 3 cases, 4 seeds, 30 rounds\n');
  fprintf(' COCAQ_R3_VALIDATE_RUN(''confirm'')   %% 12 cases, 10 seeds, 30 rounds: costly\n');
  fprintf(' COCAQ_R3_VALIDATE_RUN(''report'')\n');
  fprintf('A3 = SAME Fast-Gi score + CMA-ES; R3_REFINE vs R3_GUIDED = teacher effect.\n');
 case 'preflight'
  validateProject(root);
 case 'report'
  for label={'smoke','pilot','expand','confirm'}
   writeReport(root,protocol(root,label{1}));
  end
 case {'smoke','pilot','expand','confirm'}
  validateProject(root);S=protocol(root,action);
  fprintf('\nVALIDATION %s: %d cases x %d seeds x %d methods = %d runs, %d rounds.\n', ...
   upper(action),numel(S.cases),numel(S.seeds),numel(S.methods), ...
   numel(S.cases)*numel(S.seeds)*numel(S.methods),S.rounds);
  fprintf('MAPPO setting: COMMON_UNTUNED_PRESET; 300 candidate scores except SMOKE.\n');
  for i=1:numel(S.cases)
   MSBO_R3_VALIDATE_ENGINE(S,S.cases{i});
   writeReport(root,S);
  end
  fprintf('\n%s complete. Output: matlab/results/R3_VALIDATE_REPORTS/%s\n', ...
   upper(action),upper(action));
 otherwise
  error('Unsupported command: %s',action);
end
end

function S=protocol(root,action)
S=struct('studyID','','phase','','seeds',[], ...
 'methods',{{'A2','A3','A4','A5','A5GRAD_V4A','R3_BASE','R3_REFINE','R3_GUIDED'}}, ...
 'rounds',30,'nAcq',300,'nAnchors',48,'nTest',2048,'nRef',1024, ...
 'rank',48,'testBase',541000,'methodOverrides',struct(), ...
 'cases',{{}},'mode',upper(action));
switch action
 case 'smoke'
  S.studyID='R3_VALID_V2_SMOKE';S.phase='CODE_CHECK_NOT_RESULT';
  S.cases={'MSBO_3S_15D'};S.seeds=9821;S.rounds=2;
  S.nAcq=64;S.nAnchors=16;S.nTest=128;S.nRef=128;S.rank=16;
 case 'pilot'
  S.studyID='R3_VALID_V2_PILOT';S.phase='EXPLORATORY_DO_NOT_TUNE_ON_CONFIRM';
  S.cases={'MSBO_3S_15D'};S.seeds=9821:9823;S.rounds=12;S.testBase=542000;
 case 'expand'
  S.studyID='R3_VALID_V2_EXPAND';S.phase='EXPLORATORY_DO_NOT_TUNE_ON_CONFIRM';
  S.cases={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'};
  S.seeds=9921:9924;S.testBase=543000;
 case 'confirm'
  S.studyID='R3_VALID_V2_CONFIRM';S.phase='LOCKED_CONFIRMATORY_NO_SELECTION';
  allCases=MSBO_GRID_specs(root);S.cases={allCases.id};
  S.seeds=10021:10030;S.testBase=544000;
 otherwise,error('Unknown experiment phase: %s',action);
end
end

function validateProject(root)
needed={'MSBO_R3_VALIDATE_ENGINE.m','MSBO_R3_GUIDED_ENGINE.m', ...
 'MSBO_R2_ENGINE.m','MSBO_R2_config.m','MSBO_GRID_specs.m', ...
 fullfile('engine','GCF_mappo_guided.m'), ...
 fullfile('engine','GCF_mappo.m'),fullfile('engine','GCF_mappo_v4.m'), ...
 fullfile('engine','GCF_cmaes.m'),fullfile('engine','GCF_fastgi_build.m'), ...
 fullfile('engine','GCF_fastgi_eval.m')};
for i=1:numel(needed)
 assert(isfile(fullfile(root,needed{i})), 'Missing project dependency: %s',needed{i});
end
C=MSBO_R2_config();
assert(C.nAcq==300 && C.holdoutRounds==30 && ...
 isequal(C.holdoutSeeds,8301:8310), ...
 'Original R2 protocol has changed; use the archived unmodified project.');
allCases=MSBO_GRID_specs(root);
assert(numel(allCases)==12,'Expected 12 frozen MSBO cases, got %d.',numel(allCases));
for i=1:12
 s=allCases(i);f=fullfile(s.folder,'manifest.json');
 assert(isfile(f),'Frozen MSBO oracle missing: %s',f);
 manifest=jsondecode(fileread(f));
 assert(strcmp(char(manifest.case),char(s.id)) && manifest.K==s.K ...
  && manifest.D==s.d && numel(char(manifest.digest))==64, ...
  'Frozen oracle manifest mismatch for case %s',s.id);
end
assert(isempty(intersect(10021:10030,8301:8310)) && ...
 isempty(intersect(10021:10030,9701:9703)) && ...
 isempty(intersect(10021:10030,9821:9823)), ...
 'Confirm seeds must be disjoint from old and pilot seeds.');
fprintf('VALIDATION V2 PREFLIGHT OK: 12 frozen cases, original R2 unchanged.\n');
fprintf('NOTE: no R2 frozen MAPPO tuning files; all MAPPO methods use the SAME untuned preset.\n');
fprintf('A2 and A3 have the SAME fixed CMA-ES hyperparameters. All active methods have the same score budget.\n');
end

function writeReport(root,S)
folder=fullfile(root,'results','R3_VALIDATE_REPORTS',S.mode);
if ~isfolder(folder),mkdir(folder);end
names={'Case','Seed','Method','Rounds','Budget','ParamSource', ...
 'FinalRMSE','AULC','AcqScoringCalls','AnalyticGradientCalls', ...
 'GradTrials','GradAccepted','TeacherPairs','DistillUpdates', ...
 'GradientChosen','SearchSeconds','FitSeconds'};
types={'string','double','string','double','double','string', ...
 'double','double','double','double','double','double','double','double', ...
 'double','double','double'};
rows=cell(0,numel(names));
curveNames={'Case','Seed','Method','Round','RMSE'};
curves=cell(0,numel(curveNames));
statNames={'Case','Seed','Method','CompletedRounds','Checkpoint'};
statuses=cell(0,numel(statNames));
for i=1:numel(S.cases)
 cid=S.cases{i};
 for seed=S.seeds
  for j=1:numel(S.methods)
   meth=S.methods{j};
   file=fullfile(root,'results','R3_VALIDATE_runs',S.studyID,cid, ...
    sprintf('%s_seed%d_%s.mat',cid,seed,meth));
   if ~isfile(file),continue;end
   z=load(file,'H','signature');
   assert(isfield(z,'H')&&isfield(z,'signature'),'Checkpoint missing fields: %s',file);
   H=z.H;sig=z.signature;
   assert(strcmp(char(sig.studyID),S.studyID) && sig.seed==seed && ...
    strcmp(char(sig.method),meth) && sig.nAcq==S.nAcq && ...
    sig.rounds==S.rounds && strcmp(char(sig.engine),'MSBO_R3_VALIDATE_V2_20261106'), ...
    'Checkpoint signature mismatch: %s',file);
   completed=numel(H.RMSE)-1;
   assert(completed>=0 && completed<=S.rounds,'Invalid round count');
   statuses(end+1,:)={string(cid),seed,string(meth),completed,string(file)}; %#ok<AGROW>
   if completed~=S.rounds,continue;end
   assert(numel(H.RewardCalls)==completed && ...
    sum(H.RewardCalls)==S.nAcq*completed, 'Acquisition scoring budget incorrect: %s',file);
   assert(isfield(H,'R3Stats') && numel(H.R3Stats)==completed, ...
    'Diagnostics are missing: %s',file);
   totals=zeros(1,5);
   fields={'GradTrials','GradAccepted','TeacherPairs','DistillUpdates','GradientChosen'};
   for r=1:completed
    q=H.R3Stats{r};
    for f=1:numel(fields)
     if isfield(q,fields{f}),totals(f)=totals(f)+q.(fields{f});end
    end
   end
   if strcmp(meth,'R3_GUIDED') && totals(4)==0
    warning('R3Validate:NoGuidance','No distillation update for %s seed %d.',cid,seed);
   end
   rmse=H.RMSE(:)';
   aulc=trapz(0:completed,rmse)/completed;
   rows(end+1,:)={string(cid),seed,string(meth),completed,S.nAcq, ...
    "COMMON_UNTUNED_PRESET",rmse(end),aulc,sum(H.RewardCalls), ...
    sum(H.GradientCalls),totals(1),totals(2),totals(3),totals(4),totals(5), ...
    sum(H.OptimizeSec),sum(H.FitSec)}; %#ok<AGROW>
   for k=0:completed
    curves(end+1,:)={string(cid),seed,string(meth),k,rmse(k+1)}; %#ok<AGROW>
   end
  end
 end
end
T=cellTable(rows,names,types);
C=cellTable(curves,curveNames,{'string','double','string','double','double'});
U=cellTable(statuses,statNames,{'string','double','string','double','string'});
writetable(T,fullfile(folder,'ALL_RUNS.csv'));
writetable(C,fullfile(folder,'ALL_CURVES.csv'));
writetable(U,fullfile(folder,'CHECKPOINT_STATUS.csv'));

mnames={'Case','Method','NSeeds','MeanRMSE','MeanAULC','MeanSearchSeconds', ...
 'MeanTeacherPairs','MeanDistillUpdates'};
means=cell(0,numel(mnames));
cnames={'Case','Baseline','NPairedSeeds','BaselineRMSE','GuidedRMSE', ...
 'GuidedGainRMSE_pct','GuidedGainAULC_pct','GuidedWins','GuidedMeanDistillUpdates'};
comparisons=cell(0,numel(cnames));
pnames={'Case','Seed','Baseline','BaselineRMSE','GuidedRMSE', ...
 'GuidedGainRMSE_pct','BaselineAULC','GuidedAULC','GuidedGainAULC_pct'};
pairs=cell(0,numel(pnames));
for i=1:numel(S.cases)
 cid=string(S.cases{i});W=T(T.Case==cid,:);
 if isempty(W),continue;end
 for j=1:numel(S.methods)
  mm=string(S.methods{j});A=W(W.Method==mm,:);
  if isempty(A),continue;end
  means(end+1,:)={cid,mm,height(A),mean(A.FinalRMSE),mean(A.AULC), ...
   mean(A.SearchSeconds),mean(A.TeacherPairs),mean(A.DistillUpdates)}; %#ok<AGROW>
 end
 G=W(W.Method=="R3_GUIDED",:);
 for j=1:numel(S.methods)
  meth=S.methods{j};
  if strcmp(meth,'R3_GUIDED'),continue;end
  A=W(W.Method==string(meth),:);
  [shared,ia,ig]=intersect(A.Seed,G.Seed);
  if isempty(shared),continue;end
  x=A.FinalRMSE(ia);y=G.FinalRMSE(ig);
  ax=A.AULC(ia);gy=G.AULC(ig);
  gp=100*(mean(x)-mean(y))/max(mean(x),realmin);
  gl=100*(mean(ax)-mean(gy))/max(mean(ax),realmin);
  comparisons(end+1,:)={cid,string(meth),numel(shared),mean(x),mean(y), ...
   gp,gl,sum(y<x),mean(G.DistillUpdates(ig))}; %#ok<AGROW>
  for k=1:numel(shared)
   pairs(end+1,:)={cid,shared(k),string(meth),x(k),y(k), ...
    100*(x(k)-y(k))/max(x(k),realmin),ax(k),gy(k), ...
    100*(ax(k)-gy(k))/max(ax(k),realmin)}; %#ok<AGROW>
  end
 end
end
M=cellTable(means,mnames,{'string','string','double','double','double', ...
 'double','double','double'});
P=cellTable(comparisons,cnames,{'string','string','double', ...
 'double','double','double','double','double','double'});
I=cellTable(pairs,pnames,{'string','double','string','double','double', ...
 'double','double','double','double'});
writetable(M,fullfile(folder,'METHOD_MEANS.csv'));
writetable(P,fullfile(folder,'PAIRED_CASE_COMPARISON.csv'));
writetable(I,fullfile(folder,'PAIRED_SEED_COMPARISON.csv'));
expected=numel(S.cases)*numel(S.seeds)*numel(S.methods);
fprintf('R3 VALIDATION %s: %d/%d completed; %d case-baseline comparisons.\n', ...
 S.mode,height(T),expected,height(P));
if ~isempty(P),disp(P);end
if isempty(T),fprintf('No completed runs in %s yet: empty reports created.\n',S.mode);end
end

function T=cellTable(rows,names,types)
assert(numel(names)==numel(types),'Report schema mismatch');
if isempty(rows)
 T=table('Size',[0 numel(names)],'VariableTypes',types,'VariableNames',names);
else
 T=cell2table(rows,'VariableNames',names);
end
end

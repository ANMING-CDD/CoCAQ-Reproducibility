function S=GCF_r4_state(M,X,k)
% Identical-width state for all ablations. GP communication values come
% from the full-input draft, NEVER from unknown real intermediate outputs.
B=size(X,1);d=size(X,2);K=size(M.forwardMu,2);
assert(size(M.draft,1)==B && k>=1 && k<=K);
S=zeros(B,2*d+6*K+2);
if k>1
 numPrefix=sum(M.stageDims(1:k-1));
 S(:,1:numPrefix)=X(:,1:numPrefix);
end
S(:,d+(1:d))=M.draft;
mu=M.forwardMu;std0=M.forwardStd;
if ~M.useComm
 mu(:,k:end)=0;std0(:,k:end)=0;
end
S(:,2*d+(1:K))=mu;
S(:,2*d+K+(1:K))=std0;
S(:,2*d+2*K+(1:K))=M.backSensitivity;
S(:,2*d+3*K+(1:K))=M.terminalImportance;
S(:,2*d+4*K+(1:K))=M.backPressure;
S(:,2*d+5*K+k)=1;
S(:,end-1)=min(5,sum(std0.^2,2)/K);
S(:,end)=mean(M.trust,2);
end

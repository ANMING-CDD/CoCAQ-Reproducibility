function idx=MSBO_stage_idx(spec,k)
% Exact indexing for unequal control counts per stage.
if isfield(spec,'stageDims')
 dims=double(spec.stageDims(:)');
else
 assert(isfield(spec,'K') && isfield(spec,'p'));
 dims=repmat(spec.p,1,spec.K);
end
assert(k>=1 && k<=numel(dims) && all(dims>=1) && all(mod(dims,1)==0));
if isfield(spec,'d'),assert(sum(dims)==spec.d,'stageDims do not sum to d');end
start=sum(dims(1:k-1));idx=start+(1:dims(k));
end

function F=GCF_aio_build(model,Xref)
g=model.aio;F=struct();F.g=g;F.Xref=Xref;F.Vref=g.L\GCF_kernel(g.X,Xref,g.ell);
end

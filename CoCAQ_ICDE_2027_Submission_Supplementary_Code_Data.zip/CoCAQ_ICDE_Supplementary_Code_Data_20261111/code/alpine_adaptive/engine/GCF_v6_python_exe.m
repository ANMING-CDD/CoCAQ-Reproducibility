function py=GCF_v6_python_exe(S)
py='';
if isfield(S,'pythonExe') && ~isempty(S.pythonExe)
 py=char(S.pythonExe);
else
 py=getenv('CASCADE_PYTHON_EXE');
 if isempty(py)
  py=fullfile(getenv('USERPROFILE'),'venvs','cascade-msbo','Scripts','python.exe');
 end
end
if exist(py,'file')~=2,py='';end
end

function K=GCF_kernel(X,Q,ell)
% Unit-variance ARD squared-exponential kernel.
if isempty(X)||isempty(Q),K=zeros(size(X,1),size(Q,1));return;end
Xs=bsxfun(@rdivide,X,ell(:)');Qs=bsxfun(@rdivide,Q,ell(:)');
d2=max(0,bsxfun(@plus,sum(Xs.^2,2),sum(Qs.^2,2)')-2*(Xs*Qs'));
K=exp(-0.5*d2);
end

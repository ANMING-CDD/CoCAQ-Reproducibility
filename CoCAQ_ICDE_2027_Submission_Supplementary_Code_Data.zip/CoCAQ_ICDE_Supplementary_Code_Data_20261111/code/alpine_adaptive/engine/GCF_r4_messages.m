function M=GCF_r4_messages(F,draft,useComm)
% Bidirectional stage messages from an EXOGENOUS full-input draft.
% Forward: stage GP mean/uncertainty. Backward: downstream sensitivity and
% terminal-focused uncertainty contributions. No true intermediate y.
N=size(draft,1);K=F.K;
[mu,v,~,~,dprev]=GCF_cascade_predict(F.model,F.spec,draft);
s=zeros(N,K);s(:,K)=1;
for k=K-1:-1:1
 s(:,k)=s(:,k+1).*dprev{k+1};
end
s=max(-1e4,min(1e4,s));
impact=max(v,0).*(s.^2);
importance=bsxfun(@rdivide,impact,max(sum(impact,2),1e-12));
% Neighbor-to-neighbor backward feedback, explicitly aggregated from
% downstream importance. A downstream stage can ask upstream agents to
% target its uncertainty through sensitivity propagation.
pressure=zeros(N,K);
for k=K-1:-1:1
 pressure(:,k)=importance(:,k+1)+ ...
  min(1,abs(dprev{k+1})).*pressure(:,k+1);
end
pressure=max(0,min(1,pressure));
forwardMu=zeros(N,K);forwardStd=zeros(N,K);
for k=1:K
 scale=max(F.model.stage{k}.ys,1e-8);
 forwardMu(:,k)=max(-5,min(5,(mu(:,k)-F.model.stage{k}.ym)/scale));
 forwardStd(:,k)=min(5,sqrt(v(:,k))/scale);
end
sNorm=bsxfun(@rdivide,s,max(1,max(abs(s),[],2)));
calibration=repmat(F.trust,N,1);
importance=importance.*calibration;
pressure=pressure.*calibration;
if ~useComm
 % Keep upstream GP prefix information, but remove reverse messages and
 % future-stage communication. This is the matched 'no communication' path.
 sNorm(:)=0;importance(:)=0;pressure(:)=0;
end
M=struct('draft',draft,'forwardMu',forwardMu, ...
 'forwardStd',forwardStd,'backSensitivity',sNorm, ...
 'terminalImportance',importance,'backPressure',pressure, ...
 'trust',calibration,'stageDims',F.spec.stageDims, ...
 'useComm',logical(useComm));
end

function [path,reason]=GCF_v6_resolve_acceptance(S,projectRoot)
% Resolve the OLD external frozen model project, without fabricating data.
% Accept either the project root or its results/ folder.
paths={};labels={};
if isfield(S,'acceptanceRoot') && ~isempty(S.acceptanceRoot)
 path=char(S.acceptanceRoot);
 if strcmpi(path(max(1,end-6):end),'results'),path=fileparts(path);end
 reason='explicit S.acceptanceRoot';return;
end
v=getenv('CASCADE_ACCEPTANCE_ROOT');
if ~isempty(v)
 path=v;
 if strcmpi(path(max(1,end-6):end),'results'),path=fileparts(path);end
 reason='CASCADE_ACCEPTANCE_ROOT environment';return;
end
par=fileparts(projectRoot);
paths=[paths,{projectRoot,par,fullfile(par,'CASCADE_CASE_ACCEPTANCE_MATLAB_R2024a'), ...
 fullfile(par,'CASCADE_CASE_ACCEPTANCE_MATLAB_R2024a','CASCADE_CASE_ACCEPTANCE_MATLAB_R2024a'), ...
 'C:\MAPPO\CASCADE_CASE_ACCEPTANCE_MATLAB_R2024a\CASCADE_CASE_ACCEPTANCE_MATLAB_R2024a'}];
labels=[labels,{'package','adjacent','adjacent acceptance','nested acceptance','legacy Windows default'}];
score=-inf;path='';reason='not found';
for i=1:numel(paths)
 p=paths{i};if isempty(p),continue;end
 if strcmpi(p(max(1,end-6):end),'results')
  p=fileparts(p);
 end
 if exist(p,'dir')~=7,continue;end
 count=0;
 shapes=[4 16;4 20;5 20;5 25];
 for j=1:4
  m=fullfile(p,'results',sprintf('frozen_MSBO_%dS_%dD_seed2026',shapes(j,1),shapes(j,2)),'source_manifest.json');
  count=count+(exist(m,'file')==2);
 end
 hasBridge=exist(fullfile(p,'python','source_bridge.py'),'file')==2;
 sc=count*10+double(hasBridge);
 if sc>score
  score=sc;path=p;reason=sprintf('%s, %d/4 MSBO manifests, bridge %d',labels{i},count,hasBridge);
 end
end
if isempty(path)
 if isfield(S,'acceptanceRoot') && ~isempty(S.acceptanceRoot)
  path=char(S.acceptanceRoot);reason='configured path does not currently exist';
 else
  path=projectRoot;reason='no external acceptance project found';
 end
end
end

function F = GCF_r4_build(model,spec,Xref,rank,nFantasy,seed)
% CoCAQ-R4 terminal-aware cascade acquisition (training GP data ONLY).
% Stochastic reference trajectories are GP posterior fantasies, not observed y.
% Frozen common random numbers ensure deterministic candidate ranking.
assert(strcmp(model.kind,'cascade'),'R4 requires stagewise cascade GP.');
assert(nFantasy>=1 && nFantasy<=20 && size(Xref,1)>=4);
F.fast=GCF_fastgi_build(model,spec,Xref,rank);
F.model=model; F.spec=spec; F.Xref=Xref;
F.nFantasy=nFantasy;F.K=spec.K;F.d=spec.d;
F.refQ=cell(nFantasy,spec.K);
F.refV=cell(nFantasy,spec.K);
F.refSens=zeros(size(Xref,1),spec.K,nFantasy);
F.refLocalV=zeros(size(Xref,1),spec.K,nFantasy);
F.trust=zeros(1,spec.K);
% Calibrate each stage via analytic leave-one-out standardized residuals.
% This uses ONLY collected training data; never held-out response labels.
for k=1:spec.K
 g=model.stage{k};n=size(g.X,1);
 Li=g.L\eye(n);
 invdiag=sum(Li.^2,1)';
 zloo=abs(g.alpha)./sqrt(max(invdiag,realmin));
 calib=sqrt(mean(min(zloo.^2,100)));
 F.trust(k)=max(.10,min(1,1/(1+max(0,calib-1)^2)));
end
rngBefore=rng; rng(double(seed),'twister');
omegaRef=randn(size(Xref,1),spec.K,nFantasy);
F.omegaCandidate=randn(nFantasy,spec.K);
rng(rngBefore);
for mm=1:nFantasy
 prev=[];prevJ=zeros(size(Xref,1),spec.d);dprev=zeros(size(Xref,1),spec.K);
 for k=1:spec.K
  [Q,~,prevIdx,prevScale]=GCF_stage_query(spec,Xref,k,prev,prevJ);
  g=model.stage{k};[mu,v]=GCF_gp_predict(g,Q);
  F.refQ{mm,k}=Q;
  F.refV{mm,k}=g.L\GCF_kernel(g.X,Q,g.ell);
  F.refLocalV(:,k,mm)=max(0,v);
  if k>1
   dprev(:,k)=prevScale*GCF_gp_dmean(g,Q,prevIdx);
  end
  prev=mu+sqrt(max(v,0)).*omegaRef(:,k,mm);
 end
 s=ones(size(Xref,1),1);F.refSens(:,spec.K,mm)=s;
 for k=spec.K-1:-1:1
  s=s.*dprev(:,k+1);
  F.refSens(:,k,mm)=max(-1e6,min(1e6,s));
 end
end
% The native Fast-Gi low-rank surrogate already contains nominal terminal
% sensitivities; this confidence/uncertainty correction is deliberately
% bounded to avoid double-counting propagation weights.
num=zeros(1,spec.K);den=zeros(1,spec.K);
[~,~,Q0]=GCF_cascade_predict(model,spec,Xref);
sNom=ones(size(Xref,1),spec.K);
for k=spec.K-1:-1:1
 [ix,scale]=localPrevCoordinate(spec,k+1);
 sNom(:,k)=sNom(:,k+1).*(scale*GCF_gp_dmean(model.stage{k+1},Q0{k+1},ix));
end
for k=1:spec.K
 for mm=1:nFantasy
  num(k)=num(k)+mean(F.refSens(:,k,mm).^2.*F.refLocalV(:,k,mm))/nFantasy;
 end
 [~,vv]=GCF_gp_predict(model.stage{k},Q0{k});
 den(k)=mean(sNom(:,k).^2.*vv);
end
ratio=sqrt((num+1e-10)./(den+1e-10));
F.stageWeight=max(.45,min(1.80,ratio.*sqrt(F.trust)));
F.stageWeight=F.stageWeight/max(mean(F.stageWeight),1e-12);
F.refAttribution=num/max(sum(num),1e-12);
F.kind='R4_MC_terminal_IVR_proxy_with_LOO_gate';
end

function [ix,sc]=localPrevCoordinate(spec,k)
idx=MSBO_stage_idx(spec,k);p=numel(idx);
if strcmp(spec.kind,'forrester') && k==2,ix=1;sc=.04;
elseif strcmp(spec.kind,'cascadebo_rosenbrock'),ix=1;sc=.5;
elseif strcmp(spec.kind,'bofn_alpine2'),ix=p+1;sc=10^(-(k-1)/2);
else,ix=p+1;sc=1;end
end

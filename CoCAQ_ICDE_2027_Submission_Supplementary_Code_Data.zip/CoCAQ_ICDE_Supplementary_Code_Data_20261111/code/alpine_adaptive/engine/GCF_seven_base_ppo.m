function [out,meta]=GCF_seven_base_ppo(evalFn,model,spec,budget,c,variant,seed)
% Seven-method pilot: truly independent PPO vs centralized multi-stage MAPPO.
% A3_IPPO: separate actor/critic/Adam per stage, local pre-action observations,
%          common team acquisition reward; no centralized critic.
% A4_MAPPO_PLUS: separate actors, shared GP-prefix multi-head centralized
%               critic; stabilized PPO updates.  No GP action prior,
%               no Fast-Gi gradient proposals in either method.
% Both optimize exactly the SAME GCF_chain_eval() objective as A2 CMA-ES,
% using the same quick-score budget and stage-wise action parameterization.
assert(any(strcmp(variant,{'A3_IPPO','A4_MAPPO_PLUS'})), 'Bad PPO variant');
assert(isfield(c,'nAnchors')&&budget>c.nAnchors&&c.batch>=2);
assert(isfield(c,'ppoTargetKL')&&isfield(c,'ppoMinEpoch'));
assert(c.uniformMix>=0 && c.uniformMix<1);
isIPPO=strcmp(variant,'A3_IPPO');
rng(seed,'twister');K=spec.K;d=spec.d;D=d+3*K;
nAnch=max(1,min(round(c.nAnchors),budget-1));
anchors=GCF_halton(nAnch,d,6000+seed);
[anchorR,anchorG]=evalFn(anchors);
anchorR=anchorR(:);
assert(numel(anchorR)==nAnch && size(anchorG,2)==K);
actor=cell(1,K);actorAdam=cell(1,K);sigAdam=cell(1,K);logSig=cell(1,K);
for k=1:K
 actor{k}=nn_init(D,c.hidden,spec.stageDims(k),c.nHiddenLayers);
 actorAdam{k}=[];sigAdam{k}=[];
 logSig{k}=log(c.sigma)*ones(1,spec.stageDims(k));
end
if isIPPO
 critic=cell(1,K);criticAdam=cell(1,K);
 for k=1:K
  critic{k}=nn_init(D,c.hidden,1,c.nHiddenLayers);
  criticAdam{k}=[];
 end
else
 critic=nn_init(D,c.hidden,K,c.nHiddenLayers);criticAdam=[];
end
st=struct('PPOUpdates',0,'PPOEarlyStops',0,'CriticUpdates',0, ...
 'KLSum',0,'KLCount',0,'KLMax',0,'ActorGradClips',0, ...
 'CriticGradClips',0,'SigmaSum',0,'SigmaCount',0, ...
 'criticMSE',[],'batchReward',[]);
out=struct('best',-inf,'bestX',nan(1,d),'allX',zeros(budget,d), ...
 'allG',zeros(budget,K),'allR',zeros(budget,1),'trace',zeros(budget,1), ...
 'stats',st);
[out.best,ix]=max(anchorR);out.bestX=anchors(ix,:);
out.allX(1:nAnch,:)=anchors;out.allG(1:nAnch,:)=anchorG;
out.allR(1:nAnch)=anchorR;out.trace(1:nAnch)=cummax(anchorR);
completed=nAnch;rewardScale=max(mean(abs(anchorR)),1e-10);
eps0=c.uniformMix;eta=0;
while completed<budget
 B=min(c.batch,budget-completed);
 X=zeros(B,d);S=cell(1,K);Z=cell(1,K);logOld=cell(1,K);
 for k=1:K
  jj=MSBO_stage_idx(spec,k);p=numel(jj);
  S{k}=localState(model,spec,X,k);
  mu=nn_forward(actor{k},S{k});Z{k}=zeros(B,p);
  for b=1:B
   if rand<eps0
    xx=rand(1,p);
   else
    zz=mu(b,:)+exp(logSig{k}).*randn(1,p);
    xx=1./(1+exp(-max(-22,min(22,zz))));
   end
   xx=max(1e-10,min(1-1e-10,xx));
   X(b,jj)=xx;Z{k}(b,:)=log(xx./(1-xx));
  end
  logOld{k}=GCF_ppo_stable_logpdf(Z{k},mu,exp(logSig{k}),eps0,eta,zeros(B,1));
 end
 [R,G]=evalFn(X);R=R(:);
 assert(numel(R)==B && size(G,1)==B && size(G,2)==K && all(isfinite(R)));
 for b=1:B
  completed=completed+1;out.allX(completed,:)=X(b,:);
  out.allG(completed,:)=G(b,:);out.allR(completed)=R(b);
  if R(b)>out.best,out.best=R(b);out.bestX=X(b,:);end
  out.trace(completed)=out.best;
 end
 % Group reward is the same across agents. IPPO has independent local critics.
 r=G/rewardScale;team=sum(r,2);
 adv=zeros(B,K);
 if isIPPO
  for k=1:K
   v=nn_forward(critic{k},S{k});adv(:,k)=team-v(:,1);
  end
 else
  allS=vertcat(S{:});P=nn_forward(critic,allS);
  [~,~,V]=localCentralLoss(P,r,c);
  adv(:,K)=team-V(:,K);
  for k=K-1:-1:1
   adv(:,k)=V(:,k+1)-V(:,k)+c.lambda*adv(:,k+1);
  end
 end
 for k=1:K
  sd=std(adv(:,k));
  if sd>1e-9
   adv(:,k)=(adv(:,k)-mean(adv(:,k)))/sd;
  else
   adv(:,k)=adv(:,k)-mean(adv(:,k));
  end
 end
 out.stats.batchReward(end+1,1)=mean(R);
 active=true(1,K);lastKL=zeros(1,K);
 for ep=1:c.nEpoch
  for k=1:K
   if ~active(k),continue;end
   [actor{k},logSig{k},actorAdam{k},sigAdam{k},kk,diag]= ...
    GCF_ppo_stable_step(actor{k},logSig{k},S{k},Z{k},logOld{k}, ...
     adv(:,k),eps0,eta,zeros(B,1),c,actorAdam{k},sigAdam{k});
   lastKL(k)=kk;
   out.stats.PPOUpdates=out.stats.PPOUpdates+1;
   out.stats.ActorGradClips=out.stats.ActorGradClips+diag.actorClipped;
   if kk>c.ppoTargetKL && ep>=c.ppoMinEpoch
    active(k)=false;out.stats.PPOEarlyStops=out.stats.PPOEarlyStops+1;
   end
  end
  if isIPPO
   for k=1:K
    pred=nn_forward(critic{k},S{k});e=pred(:,1)-team;
    gr=nn_backward(critic{k},S{k},2*e/B);
    [gr,clipped]=GCF_ppo_stable_clipgrad(gr,c.ppoCriticGradMaxNorm);
    out.stats.CriticGradClips=out.stats.CriticGradClips+clipped;
    [critic{k},criticAdam{k}]=nn_adam(critic{k},gr,criticAdam{k},c.criticLR);
    out.stats.CriticUpdates=out.stats.CriticUpdates+1;
    out.stats.criticMSE(end+1,1)=mean(e.^2);
   end
  else
   P=nn_forward(critic,allS);
   [loss,dP,~]=localCentralLoss(P,r,c);
   gr=nn_backward(critic,allS,dP);
   [gr,clipped]=GCF_ppo_stable_clipgrad(gr,c.ppoCriticGradMaxNorm);
   out.stats.CriticGradClips=out.stats.CriticGradClips+clipped;
   [critic,criticAdam]=nn_adam(critic,gr,criticAdam,c.criticLR);
   out.stats.CriticUpdates=out.stats.CriticUpdates+1;
   out.stats.criticMSE(end+1,1)=loss;
  end
  if ~any(active) && ep>=c.ppoMinEpoch,break;end
 end
 out.stats.KLSum=out.stats.KLSum+sum(lastKL);
 out.stats.KLCount=out.stats.KLCount+K;
 out.stats.KLMax=max(out.stats.KLMax,max(lastKL));
 for k=1:K
  out.stats.SigmaSum=out.stats.SigmaSum+sum(exp(logSig{k}));
  out.stats.SigmaCount=out.stats.SigmaCount+numel(logSig{k});
 end
end
out.actor=actor;out.critic=critic;out.logSig=logSig;
out.gpPriorActor=false;out.gpGradientRefine=false;
out.stats.MeanKL=out.stats.KLSum/max(1,out.stats.KLCount);
out.stats.MeanSigma=out.stats.SigmaSum/max(1,out.stats.SigmaCount);
out.stats.PPOVariant=variant;
meta=struct('RewardCalls',budget,'GradientCalls',0,'GradientSeconds',0, ...
 'OptimizationSeconds',NaN);
end

function S=localState(model,spec,X,k)
% Decentralized actor input: already selected prefix and predicted *prefix*
% cascade outputs. No real unobserved y and no future chosen actions.
B=size(X,1);K=spec.K;d=spec.d;S=zeros(B,d+3*K);
if k>1
 n=sum(spec.stageDims(1:k-1));S(:,1:n)=X(:,1:n);
 [Ym,Yv]=GCF_cascade_predict(model,spec,X);
 S(:,d+(1:k-1))=Ym(:,1:k-1);
 S(:,d+K+(1:k-1))=sqrt(max(0,Yv(:,1:k-1)));
end
S(:,d+2*K+k)=1;
end

function [loss,grad,V]=localCentralLoss(P,G,c)
% GP-prefix stage-aware multi-head critic from ORIGINAL A5, but evaluated
% on the traditional GCF_chain_eval objective, with NO GP action prior.
B=size(G,1);K=size(G,2);R=sum(G,2);
grad=zeros(size(P));V=zeros(B,K);loss=0;
known=zeros(B,K);
for k=2:K,known(:,k)=sum(G(:,1:k-1),2);end
aux=0;nValid=B*K*(K+1)/2;
for k=1:K
 ii=(k-1)*B+(1:B);
 V(:,k)=known(:,k)+sum(P(ii,k:K),2);
 e=V(:,k)-R;
 loss=loss+sum(e.^2)/(K*B);
 for j=k:K
  grad(ii,j)=grad(ii,j)+2*e/(K*B);
  ae=P(ii,j)-G(:,j);aux=aux+sum(ae.^2)/nValid;
  grad(ii,j)=grad(ii,j)+c.auxWeight*2*ae/nValid;
 end
end
loss=loss+c.auxWeight*aux;
end

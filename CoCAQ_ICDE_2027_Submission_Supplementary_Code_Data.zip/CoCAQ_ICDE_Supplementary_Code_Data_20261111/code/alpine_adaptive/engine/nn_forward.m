function [y,h]=nn_forward(net,X)
h1=tanh(X*net.W1+net.b1);
if isfield(net,'W3')
 h=tanh(h1*net.W2+net.b2);
 y=h*net.W3+net.b3;
else
 h=h1;
 y=h*net.W2+net.b2;
end
end

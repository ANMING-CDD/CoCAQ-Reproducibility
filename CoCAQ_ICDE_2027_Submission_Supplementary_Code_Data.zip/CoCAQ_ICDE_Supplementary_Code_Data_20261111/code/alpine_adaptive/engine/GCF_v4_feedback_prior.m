function [prior,nAdded]=GCF_v4_feedback_prior(prior,newX,newG,newGain,c)
% Update CONDITIONAL SAMPLING PRIOR, not the GP posterior.
% Anchors remain fixed; positive gradient improvements add bounded centers.
% No eval/grad calls and no new observations are generated here.
assert(size(newX,1)==size(newG,1) && numel(newGain)==size(newX,1));
assert(size(newX,2)==size(prior.anchorX,2));
assert(size(newG,2)==size(prior.anchorG,2));
assert(isequal(prior.X(1:prior.nAnchor,:),prior.anchorX));
newGain=newGain(:);
% Gains are divided by fixed per-round observed acquisition-value scale.
valid=isfinite(newGain) & newGain>max(c.v4MinGainFrac*prior.gainScale,1e-12) & ...
 all(isfinite(newX),2) & all(isfinite(newG),2);
nAdded=sum(valid);
if ~any(valid),return;end
newX=max(1e-10,min(1-1e-10,newX(valid,:)));
newG=newG(valid,:);
newGain=min(1,newGain(valid)./prior.gainScale);
X=[prior.feedbackX;newX];G=[prior.feedbackG;newG];gain=[prior.feedbackGain;newGain];
% Prefer high acquisition reward and demonstrated gradient improvements.
acq=sum(G,2);lo=min([sum(prior.anchorG,2);acq]);
span=max(max([sum(prior.anchorG,2);acq])-lo,1e-12);
quality=(acq-lo)/span;
rankScore=(1-c.v4GainPriority)*quality+c.v4GainPriority*gain;
[~,order]=sort(rankScore,'descend');
keep=zeros(0,1);
for ii=1:numel(order)
 j=order(ii);
 if isempty(keep),far=true;
 else
  dd=bsxfun(@minus,X(keep,:),X(j,:));
  minDist=min(sqrt(sum(dd.^2,2)/size(X,2)));
  far=minDist>=c.v4FeedbackMinDist;
 end
 if far,keep(end+1,1)=j;end %#ok<AGROW>
 if numel(keep)>=c.v4FeedbackCap,break;end
end
prior.feedbackX=X(keep,:);prior.feedbackG=G(keep,:);
prior.feedbackGain=gain(keep);
prior.X=[prior.anchorX;prior.feedbackX];
prior.G=[prior.anchorG;prior.feedbackG];
prior.boost=[zeros(prior.nAnchor,1); c.v4FeedbackLogWeight*prior.feedbackGain];
assert(size(prior.X,1)<=prior.nAnchor+c.v4FeedbackCap);
assert(all(isfinite(prior.boost)));
end

function [out,meta]=GCF_mappo_guided(evalFn,gradFn,model,spec,budget,c,variant,seed)
% R3: BUDGET-CONTROLLED, on-policy PPO + off-policy gradient TEACHER.
% Variants share exactly the same actor, critic, acquisition objective, seeds:
%   R3_BASE    : full MAPPO budget, no gradient proposals, no distillation.
%   R3_REFINE  : budget-matched multi-step Fast-Gi proposals; no distillation.
%   R3_GUIDED  : same proposals + score-gated supervised Actor distillation.
% Every evalFn row consumes exactly one acquisition-scoring call. gradFn
% uses analytic derivative of the SAME fixed GP surrogate, not true outputs.
% PPO's ratio/critic use ONLY actual on-policy draws, not teacher samples.
% The teacher's proposed full x is re-conditioned through predicted GP
% intermediate means/variances for each stage. Never treat true y as action.
assert(any(strcmp(variant,{'R3_BASE','R3_REFINE','R3_GUIDED'})), 'Unsupported variant');
useGrad=~strcmp(variant,'R3_BASE');
useGuide=strcmp(variant,'R3_GUIDED');
if useGrad,assert(~isempty(gradFn),'Guided model needs Fast-Gi gradient.');end
rng(seed,'twister');K=spec.K;d=spec.d;Fdim=d+3*K;stageDims=spec.stageDims;
assert(isfield(c,'nAnchors') && ~isempty(c.nAnchors));
assert(budget>=2 && c.batch>=4 && c.gradPerBatch>=0);
assert(c.priorMix>=0 && c.uniformMix>=0 && c.priorMix+c.uniformMix<1);
assert(c.r3DistillWeight>=0 && c.r3DistillWeight<=1);
steps=c.r3StepGrid(:)';
assert(numel(steps)==2 && all(isfinite(steps)) && all(steps>0));
nAnch=max(1,min(round(c.nAnchors),budget-1));
anchors=GCF_halton(nAnch,d,6000+seed);
[anchorR,anchorG]=evalFn(anchors);anchorR=anchorR(:);
prior=struct('X',anchors,'G',anchorG,'c',c,'nAnchor',nAnch, ...
    'anchorX',anchors,'anchorG',anchorG,'stageDims',stageDims, ...
    'feedbackX',zeros(0,d),'feedbackG',zeros(0,K), ...
    'feedbackGain',zeros(0,1),'boost',zeros(nAnch,1));
actor=cell(1,K);netAdam=cell(1,K);sigAdam=cell(1,K);logSig=cell(1,K);
for k=1:K
 p=stageDims(k);actor{k}=nn_init(Fdim,c.hidden,p,c.nHiddenLayers);
 logSig{k}=log(c.sigma)*ones(1,p);
end
critic=nn_init(Fdim,c.hidden,K,c.nHiddenLayers);criticAdam=[];
st=struct('gradientCalls',0,'gradientTime',0,'gradTrials',0, ...
 'gradAccepted',0,'gradientGain',zeros(0,1),'gradientSuccess',0, ...
 'teacherPairs',0,'distillUpdates',0,'distillLoss',zeros(0,1), ...
 'startsFromCurrent',0,'startsFromHistory',0, ...
 'chosenFromGradient',0,'bestSource',0, ...
 'criticMSE',zeros(0,1),'batchReward',zeros(0,1));
out=struct('best',-inf,'bestX',nan(1,d),'allX',zeros(budget,d), ...
 'allG',zeros(budget,K),'allR',zeros(budget,1),'trace',zeros(budget,1),'stats',st);
[best,ix]=max(anchorR);out.best=best;out.bestX=anchors(ix,:);
out.allX(1:nAnch,:)=anchors;out.allG(1:nAnch,:)=anchorG;
out.allR(1:nAnch)=anchorR;out.trace(1:nAnch)=cummax(anchorR);
completed=nAnch;rewardScale=max(mean(abs(anchorR)),1e-10);
while completed<budget
 B=min(c.batch,budget-completed);
 % Each start uses exactly two reward-scored step candidates; score count
 % is constrained. More gradient trials therefore REDUCE PPO trajectories.
 nStarts=0;
 if useGrad && B>=8
  nStarts=min(floor(c.gradPerBatch/numel(steps)),floor((B-4)/numel(steps)));
 end
 nGrad=nStarts*numel(steps);Bpol=B-nGrad;
 frac=(completed-nAnch)/max(1,budget-nAnch);
 eta=c.priorMix*(1-.5*frac);eps0=c.uniformMix;
 priorBatch=prior; % fixed prior throughout a PPO update batch
 X=zeros(Bpol,d);S=cell(1,K);Z=cell(1,K);logOld=cell(1,K);qD=cell(1,K);
 for k=1:K
  p=stageDims(k);jj=MSBO_stage_idx(spec,k);
  S{k}=GCF_state_features(model,spec,X,k);
  mu=nn_forward(actor{k},S{k});Z{k}=zeros(Bpol,p);qD{k}=zeros(Bpol,1);
  for b=1:Bpol
   prefix=X(b,1:(jj(1)-1));
   [xx,zz]=GCF_policy_sample(mu(b,:),exp(logSig{k}),eps0,eta,priorBatch,k,prefix,p);
   X(b,jj)=xx;Z{k}(b,:)=zz;
   qD{k}(b)=GCF_policy_qpdf(priorBatch,k,prefix,xx,p);
  end
  logOld{k}=GCF_policy_logpdf(Z{k},mu,exp(logSig{k}),eps0,eta,qD{k});
 end
 [R,G]=evalFn(X);R=R(:);
 batchX=X;batchR=R;batchG=G;
 teacherX=zeros(0,d);teacherParent=zeros(0,d);teacherGain=zeros(0,1);
 if nStarts>0
  poolX=[X;out.allX(1:completed,:)];poolR=[R;out.allR(1:completed)];
  fresh=[true(Bpol,1);false(completed,1)];
  [j,si]=GCF_v4_select_starts(poolX,poolR,fresh,nStarts,c);
  parent=poolX(j,:);parentR=poolR(j);
  out.stats.startsFromCurrent=out.stats.startsFromCurrent+si.current;
  out.stats.startsFromHistory=out.stats.startsFromHistory+si.history;
  t0=tic;dg=gradFn(parent);out.stats.gradientTime=out.stats.gradientTime+toc(t0);
  assert(isequal(size(dg),size(parent)),'Gradient shape mismatch');
  out.stats.gradientCalls=out.stats.gradientCalls+nStarts;
  normG=sqrt(sum(dg.^2,2));
  good=isfinite(normG)&normG>c.r3MinGradNorm & all(isfinite(dg),2);
  unit=zeros(size(dg));unit(good,:)=bsxfun(@rdivide,dg(good,:),normG(good));
  proposal=zeros(nGrad,d);
  for a=1:nStarts
   for t=1:numel(steps)
    ix=(a-1)*numel(steps)+t;
    if good(a)
     proposal(ix,:)=parent(a,:)+steps(t)*unit(a,:);
    else
     % Fallback is a bounded local random candidate; it is NEVER a teacher.
     v=randn(1,d);v=v/max(norm(v),1e-12);
     proposal(ix,:)=parent(a,:)+steps(t)*v;
    end
   end
  end
  proposal=max(1e-8,min(1-1e-8,proposal));
  [rg,gg]=evalFn(proposal);rg=rg(:);
  out.stats.gradTrials=out.stats.gradTrials+nGrad;
  batchX=[batchX;proposal];batchR=[batchR;rg];batchG=[batchG;gg];
  for a=1:nStarts
   ids=(a-1)*numel(steps)+(1:numel(steps));
   [bestTrial,ind]=max(rg(ids));
   gain=bestTrial-parentR(a);
   out.stats.gradientGain(end+1,1)=gain;
   if good(a) && isfinite(gain) && gain> ...
          c.r3TeacherMinRelativeGain*max(abs(parentR(a)),1e-12)
    out.stats.gradAccepted=out.stats.gradAccepted+1;
    teacherX(end+1,:)=proposal(ids(ind),:); %#ok<AGROW>
    teacherParent(end+1,:)=parent(a,:); %#ok<AGROW>
    teacherGain(end+1,1)=gain; %#ok<AGROW>
   end
  end
  out.stats.gradientSuccess=out.stats.gradAccepted;
 end
 assert(numel(batchR)==B && size(batchX,1)==B, 'Acquisition score budget mismatch');
 for b=1:B
  completed=completed+1;
  out.allX(completed,:)=batchX(b,:);
  out.allG(completed,:)=batchG(b,:);
  out.allR(completed)=batchR(b);
  if batchR(b)>out.best
   out.best=batchR(b);out.bestX=batchX(b,:);
   if b<=Bpol,out.stats.bestSource=1;
   else,out.stats.bestSource=2;end
  end
  out.trace(completed)=out.best;
 end
 r=G/rewardScale;total=sum(r,2);known=zeros(Bpol,K);
 for k=2:K,known(:,k)=sum(r(:,1:k-1),2);end
 allS=vertcat(S{:});pred=nn_forward(critic,allS);
 [~,~,V]=GCF_critic_loss(pred,r,known,c,true);
 adv=zeros(Bpol,K);adv(:,K)=total-V(:,K);
 for k=K-1:-1:1
  adv(:,k)=V(:,k+1)-V(:,k)+c.lambda*adv(:,k+1);
 end
 for k=1:K
  sd=std(adv(:,k));
  if sd>1e-9,adv(:,k)=(adv(:,k)-mean(adv(:,k)))/sd;
  else,adv(:,k)=adv(:,k)-mean(adv(:,k));end
 end
 out.stats.batchReward(end+1,1)=mean(batchR);
 teacherS=cell(1,K);teacherZ=cell(1,K);teacherW=cell(1,K);
 w=zeros(0,1);
 if useGuide && ~isempty(teacherGain)
  % Weight ONLY strictly improved surrogate targets; bounded and normalized
  % within this small batch. No claimed test-RMSE labels are involved.
  w=min(1,teacherGain/max(max(teacherGain),realmin));
  out.stats.teacherPairs=out.stats.teacherPairs+numel(w);
  for k=1:K
   jj=MSBO_stage_idx(spec,k);
   teacherS{k}=GCF_state_features(model,spec,teacherX,k);
   x=max(1e-8,min(1-1e-8,teacherX(:,jj)));
   teacherZ{k}=log(x./(1-x));
   % Stage-specific direction: avoid teaching stages barely moved by Gi.
   stageMove=sqrt(sum((teacherX(:,jj)-teacherParent(:,jj)).^2,2));
   fullMove=sqrt(sum((teacherX-teacherParent).^2,2));
   teacherW{k}=w.*min(1,stageMove./max(fullMove,1e-12));
  end
 end
 for ep=1:c.nEpoch
  for k=1:K
   [actor{k},logSig{k},netAdam{k},sigAdam{k},dLoss]= ...
    GCF_guided_ppo_step(actor{k},logSig{k},S{k},Z{k},logOld{k}, ...
      adv(:,k),eps0,eta,qD{k},c,netAdam{k},sigAdam{k}, ...
      teacherS{k},teacherZ{k},teacherW{k},useGuide);
   if dLoss>0
    out.stats.distillUpdates=out.stats.distillUpdates+1;
    out.stats.distillLoss(end+1,1)=dLoss;
   end
  end
  pred=nn_forward(critic,allS);
  [loss,dPred,~]=GCF_critic_loss(pred,r,known,c,true);
  cg=nn_backward(critic,allS,dPred);
  [critic,criticAdam]=nn_adam(critic,cg,criticAdam,c.criticLR);
  out.stats.criticMSE(end+1,1)=loss;
 end
end
out.actor=actor;out.critic=critic;out.logSig=logSig;
out.gpPriorActor=true;out.gpPrefixCritic=true;
meta=struct('RewardCalls',budget,'GradientCalls',out.stats.gradientCalls, ...
 'GradientSeconds',out.stats.gradientTime,'GradTrials',out.stats.gradTrials, ...
 'GradAccepted',out.stats.gradAccepted,'TeacherPairs',out.stats.teacherPairs, ...
 'DistillUpdates',out.stats.distillUpdates, ...
 'GradientChosen',double(out.stats.bestSource==2), ...
 'OptimizationSeconds',NaN);
end

function S=GCF_state_features(model,spec,X,k)
B=size(X,1);K=spec.K;d=spec.d;S=zeros(B,d+3*K);
if k>1
 nPrefix=sum(spec.stageDims(1:k-1));S(:,1:nPrefix)=X(:,1:nPrefix);
 [Ym,Yv]=GCF_cascade_predict(model,spec,X);
 S(:,d+(1:k-1))=Ym(:,1:k-1);
 S(:,d+K+(1:k-1))=sqrt(max(0,Yv(:,1:k-1)));
end
S(:,d+2*K+k)=1;
end
function [x,z]=GCF_policy_sample(mu,sigma,eps0,eta,prior,k,prefix,p)
u=rand;
if u<eta,x=GCF_policy_qsample(prior,k,prefix,p);
elseif u<eta+eps0,x=rand(1,p);
else,z0=mu+sigma.*randn(1,p);x=1./(1+exp(-max(-22,min(22,z0))));end
x=max(1e-10,min(1-1e-10,x));z=log(x./(1-x));
end
function w=GCF_policy_qweights(prior,k,prefix)
val=sum(prior.G(:,k:end),2);scale=max(max(val)-min(val),1e-12);
logw=(val-max(val))/(prior.c.priorTemp*scale);
if isfield(prior,'boost'),logw=logw+prior.boost;end
if ~isempty(prefix),dd=bsxfun(@minus,prior.X(:,1:numel(prefix)),prefix);logw=logw-sum(dd.^2,2)/(2*prior.c.priorH^2);end
logw=logw-max(logw);w=exp(logw);w=w/sum(w);
end
function x=GCF_policy_qsample(prior,k,prefix,p)
w=GCF_policy_qweights(prior,k,prefix);j=find(rand<=cumsum(w),1,'first');
if isempty(j),j=numel(w);end
jj=MSBO_stage_idx(prior,k);center=prior.X(j,jj);h=prior.c.priorWidth/2;
lo=max(0,center-h);hi=min(1,center+h);x=lo+rand(1,p).*(hi-lo);
end
function q=GCF_policy_qpdf(prior,k,prefix,x,p)
w=GCF_policy_qweights(prior,k,prefix);jj=MSBO_stage_idx(prior,k);C=prior.X(:,jj);h=prior.c.priorWidth/2;
lo=max(0,C-h);hi=min(1,C+h);inside=all(bsxfun(@ge,x,lo)&bsxfun(@le,x,hi),2);
vol=prod(hi-lo,2);q=sum(w(inside)./vol(inside));
end
function [logp,resp]=GCF_policy_logpdf(z,mu,sigma,eps0,eta,q)
x=1./(1+exp(-max(-22,min(22,z))));
logG=-sum(.5*((z-mu)./sigma).^2+log(sigma)+.5*log(2*pi)+log(max(x.*(1-x),1e-25)),2);
logP=log(max(1-eta-eps0,realmin))+logG;logU=log(max(eta*q+eps0,realmin));
m=max(logP,logU);logp=m+log(exp(logP-m)+exp(logU-m));resp=exp(logP-logp);
end
function [loss,grad,V]=GCF_critic_loss(P,G,known,c,gpAware)
B=size(G,1);K=size(G,2);R=sum(G,2);grad=zeros(size(P));V=zeros(B,K);loss=0;
if ~gpAware
 for k=1:K
  ii=(k-1)*B+(1:B);V(:,k)=P(ii,1);e=V(:,k)-R;
  loss=loss+sum(e.^2)/(K*B);grad(ii,1)=2*e/(K*B);
 end
 return;
end
aux=0;nValid=B*K*(K+1)/2;
for k=1:K
 ii=(k-1)*B+(1:B);V(:,k)=known(:,k)+sum(P(ii,k:K),2);e=V(:,k)-R;
 loss=loss+sum(e.^2)/(K*B);
 for j=k:K
  grad(ii,j)=grad(ii,j)+2*e/(K*B);
  ae=P(ii,j)-G(:,j);aux=aux+sum(ae.^2)/nValid;
  grad(ii,j)=grad(ii,j)+c.auxWeight*2*ae/nValid;
 end
end
loss=loss+c.auxWeight*aux;
end
function [net,ls,adamNet,adamSig,teacherLoss]=GCF_guided_ppo_step( ...
  net,ls,S,Z,logOld,A,eps0,eta,q,c,adamNet,adamSig,T,Tz,Tw,useGuide)
% PPO ratio is computed for original on-policy samples ONLY.
% Teacher term is weighted, supervised Gaussian-component action regression.
% Gradient-proposed actions are NOT inserted into PPO's importance ratio.
mu=nn_forward(net,S);sigma=exp(ls);
[logNew,resp]=GCF_policy_logpdf(Z,mu,sigma,eps0,eta,q);
ratio=exp(max(-25,min(25,logNew-logOld)));
active=~((A>=0&ratio>1+c.clip)|(A<0&ratio<1-c.clip));
base=-A.*ratio.*active/numel(A);
gMu=bsxfun(@times,base.*resp,(Z-mu)./(sigma.^2));
gSig=sum(bsxfun(@times,base.*resp,((Z-mu).^2./(sigma.^2)-1)),1);
g=nn_backward(net,S,gMu);
teacherLoss=0;
if useGuide && ~isempty(T) && c.r3DistillWeight>0
  targetMu=nn_forward(net,T);
  resid=bsxfun(@rdivide,targetMu-Tz,sigma.^2);
  % Limit any one teacher direction from overwhelming PPO's own gradient.
  rowNorm=sqrt(sum(resid.^2,2));
  rowScale=min(1,c.r3TeacherRowClip./max(rowNorm,1e-12));
  resid=bsxfun(@times,resid,Tw.*rowScale/max(sum(Tw),realmin));
  teacherLoss=mean(sum(bsxfun(@times,(targetMu-Tz).^2,Tw),2));
  gt=nn_backward(net,T,resid);
  fn=fieldnames(g);
  for i=1:numel(fn)
    f=fn{i};g.(f)=g.(f)+c.r3DistillWeight*gt.(f);
  end
end
[net,adamNet]=nn_adam(net,g,adamNet,c.actorLR);
if isempty(adamSig)
 adamSig=struct('t',0,'m',zeros(size(ls)),'v',zeros(size(ls)));
end
adamSig.t=adamSig.t+1;
gSig=max(-10,min(10,gSig));
adamSig.m=.9*adamSig.m+.1*gSig;
adamSig.v=.999*adamSig.v+.001*gSig.^2;
ls=ls-c.actorLR*(adamSig.m/(1-.9^adamSig.t))./ ...
 (sqrt(adamSig.v/(1-.999^adamSig.t))+1e-8);
ls=max(log(c.minSigma),min(log(c.maxSigma),ls));
end

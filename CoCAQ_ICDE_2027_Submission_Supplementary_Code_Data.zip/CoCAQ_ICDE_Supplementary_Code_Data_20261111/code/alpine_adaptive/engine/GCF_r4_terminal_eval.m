function [score,stageScores] = GCF_r4_terminal_eval(F,X)
% Goal-oriented fantasy variance reduction at terminal y_K.
% For each candidate x, integrate (via common-random-number fantasies)
% the downstream stage input uncertainty. For each stage k, the update
% from observing one COMPLETE cascade is approximated by a rank-one GP
% posterior reduction at reference points, weighted by sampled downstream
% sensitivity squared. This is a first-order approximation, NOT true RMSE.
N=size(X,1);K=F.K;M=F.nFantasy;
stageScores=zeros(N,K);
for mm=1:M
 prev=zeros(N,1);
 for k=1:K
  [Qc,~,~,~]=GCF_stage_query(F.spec,X,k,prev,zeros(N,F.d));
  g=F.model.stage{k};Qr=F.refQ{mm,k};
  Kc=GCF_kernel(g.X,Qc,g.ell);Vq=g.L\Kc;
  Vr=F.refV{mm,k};
  vc=g.ys^2*max(0,1-sum(Vq.^2,1)');
  cross=g.ys^2*(GCF_kernel(Qr,Qc,g.ell)-Vr'*Vq);
  weight=F.refSens(:,k,mm).^2;
  reduction=(weight'*cross.^2)'/size(Qr,1);
  scoreK=reduction./max(vc+g.ys^2*g.jitter,1e-12*g.ys^2);
  stageScores(:,k)=stageScores(:,k)+scoreK/M;
  mu=g.ym+g.ys*(Kc'*g.alpha);
  prev=mu+sqrt(vc).*F.omegaCandidate(mm,k);
 end
end
score=sum(stageScores,2);
assert(all(isfinite(score)),'Nonfinite R4 terminal fantasy scores.');
end

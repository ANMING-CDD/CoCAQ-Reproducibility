function g=GCF_gp_fit(X,y,previous)
% Self-contained standardized-output ARD-RBF GP with warm-start ML-II fit.
if nargin<3,previous=[];end
y=y(:);assert(size(X,1)==numel(y)&&all(isfinite(X(:)))&&all(isfinite(y)));
g=struct();g.X=X;g.ym=mean(y);g.ys=std(y);
if ~isfinite(g.ys)||g.ys<1e-9,g.ys=1;end
z=(y-g.ym)/g.ys;d=size(X,2);
if ~isempty(previous)&&isfield(previous,'ell')&&numel(previous.ell)==d
 starts=[previous.ell(:)';.2*ones(1,d);.6*ones(1,d)];
else
 starts=[.14*ones(1,d);.35*ones(1,d);.7*ones(1,d)];
end
opts=optimset('Display','off','MaxIter',45,'MaxFunEvals',220,'TolX',.02);
best=inf;ell=starts(1,:);
for j=1:size(starts,1)
 [zz,val]=fminsearch(@(v)local_nll(v,X,z),log(starts(j,:)),opts);
 if isfinite(val)&&val<best,best=val;ell=exp(max(log(.025),min(log(2),zz(:)')));end
end
g.ell=ell;g.nll=best;g.jitter=1e-8;
K=GCF_kernel(X,X,ell);[L,p]=chol(K+g.jitter*eye(size(X,1)),'lower');
if p~=0
 g.jitter=1e-6;[L,p]=chol(K+g.jitter*eye(size(X,1)),'lower');
end
assert(p==0,'GCF GP covariance Cholesky failed.');
g.L=L;g.alpha=L'\(L\z);
end
function val=local_nll(t,X,z)
ell=exp(t(:)');if any(ell<.025)||any(ell>2),val=1e6+sum(t.^2);return;end
try
 K=GCF_kernel(X,X,ell);L=chol(K+1e-8*eye(size(X,1)),'lower');a=L'\(L\z);
 val=.5*(z'*a)+sum(log(diag(L)))+.5*numel(z)*log(2*pi);
catch,val=1e9;end
end

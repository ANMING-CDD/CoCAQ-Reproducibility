function Q=GCF_stage_input(spec,X,Y,k)
% Training inputs for stage k use measured preceding-stage scalar output.
if strcmp(spec.kind,'horizontal_ackley_dag')
 if k<=2,Q=X;else,Q=Y(:,1:2);end
 return;
end
if strcmp(spec.kind,'horizontal_rosen')
 idx=MSBO_stage_idx(spec,k);
 if k==1
  Q=X(:,idx);
 else
  Q=[X(:,[idx(1)-1 idx]),spec.rosenPrevScale*Y(:,k-1)];
 end
 return;
end
idx=MSBO_stage_idx(spec,k);
if k==1,Q=X(:,idx);return;end
prev=Y(:,k-1);
if strcmp(spec.kind,'forrester')
 Q=[.04*prev(:)+1/3,X(:,idx)];
elseif strcmp(spec.kind,'cascadebo_rosenbrock')
 % Source-faithful truth output is in [-2,2]; normalize this GP input coordinate.
 Q=[0.5*prev(:),X(:,idx)];
elseif strcmp(spec.kind,'horizontal_ackmat')
 Q=[X(:,idx),.05*prev(:)];
elseif strcmp(spec.kind,'bofn_alpine2')
 % |sqrt(x)sin(x)| <= sqrt(10) on [0,10], hence |y_(k-1)| <= 10^((k-1)/2).
 % This is only a GP input-coordinate normalization; the truth chain is unscaled.
 prevScale=10^(-(k-1)/2);
 Q=[X(:,idx),prevScale*prev(:)];
else
 Q=[X(:,idx),prev(:)];
end
end

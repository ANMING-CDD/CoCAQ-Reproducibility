function [out,meta]=GCF_cmaes(evalFn,gradFn,budget,d,c,seed)
% Dimension-generic bounded CMA-ES; gradient proposals replace scored candidates.
rng(seed,'twister');
if isfield(c,'cmaesRestarts'),nRestarts=max(1,round(c.cmaesRestarts));else,nRestarts=3;end
if isfield(c,'cmaesPopScale'),popScale=c.cmaesPopScale;else,popScale=1;end
if isfield(c,'cmaesSigma0'),sigma0=c.cmaesSigma0;else,sigma0=1.1;end
alloc=floor(budget/nRestarts)*ones(1,nRestarts);
alloc(1:mod(budget,nRestarts))=alloc(1:mod(budget,nRestarts))+1;
out=struct('best',-inf,'bestX',nan(1,d),'allX',zeros(budget,d), ...
 'allG',[],'allR',zeros(budget,1),'trace',zeros(budget,1));
meta=struct('RewardCalls',0,'GradientCalls',0,'GradientSeconds',0,'OptimizationSeconds',0);
tAll=tic;pos=0;
for rr=1:nRestarts
 lambda=max(8,round(popScale*(4+floor(3*log(max(d,2))))));muN=floor(lambda/2);
 w=log(muN+.5)-log(1:muN);w=w/sum(w);mueff=1/sum(w.^2);
 cc=(4+mueff/d)/(d+4+2*mueff/d);cs=(mueff+2)/(d+mueff+5);
 c1=2/((d+1.3)^2+mueff);cmu=min(1-c1,2*(mueff-2+1/mueff)/((d+2)^2+mueff));
 damps=1+2*max(0,sqrt((mueff-1)/(d+1))-1)+cs;
 chi=sqrt(d)*(1-1/(4*d)+1/(21*d^2));
 if rr==1,meanZ=zeros(d,1);else,meanZ=randn(d,1)*.8;end
 sigma=sigma0;C=eye(d);pc=zeros(d,1);ps=zeros(d,1);gen=0;kdone=0;
 while kdone<alloc(rr)
  gen=gen+1;[Q,D]=eig((C+C')/2);dd=sqrt(max(diag(D),1e-12));B=Q*diag(dd);
  draw=min(lambda,alloc(rr)-kdone);Z=meanZ+sigma*B*randn(d,draw);
  X=1./(1+exp(-max(-18,min(18,Z'))));
  if ~isempty(gradFn)&&pos>=1&&draw>=4
   ng=min(c.gradPerBatch,draw-2);
   if isfield(c,'gradElitePool'),poolSize=c.gradElitePool;else,poolSize=5;end
   [~,eliteOrder]=sort(out.allR(1:pos),'descend');
   elite=eliteOrder(1:min(pos,max(1,poolSize)));
   parent=out.allX(elite(randi(numel(elite),ng,1)),:);
   tg=tic;dg=gradFn(parent);meta.GradientSeconds=meta.GradientSeconds+toc(tg);
   meta.GradientCalls=meta.GradientCalls+ng;
   gn=sqrt(sum(dg.^2,2));proposal=max(1e-8,min(1-1e-8,parent+c.gradStep*bsxfun(@rdivide,dg,max(gn,1e-20))));
   X(end-ng+1:end,:)=proposal;Z(:,end-ng+1:end)=log(proposal'./(1-proposal'));
  end
  [val,G]=evalFn(X);val=val(:);
  if isempty(out.allG),out.allG=zeros(budget,size(G,2));end
  for j=1:draw
   pos=pos+1;kdone=kdone+1;out.allX(pos,:)=X(j,:);out.allG(pos,:)=G(j,:);out.allR(pos)=val(j);
   if val(j)>out.best,out.best=val(j);out.bestX=X(j,:);end
   out.trace(pos)=out.best;
  end
  if draw>=muN
   [~,ix]=sort(val,'descend');ix=ix(1:muN);old=meanZ;meanZ=Z(:,ix)*w';y=(meanZ-old)/sigma;
   invS=Q*diag(1./dd)*Q';ps=(1-cs)*ps+sqrt(cs*(2-cs)*mueff)*invS*y;
   hsig=norm(ps)/sqrt(1-(1-cs)^(2*gen))/chi<(1.4+2/(d+1));
   pc=(1-cc)*pc+hsig*sqrt(cc*(2-cc)*mueff)*y;
   sel=(Z(:,ix)-old)/sigma;C=(1-c1-cmu)*C+c1*(pc*pc'+(1-hsig)*cc*(2-cc)*C)+cmu*(sel.*w)*sel';
   C=(C+C')/2+1e-12*eye(d);sigma=min(3,max(.03,sigma*exp((cs/damps)*(norm(ps)/chi-1))));
  end
 end
end
meta.RewardCalls=pos;meta.OptimizationSeconds=toc(tAll);
assert(pos==budget,'CMA-ES scored %d candidates, expected %d.',pos,budget);
end

function [net,adam]=nn_adam(net,grad,adam,lr)
fields={'W1','b1','W2','b2'};
if isfield(net,'W3'),fields=[fields,{'W3','b3'}];end
if isempty(adam)
 adam.t=0;
 for i=1:numel(fields)
  f=fields{i};adam.m.(f)=zeros(size(net.(f)));adam.v.(f)=zeros(size(net.(f)));
 end
end
adam.t=adam.t+1;
for i=1:numel(fields)
 f=fields{i};g=max(-10,min(10,grad.(f)));
 adam.m.(f)=.9*adam.m.(f)+.1*g;
 adam.v.(f)=.999*adam.v.(f)+.001*(g.^2);
 net.(f)=net.(f)-lr*(adam.m.(f)/(1-.9^adam.t))./ ...
    (sqrt(adam.v.(f)/(1-.999^adam.t))+1e-8);
end
end

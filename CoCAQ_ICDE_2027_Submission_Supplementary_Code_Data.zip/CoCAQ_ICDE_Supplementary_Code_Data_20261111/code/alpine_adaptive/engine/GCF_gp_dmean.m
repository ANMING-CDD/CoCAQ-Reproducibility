function d=GCF_gp_dmean(g,Q,j)
% Analytic derivative of posterior mean with respect to query coordinate j.
K=GCF_kernel(g.X,Q,g.ell);
DX=bsxfun(@minus,g.X(:,j),Q(:,j)');
d=g.ys*sum(bsxfun(@times,g.alpha,K.*DX),1)'/(g.ell(j)^2);
end

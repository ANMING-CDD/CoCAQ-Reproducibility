function [g,clipped,gn]=GCF_ppo_stable_clipgrad(g,maxNorm)
% Global gradient norm clipping; nn_adam still has its original element cap.
fs=fieldnames(g);v=0;
for i=1:numel(fs)
 a=g.(fs{i});v=v+sum(a(:).^2);
end
gn=sqrt(v);clipped=double(gn>maxNorm && isfinite(gn));
if clipped
 f=maxNorm/max(gn,realmin);
 for i=1:numel(fs),g.(fs{i})=g.(fs{i})*f;end
end
end

function mu=GCF_predict_final(spec,model,X)
if strcmp(model.kind,'aio')
 mu=GCF_gp_predict(model.aio,X);
else
 [Ymu,~,~,~,~]=GCF_cascade_predict(model,spec,X);mu=Ymu(:,end);
end
mu=mu(:);assert(all(isfinite(mu)),'Nonfinite final-output prediction.');
end

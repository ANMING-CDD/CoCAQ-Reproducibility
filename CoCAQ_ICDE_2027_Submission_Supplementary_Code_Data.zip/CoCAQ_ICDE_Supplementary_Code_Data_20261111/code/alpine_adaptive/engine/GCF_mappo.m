function [out,meta]=GCF_mappo(evalFn,gradFn,model,spec,budget,c,variant,seed)
% Dimension-generic sequential MAPPO for arbitrary K-stage, p-control cascades.
% A4: shared state features + single-head Critic. A5: GP-prefix Critic + conditional GP action prior.
% A5GRAD: A5 plus analytic Fast-Gi gradient proposals; all proposals count in budget.
assert(any(strcmp(variant,{'A4','A5','A5GRAD'})));
useGP=~strcmp(variant,'A4');useGrad=strcmp(variant,'A5GRAD');
rng(seed,'twister');K=spec.K;d=spec.d;Fdim=d+3*K;stageDims=spec.stageDims;
if ~isfield(c,'nAnchors')||isempty(c.nAnchors)
 error('GCF_mappo:MissingNAnchors', ...
  'MAPPO config is missing nAnchors. RUN_FINAL_EXPERIMENTS injects cfg.nAnchors.');
end
assert(budget>=2,'MAPPO acquisition budget must be at least 2.');
nAnch=max(1,min(round(c.nAnchors),budget-1));
anchors=GCF_halton(nAnch,d,6000+seed);
[anchorR,anchorG]=evalFn(anchors);prior=struct('X',anchors,'G',anchorG,'c',c,'stageDims',stageDims);
actor=cell(1,K);netAdam=cell(1,K);sigAdam=cell(1,K);logSig=cell(1,K);
for k=1:K
 p=stageDims(k);actor{k}=nn_init(Fdim,c.hidden,p,c.nHiddenLayers);logSig{k}=log(c.sigma)*ones(1,p);
end
nHeads=1;if useGP,nHeads=K;end
critic=nn_init(Fdim,c.hidden,nHeads,c.nHiddenLayers);criticAdam=[];
out=struct('best',-inf,'bestX',nan(1,d),'allX',zeros(budget,d), ...
 'allG',zeros(budget,K),'allR',zeros(budget,1),'trace',zeros(budget,1), ...
 'stats',struct('gradientCalls',0,'gradientTime',0,'criticMSE',[],'batchReward',[]));
[best,ix]=max(anchorR);out.best=best;out.bestX=anchors(ix,:);
out.allX(1:nAnch,:)=anchors;out.allG(1:nAnch,:)=anchorG;out.allR(1:nAnch)=anchorR;
out.trace(1:nAnch)=cummax(anchorR);completed=nAnch;
rewardScale=max(mean(abs(anchorR)),1e-10);
while completed<budget
 B=min(c.batch,budget-completed);nGrad=0;
 if useGrad&&B>=4,nGrad=min(c.gradPerBatch,B-2);end
 Bpol=B-nGrad;frac=(completed-nAnch)/max(1,budget-nAnch);
 eta=0;if useGP,eta=c.priorMix*(1-.5*frac);end;eps0=c.uniformMix;
 X=zeros(Bpol,d);S=cell(1,K);Z=cell(1,K);logOld=cell(1,K);qD=cell(1,K);
 for k=1:K
  p=stageDims(k);jj=MSBO_stage_idx(spec,k);
  S{k}=GCF_state_features(model,spec,X,k);
  mu=nn_forward(actor{k},S{k});Z{k}=zeros(Bpol,p);qD{k}=zeros(Bpol,1);
  for b=1:Bpol
   prefix=X(b,1:(jj(1)-1));
   [xx,zz]=GCF_policy_sample(mu(b,:),exp(logSig{k}),eps0,eta,prior,k,prefix,p);
   X(b,jj)=xx;Z{k}(b,:)=zz;
   if useGP,qD{k}(b)=GCF_policy_qpdf(prior,k,prefix,xx,p);end
  end
  logOld{k}=GCF_policy_logpdf(Z{k},mu,exp(logSig{k}),eps0,eta,qD{k});
 end
 [R,G]=evalFn(X);R=R(:);batchX=X;batchR=R;batchG=G;
 if nGrad>0
  [~,ord]=sort(out.allR(1:completed),'descend');pool=ord(1:min(numel(ord),max(5,c.gradElitePool)));
  parent=out.allX(pool(randi(numel(pool),nGrad,1)),:);
  tg=tic;dg=gradFn(parent);out.stats.gradientTime=out.stats.gradientTime+toc(tg);
  out.stats.gradientCalls=out.stats.gradientCalls+nGrad;
  gn=sqrt(sum(dg.^2,2));proposal=max(1e-8,min(1-1e-8,parent+c.gradStep*bsxfun(@rdivide,dg,max(gn,1e-20))));
  [rg,gg]=evalFn(proposal);batchX=[batchX;proposal];batchR=[batchR;rg(:)];batchG=[batchG;gg];
 end
 for b=1:B
  completed=completed+1;out.allX(completed,:)=batchX(b,:);out.allG(completed,:)=batchG(b,:);out.allR(completed)=batchR(b);
  if batchR(b)>out.best,out.best=batchR(b);out.bestX=batchX(b,:);end
  out.trace(completed)=out.best;
 end
 r=G/rewardScale;total=sum(r,2);known=zeros(Bpol,K);
 for k=2:K,known(:,k)=sum(r(:,1:k-1),2);end
 allS=vertcat(S{:});pred=nn_forward(critic,allS);
 [loss,dPred,V]=GCF_critic_loss(pred,r,known,c,useGP);
 adv=zeros(Bpol,K);adv(:,K)=total-V(:,K);
 for k=K-1:-1:1,adv(:,k)=V(:,k+1)-V(:,k)+c.lambda*adv(:,k+1);end
 for k=1:K
  sd=std(adv(:,k));if sd>1e-9,adv(:,k)=(adv(:,k)-mean(adv(:,k)))/sd;else,adv(:,k)=adv(:,k)-mean(adv(:,k));end
 end
 out.stats.batchReward(end+1,1)=mean(batchR);
 for ep=1:c.nEpoch
  for k=1:K
   [actor{k},logSig{k},netAdam{k},sigAdam{k}]=GCF_ppo_step(actor{k},logSig{k},S{k},Z{k}, ...
     logOld{k},adv(:,k),eps0,eta,qD{k},c,netAdam{k},sigAdam{k});
  end
  pred=nn_forward(critic,allS);[loss,dPred,~]=GCF_critic_loss(pred,r,known,c,useGP);
  cg=nn_backward(critic,allS,dPred);[critic,criticAdam]=nn_adam(critic,cg,criticAdam,c.criticLR);
  out.stats.criticMSE(end+1,1)=loss;
 end
end
out.actor=actor;out.critic=critic;out.logSig=logSig;out.gpPriorActor=useGP;out.gpPrefixCritic=useGP;
meta=struct('RewardCalls',budget,'GradientCalls',out.stats.gradientCalls, ...
 'GradientSeconds',out.stats.gradientTime,'OptimizationSeconds',NaN);
end

function S=GCF_state_features(model,spec,X,k)
B=size(X,1);K=spec.K;d=spec.d;S=zeros(B,d+3*K);
if k>1
 nPrefix=sum(spec.stageDims(1:k-1));S(:,1:nPrefix)=X(:,1:nPrefix);
 [Ym,Yv]=GCF_cascade_predict(model,spec,X);
 S(:,d+(1:k-1))=Ym(:,1:k-1);
 S(:,d+K+(1:k-1))=sqrt(max(0,Yv(:,1:k-1)));
end
S(:,d+2*K+k)=1;
end
function [x,z]=GCF_policy_sample(mu,sigma,eps0,eta,prior,k,prefix,p)
u=rand;
if u<eta,x=GCF_policy_qsample(prior,k,prefix,p);
elseif u<eta+eps0,x=rand(1,p);
else,z0=mu+sigma.*randn(1,p);x=1./(1+exp(-max(-22,min(22,z0))));end
x=max(1e-10,min(1-1e-10,x));z=log(x./(1-x));
end
function w=GCF_policy_qweights(prior,k,prefix)
val=sum(prior.G(:,k:end),2);scale=max(max(val)-min(val),1e-12);
logw=(val-max(val))/(prior.c.priorTemp*scale);
if ~isempty(prefix),dd=bsxfun(@minus,prior.X(:,1:numel(prefix)),prefix);logw=logw-sum(dd.^2,2)/(2*prior.c.priorH^2);end
logw=logw-max(logw);w=exp(logw);w=w/sum(w);
end
function x=GCF_policy_qsample(prior,k,prefix,p)
w=GCF_policy_qweights(prior,k,prefix);j=find(rand<=cumsum(w),1,'first');
if isempty(j),j=numel(w);end
jj=MSBO_stage_idx(prior,k);center=prior.X(j,jj);h=prior.c.priorWidth/2;
lo=max(0,center-h);hi=min(1,center+h);x=lo+rand(1,p).*(hi-lo);
end
function q=GCF_policy_qpdf(prior,k,prefix,x,p)
w=GCF_policy_qweights(prior,k,prefix);jj=MSBO_stage_idx(prior,k);C=prior.X(:,jj);h=prior.c.priorWidth/2;
lo=max(0,C-h);hi=min(1,C+h);inside=all(bsxfun(@ge,x,lo)&bsxfun(@le,x,hi),2);
vol=prod(hi-lo,2);q=sum(w(inside)./vol(inside));
end
function [logp,resp]=GCF_policy_logpdf(z,mu,sigma,eps0,eta,q)
x=1./(1+exp(-max(-22,min(22,z))));
logG=-sum(.5*((z-mu)./sigma).^2+log(sigma)+.5*log(2*pi)+log(max(x.*(1-x),1e-25)),2);
logP=log(max(1-eta-eps0,realmin))+logG;logU=log(max(eta*q+eps0,realmin));
m=max(logP,logU);logp=m+log(exp(logP-m)+exp(logU-m));resp=exp(logP-logp);
end
function [loss,grad,V]=GCF_critic_loss(P,G,known,c,gpAware)
B=size(G,1);K=size(G,2);R=sum(G,2);grad=zeros(size(P));V=zeros(B,K);loss=0;
if ~gpAware
 for k=1:K
  ii=(k-1)*B+(1:B);V(:,k)=P(ii,1);e=V(:,k)-R;
  loss=loss+sum(e.^2)/(K*B);grad(ii,1)=2*e/(K*B);
 end
 return;
end
aux=0;nValid=B*K*(K+1)/2;
for k=1:K
 ii=(k-1)*B+(1:B);V(:,k)=known(:,k)+sum(P(ii,k:K),2);e=V(:,k)-R;
 loss=loss+sum(e.^2)/(K*B);
 for j=k:K
  grad(ii,j)=grad(ii,j)+2*e/(K*B);
  ae=P(ii,j)-G(:,j);aux=aux+sum(ae.^2)/nValid;
  grad(ii,j)=grad(ii,j)+c.auxWeight*2*ae/nValid;
 end
end
loss=loss+c.auxWeight*aux;
end
function [net,ls,adamNet,adamSig]=GCF_ppo_step(net,ls,S,Z,logOld,A,eps0,eta,q,c,adamNet,adamSig)
mu=nn_forward(net,S);sigma=exp(ls);[logNew,resp]=GCF_policy_logpdf(Z,mu,sigma,eps0,eta,q);
ratio=exp(max(-25,min(25,logNew-logOld)));active=~((A>=0&ratio>1+c.clip)|(A<0&ratio<1-c.clip));
base=-A.*ratio.*active/numel(A);gMu=bsxfun(@times,base.*resp,(Z-mu)./(sigma.^2));
gSig=sum(bsxfun(@times,base.*resp,((Z-mu).^2./(sigma.^2)-1)),1);
g=nn_backward(net,S,gMu);[net,adamNet]=nn_adam(net,g,adamNet,c.actorLR);
if isempty(adamSig),adamSig=struct('t',0,'m',zeros(size(ls)),'v',zeros(size(ls)));end
adamSig.t=adamSig.t+1;gSig=max(-10,min(10,gSig));adamSig.m=.9*adamSig.m+.1*gSig;adamSig.v=.999*adamSig.v+.001*gSig.^2;
ls=ls-c.actorLR*(adamSig.m/(1-.9^adamSig.t))./(sqrt(adamSig.v/(1-.999^adamSig.t))+1e-8);
ls=max(log(c.minSigma),min(log(c.maxSigma),ls));
end

function net=nn_init(d,h,o,depth)
% Neural network for MAPPO; depth=1 reproduces the original architecture.
if nargin<4||isempty(depth),depth=1;end
assert(isscalar(depth)&&any(depth==[1 2]),'depth must be 1 or 2');
net.W1=randn(d,h)*sqrt(1/d)*.4;
net.b1=zeros(1,h);
if depth==2
 net.W2=randn(h,h)*sqrt(1/h)*.4;
 net.b2=zeros(1,h);
 net.W3=randn(h,o)*sqrt(1/h)*.3;
 net.b3=zeros(1,o);
else
 net.W2=randn(h,o)*sqrt(1/h)*.3;
 net.b2=zeros(1,o);
end
end

function [out,meta]=GCF_gpcoop_ppo(evalFn,model,spec,budget,c,variant,seed)
% Paired IPPO / stage-aware MAPPO / GP-conditionally-cooperative MAPPO.
% All three optimize identical GCF_chain_eval under exactly budget evaluations.
% IPPO: local critic for each agent; common team reward and causal prefix input.
% MAPPO: shared stage-aware multihead critic, identical actor state dimension.
% GP-MAPPO: MAPPO + causal GP-conditional anchor MESSAGE and prior sampling.
% Earlier actors influence downstream GP messages through their sampled x-prefix.
% Anchor suffix acquisition value supplies backward task relevance. No true y is
% accessed until an entire candidate x is chosen and the outer engine evaluates it.
% PPO only updates on draws from the exact (actor+uniform+GP) mixture density.
assert(any(strcmp(variant,{'A3_IPPO','A4_MAPPO','A5_GP_MAPPO'})), ...
 'Unknown GP-coop PPO variant.');
isIPPO=strcmp(variant,'A3_IPPO');useGP=strcmp(variant,'A5_GP_MAPPO');
assert(isfield(c,'nAnchors') && budget>=2 && c.batch>=2);
assert(c.uniformMix>=0 && c.priorMix>=0 && c.uniformMix+c.priorMix<1);
assert(c.priorWidth>0 && c.priorH>0 && c.priorTemp>0);
rng(seed,'twister');K=spec.K;d=spec.d;
% Shared actor architecture across all three variants; GP extra features are
% zeroed for IPPO and MAPPO, eliminating capacity as a confound.
D=d+3*K+2*d+2;
nAnch=max(1,min(round(c.nAnchors),budget-1));
anchors=GCF_halton(nAnch,d,6000+seed);
[anchorR,anchorG]=evalFn(anchors);anchorR=anchorR(:);
assert(numel(anchorR)==nAnch && size(anchorG,2)==K);
prior=struct('X',anchors,'G',anchorG,'c',c,'spec',spec);
actor=cell(1,K);actorAdam=cell(1,K);sigAdam=cell(1,K);logSig=cell(1,K);
for k=1:K
 actor{k}=nn_init(D,c.hidden,spec.stageDims(k),c.nHiddenLayers);
 actorAdam{k}=[];sigAdam{k}=[];
 logSig{k}=log(c.sigma)*ones(1,spec.stageDims(k));
end
if isIPPO
 critic=cell(1,K);criticAdam=cell(1,K);
 for k=1:K
  critic{k}=nn_init(D,c.hidden,1,c.nHiddenLayers);criticAdam{k}=[];
 end
else
 critic=nn_init(D,c.hidden,K,c.nHiddenLayers);criticAdam=[];
end
st=struct('PPOUpdates',0,'PPOEarlyStops',0,'CriticUpdates',0, ...
 'KLSum',0,'KLCount',0,'KLMax',0,'ActorGradClips',0, ...
 'CriticGradClips',0,'SigmaSum',0,'SigmaCount',0, ...
 'GPPriorSamples',0,'GPMessageRows',0,'GPPrefixShiftSum',0, ...
 'criticMSE',[],'batchReward',[]);
out=struct('best',-inf,'bestX',nan(1,d),'allX',zeros(budget,d), ...
 'allG',zeros(budget,K),'allR',zeros(budget,1),'trace',zeros(budget,1), ...
 'stats',st);
[out.best,ix]=max(anchorR);out.bestX=anchors(ix,:);
out.allX(1:nAnch,:)=anchors;out.allG(1:nAnch,:)=anchorG;
out.allR(1:nAnch)=anchorR;out.trace(1:nAnch)=cummax(anchorR);
completed=nAnch;rewardScale=max(mean(abs(anchorR)),1e-10);
eps0=c.uniformMix;
while completed<budget
 B=min(c.batch,budget-completed);X=zeros(B,d);
 S=cell(1,K);Z=cell(1,K);logOld=cell(1,K);qD=cell(1,K);
 frac=(completed-nAnch)/max(1,budget-nAnch);
 eta=0;if useGP,eta=c.priorMix*(1-0.5*frac);end
 for k=1:K
  jj=MSBO_stage_idx(spec,k);p=numel(jj);
  S{k}=localState(model,spec,X,k,D);Z{k}=zeros(B,p);qD{k}=zeros(B,1);
  if useGP
   [W,center,spread,utility,shift]=localConditional(prior,k,X,jj);
   % GP messages are recomputed AFTER earlier actors have chosen the prefix.
   % The forward channel is prefix x, the backwards channel is GP suffix IVR.
   S{k}(:,d+3*K+jj)=center;
   S{k}(:,d+3*K+d+jj)=spread;
   S{k}(:,D-1)=utility;
   S{k}(:,D)=shift;
   out.stats.GPMessageRows=out.stats.GPMessageRows+B;
   out.stats.GPPrefixShiftSum=out.stats.GPPrefixShiftSum+sum(shift);
  end
  mu=nn_forward(actor{k},S{k});
  for b=1:B
   u=rand;
   if useGP && u<eta
    xx=localPriorSample(prior,jj,W(b,:));
    out.stats.GPPriorSamples=out.stats.GPPriorSamples+1;
   elseif u<eta+eps0
    xx=rand(1,p);
   else
    z0=mu(b,:)+exp(logSig{k}).*randn(1,p);
    xx=1./(1+exp(-max(-22,min(22,z0))));
   end
   xx=max(1e-10,min(1-1e-10,xx));
   X(b,jj)=xx;Z{k}(b,:)=log(xx./(1-xx));
   if useGP,qD{k}(b)=localPriorPdf(prior,jj,W(b,:),xx);end
  end
  logOld{k}=GCF_ppo_stable_logpdf(Z{k},mu,exp(logSig{k}), ...
   eps0,eta,qD{k});
 end
 [R,G]=evalFn(X);R=R(:);
 assert(numel(R)==B && size(G,1)==B && size(G,2)==K && ...
  all(isfinite(R)) && all(isfinite(G(:))));
 for b=1:B
  completed=completed+1;out.allX(completed,:)=X(b,:);
  out.allG(completed,:)=G(b,:);out.allR(completed)=R(b);
  if R(b)>out.best,out.best=R(b);out.bestX=X(b,:);end
  out.trace(completed)=out.best;
 end
 r=G/rewardScale;team=sum(r,2);adv=zeros(B,K);
 if isIPPO
  for k=1:K
   v=nn_forward(critic{k},S{k});adv(:,k)=team-v(:,1);
  end
 else
  allS=vertcat(S{:});P=nn_forward(critic,allS);
  [~,~,V]=localCentralLoss(P,r,c);
  adv(:,K)=team-V(:,K);
  for k=K-1:-1:1
   adv(:,k)=V(:,k+1)-V(:,k)+c.lambda*adv(:,k+1);
  end
 end
 for k=1:K
  sd=std(adv(:,k));
  if sd>1e-9
   adv(:,k)=(adv(:,k)-mean(adv(:,k)))/sd;
  else
   adv(:,k)=adv(:,k)-mean(adv(:,k));
  end
 end
 out.stats.batchReward(end+1,1)=mean(R);
 active=true(1,K);lastKL=zeros(1,K);
 for ep=1:c.nEpoch
  for k=1:K
   if ~active(k),continue;end
   [actor{k},logSig{k},actorAdam{k},sigAdam{k},kk,diag]= ...
    GCF_ppo_stable_step(actor{k},logSig{k},S{k},Z{k},logOld{k}, ...
     adv(:,k),eps0,eta,qD{k},c,actorAdam{k},sigAdam{k});
   lastKL(k)=kk;out.stats.PPOUpdates=out.stats.PPOUpdates+1;
   out.stats.ActorGradClips=out.stats.ActorGradClips+diag.actorClipped;
   if kk>c.ppoTargetKL && ep>=c.ppoMinEpoch
    active(k)=false;out.stats.PPOEarlyStops=out.stats.PPOEarlyStops+1;
   end
  end
  if isIPPO
   for k=1:K
    pred=nn_forward(critic{k},S{k});e=pred(:,1)-team;
    gr=nn_backward(critic{k},S{k},2*e/B);
    [gr,clipped]=GCF_ppo_stable_clipgrad(gr,c.ppoCriticGradMaxNorm);
    out.stats.CriticGradClips=out.stats.CriticGradClips+clipped;
    [critic{k},criticAdam{k}]=nn_adam(critic{k},gr,criticAdam{k},c.criticLR);
    out.stats.CriticUpdates=out.stats.CriticUpdates+1;
    out.stats.criticMSE(end+1,1)=mean(e.^2);
   end
  else
   P=nn_forward(critic,allS);
   [loss,dP,~]=localCentralLoss(P,r,c);
   gr=nn_backward(critic,allS,dP);
   [gr,clipped]=GCF_ppo_stable_clipgrad(gr,c.ppoCriticGradMaxNorm);
   out.stats.CriticGradClips=out.stats.CriticGradClips+clipped;
   [critic,criticAdam]=nn_adam(critic,gr,criticAdam,c.criticLR);
   out.stats.CriticUpdates=out.stats.CriticUpdates+1;
   out.stats.criticMSE(end+1,1)=loss;
  end
  if ~any(active) && ep>=c.ppoMinEpoch,break;end
 end
 out.stats.KLSum=out.stats.KLSum+sum(lastKL);
 out.stats.KLCount=out.stats.KLCount+K;
 out.stats.KLMax=max(out.stats.KLMax,max(lastKL));
 for k=1:K
  out.stats.SigmaSum=out.stats.SigmaSum+sum(exp(logSig{k}));
  out.stats.SigmaCount=out.stats.SigmaCount+numel(logSig{k});
 end
end
out.actor=actor;out.critic=critic;out.logSig=logSig;
out.gpPriorActor=useGP;out.gpMessageActor=useGP;
out.stats.MeanKL=out.stats.KLSum/max(1,out.stats.KLCount);
out.stats.MeanSigma=out.stats.SigmaSum/max(1,out.stats.SigmaCount);
out.stats.MeanPrefixShift=out.stats.GPPrefixShiftSum/ ...
 max(1,out.stats.GPMessageRows);
out.stats.PPOVariant=variant;
meta=struct('RewardCalls',budget,'GradientCalls',0, ...
 'GradientSeconds',0,'OptimizationSeconds',NaN);
end

function S=localState(model,spec,X,k,D)
B=size(X,1);K=spec.K;d=spec.d;S=zeros(B,D);
if k>1
 n=sum(spec.stageDims(1:k-1));S(:,1:n)=X(:,1:n);
 [Ym,Yv]=GCF_cascade_predict(model,spec,X);
 S(:,d+(1:k-1))=Ym(:,1:k-1);
 S(:,d+K+(1:k-1))=sqrt(max(0,Yv(:,1:k-1)));
end
S(:,d+2*K+k)=1;
end

function [W,center,spread,utility,shift]=localConditional(prior,k,X,jj)
% GP posterior conditional message. Given upstream actor prefix, reweight
% complete anchor candidates by GP suffix value and prefix compatibility.
% No extra reward function evaluations: anchor.G are previously scored.
B=size(X,1);N=size(prior.X,1);d=prior.spec.d;
C=prior.X(:,jj);suffix=sum(prior.G(:,k:end),2);
s=max(max(suffix)-min(suffix),max(mean(abs(suffix)),1e-12));
logBase=(suffix-max(suffix))/(prior.c.priorTemp*s);
W=zeros(B,N);center=zeros(B,numel(jj));spread=center;
utility=zeros(B,1);shift=zeros(B,1);
p=jj(1)-1;
for b=1:B
 lw=logBase;
 if p>0
  dd=bsxfun(@minus,prior.X(:,1:p),X(b,1:p));
  lw=lw-sum(dd.^2,2)/(2*prior.c.priorH^2*max(1,sqrt(p)));
 end
 lw=lw-max(lw);w=exp(lw);w=w/max(sum(w),realmin);
 W(b,:)=w';m=w'*C;center(b,:)=m;
 spread(b,:)=sqrt(max(w'*(C.^2)-m.^2,0));
 utility(b)=min(5,max(-5,(w'*suffix)/s));
 % This diagnostic quantifies how upstream choices change GP proposals.
 if p>0
  z=logBase-max(logBase);ww=exp(z);ww=ww/max(sum(ww),realmin);
  shift(b)=sum(abs(w-ww))/2;
 end
end
assert(size(W,2)==N && all(isfinite(W(:))) && all(isfinite(center(:))));
end

function x=localPriorSample(prior,jj,w)
q=cumsum(w(:));i=find(rand<=q,1,'first');
if isempty(i),i=numel(w);end
c=prior.X(i,jj);h=prior.c.priorWidth/2;
lo=max(0,c-h);hi=min(1,c+h);
x=lo+rand(size(c)).*(hi-lo);
end

function q=localPriorPdf(prior,jj,w,x)
C=prior.X(:,jj);h=prior.c.priorWidth/2;
lo=max(0,C-h);hi=min(1,C+h);
inside=all(bsxfun(@ge,x,lo)&bsxfun(@le,x,hi),2);
vol=prod(hi-lo,2);
ws=w(:);q=sum(ws(inside)./vol(inside));
assert(isfinite(q) && q>=0,'GP prior PDF must be nonnegative and finite.');
end

function [loss,grad,V]=localCentralLoss(P,G,c)
B=size(G,1);K=size(G,2);R=sum(G,2);
grad=zeros(size(P));V=zeros(B,K);loss=0;
known=zeros(B,K);
for k=2:K,known(:,k)=sum(G(:,1:k-1),2);end
aux=0;nValid=B*K*(K+1)/2;
for k=1:K
 ii=(k-1)*B+(1:B);
 V(:,k)=known(:,k)+sum(P(ii,k:K),2);
 e=V(:,k)-R;loss=loss+sum(e.^2)/(K*B);
 for j=k:K
  grad(ii,j)=grad(ii,j)+2*e/(K*B);
  ae=P(ii,j)-G(:,j);aux=aux+sum(ae.^2)/nValid;
  grad(ii,j)=grad(ii,j)+c.auxWeight*2*ae/nValid;
 end
end
loss=loss+c.auxWeight*aux;
end

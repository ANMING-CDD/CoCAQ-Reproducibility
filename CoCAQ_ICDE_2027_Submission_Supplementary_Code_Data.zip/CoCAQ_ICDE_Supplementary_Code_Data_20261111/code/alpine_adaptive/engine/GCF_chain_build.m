function F=GCF_chain_build(model,spec,Xref)
[~,~,Qref]=GCF_cascade_predict(model,spec,Xref);
N=size(Xref,1);K=spec.K;sens=cell(1,K);sens{K}=ones(N,1);
if strcmp(spec.kind,'horizontal_ackley_dag')
 sens{1}=GCF_gp_dmean(model.stage{3},Qref{3},1);
 sens{2}=GCF_gp_dmean(model.stage{3},Qref{3},2);
else
 for k=K-1:-1:1
  [pi,ps]=GCF_prev_coordinate(spec,k+1);
  d=GCF_gp_dmean(model.stage{k+1},Qref{k+1},pi)*ps;
  sens{k}=sens{k+1}.*d;
 end
end
Vref=cell(1,K);
for k=1:K,Vref{k}=model.stage{k}.L\GCF_kernel(model.stage{k}.X,Qref{k},model.stage{k}.ell);end
F=struct('model',model,'spec',spec,'Xref',Xref,'Qref',{Qref},'sens',{sens},'Vref',{Vref});
end
function [idx,scale]=GCF_prev_coordinate(spec,k)
if strcmp(spec.kind,'forrester')&&k==2
 idx=1;scale=.04;
elseif strcmp(spec.kind,'cascadebo_rosenbrock')
 idx=1;scale=.5;
elseif strcmp(spec.kind,'horizontal_ackmat')
 idx=2;scale=.05;
elseif strcmp(spec.kind,'horizontal_rosen')
 idx=numel(MSBO_stage_idx(spec,k))+2;scale=spec.rosenPrevScale;
elseif strcmp(spec.kind,'bofn_alpine2')
 idx=2;scale=10^(-(k-1)/2);
else
 idx=numel(MSBO_stage_idx(spec,k))+1;scale=1;
end
end

function GCF_v6_truth_selftest(root)
% Lightweight oracle contract tests; no external weights or Python required.
addpath(fullfile(root,'truth'),'-begin');
assert(exist(fullfile(root,'truth','cascade_truth.m'),'file')==2);
assert(exist(fullfile(root,'truth','EVAL_FROZEN_MSBO.m'),'file')==2);
cases=GCF_case_registry(root);cfg=struct('acceptanceRoot',root);
X=[.13,.21;.75,.25;.02,.98];Y=GCF_truth(cases(1),X,cfg);
assert(isequal(size(Y),[3,2])&&all(isfinite(Y(:))));
X6=repmat([.13 .21 .37 .49 .63 .81],3,1);
Y2=GCF_truth(cases(2),X6,cfg);Y3=GCF_truth(cases(3),X6,cfg);
assert(isequal(size(Y2),[3,6])&&isequal(size(Y3),[3,3]));
assert(all(isfinite(Y2(:)))&&all(isfinite(Y3(:))));
fprintf('PASS: restored CASE01, BOFN and Rosenbrock truth contracts.\n');
end

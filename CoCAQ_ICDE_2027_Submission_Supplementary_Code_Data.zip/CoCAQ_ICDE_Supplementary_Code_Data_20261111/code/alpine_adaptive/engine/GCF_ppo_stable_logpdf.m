function [logp,resp]=GCF_ppo_stable_logpdf(z,mu,sigma,eps0,eta,q)
% Exactly the V4A mixture density: Gaussian-logit Actor + GP prior + uniform.
% The conditional prior is held fixed for the entire PPO minibatch.
assert(eta>=0 && eps0>=0 && eta+eps0<1);
x=1./(1+exp(-max(-22,min(22,z))));
logG=-sum(.5*((z-mu)./sigma).^2+log(sigma)+.5*log(2*pi) ...
 +log(max(x.*(1-x),1e-25)),2);
logP=log(max(1-eta-eps0,realmin))+logG;
logU=log(max(eta*q+eps0,realmin));
m=max(logP,logU);
logp=m+log(exp(logP-m)+exp(logU-m));
resp=exp(logP-logp);
end

function GCF_v5_selftest()
% Does not depend on any external MSBO/Python oracles.
rng(20261102,'twister');
X=randn(5,4);net=nn_init(4,7,2,2);dy=randn(5,2);
gr=nn_backward(net,X,dy);
assert(isequal(size(nn_forward(net,X)),[5,2]));
h=1e-6;
for field={'W1','b1','W2','b2','W3','b3'}
 f=field{1};pos=ones(size(net.(f)));ix=min(3,numel(pos));pos(:)=0;pos(ix)=1;
 np=net;nm=net;np.(f)=np.(f)+h*pos;nm.(f)=nm.(f)-h*pos;
 yp=nn_forward(np,X);ym=nn_forward(nm,X);
 numeric=sum((yp(:)-ym(:)).*dy(:))/(2*h);
 temp=gr.(f);analytic=sum(temp(:).*pos(:));
 assert(abs(numeric-analytic)<2e-7,'Deep NN derivative mismatch %s: %.3g',f,abs(numeric-analytic));
end
net1=nn_init(4,7,2,1);g1=nn_backward(net1,X,dy);assert(isfield(g1,'W2')&&~isfield(g1,'W3'));
% PPO mixed policy logSigma analytic derivative finite difference.
Z=randn(6,2);mu=.3*randn(6,2);sigma=exp([-.2 .3]);A=randn(6,1);
eps0=.08;eta=.30;q=.7*ones(6,1);clip=.2;
[old,~]=local_logpdf(Z,mu,sigma,eps0,eta,q);
ls=log(sigma);[new,resp]=local_logpdf(Z,mu,exp(ls),eps0,eta,q);
ratio=exp(max(-25,min(25,new-old)));
active=~((A>=0&ratio>1+clip)|(A<0&ratio<1-clip));
base=-A.*ratio.*active/numel(A);
analytic=sum(bsxfun(@times,base.*resp,((Z-mu).^2./sigma.^2-1)),1);
for j=1:2
 lp=ls;lm=ls;lp(j)=lp(j)+h;lm(j)=lm(j)-h;
 fp=local_ppoloss(Z,mu,lp,eps0,eta,q,old,A,clip);
 fm=local_ppoloss(Z,mu,lm,eps0,eta,q,old,A,clip);
 err=abs((fp-fm)/(2*h)-analytic(j));
 assert(err<1e-7,'PPO logSigma gradient error: %.3g',err);
end
% Fast-Gi and V4 candidate selector are covered independently here.
c=struct('v4FreshFraction',.5,'v4DiversityWeight',.2, ...
 'v4DistanceScale',.3,'v4CurrentBonus',.05);
[ids,info]=GCF_v4_select_starts(rand(20,6),rand(20,1), ...
 [true(10,1);false(10,1)],4,c);
assert(numel(unique(ids))==4 && info.current>=2);
fprintf('PASS: 2-layer MLP numerical gradients, 1-layer backward compatibility, PPO logSigma, V4 selector.\n');
end
function [lp,resp]=local_logpdf(z,mu,sigma,eps0,eta,q)
x=1./(1+exp(-z));
logG=-sum(.5*((z-mu)./sigma).^2+log(sigma)+.5*log(2*pi)+log(max(x.*(1-x),1e-25)),2);
logP=log(max(1-eta-eps0,realmin))+logG;
logU=log(max(eta*q+eps0,realmin));
m=max(logP,logU);lp=m+log(exp(logP-m)+exp(logU-m));resp=exp(logP-lp);
end
function loss=local_ppoloss(z,mu,ls,eps0,eta,q,old,A,clip)
lp=local_logpdf(z,mu,exp(ls),eps0,eta,q);
r=exp(max(-25,min(25,lp-old)));
loss=-mean(min(r.*A,max(1-clip,min(1+clip,r)).*A));
end

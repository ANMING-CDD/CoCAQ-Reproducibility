function [indices,info]=GCF_v4_select_starts(X,R,isCurrent,nGrad,c)
% Pick Fast-Gi parent points from ALREADY SCORED candidates (no eval calls).
% At least one parent per batch originates in current GP-MAPPO proposals.
% Selection balances acquisition utility, spatial diversity and freshness.
% X are scaled controls in [0,1]^d; higher R is better.
R=R(:);isCurrent=logical(isCurrent(:));n=size(X,1);
assert(size(R,1)==n && numel(isCurrent)==n && n>=nGrad && nGrad>=0);
assert(all(isfinite(X(:))) && all(isfinite(R)));
indices=zeros(nGrad,1);
if nGrad==0,info=struct('current',0,'history',0);return;end
r0=min(R);rr=max(max(R)-r0,1e-12);
score=(R-r0)./rr;
taken=false(n,1);
nFresh=min(sum(isCurrent),max(1,ceil(c.v4FreshFraction*nGrad)));
for ii=1:nGrad
 if ii<=nFresh
  eligible=isCurrent & ~taken;
 else
  eligible=~taken;
 end
 if ~any(eligible),eligible=~taken;end
 if ii==1
  diversity=ones(n,1);
 else
  % normalized distances, capped to prevent diversity swamping acquisition.
  diversity=inf(n,1);
  for jj=1:ii-1
   dx=bsxfun(@minus,X,X(indices(jj),:));
   diversity=min(diversity,sqrt(sum(dx.^2,2)./size(X,2)));
  end
  diversity=min(1,diversity./max(c.v4DistanceScale,1e-9));
 end
 utility=(1-c.v4DiversityWeight)*score + c.v4DiversityWeight*diversity + ...
          c.v4CurrentBonus*double(isCurrent);
 utility(~eligible)=-inf;
 [~,j]=max(utility);assert(isfinite(utility(j)));
 indices(ii)=j;taken(j)=true;
end
info=struct('current',sum(isCurrent(indices)), ...
 'history',sum(~isCurrent(indices)));
end

function gr=nn_backward(net,X,dy)
% dy is d(loss)/d(output); caller is responsible for batch normalization.
h1=tanh(X*net.W1+net.b1);
if isfield(net,'W3')
 h2=tanh(h1*net.W2+net.b2);
 gr.W3=h2'*dy;gr.b3=sum(dy,1);
 dh2=(dy*net.W3').*(1-h2.^2);
 gr.W2=h1'*dh2;gr.b2=sum(dh2,1);
 dh1=(dh2*net.W2').*(1-h1.^2);
else
 gr.W2=h1'*dy;gr.b2=sum(dy,1);
 dh1=(dy*net.W2').*(1-h1.^2);
end
 gr.W1=X'*dh1;gr.b1=sum(dh1,1);
end

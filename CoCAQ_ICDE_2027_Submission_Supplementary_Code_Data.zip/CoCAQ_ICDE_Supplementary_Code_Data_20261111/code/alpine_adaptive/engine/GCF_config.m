function cfg=GCF_config(mode)
% Shared experiment settings. Tuning and final seeds/test designs are disjoint.
if nargin<1,mode='pilot';end
cfg.mode=lower(char(mode));
cfg.methods={'P1','P2','A1','A2','A3','A3GRAD','A4','A5','A5GRAD'};
cfg.seedList=11;cfg.nAddOverride=1;cfg.nAcq=64;cfg.nAnchors=12;
cfg.nTestOverride=[];cfg.nRefOverride=256;cfg.rankOverride=24;
cfg.mappo=struct('hidden',32,'batch',16,'nEpoch',2,'clip',.20,'lambda',.65, ...
 'actorLR',.003,'criticLR',.006,'sigma',1.1,'minSigma',.25,'maxSigma',2.5, ...
 'uniformMix',.08,'priorMix',.30,'priorWidth',.40,'priorH',.45,'priorTemp',.20, ...
 'auxWeight',.20,'gradStep',.08,'gradPerBatch',2,'gradElitePool',5, ...
 'cmaesRestarts',3,'cmaesPopScale',1.0,'cmaesSigma0',1.1);
switch cfg.mode
 case 'pilot'
  % Integration check only; never used for tuning or final parameter selection.
 case 'tune'
  % Independent validation seeds; 4 candidate configurations per tunable method.
  cfg.seedList=101:103;cfg.nAddOverride=6;cfg.nAcq=128;cfg.nAnchors=32;
  cfg.nTestOverride=512;cfg.nRefOverride=512;cfg.rankOverride=48;
  cfg.mappo.batch=32;cfg.mappo.nEpoch=5;
 case 'overnight'
  % First independent, frozen-parameter experiment after tuning.
  cfg.seedList=201:205;cfg.nAddOverride=30;cfg.nAcq=300;cfg.nAnchors=48;
  cfg.nTestOverride=2048;cfg.nRefOverride=1024;cfg.rankOverride=48;
  cfg.mappo.batch=32;cfg.mappo.nEpoch=6;
 case 'full'
  % Larger final study; independent from both tuning and overnight seeds.
  cfg.seedList=301:320;cfg.nAddOverride=30;cfg.nAcq=300;cfg.nAnchors=48;
  cfg.nTestOverride=2048;cfg.nRefOverride=2048;cfg.rankOverride=64;
  cfg.mappo.batch=32;cfg.mappo.nEpoch=6;
 otherwise
  error('Mode must be pilot, tune, overnight, or full.');
end
end

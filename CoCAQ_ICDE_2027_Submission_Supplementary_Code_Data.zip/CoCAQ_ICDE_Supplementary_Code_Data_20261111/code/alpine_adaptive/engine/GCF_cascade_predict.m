function [Ymu,Yvar,Qcell,Jcell,DprevCell]=GCF_cascade_predict(model,spec,X)
% First-order propagated posterior mean/variance for arbitrary K and p.
if strcmp(spec.kind,'horizontal_ackley_dag')
 [Ymu,Yvar,Qcell,Jcell,DprevCell]=localAckleyDAG(model,spec,X);
 return;
end
N=size(X,1);Ymu=zeros(N,spec.K);Yvar=zeros(N,spec.K);
Qcell=cell(1,spec.K);Jcell=cell(1,spec.K);DprevCell=cell(1,spec.K);
prevMu=[];prevVar=zeros(N,1);prevGrad=zeros(N,spec.d);
for k=1:spec.K
 [Q,J,prevIndex,prevScale]=GCF_stage_query(spec,X,k,prevMu,prevGrad);
 [mu,latentVar]=GCF_gp_predict(model.stage{k},Q);
 dq=zeros(N,size(Q,2));
 for j=1:size(Q,2),dq(:,j)=GCF_gp_dmean(model.stage{k},Q,j);end
 dmuDx=zeros(N,spec.d);
 for j=1:size(Q,2)
  Jj=reshape(J(:,j,:),N,spec.d);
  dmuDx=dmuDx+bsxfun(@times,Jj,dq(:,j));
 end
 if k==1
  vv=latentVar;dprev=zeros(N,1);
 else
  dprev=dq(:,prevIndex)*prevScale;
  vv=latentVar+(dprev.^2).*prevVar;
 end
 Ymu(:,k)=mu;Yvar(:,k)=max(0,vv);
 Qcell{k}=Q;Jcell{k}=J;DprevCell{k}=dprev;
 prevMu=mu;prevVar=Yvar(:,k);prevGrad=dmuDx;
end
end

function [Ymu,Yvar,Qcell,Jcell,DprevCell]=localAckleyDAG(model,spec,X)
% Exact BOFN DAG TOPOLOGY, first-order independent-stage GP variance.
% Nodes 1 and 2 both consume all D x; node 3 consumes BOTH parent outputs.
N=size(X,1);d=spec.d;
Ymu=zeros(N,3);Yvar=zeros(N,3);
Qcell=cell(1,3);Jcell=cell(1,3);DprevCell=cell(1,3);
parentGrad=cell(1,2);
for k=1:2
 Q=X;g=model.stage{k};[mu,var]=GCF_gp_predict(g,Q);
 G=zeros(N,d);
 for j=1:d,G(:,j)=GCF_gp_dmean(g,Q,j);end
 J=zeros(N,d,d);
 for j=1:d,J(:,j,j)=1;end
 Qcell{k}=Q;Jcell{k}=J;DprevCell{k}=zeros(N,1);
 Ymu(:,k)=mu;Yvar(:,k)=var;parentGrad{k}=G;
end
Q=Ymu(:,1:2);g=model.stage{3};[mu,var]=GCF_gp_predict(g,Q);
s1=GCF_gp_dmean(g,Q,1);s2=GCF_gp_dmean(g,Q,2);
J=zeros(N,2,d);J(:,1,:)=parentGrad{1};J(:,2,:)=parentGrad{2};
Ymu(:,3)=mu;Yvar(:,3)=max(0,var+s1.^2.*Yvar(:,1)+s2.^2.*Yvar(:,2));
Qcell{3}=Q;Jcell{3}=J;DprevCell{3}=[s1,s2];
end

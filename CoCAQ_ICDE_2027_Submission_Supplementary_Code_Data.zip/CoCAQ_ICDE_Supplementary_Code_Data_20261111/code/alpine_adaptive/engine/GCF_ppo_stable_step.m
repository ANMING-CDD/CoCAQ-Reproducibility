function [net,ls,adamNet,adamSig,kl,diag]=GCF_ppo_stable_step( ...
 net,ls,S,Z,logOld,A,eps0,eta,q,c,adamNet,adamSig)
% V4A mixture-policy PPO with global clipping, optional Gaussian entropy,
% and nonnegative Monte-Carlo KL monitor. No GP/Fast-Gi evaluations.
mu=nn_forward(net,S);sigma=exp(ls);
[logNew,resp]=GCF_ppo_stable_logpdf(Z,mu,sigma,eps0,eta,q);
ratio=exp(max(-25,min(25,logNew-logOld)));
active=~((A>=0&ratio>1+c.clip)|(A<0&ratio<1-c.clip));
base=-A.*ratio.*active/numel(A);
gMu=bsxfun(@times,base.*resp,(Z-mu)./(sigma.^2));
gSig=sum(bsxfun(@times,base.*resp,((Z-mu).^2./(sigma.^2)-1)),1);
% Differential entropy of the *Gaussian component* only. This is not
% entropy of the full mixture; the GP/uniform components remain fixed.
gSig=gSig-c.ppoEntropyCoeff;
g=nn_backward(net,S,gMu);
[g,clipActor]=GCF_ppo_stable_clipgrad(g,c.ppoActorGradMaxNorm);
[net,adamNet]=nn_adam(net,g,adamNet,c.actorLR);
if isempty(adamSig)
 adamSig=struct('t',0,'m',zeros(size(ls)),'v',zeros(size(ls)));
end
% Scalar exploration gradients are clipped in L2 norm as well.
gNorm=norm(gSig(:));
if gNorm>c.ppoSigmaGradMaxNorm
 gSig=gSig*c.ppoSigmaGradMaxNorm/max(gNorm,realmin);
end
adamSig.t=adamSig.t+1;
adamSig.m=.9*adamSig.m+.1*gSig;
adamSig.v=.999*adamSig.v+.001*(gSig.^2);
ls=ls-c.actorLR*(adamSig.m/(1-.9^adamSig.t))./ ...
 (sqrt(adamSig.v/(1-.999^adamSig.t))+1e-8);
ls=max(log(c.minSigma),min(log(c.maxSigma),ls));
% Measure KL after update, on the on-policy rollout from this batch.
muNew=nn_forward(net,S);
[lp,~]=GCF_ppo_stable_logpdf(Z,muNew,exp(ls),eps0,eta,q);
ld=max(-25,min(25,lp-logOld));
% Schulman-style k3 approximation: E[exp(log r)-1-log r].
kl=mean(expm1(ld)-ld);
if ~isfinite(kl),kl=inf;end
kl=max(0,kl);
diag=struct('actorClipped',clipActor,'gradNorm',gNorm);
end

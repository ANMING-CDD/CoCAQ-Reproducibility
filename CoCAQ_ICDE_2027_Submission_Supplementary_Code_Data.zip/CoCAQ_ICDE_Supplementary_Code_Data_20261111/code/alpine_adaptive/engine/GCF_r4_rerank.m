function [out,info] = GCF_r4_rerank(F,out,nShort)
% High-fidelity, deterministic post-search rerank (shared across MAPPO/CMA).
% Counts are reported separately from fast proxy scoring calls.
nShort=min(size(out.allX,1),max(1,round(nShort)));
[~,ix]=sort(out.allR,'descend');
idx=ix(1:nShort);
% Ensure spatial diversity in shortlisted options, without scoring more.
% The best fast proxy candidate is always present.
X=out.allX(idx,:);
t=tic;[score,parts]=GCF_r4_terminal_eval(F,X);secs=toc(t);
[best,which]=max(score);
out.bestX=X(which,:);
out.r4TerminalBest=best;
out.r4TerminalSourceProxyRank=which;
out.r4TerminalAllScores=score;
info=struct('TerminalLookaheadCalls',nShort, ...
 'TerminalLookaheadSeconds',secs, ...
 'TerminalBestScore',best, ...
 'ProxyWinnerChanged',double(idx(which)~=idx(1)), ...
 'TerminalStageScores',parts(which,:));
end

function X=GCF_lhs(n,d)
X=zeros(n,d);
for j=1:d,X(:,j)=(randperm(n)'-1+rand(n,1))/n;end
end

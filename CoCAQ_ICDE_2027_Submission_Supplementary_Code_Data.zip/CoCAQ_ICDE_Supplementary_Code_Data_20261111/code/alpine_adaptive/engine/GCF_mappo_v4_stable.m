function [out,meta]=GCF_mappo_v4_stable(evalFn,gradFn,model,spec,budget,c,variant,seed)
% R5: exact V4A acquisition/prior/candidate code with controlled PPO stability.
% GP, Fast-Gi, anchors, candidate scoring, gradients and budget are unchanged.
% V4A: GP-MAPPO scored candidates + utility/diversity Fast-Gi starts.
% A fixed GP posterior is used inside each outer real-sampling iteration.
% DO NOT use previous-round Actor/Critic. No extra acquisition evaluations.
assert(any(strcmp(variant,{'V4A_PPO_STABLE','V4A_PPO_EXPLORE'})));
useFeedback=false; % V4A did not use V4B feedback.
useExplore=strcmp(variant,'V4A_PPO_EXPLORE');
if useExplore
 c.ppoEntropyCoeff=c.ppoExploreEntropyCoeff;
 c.minSigma=max(c.minSigma,c.ppoExploreMinSigma);
else
 c.ppoEntropyCoeff=0;
end
rng(seed,'twister');K=spec.K;d=spec.d;Fdim=d+3*K;stageDims=spec.stageDims;
assert(isfield(c,'nAnchors') && ~isempty(c.nAnchors));
assert(budget>=2 && c.batch>=4 && c.gradPerBatch>=0);
assert(c.priorMix>=0 && c.uniformMix>=0 && c.priorMix+c.uniformMix<1);
assert(c.v4FreshFraction>=0 && c.v4FreshFraction<=1);
assert(c.v4DiversityWeight>=0 && c.v4DiversityWeight<=1);
assert(c.v4GainPriority>=0 && c.v4GainPriority<=1);
assert(c.v4FeedbackCap>=1 && c.v4FeedbackMinDist>=0);
nAnch=max(1,min(round(c.nAnchors),budget-1));
anchors=GCF_halton(nAnch,d,6000+seed);
[anchorR,anchorG]=evalFn(anchors);anchorR=anchorR(:);
prior=struct('X',anchors,'G',anchorG,'c',c, ...
 'nAnchor',nAnch,'anchorX',anchors,'anchorG',anchorG,'stageDims',stageDims, ...
 'feedbackX',zeros(0,d),'feedbackG',zeros(0,K), ...
 'feedbackGain',zeros(0,1),'boost',zeros(nAnch,1), ...
 'gainScale',max(max(anchorR)-min(anchorR),max(mean(abs(anchorR)),1e-10)));
actor=cell(1,K);netAdam=cell(1,K);sigAdam=cell(1,K);logSig=cell(1,K);
for k=1:K
 p=stageDims(k);actor{k}=nn_init(Fdim,c.hidden,p,c.nHiddenLayers);
 logSig{k}=log(c.sigma)*ones(1,p);
end
critic=nn_init(Fdim,c.hidden,K,c.nHiddenLayers);criticAdam=[];
st=struct('gradientCalls',0,'gradientTime',0,'criticMSE',[], ...
 'batchReward',[],'gradientGain',zeros(0,1),'gradientSuccess',0, ...
 'startsFromCurrent',0,'startsFromHistory',0,'feedbackAdds',0, ...
 'feedbackCenters',zeros(0,1),'currentBestReward',zeros(0,1), ...
 'gradientBestReward',zeros(0,1),'bestSource',0, ...
 'PPOUpdates',0,'PPOEarlyStops',0,'CriticUpdates',0, ...
 'KLSum',0,'KLCount',0,'KLMax',0,'ActorGradClips',0, ...
 'CriticGradClips',0,'SigmaSum',0,'SigmaCount',0);
out=struct('best',-inf,'bestX',nan(1,d),'allX',zeros(budget,d), ...
 'allG',zeros(budget,K),'allR',zeros(budget,1),'trace',zeros(budget,1), ...
 'stats',st);
[best,ix]=max(anchorR);out.best=best;out.bestX=anchors(ix,:);
out.allX(1:nAnch,:)=anchors;out.allG(1:nAnch,:)=anchorG;
out.allR(1:nAnch)=anchorR;out.trace(1:nAnch)=cummax(anchorR);
completed=nAnch;rewardScale=max(mean(abs(anchorR)),1e-10);
while completed<budget
 B=min(c.batch,budget-completed);nGrad=0;
 if B>=4,nGrad=min(c.gradPerBatch,B-2);end
 Bpol=B-nGrad;frac=(completed-nAnch)/max(1,budget-nAnch);
 eta=c.priorMix*(1-.5*frac);eps0=c.uniformMix;
 % Prior is frozen for all samples and all PPO epochs in this batch.
 priorBatch=prior;
 X=zeros(Bpol,d);S=cell(1,K);Z=cell(1,K);logOld=cell(1,K);qD=cell(1,K);
 for k=1:K
  p=stageDims(k);jj=MSBO_stage_idx(spec,k);
  S{k}=GCF_state_features(model,spec,X,k);
  mu=nn_forward(actor{k},S{k});Z{k}=zeros(Bpol,p);qD{k}=zeros(Bpol,1);
  for b=1:Bpol
   prefix=X(b,1:(jj(1)-1));
   [xx,zz]=GCF_policy_sample(mu(b,:),exp(logSig{k}),eps0,eta,priorBatch,k,prefix,p);
   X(b,jj)=xx;Z{k}(b,:)=zz;
   qD{k}(b)=GCF_policy_qpdf(priorBatch,k,prefix,xx,p);
  end
  logOld{k}=GCF_policy_logpdf(Z{k},mu,exp(logSig{k}),eps0,eta,qD{k});
 end
 [R,G]=evalFn(X);R=R(:);batchX=X;batchR=R;batchG=G;
 if nGrad>0
  % The policy candidates are already scored. Reuse those GP-guided
  % candidates AS STARTS instead of randomly sampling historical elites.
  poolX=[X;out.allX(1:completed,:)];poolR=[R;out.allR(1:completed)];
  fresh=[true(Bpol,1);false(completed,1)];
  [j,si]=GCF_v4_select_starts(poolX,poolR,fresh,nGrad,c);
  parent=poolX(j,:);parentR=poolR(j);
  out.stats.startsFromCurrent=out.stats.startsFromCurrent+si.current;
  out.stats.startsFromHistory=out.stats.startsFromHistory+si.history;
  tg=tic;dg=gradFn(parent);
  out.stats.gradientTime=out.stats.gradientTime+toc(tg);
  out.stats.gradientCalls=out.stats.gradientCalls+nGrad;
  gn=sqrt(sum(dg.^2,2));
  proposal=max(1e-8,min(1-1e-8, ...
   parent+c.gradStep*bsxfun(@rdivide,dg,max(gn,1e-20))));
  [rg,gg]=evalFn(proposal);rg=rg(:);gain=rg-parentR;
  batchX=[batchX;proposal];batchR=[batchR;rg];batchG=[batchG;gg];
  out.stats.gradientGain=[out.stats.gradientGain;gain];
  out.stats.gradientSuccess=out.stats.gradientSuccess+sum(gain>0);
 else
  proposal=zeros(0,d);rg=zeros(0,1);gg=zeros(0,K);gain=zeros(0,1);
 end
 out.stats.currentBestReward(end+1,1)=max(R);
 if ~isempty(rg),out.stats.gradientBestReward(end+1,1)=max(rg);
 else,out.stats.gradientBestReward(end+1,1)=NaN;end
 for b=1:B
  completed=completed+1;
  out.allX(completed,:)=batchX(b,:);
  out.allG(completed,:)=batchG(b,:);
  out.allR(completed)=batchR(b);
  if batchR(b)>out.best
   out.best=batchR(b);out.bestX=batchX(b,:);
   if b<=Bpol,out.stats.bestSource=1;
   else,out.stats.bestSource=2;end
  end
  out.trace(completed)=out.best;
 end
 % V4A data, states and advantage targets are unchanged; PPO updates are stabilized.
 r=G/rewardScale;total=sum(r,2);known=zeros(Bpol,K);
 for k=2:K,known(:,k)=sum(r(:,1:k-1),2);end
 allS=vertcat(S{:});pred=nn_forward(critic,allS);
 [loss,dPred,V]=GCF_critic_loss(pred,r,known,c,true);
 adv=zeros(Bpol,K);adv(:,K)=total-V(:,K);
 for k=K-1:-1:1
  adv(:,k)=V(:,k+1)-V(:,k)+c.lambda*adv(:,k+1);
 end
 for k=1:K
  sd=std(adv(:,k));
  if sd>1e-9
   adv(:,k)=(adv(:,k)-mean(adv(:,k)))/sd;
  else
   adv(:,k)=adv(:,k)-mean(adv(:,k));
  end
 end
 out.stats.batchReward(end+1,1)=mean(batchR);
 % Advantages remain identical to V4A; only update stability changes.
 active=true(1,K);lastKL=zeros(1,K);
 for ep=1:c.nEpoch
  for k=1:K
   if ~active(k),continue;end
   [actor{k},logSig{k},netAdam{k},sigAdam{k},kk,diag]=GCF_ppo_stable_step( ...
     actor{k},logSig{k},S{k},Z{k},logOld{k},adv(:,k),eps0,eta,qD{k}, ...
     c,netAdam{k},sigAdam{k});
   lastKL(k)=kk;
   out.stats.PPOUpdates=out.stats.PPOUpdates+1;
   out.stats.ActorGradClips=out.stats.ActorGradClips+diag.actorClipped;
   if kk>c.ppoTargetKL && ep>=c.ppoMinEpoch
    active(k)=false;
    out.stats.PPOEarlyStops=out.stats.PPOEarlyStops+1;
   end
  end
  pred=nn_forward(critic,allS);
  [loss,dPred,~]=GCF_critic_loss(pred,r,known,c,true);
  cg=nn_backward(critic,allS,dPred);
  [cg,clipped]=GCF_ppo_stable_clipgrad(cg,c.ppoCriticGradMaxNorm);
  out.stats.CriticGradClips=out.stats.CriticGradClips+clipped;
  [critic,criticAdam]=nn_adam(critic,cg,criticAdam,c.criticLR);
  out.stats.CriticUpdates=out.stats.CriticUpdates+1;
  out.stats.criticMSE(end+1,1)=loss;
  if ~any(active) && ep>=c.ppoMinEpoch,break;end
 end
 out.stats.KLSum=out.stats.KLSum+sum(lastKL);
 out.stats.KLCount=out.stats.KLCount+K;
 out.stats.KLMax=max(out.stats.KLMax,max(lastKL));
 for k=1:K
  out.stats.SigmaSum=out.stats.SigmaSum+sum(exp(logSig{k}));
  out.stats.SigmaCount=out.stats.SigmaCount+numel(logSig{k});
 end
 % Feedback is applied AFTER all PPO epochs. Never re-label old on-policy
 % trajectories with a changed conditional prior probability density.
 if useFeedback && nGrad>0
  [prior,nAdded]=GCF_v4_feedback_prior(prior,proposal,gg,gain,c);
  out.stats.feedbackAdds=out.stats.feedbackAdds+nAdded;
 end
 out.stats.feedbackCenters(end+1,1)=size(prior.feedbackX,1);
end
out.actor=actor;out.critic=critic;out.logSig=logSig;
out.gpPriorActor=true;out.gpPrefixCritic=true;
out.priorCenters=prior.X;
out.stats.MeanKL=out.stats.KLSum/max(out.stats.KLCount,1);
out.stats.MeanSigma=out.stats.SigmaSum/max(out.stats.SigmaCount,1);
out.stats.PPOVariant=variant;
meta=struct('RewardCalls',budget,'GradientCalls',out.stats.gradientCalls, ...
 'GradientSeconds',out.stats.gradientTime,'OptimizationSeconds',NaN);
end

function S=GCF_state_features(model,spec,X,k)
B=size(X,1);K=spec.K;d=spec.d;S=zeros(B,d+3*K);
if k>1
 nPrefix=sum(spec.stageDims(1:k-1));S(:,1:nPrefix)=X(:,1:nPrefix);
 [Ym,Yv]=GCF_cascade_predict(model,spec,X);
 S(:,d+(1:k-1))=Ym(:,1:k-1);
 S(:,d+K+(1:k-1))=sqrt(max(0,Yv(:,1:k-1)));
end
S(:,d+2*K+k)=1;
end
function [x,z]=GCF_policy_sample(mu,sigma,eps0,eta,prior,k,prefix,p)
u=rand;
if u<eta,x=GCF_policy_qsample(prior,k,prefix,p);
elseif u<eta+eps0,x=rand(1,p);
else,z0=mu+sigma.*randn(1,p);x=1./(1+exp(-max(-22,min(22,z0))));end
x=max(1e-10,min(1-1e-10,x));z=log(x./(1-x));
end
function w=GCF_policy_qweights(prior,k,prefix)
val=sum(prior.G(:,k:end),2);scale=max(max(val)-min(val),1e-12);
logw=(val-max(val))/(prior.c.priorTemp*scale);
if isfield(prior,'boost'),logw=logw+prior.boost;end
if ~isempty(prefix),dd=bsxfun(@minus,prior.X(:,1:numel(prefix)),prefix);logw=logw-sum(dd.^2,2)/(2*prior.c.priorH^2);end
logw=logw-max(logw);w=exp(logw);w=w/sum(w);
end
function x=GCF_policy_qsample(prior,k,prefix,p)
w=GCF_policy_qweights(prior,k,prefix);j=find(rand<=cumsum(w),1,'first');
if isempty(j),j=numel(w);end
jj=MSBO_stage_idx(prior,k);center=prior.X(j,jj);h=prior.c.priorWidth/2;
lo=max(0,center-h);hi=min(1,center+h);x=lo+rand(1,p).*(hi-lo);
end
function q=GCF_policy_qpdf(prior,k,prefix,x,p)
w=GCF_policy_qweights(prior,k,prefix);jj=MSBO_stage_idx(prior,k);C=prior.X(:,jj);h=prior.c.priorWidth/2;
lo=max(0,C-h);hi=min(1,C+h);inside=all(bsxfun(@ge,x,lo)&bsxfun(@le,x,hi),2);
vol=prod(hi-lo,2);q=sum(w(inside)./vol(inside));
end
function [logp,resp]=GCF_policy_logpdf(z,mu,sigma,eps0,eta,q)
x=1./(1+exp(-max(-22,min(22,z))));
logG=-sum(.5*((z-mu)./sigma).^2+log(sigma)+.5*log(2*pi)+log(max(x.*(1-x),1e-25)),2);
logP=log(max(1-eta-eps0,realmin))+logG;logU=log(max(eta*q+eps0,realmin));
m=max(logP,logU);logp=m+log(exp(logP-m)+exp(logU-m));resp=exp(logP-logp);
end
function [loss,grad,V]=GCF_critic_loss(P,G,known,c,gpAware)
B=size(G,1);K=size(G,2);R=sum(G,2);grad=zeros(size(P));V=zeros(B,K);loss=0;
if ~gpAware
 for k=1:K
  ii=(k-1)*B+(1:B);V(:,k)=P(ii,1);e=V(:,k)-R;
  loss=loss+sum(e.^2)/(K*B);grad(ii,1)=2*e/(K*B);
 end
 return;
end
aux=0;nValid=B*K*(K+1)/2;
for k=1:K
 ii=(k-1)*B+(1:B);V(:,k)=known(:,k)+sum(P(ii,k:K),2);e=V(:,k)-R;
 loss=loss+sum(e.^2)/(K*B);
 for j=k:K
  grad(ii,j)=grad(ii,j)+2*e/(K*B);
  ae=P(ii,j)-G(:,j);aux=aux+sum(ae.^2)/nValid;
  grad(ii,j)=grad(ii,j)+c.auxWeight*2*ae/nValid;
 end
end
loss=loss+c.auxWeight*aux;
end

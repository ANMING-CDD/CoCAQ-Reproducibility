function [Q,J,prevIndex,prevScale]=GCF_stage_query(spec,X,k,prevMu,prevGrad)
% Nominal cascade stage input and Jacobian dQ/dX.
assert(~strcmp(spec.kind,'horizontal_ackley_dag'), ...
 'Ackley DAG has two parents; use GCF_cascade_predict DAG branch');
N=size(X,1);d=spec.d;idx=MSBO_stage_idx(spec,k);pk=numel(idx);
if strcmp(spec.kind,'horizontal_rosen')
 if k==1
  localIdx=idx;
  Q=X(:,localIdx);J=zeros(N,pk,d);
  for a=1:pk,J(:,a,localIdx(a))=1;end
  prevIndex=[];prevScale=0;
 else
  localIdx=[idx(1)-1,idx];
  prevScale=spec.rosenPrevScale;
  Q=[X(:,localIdx),prevScale*prevMu(:)];J=zeros(N,pk+2,d);
  for a=1:numel(localIdx),J(:,a,localIdx(a))=1;end
  J(:,end,:)=prevScale*prevGrad;
  prevIndex=pk+2;
 end
 return;
end
if k==1
 Q=X(:,idx);J=zeros(N,pk,d);
 for a=1:pk,J(:,a,idx(a))=1;end
 prevIndex=[];prevScale=0;return;
end
if strcmp(spec.kind,'forrester')
 Q=[.04*prevMu(:)+1/3,X(:,idx)];J=zeros(N,2,d);
 J(:,1,:)=.04*prevGrad;
 for a=1:pk,J(:,1+a,idx(a))=1;end
 prevIndex=1;prevScale=.04;
elseif strcmp(spec.kind,'cascadebo_rosenbrock')
 prevScale=.5;Q=[prevScale*prevMu(:),X(:,idx)];J=zeros(N,pk+1,d);
 J(:,1,:)=prevScale*prevGrad;
 for a=1:pk,J(:,1+a,idx(a))=1;end
 prevIndex=1;
elseif strcmp(spec.kind,'horizontal_ackmat')
 prevScale=.05;Q=[X(:,idx),prevScale*prevMu(:)];J=zeros(N,pk+1,d);
 for a=1:pk,J(:,a,idx(a))=1;end
 J(:,pk+1,:)=prevScale*prevGrad;
 prevIndex=pk+1;
elseif strcmp(spec.kind,'bofn_alpine2')
 prevScale=10^(-(k-1)/2);Q=[X(:,idx),prevScale*prevMu(:)];J=zeros(N,pk+1,d);
 for a=1:pk,J(:,a,idx(a))=1;end
 J(:,pk+1,:)=prevScale*prevGrad;
 prevIndex=pk+1;
else
 Q=[X(:,idx),prevMu(:)];J=zeros(N,pk+1,d);
 for a=1:pk,J(:,a,idx(a))=1;end
 J(:,pk+1,:)=prevGrad;
 prevIndex=pk+1;prevScale=1;
end
end

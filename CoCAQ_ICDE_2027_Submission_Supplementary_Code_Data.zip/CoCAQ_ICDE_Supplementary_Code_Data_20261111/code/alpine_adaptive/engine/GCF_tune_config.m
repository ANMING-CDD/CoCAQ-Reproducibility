function T=GCF_tune_config()
% CASE01 automatic HYPERPARAMETER SEARCH: validation only.
% Tune params based ONLY on held-out validation seeds/test design.
% Do NOT use previously inspected seeds 1701:1720, or final 2901:2905.
T=struct();
T.studyID='CASE01_AUTO_TUNE_8GRID_R1';
T.cases={'CASE01'};
T.methods={'A4','A5','A5GRAD_V4A'};
T.seeds=2101:2103;
T.rounds=10;
% Per-case override set only by RUN_EIGHT_CASES_AUTO; legacy defaults retained.
global GCF_AUTO8_TUNE_OVERRIDE;
if isstruct(GCF_AUTO8_TUNE_OVERRIDE) && ~isempty(fieldnames(GCF_AUTO8_TUNE_OVERRIDE))
 T=GCF_AUTO8_TUNE_OVERRIDE;
end

end

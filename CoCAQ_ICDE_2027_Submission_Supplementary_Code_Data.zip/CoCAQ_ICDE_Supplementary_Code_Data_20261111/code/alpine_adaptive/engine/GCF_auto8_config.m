function C=GCF_auto8_config()
% V9: automatic per-case 2-stage RL hyperparameter search, freeze, evaluation.
% Modify studyTag after changes to candidate grid, seeds, rounds or method list.
C=struct();
C.studyTag='R9A';
C.cases={ ...
 'CASE01', ...
 'BOFN_ALPINE2_6S6D', ...
 'CASCADEBO_ROSENBROCK_3S6D', ...
 'MSBO_4S_16D', ...
 'MSBO_4S_20D', ...
 'MSBO_5S_20D', ...
 'MSBO_5S_25D', ...
 'YB_FIBER_4S8D'};
C.methods={'P1','P2','A1','A2','A3','A4','A5','A5GRAD_V4A'};
% Phase-1 broad RL screen: 12 candidates x 2 seeds x 6 added trials.
C.screenSeeds=4101:4102;
C.screenRounds=6;
% Phase-2 adaptive refine: 10 candidates x 3 NEW seeds x 10 trials.
C.refineSeeds=4201:4203;
C.refineRounds=10;
% Independent holdout, never used by the tuning algorithm.
C.holdoutSeeds=4901:4905;
C.holdoutRounds=30;
C.holdoutTestBase=99000;
C.acceptanceRoot='';
C.pythonExe='';
C.continueOnCaseError=true;
end

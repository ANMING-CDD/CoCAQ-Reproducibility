function [out,meta] = GCF_r4_mappo(evalFn,gradFn,F,spec,budget,c,variant,seed,initState)
% R4: terminal-aligned MAPPO, optional bidirectional GP communication,
% optional confidence-gated Fast-Gi imitation, optional cross-round warm start.
% PPO is on-policy for FINAL policy decisions conditional on an EXOGENOUS
% draft. Drafts and all GP messages are computed before true evaluation.
if nargin<9,initState=[];end
variants={'R4_TERM','R4_COMM','R4_NOCOMM','R4_FULL','R4_FULL_WARM'};
assert(any(strcmp(variant,variants)),'Unknown R4 MAPPO variant.');
useComm=any(strcmp(variant,{'R4_COMM','R4_FULL','R4_FULL_WARM'}));
useTeacher=any(strcmp(variant,{'R4_NOCOMM','R4_FULL','R4_FULL_WARM'}));
useWarm=strcmp(variant,'R4_FULL_WARM');
if useTeacher,assert(~isempty(gradFn),'Fast-Gi analytic gradient missing.');end
rng(seed,'twister');K=spec.K;d=spec.d;stageDims=spec.stageDims;
Fdim=2*d+6*K+2;nAnch=min(max(1,round(c.nAnchors)),budget-1);
assert(budget>=16 && c.batch>=4 && c.priorMix+c.uniformMix<1);
anchors=GCF_halton(nAnch,d,6000+seed);
[ar,ag]=evalFn(anchors);ar=ar(:);
prior=struct('X',anchors,'G',ag,'c',c,'stageDims',stageDims);
actor=cell(1,K);netAdam=cell(1,K);sigAdam=cell(1,K);logSig=cell(1,K);
for k=1:K
 p=stageDims(k);actor{k}=nn_init(Fdim,c.hidden,p,c.nHiddenLayers);
 logSig{k}=log(c.sigma)*ones(1,p);
end
critic=nn_init(Fdim,c.hidden,K,c.nHiddenLayers);criticAdam=[];
usedWarm=0;
if useWarm && ~isempty(initState) && isstruct(initState) && ...
   isfield(initState,'actor') && numel(initState.actor)==K
 try
  for k=1:K
   assert(isequal(size(initState.actor{k}.W1),size(actor{k}.W1)));
  end
  actor=initState.actor;
  logSig=initState.logSig;
  critic=initState.critic;
  usedWarm=1;
 catch
  warning('R4:WarmStart','Warm start shape mismatch; reinitializing policy.');
 end
end
st=struct('GradientCalls',0,'GradTrials',0,'GradAccepted',0, ...
 'TeacherPairs',0,'DistillUpdates',0,'GradientSeconds',0, ...
 'DraftMessages',0,'CommunicationEnabled',double(useComm), ...
 'WarmStartUsed',usedWarm,'TeacherGateRejected',0, ...
 'PPOOnPolicySamples',0,'TeacherWeightSum',0, ...
 'TeacherTerminalCalls',0,'TeacherTerminalSeconds',0, ...
 'TerminalGatePassed',0);
out=struct('best',-inf,'bestX',nan(1,d),'allX',zeros(budget,d), ...
 'allG',zeros(budget,K),'allR',zeros(budget,1), ...
 'trace',zeros(budget,1),'stats',st);
[out.best,ix]=max(ar);out.bestX=anchors(ix,:);
out.allX(1:nAnch,:)=anchors;out.allG(1:nAnch,:)=ag;
out.allR(1:nAnch)=ar;out.trace(1:nAnch)=cummax(ar);
completed=nAnch;rewardScale=max(mean(abs(ar)),1e-9);
steps=c.r4StepGrid(:)';assert(numel(steps)==2);
while completed<budget
 B=min(c.batch,budget-completed);
 nStarts=0;
 if useTeacher && B>=8
  nStarts=min(1,floor((B-4)/numel(steps)));
 end
 nGrad=nStarts*numel(steps);Bpol=B-nGrad;
 frac=(completed-nAnch)/max(1,budget-nAnch);
 eta=c.priorMix*(1-.5*frac);eps0=c.uniformMix;
 % GP draft is an external proposal, not an action from the current Actor.
 % This permits an honest conditional on-policy PPO ratio for the second
 % pass, while still conveying reverse terminal messages before sampling.
 draft=GCF_halton(Bpol,d,9000+seed+completed);
 [~,sortAnch]=sort(ar,'descend');numElite=min(nAnch,max(1,ceil(.2*nAnch)));
 for b=1:Bpol
  if mod(b,3)==0
   a=sortAnch(1+mod(b-1,numElite));
   draft(b,:)=max(1e-8,min(1-1e-8,anchors(a,:)+.08*randn(1,d)));
  end
 end
 M=GCF_r4_messages(F,draft,useComm);
 out.stats.DraftMessages=out.stats.DraftMessages+Bpol;
 X=zeros(Bpol,d);S=cell(1,K);Z=cell(1,K);logOld=cell(1,K);qD=cell(1,K);
 for k=1:K
  jj=MSBO_stage_idx(spec,k);p=numel(jj);
  S{k}=GCF_r4_state(M,X,k);
  mu=nn_forward(actor{k},S{k});Z{k}=zeros(Bpol,p);qD{k}=zeros(Bpol,1);
  for b=1:Bpol
   prefix=X(b,1:(jj(1)-1));
   [xx,zz]=GCF_policy_sample(mu(b,:),exp(logSig{k}),eps0,eta,prior,k,prefix,p);
   X(b,jj)=xx;Z{k}(b,:)=zz;
   qD{k}(b)=GCF_policy_qpdf(prior,k,prefix,xx,p);
  end
  logOld{k}=GCF_policy_logpdf(Z{k},mu,exp(logSig{k}),eps0,eta,qD{k});
 end
 [R,G]=evalFn(X);R=R(:);
 batchX=X;batchR=R;batchG=G;
 teacherX=zeros(0,d);teacherParent=zeros(0,d);teacherGain=zeros(0,1);
 teacherStates=cell(1,K);for k=1:K,teacherStates{k}=zeros(0,Fdim);end
 if nStarts>0
  poolX=[X;out.allX(1:completed,:)];poolR=[R;out.allR(1:completed)];
  fresh=[true(Bpol,1);false(completed,1)];
  [j,~]=GCF_v4_select_starts(poolX,poolR,fresh,nStarts,c);
  parent=poolX(j,:);parentR=poolR(j);
  ticGrad=tic;dg=gradFn(parent);out.stats.GradientSeconds=out.stats.GradientSeconds+toc(ticGrad);
  out.stats.GradientCalls=out.stats.GradientCalls+nStarts;
  ng=sqrt(sum(dg.^2,2));good=all(isfinite(dg),2)&ng>c.r4MinGradNorm;
  unit=zeros(size(dg));unit(good,:)=bsxfun(@rdivide,dg(good,:),ng(good));
  proposal=zeros(nGrad,d);
  for a=1:nStarts
   for t=1:numel(steps)
    j0=(a-1)*numel(steps)+t;
    if good(a)
     proposal(j0,:)=parent(a,:)+steps(t)*unit(a,:);
    else
     v=randn(1,d);v=v/max(norm(v),1e-12);
     proposal(j0,:)=parent(a,:)+steps(t)*v;
    end
   end
  end
  proposal=max(1e-8,min(1-1e-8,proposal));
  [rg,gg]=evalFn(proposal);rg=rg(:);
  out.stats.GradTrials=out.stats.GradTrials+nGrad;
  batchX=[batchX;proposal];batchR=[batchR;rg];batchG=[batchG;gg];
  for a=1:nStarts
   ids=(a-1)*numel(steps)+(1:numel(steps));
   [maxR,jbest]=max(rg(ids));delta=maxR-parentR(a);
   accept=good(a) && isfinite(delta) && delta> ...
       c.r4TeacherMinGain*max(abs(parentR(a)),1e-9);
   if accept
    % More precise terminal IVR agreement gate, independent of test RMSE.
    % Use common random numbers for parent/proposal (deterministic).
    tt=tic;term=GCF_r4_terminal_eval(F, ...
      [parent(a,:);proposal(ids(jbest),:)]);
    out.stats.TeacherTerminalSeconds=out.stats.TeacherTerminalSeconds+toc(tt);
    out.stats.TeacherTerminalCalls=out.stats.TeacherTerminalCalls+2;
    accept=term(2)>term(1)+c.r4TerminalGateRel*max(abs(term(1)),1e-12);
   end
   if accept
    out.stats.TerminalGatePassed=out.stats.TerminalGatePassed+1;
    out.stats.GradAccepted=out.stats.GradAccepted+1;
    teacherX(end+1,:)=proposal(ids(jbest),:); %#ok<AGROW>
    teacherParent(end+1,:)=parent(a,:); %#ok<AGROW>
    teacherGain(end+1,1)=delta; %#ok<AGROW>
    % Teach the coherent REFINED joint action. Each downstream stage
    % receives the refined upstream prefix, while GP messages remain
    % conditioned on the same fixed, exogenous draft context.
    if j(a)<=Bpol
     teachDraft=draft(j(a),:);
    else
     teachDraft=parent(a,:);
    end
    teachMessage=GCF_r4_messages(F,teachDraft,useComm);
    teacherAction=proposal(ids(jbest),:);
    for k=1:K
     teacherStates{k}(end+1,:)=GCF_r4_state(teachMessage,teacherAction,k); %#ok<AGROW>
    end
   else
    out.stats.TeacherGateRejected=out.stats.TeacherGateRejected+1;
   end
  end
 end
 assert(size(batchX,1)==B && numel(batchR)==B,'R4 proxy scoring budget mismatch');
 for b=1:B
  completed=completed+1;
  out.allX(completed,:)=batchX(b,:);
  out.allG(completed,:)=batchG(b,:);
  out.allR(completed)=batchR(b);
  if batchR(b)>out.best
   out.best=batchR(b);out.bestX=batchX(b,:);
  end
  out.trace(completed)=out.best;
 end
 r=G/rewardScale;total=sum(r,2);known=zeros(Bpol,K);
 for k=2:K,known(:,k)=sum(r(:,1:k-1),2);end
 allS=vertcat(S{:});pred=nn_forward(critic,allS);
 [~,~,V]=GCF_critic_loss(pred,r,known,c,true);
 adv=zeros(Bpol,K);adv(:,K)=total-V(:,K);
 for k=K-1:-1:1
  adv(:,k)=V(:,k+1)-V(:,k)+c.lambda*adv(:,k+1);
 end
 for k=1:K
  sd=std(adv(:,k));
  if sd>1e-9,adv(:,k)=(adv(:,k)-mean(adv(:,k)))/sd;
  else,adv(:,k)=adv(:,k)-mean(adv(:,k));end
 end
 out.stats.PPOOnPolicySamples=out.stats.PPOOnPolicySamples+Bpol;
 teacherZ=cell(1,K);teacherW=cell(1,K);
 if useTeacher && ~isempty(teacherGain)
  w=min(1,teacherGain./max(teacherGain+abs(batchR(1))*0.02,1e-9));
  out.stats.TeacherPairs=out.stats.TeacherPairs+numel(w);
  for k=1:K
   jj=MSBO_stage_idx(spec,k);
   zt=max(1e-8,min(1-1e-8,teacherX(:,jj)));
   teacherZ{k}=log(zt./(1-zt));
   stageMove=sqrt(sum((teacherX(:,jj)-teacherParent(:,jj)).^2,2));
   fullMove=sqrt(sum((teacherX-teacherParent).^2,2));
   % Training-only LOO stage confidence. The terminal importance is already
   % embedded in the common Fast-Gi teacher gain.
   teacherW{k}=w.*min(1,stageMove./max(fullMove,1e-12))*F.trust(k);
  end
  out.stats.TeacherWeightSum=out.stats.TeacherWeightSum+sum(w);
 else
  for k=1:K,teacherZ{k}=[];teacherW{k}=[];end
 end
 for ep=1:c.nEpoch
  for k=1:K
   [actor{k},logSig{k},netAdam{k},sigAdam{k},lossT]= ...
    GCF_guided_ppo_step(actor{k},logSig{k},S{k},Z{k},logOld{k}, ...
      adv(:,k),eps0,eta,qD{k},c,netAdam{k},sigAdam{k}, ...
      teacherStates{k},teacherZ{k},teacherW{k},useTeacher);
   if isfinite(lossT) && lossT>0
    out.stats.DistillUpdates=out.stats.DistillUpdates+1;
   end
  end
  pred=nn_forward(critic,allS);
  [~,dp,~]=GCF_critic_loss(pred,r,known,c,true);
  cg=nn_backward(critic,allS,dp);
  [critic,criticAdam]=nn_adam(critic,cg,criticAdam,c.criticLR);
 end
end
out.policyState=struct('actor',{actor},'critic',critic,'logSig',{logSig});
out.gpCommunication=useComm;out.gpTeacher=useTeacher;
meta=out.stats;
meta.RewardCalls=budget;
meta.OptimizationSeconds=NaN;
end

function [x,z]=GCF_policy_sample(mu,sigma,eps0,eta,prior,k,prefix,p)
u=rand;
if u<eta,x=GCF_policy_qsample(prior,k,prefix,p);
elseif u<eta+eps0,x=rand(1,p);
else,z0=mu+sigma.*randn(1,p);x=1./(1+exp(-max(-22,min(22,z0))));end
x=max(1e-10,min(1-1e-10,x));z=log(x./(1-x));
end
function w=GCF_policy_qweights(prior,k,prefix)
val=sum(prior.G(:,k:end),2);scale=max(max(val)-min(val),1e-12);
logw=(val-max(val))/(prior.c.priorTemp*scale);
if isfield(prior,'boost'),logw=logw+prior.boost;end
if ~isempty(prefix),dd=bsxfun(@minus,prior.X(:,1:numel(prefix)),prefix);logw=logw-sum(dd.^2,2)/(2*prior.c.priorH^2);end
logw=logw-max(logw);w=exp(logw);w=w/sum(w);
end
function x=GCF_policy_qsample(prior,k,prefix,p)
w=GCF_policy_qweights(prior,k,prefix);j=find(rand<=cumsum(w),1,'first');
if isempty(j),j=numel(w);end
jj=MSBO_stage_idx(prior,k);center=prior.X(j,jj);h=prior.c.priorWidth/2;
lo=max(0,center-h);hi=min(1,center+h);x=lo+rand(1,p).*(hi-lo);
end
function q=GCF_policy_qpdf(prior,k,prefix,x,p)
w=GCF_policy_qweights(prior,k,prefix);jj=MSBO_stage_idx(prior,k);C=prior.X(:,jj);h=prior.c.priorWidth/2;
lo=max(0,C-h);hi=min(1,C+h);inside=all(bsxfun(@ge,x,lo)&bsxfun(@le,x,hi),2);
vol=prod(hi-lo,2);q=sum(w(inside)./vol(inside));
end
function [logp,resp]=GCF_policy_logpdf(z,mu,sigma,eps0,eta,q)
x=1./(1+exp(-max(-22,min(22,z))));
logG=-sum(.5*((z-mu)./sigma).^2+log(sigma)+.5*log(2*pi)+log(max(x.*(1-x),1e-25)),2);
logP=log(max(1-eta-eps0,realmin))+logG;logU=log(max(eta*q+eps0,realmin));
m=max(logP,logU);logp=m+log(exp(logP-m)+exp(logU-m));resp=exp(logP-logp);
end
function [loss,grad,V]=GCF_critic_loss(P,G,known,c,gpAware)
B=size(G,1);K=size(G,2);R=sum(G,2);grad=zeros(size(P));V=zeros(B,K);loss=0;
if ~gpAware
 for k=1:K
  ii=(k-1)*B+(1:B);V(:,k)=P(ii,1);e=V(:,k)-R;
  loss=loss+sum(e.^2)/(K*B);grad(ii,1)=2*e/(K*B);
 end
 return;
end
aux=0;nValid=B*K*(K+1)/2;
for k=1:K
 ii=(k-1)*B+(1:B);V(:,k)=known(:,k)+sum(P(ii,k:K),2);e=V(:,k)-R;
 loss=loss+sum(e.^2)/(K*B);
 for j=k:K
  grad(ii,j)=grad(ii,j)+2*e/(K*B);
  ae=P(ii,j)-G(:,j);aux=aux+sum(ae.^2)/nValid;
  grad(ii,j)=grad(ii,j)+c.auxWeight*2*ae/nValid;
 end
end
loss=loss+c.auxWeight*aux;
end
function [net,ls,adamNet,adamSig,teacherLoss]=GCF_guided_ppo_step( ...
  net,ls,S,Z,logOld,A,eps0,eta,q,c,adamNet,adamSig,T,Tz,Tw,useGuide)
% PPO ratio is computed for original on-policy samples ONLY.
% Teacher term is weighted, supervised Gaussian-component action regression.
% Gradient-proposed actions are NOT inserted into PPO's importance ratio.
mu=nn_forward(net,S);sigma=exp(ls);
[logNew,resp]=GCF_policy_logpdf(Z,mu,sigma,eps0,eta,q);
ratio=exp(max(-25,min(25,logNew-logOld)));
active=~((A>=0&ratio>1+c.clip)|(A<0&ratio<1-c.clip));
base=-A.*ratio.*active/numel(A);
gMu=bsxfun(@times,base.*resp,(Z-mu)./(sigma.^2));
gSig=sum(bsxfun(@times,base.*resp,((Z-mu).^2./(sigma.^2)-1)),1);
g=nn_backward(net,S,gMu);
teacherLoss=0;
if useGuide && ~isempty(T) && c.r3DistillWeight>0 && ...
   mean(logOld-logNew)<c.r4MaxApproxKL
  targetMu=nn_forward(net,T);
  resid=bsxfun(@rdivide,targetMu-Tz,sigma.^2);
  % Limit any one teacher direction from overwhelming PPO's own gradient.
  rowNorm=sqrt(sum(resid.^2,2));
  rowScale=min(1,c.r3TeacherRowClip./max(rowNorm,1e-12));
  resid=bsxfun(@times,resid,Tw.*rowScale/max(sum(Tw),realmin));
  teacherLoss=mean(sum(bsxfun(@times,(targetMu-Tz).^2,Tw),2));
  gt=nn_backward(net,T,resid);
  fn=fieldnames(g);
  baseNorm=0;teachNorm=0;
  for i=1:numel(fn)
   f=fn{i};gb=g.(f);tb=gt.(f);
   baseNorm=baseNorm+sum(gb(:).^2);
   teachNorm=teachNorm+sum(tb(:).^2);
  end
  % Keep the added teacher gradient below a fraction of the native PPO
  % gradient norm; this avoids suppressing global policy exploration.
  effective=c.r3DistillWeight*min(1, ...
   c.r4MaxTeacherGradRatio*max(sqrt(baseNorm),1e-7)/ ...
   max(c.r3DistillWeight*sqrt(teachNorm),1e-12));
  for i=1:numel(fn)
   f=fn{i};g.(f)=g.(f)+effective*gt.(f);
  end
end
[net,adamNet]=nn_adam(net,g,adamNet,c.actorLR);
if isempty(adamSig)
 adamSig=struct('t',0,'m',zeros(size(ls)),'v',zeros(size(ls)));
end
adamSig.t=adamSig.t+1;
gSig=max(-10,min(10,gSig));
adamSig.m=.9*adamSig.m+.1*gSig;
adamSig.v=.999*adamSig.v+.001*gSig.^2;
ls=ls-c.actorLR*(adamSig.m/(1-.9^adamSig.t))./ ...
 (sqrt(adamSig.v/(1-.999^adamSig.t))+1e-8);
ls=max(log(c.minSigma),min(log(c.maxSigma),ls));
end

function [ok,detail]=GCF_case_truth_selftest(spec,cfg)
% Deterministic source-formula and stage-input-order tests for restored cases.
ok=false;detail='';
switch spec.kind
 case 'bofn_alpine2'
  X=[.13 .21 .37 .49 .63 .81; .75 .25 .90 .40 .55 .15; ...
     .02 .98 .18 .72 .44 .66];
  Y=GCF_truth(spec,X,cfg);
  xp=10*X;a=sqrt(xp).*sin(xp);
  Yr=zeros(size(X,1),6);Yr(:,1)=-a(:,1);
  for k=2:6,Yr(:,k)=a(:,k).*Yr(:,k-1);end
  err=max(abs(Y(:)-Yr(:)));
  Q=GCF_stage_input(spec,X,Y,2);
  prevScale=10^(-.5);Qexpected=[X(:,2),prevScale*Y(:,1)];
  qerr=max(abs(Q(:)-Qexpected(:)));
  N=size(X,1);pg=reshape(1:(N*spec.d),N,spec.d);
  [Qq,J,pi,ps]=GCF_stage_query(spec,X,2,Y(:,1),pg);
  qqueryerr=max(abs(Qq(:)-Qexpected(:)));
  jerr=max(abs(reshape(J(:,2,:),N,spec.d)-prevScale*pg),[],'all');
  assert(err<1e-12&&qerr<1e-12&&qqueryerr<1e-12&&jerr<1e-12&&pi==2&&abs(ps-prevScale)<1e-14, ...
    'BOFN Alpine2 formula/order/Jacobian parity failed.');
  assert(isequal(size(Y),[size(X,1),6])&&all(isfinite(Y(:))));
  ok=true;detail=sprintf('BOFN Alpine2 K=6 formula parity %.3g; stage order [x_k,y_{k-1}], Jacobian %.3g',err,jerr);
 case 'cascadebo_rosenbrock'
  X=[.17 .28 .39 .46 .63 .72; .75 .75 .75 .75 .75 .75; ...
     .04 .91 .32 .83 .58 .21];
  Y=GCF_truth(spec,X,cfg);
  xp=-2+4*X;Yr=zeros(size(X,1),3);
  for k=1:3
   idx=(k-1)*2+(1:2);
   if k==1,Z=xp(:,idx);else,Z=[Yr(:,k-1),xp(:,idx)];end
   R=sum(100*(Z(:,2:end)-Z(:,1:end-1).^2).^2 + ...
         (Z(:,1:end-1)-1).^2,2);
   raw=-R;rawMin=-3609*(size(Z,2)-1);
   Yr(:,k)=((raw-rawMin)/(0-rawMin))*4-2;
  end
  err=max(abs(Y(:)-Yr(:)));
  Q=GCF_stage_input(spec,X,Y,2);
  prevScale=.5;Qexpected=[prevScale*Y(:,1),X(:,3:4)];
  qerr=max(abs(Q(:)-Qexpected(:)));
  N=size(X,1);pg=reshape(1:(N*spec.d),N,spec.d);
  [Qq,J,pi,ps]=GCF_stage_query(spec,X,2,Y(:,1),pg);
  qqueryerr=max(abs(Qq(:)-Qexpected(:)));
  jerr=max(abs(reshape(J(:,1,:),N,spec.d)-prevScale*pg),[],'all');
  assert(err<1e-12&&qerr<1e-12&&qqueryerr<1e-12&&jerr<1e-12&&pi==1&&abs(ps-prevScale)<1e-14, ...
    'CascadeBO Rosenbrock formula/order/Jacobian parity failed.');
  assert(all(Y(:)>=-2-1e-10 & Y(:)<=2+1e-10),'CascadeBO stage output outside [-2,2].');
  ok=true;detail=sprintf('CascadeBO s3d2 formula parity %.3g; stage-2 order [y_{k-1},x_k]; Jacobian %.3g',err,jerr);
 otherwise
  detail='No dedicated source self-test for this case kind.';
end
end

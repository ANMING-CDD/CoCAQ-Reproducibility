function COCAQ_SEVEN_RUN(action)
% Seven-method CLEAN-LABEL experiment. MATLAB R2024a, independent study IDs.
% Original P1/P2/A1/A2 and original V4A code are reused unchanged.
% A3_IPPO and A4_MAPPO_PLUS both optimize A2's GCF_chain_eval objective.
if nargin<1,action='help';end
root=fileparts(mfilename('fullpath'));
addpath(root,'-begin');addpath(fullfile(root,'engine'),'-begin');
action=lower(char(action));
switch action
 case {'help','?'}
  fprintf('\nSeven methods: P1,P2,A1,A2,A3_IPPO,A4_MAPPO_PLUS,A5_COCAQ_V4A\n');
  fprintf('COCAQ_SEVEN_RUN(''preflight'')\n');
  fprintf('COCAQ_SEVEN_RUN(''smoke'')\n');
  fprintf('COCAQ_SEVEN_RUN(''pilot'')\n');
  fprintf('COCAQ_SEVEN_RUN(''expand'')\n');
  fprintf('COCAQ_SEVEN_RUN(''report'')\n');
 case 'preflight'
  preflight(root);
 case 'report'
  for ph={'smoke','pilot','expand','confirm'}
   writeReport(root,protocol(root,ph{1}));
  end
 case {'smoke','pilot','expand','confirm'}
  preflight(root);S=protocol(root,action);
  if strcmp(action,'confirm')
   error('CONFIRM is locked: first freeze A3/A4 hyperparameters on new validation seeds, then explicitly unlock a new protocol.');
  end
  fprintf('\nSEVEN %s: %d cases x %d seeds x %d methods = %d runs; %d real rounds; %d GP scores per active round.\n', ...
   upper(action),numel(S.cases),numel(S.seeds),numel(S.methods), ...
   numel(S.cases)*numel(S.seeds)*numel(S.methods),S.rounds,S.nAcq);
  fprintf('Parameters: COMMON_UNTUNED_PILOT. No R2 frozen configs.\n');
  for i=1:numel(S.cases)
   MSBO_SEVEN_ENGINE(S,S.cases{i});
   writeReport(root,S);
  end
 otherwise
  error('Unknown action %s',action);
end
end

function S=protocol(root,ph)
S=struct('studyID','','phase','','seeds',[], ...
 'methods',{{'P1','P2','A1','A2','A3_IPPO','A4_MAPPO_PLUS','A5_COCAQ_V4A'}}, ...
 'rounds',30,'nAcq',300,'nAnchors',48,'nTest',2048,'nRef',1024, ...
 'rank',48,'testBase',1300000,'methodOverrides',struct(), ...
 'cases',{{}},'mode',upper(ph));
switch ph
 case 'smoke'
  S.studyID='SEVEN_V1_SMOKE';S.phase='CODE_CHECK_ONLY';
  S.cases={'MSBO_3S_15D'};S.seeds=12501;S.rounds=2;
  S.nAcq=64;S.nAnchors=16;S.nTest=128;S.nRef=128;S.rank=16;
 case 'pilot'
  S.studyID='SEVEN_V1_PILOT';S.phase='EXPLORATORY';
  % Two cases deliberately vary K/D. No post-hoc case or seed selection.
  S.cases={'MSBO_3S_15D','MSBO_5S_20D'};
  S.seeds=12511:12513;S.rounds=12;S.testBase=1310000;
 case 'expand'
  S.studyID='SEVEN_V1_EXPAND';S.phase='EXPLORATORY';
  S.cases={'MSBO_3S_15D','MSBO_4S_20D','MSBO_5S_20D'};
  S.seeds=12521:12524;S.rounds=30;S.testBase=1320000;
 case 'confirm'
  S.studyID='SEVEN_V1_CONFIRM_LOCKED';S.phase='RESERVED_DO_NOT_RUN';
  Q=MSBO_GRID_specs(root);S.cases={Q.id};S.seeds=12601:12610;
  S.testBase=1330000;
 otherwise
  error('Unknown phase %s',ph);
end
end

function preflight(root)
files={'MSBO_SEVEN_ENGINE.m','MSBO_R2_ENGINE.m','MSBO_R2_config.m', ...
 'MSBO_GRID_specs.m','MSBO_GRID_truth.m', ...
 fullfile('engine','GCF_seven_base_ppo.m'), ...
 fullfile('engine','GCF_ppo_stable_step.m'), ...
 fullfile('engine','GCF_ppo_stable_logpdf.m'), ...
 fullfile('engine','GCF_mappo_v4.m'), ...
 fullfile('engine','GCF_chain_build.m'), ...
 fullfile('engine','GCF_chain_eval.m'), ...
 fullfile('engine','GCF_aio_build.m'), ...
 fullfile('engine','GCF_aio_eval.m'), ...
 fullfile('engine','GCF_cmaes.m')};
for i=1:numel(files)
 assert(isfile(fullfile(root,files{i})),'Missing dependency: %s',files{i});
end
cases=MSBO_GRID_specs(root);
assert(numel(cases)==12,'Expected 12 MSBO oracles');
for i=1:numel(cases)
 file=fullfile(cases(i).folder,'manifest.json');
 assert(isfile(file),'Missing frozen oracle %s',cases(i).id);
 m=jsondecode(fileread(file));
 assert(strcmp(char(m.case),cases(i).id) && m.K==cases(i).K && ...
  m.D==cases(i).d && length(char(m.digest))==64, ...
  'Frozen oracle manifest mismatch: %s',cases(i).id);
end
C=MSBO_R2_config();
assert(C.nAcq==300 && C.holdoutRounds==30 && ...
 isequal(C.holdoutSeeds,8301:8310),'Original R2 config modified. STOP.');
assert(isempty(intersect(12501:12610,8301:8310)),'Test seeds overlap old R2');
fprintf('PREFLIGHT OK: 12 frozen MSBO cases, 7 methods, original V4A source intact.\n');
fprintf('A2/A3/A4 optimize SAME chain GP acquisition; A5 original V4A uses Fast-Gi acquisition.\n');
end

function writeReport(root,S)
folder=fullfile(root,'results','SEVEN_reports',S.mode);
if ~isfolder(folder),mkdir(folder);end
rn={'Case','Seed','Method','RoundBudget','CandidateBudget','ParamSource', ...
 'FinalRMSE','AULC','SearchSeconds','GradientCalls','PPOUpdates','PPOEarlyStops','MeanKL'};
rows=cell(0,numel(rn));
cn={'Case','Seed','Method','Round','RMSE'};cr=cell(0,numel(cn));
sn={'Case','Seed','Method','CompletedRounds','Checkpoint'};stat=cell(0,numel(sn));
for i=1:numel(S.cases)
 id=S.cases{i};
 for seed=S.seeds
  for j=1:numel(S.methods)
   method=S.methods{j};
   file=fullfile(root,'results','SEVEN_METHOD_runs',S.studyID,id, ...
    sprintf('%s_seed%d_%s.mat',id,seed,method));
   if ~isfile(file),continue;end
   z=load(file,'H','signature');H=z.H;sg=z.signature;
   assert(strcmp(char(sg.engine),'MSBO_SEVEN_V1_20261106') && ...
    strcmp(char(sg.studyID),S.studyID) && sg.seed==seed && ...
    strcmp(char(sg.method),method) && sg.nAcq==S.nAcq && ...
    sg.rounds==S.rounds,'Checkpoint provenance mismatch: %s',file);
   done=numel(H.RMSE)-1;
   stat(end+1,:)={string(id),seed,string(method),done,string(file)}; %#ok<AGROW>
   if done~=S.rounds,continue;end
   if ~any(strcmp(method,{'P1','P2'}))
    assert(sum(H.RewardCalls)==done*S.nAcq,'Acquisition score mismatch %s',file);
   end
   rmse=H.RMSE(:);aulc=trapz(0:done,rmse')/done;
   updates=0;stops=0;sumKL=0;countKL=0;
   if isfield(H,'PPOStats')
    for r=1:numel(H.PPOStats)
     q=H.PPOStats{r};
     if isfield(q,'PPOUpdates'),updates=updates+q.PPOUpdates;end
     if isfield(q,'PPOEarlyStops'),stops=stops+q.PPOEarlyStops;end
     if isfield(q,'KLSum'),sumKL=sumKL+q.KLSum;end
     if isfield(q,'KLCount'),countKL=countKL+q.KLCount;end
    end
   end
   rows(end+1,:)={string(id),seed,string(method),done,S.nAcq, ...
    "COMMON_UNTUNED_PRESET",rmse(end),aulc,sum(H.OptimizeSec), ...
    sum(H.GradientCalls),updates,stops,sumKL/max(1,countKL)}; %#ok<AGROW>
   for r=0:done
    cr(end+1,:)={string(id),seed,string(method),r,rmse(r+1)}; %#ok<AGROW>
   end
  end
 end
end
T=makeTable(rows,rn,{'string','double','string','double','double','string', ...
 'double','double','double','double','double','double','double'});
C=makeTable(cr,cn,{'string','double','string','double','double'});
Q=makeTable(stat,sn,{'string','double','string','double','string'});
writetable(T,fullfile(folder,'ALL_RUNS.csv'));
writetable(C,fullfile(folder,'ALL_CURVES.csv'));
writetable(Q,fullfile(folder,'CHECKPOINT_STATUS.csv'));

pn={'Case','Baseline','Proposed','NPairedSeeds', ...
 'BaselineRMSE','ProposedRMSE','GainRMSE_pct','GainAULC_pct','ProposedWins'};
pr=cell(0,numel(pn));
in={'Case','Seed','Baseline','Proposed','BaselineRMSE','ProposedRMSE', ...
 'GainRMSE_pct','GainAULC_pct'};ir=cell(0,numel(in));
mn={'Case','Method','NSeeds','MeanRMSE','MeanAULC','MeanSearchSeconds'};
mr=cell(0,numel(mn));
% Prespecified scientific comparisons, not chosen after results.
comp={... 
 'P1','P2'; ...
 'P2','A2'; ...
 'P1','A1'; ...
 'A2','A3_IPPO'; ...
 'A2','A4_MAPPO_PLUS'; ...
 'A3_IPPO','A4_MAPPO_PLUS'; ...
 'A4_MAPPO_PLUS','A5_COCAQ_V4A'; ...
 'A2','A5_COCAQ_V4A'};
for i=1:numel(S.cases)
 id=string(S.cases{i});W=T(T.Case==id,:);
 if isempty(W),continue;end
 for j=1:numel(S.methods)
  A=W(W.Method==string(S.methods{j}),:);
  if isempty(A),continue;end
  mr(end+1,:)={id,string(S.methods{j}),height(A), ...
   mean(A.FinalRMSE),mean(A.AULC),mean(A.SearchSeconds)}; %#ok<AGROW>
 end
 for j=1:size(comp,1)
  base=string(comp{j,1});prop=string(comp{j,2});
  A=W(W.Method==base,:);B=W(W.Method==prop,:);
  [common,ia,ib]=intersect(A.Seed,B.Seed);
  if isempty(common),continue;end
  x=A.FinalRMSE(ia);y=B.FinalRMSE(ib);
  ax=A.AULC(ia);by=B.AULC(ib);
  pr(end+1,:)={id,base,prop,numel(common),mean(x),mean(y), ...
   100*(mean(x)-mean(y))/max(mean(x),realmin), ...
   100*(mean(ax)-mean(by))/max(mean(ax),realmin),sum(y<x)}; %#ok<AGROW>
  for u=1:numel(common)
   ir(end+1,:)={id,common(u),base,prop,x(u),y(u), ...
    100*(x(u)-y(u))/max(x(u),realmin), ...
    100*(ax(u)-by(u))/max(ax(u),realmin)}; %#ok<AGROW>
  end
 end
end
P=makeTable(pr,pn,{'string','string','string','double','double','double', ...
 'double','double','double'});
I=makeTable(ir,in,{'string','double','string','string', ...
 'double','double','double','double'});
M=makeTable(mr,mn,{'string','string','double','double','double','double'});
writetable(P,fullfile(folder,'PAIRED_CASE_COMPARISON.csv'));
writetable(I,fullfile(folder,'PAIRED_SEED_COMPARISON.csv'));
writetable(M,fullfile(folder,'METHOD_MEANS.csv'));
expected=numel(S.cases)*numel(S.seeds)*numel(S.methods);
fprintf('SEVEN %s: %d/%d complete; %d comparison rows.\n', ...
 S.mode,height(T),expected,height(P));
if ~isempty(P),disp(P);end
end

function T=makeTable(rows,names,types)
if isempty(rows)
 T=table('Size',[0 numel(names)],'VariableTypes',types,'VariableNames',names);
else
 T=cell2table(rows,'VariableNames',names);
end
end

# CoCAQ：IPPO / MAPPO / GP-条件协同 MAPPO —— 独立调参 + 冻结评估

版本：2026-11-06。目的：先诊断协作训练能否超越独立学习与 CMA-ES；再看 GP 参与条件协作的增量收益。**没有任何预设赢家，也没有完成 MATLAB 性能实验。**

## 一、比较的五种方法

| 内部方法名 | 描述 | GP 采集评分 | 说明 |
|---|---|---|---|
| `A2` | 级联 GP + CMA-ES | `GCF_chain_eval` | CMA-ES 也独立调参，避免弱基线 |
| `A3_IPPO` | 独立 Critic、独立 Actor 的 IPPO | 同一 `GCF_chain_eval` | 可以看到 GP 前缀预测，行动按前缀顺序生成，获得共同团队奖励；不等于完全无协作 |
| `A4_MAPPO` | 集中式阶段多头 Critic + 稳定 PPO | 同一 `GCF_chain_eval` | 与 IPPO 共享相同 Actor 维度和参数候选网格 |
| `A5_GP_MAPPO` | A4 + GP 条件信息及采样 | 同一 `GCF_chain_eval` | 由 GP 代理把前一 Actor 的输入前缀转为下一 Actor 的加权候选中心、扩散度和下游重要性消息；混合策略概率在 PPO 中正确计算 |
| `V4A_REFERENCE` | 旧版 CoCAQ V4A | **不同**：`GCF_fastgi_eval` | 源码原封不动，仅作研究参考；与 A2-A5 不是同采集函数纯优化器比较 |

这里的 `A5_GP_MAPPO` 是**新的同目标受控 GP 协作版**，并不冒充原 R2 的 `A5` 或旧 `A5GRAD_V4A`，原版本仍保留。

## 二、真正的 GP 协作机制

三个 PPO 算法都按阶段依次形成完整输入 x，且都只使用执行前已经得到的级联 GP 后验。IPPO 和 MAPPO 可以从已选前缀读取上游 GP 均值/方差；MAPPO 用集中式阶段 Critic 学习对后续采集价值的预测。

GP-MAPPO 在第 k 个 Actor 作决定之前，根据它前面所有 Actor **已经选定的当前候选前缀** x_{1:k-1}，在已评分的联合锚点集合上计算：

w_i(x_{1:k-1}) ∝ exp( GP_IVR_suffix(i) / 温度 - prefix_distance(i,x_{1:k-1}) / 带宽 )。

`GP_IVR_suffix(i)` 由当前级联 GP 的 `GCF_chain_eval` 分阶段贡献得到，包含原采集函数已有的终端敏感性近似。条件权重产生候选中心、宽度、下游 GP 价值和前缀影响强度，送入当前 Actor；同一权重也形成显式的条件动作先验。随后 PPO **只对来自实际混合采样分布的动作**使用混合分布概率及比率更新。

前一 Actor 的选择会改变下一 Actor 接收到的 GP 消息；这种内部计算不依赖未观测的真实中间 y。GP 条件信息不同于对真实物理级联进行中途决策。它是一种轻量级、可检验的 GP 中介信息传递，**不是神经网络直接通信，也没有证明其必然优于 IPPO**。

相同 PPO 内核、Actor 输入维度与 300 次完整候选采集函数评分预算保持一致。GP 条件消息/概率密度计算消耗额外 CPU 时间，已记录优化耗时。

## 三、运行（MATLAB R2024a）

请把完整 ZIP 解压到 `C:\MAPPO整合\`，MATLAB 工作目录应是：

`C:\MAPPO整合\CoCAQ_GP_COOP_TUNED_20261106\matlab`

```matlab
cd('C:\MAPPO整合\CoCAQ_GP_COOP_TUNED_20261106\matlab')
clear functions
COCAQ_GP_COOP_RUN('preflight'); % 12 个冻结 MSBO 级联真值及依赖
COCAQ_GP_COOP_RUN('selftest');  % 混合策略概率数值梯度自检
COCAQ_GP_COOP_RUN('smoke');     % 5 方法 x 1 种子 x 2 轮 x 64 评分
COCAQ_GP_COOP_RUN('tune');      % 四方法(含 CMA-ES) x 4 配置 x 2 案例 x 2 种子 x 8 轮
COCAQ_GP_COOP_RUN('eval');      % 5 方法 x 2 案例 x 3 新种子 x 12 轮 x 300 评分
COCAQ_GP_COOP_RUN('report');    % 无需重新训练，汇总已完成结果
```

后续有前景才运行：

```matlab
COCAQ_GP_COOP_RUN('expand');    % 5 方法 x 3 案例 x 4 种子 x 30 轮
```

**注意**：`tune` 可能需要较长运行时间；实验按每轮检查点保存，可以用同一命令继续未完成项。只在全部调参完成时产生 `LOCKED_PARAMS.mat`，之后禁止重复调参；`eval` 必须读取锁定文件。

## 四、调参方式和公平性

四种方法 A2、IPPO、MAPPO、GP-MAPPO **各有四个提前指定的候选配置**，只在训练种子 **14511–14512**、案例 **3S15D + 5S20D**、8 轮预算上选择。CMA 的候选为重启次数、种群尺度和初始步长；PPO 的候选包括网络宽度、批量、更新轮次、学习率、KL 早停、初始方差和轻量熵奖励；GP-MAPPO 的候选另包含 GP 条件先验比例和温度/带宽。

每种方法的最佳配置，仅指**在四个预先列出的候选中**，训练集上最小化 `0.65 × 归一化 AULC + 0.35 × 归一化最终 RMSE` 的配置；**不能称为全局最优**。所有方法的评价种子 **14611–14613** 和实验案例设置在调参前已固定，且不参与参数选择。我们报告全体案例和种子结果，不挑选符合预期的胜者。

原 R2 的冻结调参记录并不完整，所以新版实验不替代 R2 正式基线；本文新调参配置及运行记录全部单独保留。

## 五、结果位置

- `matlab/results/GP_COOP_TUNING/TUNING_GRID_RESULTS.csv`：所有 16 个方法-配置组合在两案例两种子上的调参得分。
- `matlab/results/GP_COOP_TUNING/LOCKED_PARAMS.mat`：四方法的冻结配置，只有 `tune` 全部完成后生成。
- `matlab/results/GP_COOP_reports/EVAL/PAIRED_CASE_COMPARISON.csv`：主要对比。
- `matlab/results/GP_COOP_reports/EVAL/METHOD_MEANS.csv`：五方法平均值。
- `matlab/results/GP_COOP_reports/EVAL/ALL_RUNS.csv`：逐种子 RMSE、AULC、评分预算、搜索时间、PPO 更新数、KL 和 GP 消息指标。
- `matlab/results/GP_COOP_reports/EVAL/ALL_CURVES.csv`：每一真实采样轮 RMSE。

必须优先判断：

1. `A3_IPPO → A4_MAPPO`：集中协作训练是否带来净收益；
2. `A4_MAPPO → A5_GP_MAPPO`：动态 GP 条件消息是否带来净收益；
3. `A2 → A4_MAPPO`、`A2 → A5_GP_MAPPO`：强化搜索器能否超过调参的 CMA-ES；
4. `A5_GP_MAPPO → V4A_REFERENCE`：旧 CoCAQ 完整版本的参考结果，**因采集函数不同，不能单独归因于 PPO**。

期待的排序 `A5_GP_MAPPO < A4_MAPPO < A3_IPPO / A2`（RMSE 越低越好）是明确的研究假设，不是实际实验结论。

## 六、验证状态

已进行静态工程核查及源文件完整性校验；原旧版 `GCF_mappo_v4.m`、`GCF_chain_eval.m`、`GCF_cmaes.m` 未被修改。**环境缺少 MATLAB/Octave，因此本包没有完成 MATLAB smoke 或性能实验，首次运行仍可能暴露兼容性问题。**

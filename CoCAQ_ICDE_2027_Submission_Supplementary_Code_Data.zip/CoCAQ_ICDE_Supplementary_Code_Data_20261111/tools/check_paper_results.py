#!/usr/bin/env python3
"""Read-only verification of the CoCAQ 2027 paper's seven-method result summaries.
Standard-library Python 3; no GP training or label access performed here.
"""
import csv, math, pathlib, statistics, collections
ROOT=pathlib.Path(__file__).resolve().parents[1]
R=ROOT/'results'

def rows(p):
    with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def almost(a,b,tol=1e-8):
    if not math.isclose(a,b,rel_tol=tol,abs_tol=tol):
        raise AssertionError(f'mismatch: {a:.12g} != {b:.12g}')

def uniq(rows, keys):
    out={}
    for row in rows:
        k=tuple(row[x] for x in keys)
        if k in out:raise AssertionError(f'duplicate record {k}')
        out[k]=row
    return out

P=rows(R/'p12/P12_ALPINE_ALL_RUNS.csv')
PA=uniq(P,['Case','Seed','Method'])
A=rows(R/'alpine/ALL_RUNS.csv')
AT=uniq(A,['Case','Seed','Method'])
T=rows(R/'derived/Alpine_SevenMethod_10Seed_Summary.csv')
ALP={}
for p in P:
    k=(p['Case'],p['Seed']); v=float(p['TruthStd'])
    if k in ALP:almost(ALP[k],v)
    ALP[k]=v
assert len({q['Case'] for q in A})==10
assert len(A)==10*10*5 and len(P)==10*10*2
for d in range(2,21,2):
    case=f'BOFN_ALPINE2_{d}S{d}D'
    for m in ['A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_REFERENCE','P1','P2']:
        vals=[]
        for seed in range(16501,16511):
            key=(case,str(seed),m)
            if m in ['P1','P2']:
                pp=PA[key]; v=float(pp['FinalNRMSE'])
            else:
                aa=AT[key]; v=float(aa['FinalRMSE'])/ALP[(case,str(seed))]
            vals.append(v)
        reported=[x for x in T if x['Stages']==str(d) and x['Method']==m]
        assert len(reported)==1 and int(reported[0]['NSeeds'])==10
        almost(statistics.mean(vals),float(reported[0]['MeanFinalNRMSE']))
print('PASS: Alpine 10 tasks x 7 methods x 10 seeds, final mean NRMSE.')

O=rows(R/'opsd/OPSD_FIVE_METHODS_ROUNDS_0_TO_12.csv')
OP=rows(R/'p12/P12_OPSD_ALL_CURVES.csv')
OR=uniq(O,['Method','Seed','Round']); PR=uniq(OP,['Method','Seed','Round'])
OT=rows(R/'derived/OPSD_SevenMethod_R0to12_Summary.csv')
assert len(O)==5*10*13 and len(OP)==2*10*13
for m in ['A2','A3_IPPO','A4_MAPPO','A5_GP_MAPPO','V4A_REFERENCE','P1','P2']:
    finals=[]; auc=[]
    for seed in range(30590,30600):
        traj=[]
        for t in range(13):
            key=(m,str(seed),str(t))
            row = PR[key] if m in ('P1','P2') else OR[key]
            traj.append(float(row['RMSE']))
        finals.append(traj[-1])
        auc.append((0.5*traj[0]+sum(traj[1:-1])+0.5*traj[-1])/12)
    reported=[x for x in OT if x['Method']==m]
    assert len(reported)==1 and int(reported[0]['NSeeds'])==10
    almost(statistics.mean(finals),float(reported[0]['MeanFinalRMSE']))
    almost(statistics.mean(auc),float(reported[0]['MeanAULCRMSE']))
print('PASS: OPSD 7 methods x 10 seeds x rounds 0..12, final RMSE and AULC.')
print('FROZEN RESULTS CHECK PASSED (not an independent MATLAB rerun).')
